
kernel:     file format elf32-i386


Disassembly of section .text:

80100000 <multiboot_header>:
80100000:	02 b0 ad 1b 00 00    	add    0x1bad(%eax),%dh
80100006:	00 00                	add    %al,(%eax)
80100008:	fe 4f 52             	decb   0x52(%edi)
8010000b:	e4                   	.byte 0xe4

8010000c <entry>:

# Entering xv6 on boot processor, with paging off.
.globl entry
entry:
  # Turn on page size extension for 4Mbyte pages
  movl    %cr4, %eax
8010000c:	0f 20 e0             	mov    %cr4,%eax
  orl     $(CR4_PSE), %eax
8010000f:	83 c8 10             	or     $0x10,%eax
  movl    %eax, %cr4
80100012:	0f 22 e0             	mov    %eax,%cr4
  # Set page directory
  movl    $(V2P_WO(entrypgdir)), %eax
80100015:	b8 00 a0 10 00       	mov    $0x10a000,%eax
  movl    %eax, %cr3
8010001a:	0f 22 d8             	mov    %eax,%cr3
  # Turn on paging.
  movl    %cr0, %eax
8010001d:	0f 20 c0             	mov    %cr0,%eax
  orl     $(CR0_PG|CR0_WP), %eax
80100020:	0d 00 00 01 80       	or     $0x80010000,%eax
  movl    %eax, %cr0
80100025:	0f 22 c0             	mov    %eax,%cr0

  # Set up the stack pointer.
  movl $(stack + KSTACKSIZE), %esp
80100028:	bc c0 c5 10 80       	mov    $0x8010c5c0,%esp

  # Jump to main(), and switch to executing at
  # high addresses. The indirect call is needed because
  # the assembler produces a PC-relative instruction
  # for a direct jump.
  mov $main, %eax
8010002d:	b8 20 37 10 80       	mov    $0x80103720,%eax
  jmp *%eax
80100032:	ff e0                	jmp    *%eax
80100034:	66 90                	xchg   %ax,%ax
80100036:	66 90                	xchg   %ax,%ax
80100038:	66 90                	xchg   %ax,%ax
8010003a:	66 90                	xchg   %ax,%ax
8010003c:	66 90                	xchg   %ax,%ax
8010003e:	66 90                	xchg   %ax,%ax

80100040 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
80100040:	55                   	push   %ebp
80100041:	89 e5                	mov    %esp,%ebp
80100043:	53                   	push   %ebx

//PAGEBREAK!
  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
  bcache.head.next = &bcache.head;
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
80100044:	bb f4 c5 10 80       	mov    $0x8010c5f4,%ebx
{
80100049:	83 ec 0c             	sub    $0xc,%esp
  initlock(&bcache.lock, "bcache");
8010004c:	68 80 77 10 80       	push   $0x80107780
80100051:	68 c0 c5 10 80       	push   $0x8010c5c0
80100056:	e8 25 4a 00 00       	call   80104a80 <initlock>
  bcache.head.prev = &bcache.head;
8010005b:	c7 05 0c 0d 11 80 bc 	movl   $0x80110cbc,0x80110d0c
80100062:	0c 11 80 
  bcache.head.next = &bcache.head;
80100065:	c7 05 10 0d 11 80 bc 	movl   $0x80110cbc,0x80110d10
8010006c:	0c 11 80 
8010006f:	83 c4 10             	add    $0x10,%esp
80100072:	ba bc 0c 11 80       	mov    $0x80110cbc,%edx
80100077:	eb 09                	jmp    80100082 <binit+0x42>
80100079:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80100080:	89 c3                	mov    %eax,%ebx
    b->next = bcache.head.next;
    b->prev = &bcache.head;
    initsleeplock(&b->lock, "buffer");
80100082:	8d 43 0c             	lea    0xc(%ebx),%eax
80100085:	83 ec 08             	sub    $0x8,%esp
    b->next = bcache.head.next;
80100088:	89 53 54             	mov    %edx,0x54(%ebx)
    b->prev = &bcache.head;
8010008b:	c7 43 50 bc 0c 11 80 	movl   $0x80110cbc,0x50(%ebx)
    initsleeplock(&b->lock, "buffer");
80100092:	68 87 77 10 80       	push   $0x80107787
80100097:	50                   	push   %eax
80100098:	e8 b3 48 00 00       	call   80104950 <initsleeplock>
    bcache.head.next->prev = b;
8010009d:	a1 10 0d 11 80       	mov    0x80110d10,%eax
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
801000a2:	83 c4 10             	add    $0x10,%esp
801000a5:	89 da                	mov    %ebx,%edx
    bcache.head.next->prev = b;
801000a7:	89 58 50             	mov    %ebx,0x50(%eax)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
801000aa:	8d 83 5c 02 00 00    	lea    0x25c(%ebx),%eax
    bcache.head.next = b;
801000b0:	89 1d 10 0d 11 80    	mov    %ebx,0x80110d10
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
801000b6:	3d bc 0c 11 80       	cmp    $0x80110cbc,%eax
801000bb:	72 c3                	jb     80100080 <binit+0x40>
  }
}
801000bd:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801000c0:	c9                   	leave  
801000c1:	c3                   	ret    
801000c2:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801000c9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

801000d0 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
801000d0:	55                   	push   %ebp
801000d1:	89 e5                	mov    %esp,%ebp
801000d3:	57                   	push   %edi
801000d4:	56                   	push   %esi
801000d5:	53                   	push   %ebx
801000d6:	83 ec 18             	sub    $0x18,%esp
801000d9:	8b 75 08             	mov    0x8(%ebp),%esi
801000dc:	8b 7d 0c             	mov    0xc(%ebp),%edi
  acquire(&bcache.lock);
801000df:	68 c0 c5 10 80       	push   $0x8010c5c0
801000e4:	e8 d7 4a 00 00       	call   80104bc0 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
801000e9:	8b 1d 10 0d 11 80    	mov    0x80110d10,%ebx
801000ef:	83 c4 10             	add    $0x10,%esp
801000f2:	81 fb bc 0c 11 80    	cmp    $0x80110cbc,%ebx
801000f8:	75 11                	jne    8010010b <bread+0x3b>
801000fa:	eb 24                	jmp    80100120 <bread+0x50>
801000fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100100:	8b 5b 54             	mov    0x54(%ebx),%ebx
80100103:	81 fb bc 0c 11 80    	cmp    $0x80110cbc,%ebx
80100109:	74 15                	je     80100120 <bread+0x50>
    if(b->dev == dev && b->blockno == blockno){
8010010b:	3b 73 04             	cmp    0x4(%ebx),%esi
8010010e:	75 f0                	jne    80100100 <bread+0x30>
80100110:	3b 7b 08             	cmp    0x8(%ebx),%edi
80100113:	75 eb                	jne    80100100 <bread+0x30>
      b->refcnt++;
80100115:	83 43 4c 01          	addl   $0x1,0x4c(%ebx)
80100119:	eb 3f                	jmp    8010015a <bread+0x8a>
8010011b:	90                   	nop
8010011c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
80100120:	8b 1d 0c 0d 11 80    	mov    0x80110d0c,%ebx
80100126:	81 fb bc 0c 11 80    	cmp    $0x80110cbc,%ebx
8010012c:	75 0d                	jne    8010013b <bread+0x6b>
8010012e:	eb 60                	jmp    80100190 <bread+0xc0>
80100130:	8b 5b 50             	mov    0x50(%ebx),%ebx
80100133:	81 fb bc 0c 11 80    	cmp    $0x80110cbc,%ebx
80100139:	74 55                	je     80100190 <bread+0xc0>
    if(b->refcnt == 0 && (b->flags & B_DIRTY) == 0) {
8010013b:	8b 43 4c             	mov    0x4c(%ebx),%eax
8010013e:	85 c0                	test   %eax,%eax
80100140:	75 ee                	jne    80100130 <bread+0x60>
80100142:	f6 03 04             	testb  $0x4,(%ebx)
80100145:	75 e9                	jne    80100130 <bread+0x60>
      b->dev = dev;
80100147:	89 73 04             	mov    %esi,0x4(%ebx)
      b->blockno = blockno;
8010014a:	89 7b 08             	mov    %edi,0x8(%ebx)
      b->flags = 0;
8010014d:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
      b->refcnt = 1;
80100153:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
      release(&bcache.lock);
8010015a:	83 ec 0c             	sub    $0xc,%esp
8010015d:	68 c0 c5 10 80       	push   $0x8010c5c0
80100162:	e8 19 4b 00 00       	call   80104c80 <release>
      acquiresleep(&b->lock);
80100167:	8d 43 0c             	lea    0xc(%ebx),%eax
8010016a:	89 04 24             	mov    %eax,(%esp)
8010016d:	e8 1e 48 00 00       	call   80104990 <acquiresleep>
80100172:	83 c4 10             	add    $0x10,%esp
  struct buf *b;

  b = bget(dev, blockno);
  if((b->flags & B_VALID) == 0) {
80100175:	f6 03 02             	testb  $0x2,(%ebx)
80100178:	75 0c                	jne    80100186 <bread+0xb6>
    iderw(b);
8010017a:	83 ec 0c             	sub    $0xc,%esp
8010017d:	53                   	push   %ebx
8010017e:	e8 1d 28 00 00       	call   801029a0 <iderw>
80100183:	83 c4 10             	add    $0x10,%esp
  }
  return b;
}
80100186:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100189:	89 d8                	mov    %ebx,%eax
8010018b:	5b                   	pop    %ebx
8010018c:	5e                   	pop    %esi
8010018d:	5f                   	pop    %edi
8010018e:	5d                   	pop    %ebp
8010018f:	c3                   	ret    
  panic("bget: no buffers");
80100190:	83 ec 0c             	sub    $0xc,%esp
80100193:	68 8e 77 10 80       	push   $0x8010778e
80100198:	e8 f3 01 00 00       	call   80100390 <panic>
8010019d:	8d 76 00             	lea    0x0(%esi),%esi

801001a0 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
801001a0:	55                   	push   %ebp
801001a1:	89 e5                	mov    %esp,%ebp
801001a3:	53                   	push   %ebx
801001a4:	83 ec 10             	sub    $0x10,%esp
801001a7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holdingsleep(&b->lock))
801001aa:	8d 43 0c             	lea    0xc(%ebx),%eax
801001ad:	50                   	push   %eax
801001ae:	e8 7d 48 00 00       	call   80104a30 <holdingsleep>
801001b3:	83 c4 10             	add    $0x10,%esp
801001b6:	85 c0                	test   %eax,%eax
801001b8:	74 0f                	je     801001c9 <bwrite+0x29>
    panic("bwrite");
  b->flags |= B_DIRTY;
801001ba:	83 0b 04             	orl    $0x4,(%ebx)
  iderw(b);
801001bd:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
801001c0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801001c3:	c9                   	leave  
  iderw(b);
801001c4:	e9 d7 27 00 00       	jmp    801029a0 <iderw>
    panic("bwrite");
801001c9:	83 ec 0c             	sub    $0xc,%esp
801001cc:	68 9f 77 10 80       	push   $0x8010779f
801001d1:	e8 ba 01 00 00       	call   80100390 <panic>
801001d6:	8d 76 00             	lea    0x0(%esi),%esi
801001d9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

801001e0 <brelse>:

// Release a locked buffer.
// Move to the head of the MRU list.
void
brelse(struct buf *b)
{
801001e0:	55                   	push   %ebp
801001e1:	89 e5                	mov    %esp,%ebp
801001e3:	56                   	push   %esi
801001e4:	53                   	push   %ebx
801001e5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holdingsleep(&b->lock))
801001e8:	83 ec 0c             	sub    $0xc,%esp
801001eb:	8d 73 0c             	lea    0xc(%ebx),%esi
801001ee:	56                   	push   %esi
801001ef:	e8 3c 48 00 00       	call   80104a30 <holdingsleep>
801001f4:	83 c4 10             	add    $0x10,%esp
801001f7:	85 c0                	test   %eax,%eax
801001f9:	74 66                	je     80100261 <brelse+0x81>
    panic("brelse");

  releasesleep(&b->lock);
801001fb:	83 ec 0c             	sub    $0xc,%esp
801001fe:	56                   	push   %esi
801001ff:	e8 ec 47 00 00       	call   801049f0 <releasesleep>

  acquire(&bcache.lock);
80100204:	c7 04 24 c0 c5 10 80 	movl   $0x8010c5c0,(%esp)
8010020b:	e8 b0 49 00 00       	call   80104bc0 <acquire>
  b->refcnt--;
80100210:	8b 43 4c             	mov    0x4c(%ebx),%eax
  if (b->refcnt == 0) {
80100213:	83 c4 10             	add    $0x10,%esp
  b->refcnt--;
80100216:	83 e8 01             	sub    $0x1,%eax
  if (b->refcnt == 0) {
80100219:	85 c0                	test   %eax,%eax
  b->refcnt--;
8010021b:	89 43 4c             	mov    %eax,0x4c(%ebx)
  if (b->refcnt == 0) {
8010021e:	75 2f                	jne    8010024f <brelse+0x6f>
    // no one is waiting for it.
    b->next->prev = b->prev;
80100220:	8b 43 54             	mov    0x54(%ebx),%eax
80100223:	8b 53 50             	mov    0x50(%ebx),%edx
80100226:	89 50 50             	mov    %edx,0x50(%eax)
    b->prev->next = b->next;
80100229:	8b 43 50             	mov    0x50(%ebx),%eax
8010022c:	8b 53 54             	mov    0x54(%ebx),%edx
8010022f:	89 50 54             	mov    %edx,0x54(%eax)
    b->next = bcache.head.next;
80100232:	a1 10 0d 11 80       	mov    0x80110d10,%eax
    b->prev = &bcache.head;
80100237:	c7 43 50 bc 0c 11 80 	movl   $0x80110cbc,0x50(%ebx)
    b->next = bcache.head.next;
8010023e:	89 43 54             	mov    %eax,0x54(%ebx)
    bcache.head.next->prev = b;
80100241:	a1 10 0d 11 80       	mov    0x80110d10,%eax
80100246:	89 58 50             	mov    %ebx,0x50(%eax)
    bcache.head.next = b;
80100249:	89 1d 10 0d 11 80    	mov    %ebx,0x80110d10
  }
  
  release(&bcache.lock);
8010024f:	c7 45 08 c0 c5 10 80 	movl   $0x8010c5c0,0x8(%ebp)
}
80100256:	8d 65 f8             	lea    -0x8(%ebp),%esp
80100259:	5b                   	pop    %ebx
8010025a:	5e                   	pop    %esi
8010025b:	5d                   	pop    %ebp
  release(&bcache.lock);
8010025c:	e9 1f 4a 00 00       	jmp    80104c80 <release>
    panic("brelse");
80100261:	83 ec 0c             	sub    $0xc,%esp
80100264:	68 a6 77 10 80       	push   $0x801077a6
80100269:	e8 22 01 00 00       	call   80100390 <panic>
8010026e:	66 90                	xchg   %ax,%ax

80100270 <consoleread>:
  }
}

int
consoleread(struct inode *ip, char *dst, int n)
{
80100270:	55                   	push   %ebp
80100271:	89 e5                	mov    %esp,%ebp
80100273:	57                   	push   %edi
80100274:	56                   	push   %esi
80100275:	53                   	push   %ebx
80100276:	83 ec 28             	sub    $0x28,%esp
80100279:	8b 7d 08             	mov    0x8(%ebp),%edi
8010027c:	8b 75 0c             	mov    0xc(%ebp),%esi
  uint target;
  int c;

  iunlock(ip);
8010027f:	57                   	push   %edi
80100280:	e8 bb 16 00 00       	call   80101940 <iunlock>
  target = n;
  acquire(&cons.lock);
80100285:	c7 04 24 20 b5 10 80 	movl   $0x8010b520,(%esp)
8010028c:	e8 2f 49 00 00       	call   80104bc0 <acquire>
  while(n > 0){
80100291:	8b 5d 10             	mov    0x10(%ebp),%ebx
80100294:	83 c4 10             	add    $0x10,%esp
80100297:	31 c0                	xor    %eax,%eax
80100299:	85 db                	test   %ebx,%ebx
8010029b:	0f 8e a1 00 00 00    	jle    80100342 <consoleread+0xd2>
    while(input.r == input.w){
801002a1:	8b 15 a0 0f 11 80    	mov    0x80110fa0,%edx
801002a7:	39 15 a4 0f 11 80    	cmp    %edx,0x80110fa4
801002ad:	74 2c                	je     801002db <consoleread+0x6b>
801002af:	eb 5f                	jmp    80100310 <consoleread+0xa0>
801002b1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      if(myproc()->killed){
        release(&cons.lock);
        ilock(ip);
        return -1;
      }
      sleep(&input.r, &cons.lock);
801002b8:	83 ec 08             	sub    $0x8,%esp
801002bb:	68 20 b5 10 80       	push   $0x8010b520
801002c0:	68 a0 0f 11 80       	push   $0x80110fa0
801002c5:	e8 36 43 00 00       	call   80104600 <sleep>
    while(input.r == input.w){
801002ca:	8b 15 a0 0f 11 80    	mov    0x80110fa0,%edx
801002d0:	83 c4 10             	add    $0x10,%esp
801002d3:	3b 15 a4 0f 11 80    	cmp    0x80110fa4,%edx
801002d9:	75 35                	jne    80100310 <consoleread+0xa0>
      if(myproc()->killed){
801002db:	e8 80 3d 00 00       	call   80104060 <myproc>
801002e0:	8b 40 24             	mov    0x24(%eax),%eax
801002e3:	85 c0                	test   %eax,%eax
801002e5:	74 d1                	je     801002b8 <consoleread+0x48>
        release(&cons.lock);
801002e7:	83 ec 0c             	sub    $0xc,%esp
801002ea:	68 20 b5 10 80       	push   $0x8010b520
801002ef:	e8 8c 49 00 00       	call   80104c80 <release>
        ilock(ip);
801002f4:	89 3c 24             	mov    %edi,(%esp)
801002f7:	e8 64 15 00 00       	call   80101860 <ilock>
        return -1;
801002fc:	83 c4 10             	add    $0x10,%esp
  }
  release(&cons.lock);
  ilock(ip);

  return target - n;
}
801002ff:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return -1;
80100302:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80100307:	5b                   	pop    %ebx
80100308:	5e                   	pop    %esi
80100309:	5f                   	pop    %edi
8010030a:	5d                   	pop    %ebp
8010030b:	c3                   	ret    
8010030c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    c = input.buf[input.r++ % INPUT_BUF];
80100310:	8d 42 01             	lea    0x1(%edx),%eax
80100313:	a3 a0 0f 11 80       	mov    %eax,0x80110fa0
80100318:	89 d0                	mov    %edx,%eax
8010031a:	83 e0 7f             	and    $0x7f,%eax
8010031d:	0f be 80 20 0f 11 80 	movsbl -0x7feef0e0(%eax),%eax
    if(c == C('D')){  // EOF
80100324:	83 f8 04             	cmp    $0x4,%eax
80100327:	74 3f                	je     80100368 <consoleread+0xf8>
    *dst++ = c;
80100329:	83 c6 01             	add    $0x1,%esi
    --n;
8010032c:	83 eb 01             	sub    $0x1,%ebx
    if(c == '\n')
8010032f:	83 f8 0a             	cmp    $0xa,%eax
    *dst++ = c;
80100332:	88 46 ff             	mov    %al,-0x1(%esi)
    if(c == '\n')
80100335:	74 43                	je     8010037a <consoleread+0x10a>
  while(n > 0){
80100337:	85 db                	test   %ebx,%ebx
80100339:	0f 85 62 ff ff ff    	jne    801002a1 <consoleread+0x31>
8010033f:	8b 45 10             	mov    0x10(%ebp),%eax
  release(&cons.lock);
80100342:	83 ec 0c             	sub    $0xc,%esp
80100345:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80100348:	68 20 b5 10 80       	push   $0x8010b520
8010034d:	e8 2e 49 00 00       	call   80104c80 <release>
  ilock(ip);
80100352:	89 3c 24             	mov    %edi,(%esp)
80100355:	e8 06 15 00 00       	call   80101860 <ilock>
  return target - n;
8010035a:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010035d:	83 c4 10             	add    $0x10,%esp
}
80100360:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100363:	5b                   	pop    %ebx
80100364:	5e                   	pop    %esi
80100365:	5f                   	pop    %edi
80100366:	5d                   	pop    %ebp
80100367:	c3                   	ret    
80100368:	8b 45 10             	mov    0x10(%ebp),%eax
8010036b:	29 d8                	sub    %ebx,%eax
      if(n < target){
8010036d:	3b 5d 10             	cmp    0x10(%ebp),%ebx
80100370:	73 d0                	jae    80100342 <consoleread+0xd2>
        input.r--;
80100372:	89 15 a0 0f 11 80    	mov    %edx,0x80110fa0
80100378:	eb c8                	jmp    80100342 <consoleread+0xd2>
8010037a:	8b 45 10             	mov    0x10(%ebp),%eax
8010037d:	29 d8                	sub    %ebx,%eax
8010037f:	eb c1                	jmp    80100342 <consoleread+0xd2>
80100381:	eb 0d                	jmp    80100390 <panic>
80100383:	90                   	nop
80100384:	90                   	nop
80100385:	90                   	nop
80100386:	90                   	nop
80100387:	90                   	nop
80100388:	90                   	nop
80100389:	90                   	nop
8010038a:	90                   	nop
8010038b:	90                   	nop
8010038c:	90                   	nop
8010038d:	90                   	nop
8010038e:	90                   	nop
8010038f:	90                   	nop

80100390 <panic>:
{
80100390:	55                   	push   %ebp
80100391:	89 e5                	mov    %esp,%ebp
80100393:	56                   	push   %esi
80100394:	53                   	push   %ebx
80100395:	83 ec 30             	sub    $0x30,%esp
}

static inline void
cli(void)
{
  asm volatile("cli");
80100398:	fa                   	cli    
  cons.locking = 0;
80100399:	c7 05 54 b5 10 80 00 	movl   $0x0,0x8010b554
801003a0:	00 00 00 
  getcallerpcs(&s, pcs);
801003a3:	8d 5d d0             	lea    -0x30(%ebp),%ebx
801003a6:	8d 75 f8             	lea    -0x8(%ebp),%esi
  cprintf("lapicid %d: panic: ", lapicid());
801003a9:	e8 02 2c 00 00       	call   80102fb0 <lapicid>
801003ae:	83 ec 08             	sub    $0x8,%esp
801003b1:	50                   	push   %eax
801003b2:	68 ad 77 10 80       	push   $0x801077ad
801003b7:	e8 a4 02 00 00       	call   80100660 <cprintf>
  cprintf(s);
801003bc:	58                   	pop    %eax
801003bd:	ff 75 08             	pushl  0x8(%ebp)
801003c0:	e8 9b 02 00 00       	call   80100660 <cprintf>
  cprintf("\n");
801003c5:	c7 04 24 db 81 10 80 	movl   $0x801081db,(%esp)
801003cc:	e8 8f 02 00 00       	call   80100660 <cprintf>
  getcallerpcs(&s, pcs);
801003d1:	5a                   	pop    %edx
801003d2:	8d 45 08             	lea    0x8(%ebp),%eax
801003d5:	59                   	pop    %ecx
801003d6:	53                   	push   %ebx
801003d7:	50                   	push   %eax
801003d8:	e8 c3 46 00 00       	call   80104aa0 <getcallerpcs>
801003dd:	83 c4 10             	add    $0x10,%esp
    cprintf(" %p", pcs[i]);
801003e0:	83 ec 08             	sub    $0x8,%esp
801003e3:	ff 33                	pushl  (%ebx)
801003e5:	83 c3 04             	add    $0x4,%ebx
801003e8:	68 c1 77 10 80       	push   $0x801077c1
801003ed:	e8 6e 02 00 00       	call   80100660 <cprintf>
  for(i=0; i<10; i++)
801003f2:	83 c4 10             	add    $0x10,%esp
801003f5:	39 f3                	cmp    %esi,%ebx
801003f7:	75 e7                	jne    801003e0 <panic+0x50>
  panicked = 1; // freeze other CPU
801003f9:	c7 05 58 b5 10 80 01 	movl   $0x1,0x8010b558
80100400:	00 00 00 
80100403:	eb fe                	jmp    80100403 <panic+0x73>
80100405:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100409:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80100410 <consputc>:
  if(panicked){
80100410:	8b 0d 58 b5 10 80    	mov    0x8010b558,%ecx
80100416:	85 c9                	test   %ecx,%ecx
80100418:	74 06                	je     80100420 <consputc+0x10>
8010041a:	fa                   	cli    
8010041b:	eb fe                	jmp    8010041b <consputc+0xb>
8010041d:	8d 76 00             	lea    0x0(%esi),%esi
{
80100420:	55                   	push   %ebp
80100421:	89 e5                	mov    %esp,%ebp
80100423:	57                   	push   %edi
80100424:	56                   	push   %esi
80100425:	53                   	push   %ebx
80100426:	89 c6                	mov    %eax,%esi
80100428:	83 ec 0c             	sub    $0xc,%esp
  if(c == BACKSPACE){
8010042b:	3d 00 01 00 00       	cmp    $0x100,%eax
80100430:	0f 84 b1 00 00 00    	je     801004e7 <consputc+0xd7>
    uartputc(c);
80100436:	83 ec 0c             	sub    $0xc,%esp
80100439:	50                   	push   %eax
8010043a:	e8 51 5f 00 00       	call   80106390 <uartputc>
8010043f:	83 c4 10             	add    $0x10,%esp
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80100442:	bb d4 03 00 00       	mov    $0x3d4,%ebx
80100447:	b8 0e 00 00 00       	mov    $0xe,%eax
8010044c:	89 da                	mov    %ebx,%edx
8010044e:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010044f:	b9 d5 03 00 00       	mov    $0x3d5,%ecx
80100454:	89 ca                	mov    %ecx,%edx
80100456:	ec                   	in     (%dx),%al
  pos = inb(CRTPORT+1) << 8;
80100457:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010045a:	89 da                	mov    %ebx,%edx
8010045c:	c1 e0 08             	shl    $0x8,%eax
8010045f:	89 c7                	mov    %eax,%edi
80100461:	b8 0f 00 00 00       	mov    $0xf,%eax
80100466:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80100467:	89 ca                	mov    %ecx,%edx
80100469:	ec                   	in     (%dx),%al
8010046a:	0f b6 d8             	movzbl %al,%ebx
  pos |= inb(CRTPORT+1);
8010046d:	09 fb                	or     %edi,%ebx
  if(c == '\n')
8010046f:	83 fe 0a             	cmp    $0xa,%esi
80100472:	0f 84 f3 00 00 00    	je     8010056b <consputc+0x15b>
  else if(c == BACKSPACE){
80100478:	81 fe 00 01 00 00    	cmp    $0x100,%esi
8010047e:	0f 84 d7 00 00 00    	je     8010055b <consputc+0x14b>
    crt[pos++] = (c&0xff) | 0x0700;  // black on white
80100484:	89 f0                	mov    %esi,%eax
80100486:	0f b6 c0             	movzbl %al,%eax
80100489:	80 cc 07             	or     $0x7,%ah
8010048c:	66 89 84 1b 00 80 0b 	mov    %ax,-0x7ff48000(%ebx,%ebx,1)
80100493:	80 
80100494:	83 c3 01             	add    $0x1,%ebx
  if(pos < 0 || pos > 25*80)
80100497:	81 fb d0 07 00 00    	cmp    $0x7d0,%ebx
8010049d:	0f 8f ab 00 00 00    	jg     8010054e <consputc+0x13e>
  if((pos/80) >= 24){  // Scroll up.
801004a3:	81 fb 7f 07 00 00    	cmp    $0x77f,%ebx
801004a9:	7f 66                	jg     80100511 <consputc+0x101>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801004ab:	be d4 03 00 00       	mov    $0x3d4,%esi
801004b0:	b8 0e 00 00 00       	mov    $0xe,%eax
801004b5:	89 f2                	mov    %esi,%edx
801004b7:	ee                   	out    %al,(%dx)
801004b8:	b9 d5 03 00 00       	mov    $0x3d5,%ecx
  outb(CRTPORT+1, pos>>8);
801004bd:	89 d8                	mov    %ebx,%eax
801004bf:	c1 f8 08             	sar    $0x8,%eax
801004c2:	89 ca                	mov    %ecx,%edx
801004c4:	ee                   	out    %al,(%dx)
801004c5:	b8 0f 00 00 00       	mov    $0xf,%eax
801004ca:	89 f2                	mov    %esi,%edx
801004cc:	ee                   	out    %al,(%dx)
801004cd:	89 d8                	mov    %ebx,%eax
801004cf:	89 ca                	mov    %ecx,%edx
801004d1:	ee                   	out    %al,(%dx)
  crt[pos] = ' ' | 0x0700;
801004d2:	b8 20 07 00 00       	mov    $0x720,%eax
801004d7:	66 89 84 1b 00 80 0b 	mov    %ax,-0x7ff48000(%ebx,%ebx,1)
801004de:	80 
}
801004df:	8d 65 f4             	lea    -0xc(%ebp),%esp
801004e2:	5b                   	pop    %ebx
801004e3:	5e                   	pop    %esi
801004e4:	5f                   	pop    %edi
801004e5:	5d                   	pop    %ebp
801004e6:	c3                   	ret    
    uartputc('\b'); uartputc(' '); uartputc('\b');
801004e7:	83 ec 0c             	sub    $0xc,%esp
801004ea:	6a 08                	push   $0x8
801004ec:	e8 9f 5e 00 00       	call   80106390 <uartputc>
801004f1:	c7 04 24 20 00 00 00 	movl   $0x20,(%esp)
801004f8:	e8 93 5e 00 00       	call   80106390 <uartputc>
801004fd:	c7 04 24 08 00 00 00 	movl   $0x8,(%esp)
80100504:	e8 87 5e 00 00       	call   80106390 <uartputc>
80100509:	83 c4 10             	add    $0x10,%esp
8010050c:	e9 31 ff ff ff       	jmp    80100442 <consputc+0x32>
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
80100511:	52                   	push   %edx
80100512:	68 60 0e 00 00       	push   $0xe60
    pos -= 80;
80100517:	83 eb 50             	sub    $0x50,%ebx
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
8010051a:	68 a0 80 0b 80       	push   $0x800b80a0
8010051f:	68 00 80 0b 80       	push   $0x800b8000
80100524:	e8 57 48 00 00       	call   80104d80 <memmove>
    memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
80100529:	b8 80 07 00 00       	mov    $0x780,%eax
8010052e:	83 c4 0c             	add    $0xc,%esp
80100531:	29 d8                	sub    %ebx,%eax
80100533:	01 c0                	add    %eax,%eax
80100535:	50                   	push   %eax
80100536:	8d 04 1b             	lea    (%ebx,%ebx,1),%eax
80100539:	6a 00                	push   $0x0
8010053b:	2d 00 80 f4 7f       	sub    $0x7ff48000,%eax
80100540:	50                   	push   %eax
80100541:	e8 8a 47 00 00       	call   80104cd0 <memset>
80100546:	83 c4 10             	add    $0x10,%esp
80100549:	e9 5d ff ff ff       	jmp    801004ab <consputc+0x9b>
    panic("pos under/overflow");
8010054e:	83 ec 0c             	sub    $0xc,%esp
80100551:	68 c5 77 10 80       	push   $0x801077c5
80100556:	e8 35 fe ff ff       	call   80100390 <panic>
    if(pos > 0) --pos;
8010055b:	85 db                	test   %ebx,%ebx
8010055d:	0f 84 48 ff ff ff    	je     801004ab <consputc+0x9b>
80100563:	83 eb 01             	sub    $0x1,%ebx
80100566:	e9 2c ff ff ff       	jmp    80100497 <consputc+0x87>
    pos += 80 - pos%80;
8010056b:	89 d8                	mov    %ebx,%eax
8010056d:	b9 50 00 00 00       	mov    $0x50,%ecx
80100572:	99                   	cltd   
80100573:	f7 f9                	idiv   %ecx
80100575:	29 d1                	sub    %edx,%ecx
80100577:	01 cb                	add    %ecx,%ebx
80100579:	e9 19 ff ff ff       	jmp    80100497 <consputc+0x87>
8010057e:	66 90                	xchg   %ax,%ax

80100580 <printint>:
{
80100580:	55                   	push   %ebp
80100581:	89 e5                	mov    %esp,%ebp
80100583:	57                   	push   %edi
80100584:	56                   	push   %esi
80100585:	53                   	push   %ebx
80100586:	89 d3                	mov    %edx,%ebx
80100588:	83 ec 2c             	sub    $0x2c,%esp
  if(sign && (sign = xx < 0))
8010058b:	85 c9                	test   %ecx,%ecx
{
8010058d:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
  if(sign && (sign = xx < 0))
80100590:	74 04                	je     80100596 <printint+0x16>
80100592:	85 c0                	test   %eax,%eax
80100594:	78 5a                	js     801005f0 <printint+0x70>
    x = xx;
80100596:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%ebp)
  i = 0;
8010059d:	31 c9                	xor    %ecx,%ecx
8010059f:	8d 75 d7             	lea    -0x29(%ebp),%esi
801005a2:	eb 06                	jmp    801005aa <printint+0x2a>
801005a4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    buf[i++] = digits[x % base];
801005a8:	89 f9                	mov    %edi,%ecx
801005aa:	31 d2                	xor    %edx,%edx
801005ac:	8d 79 01             	lea    0x1(%ecx),%edi
801005af:	f7 f3                	div    %ebx
801005b1:	0f b6 92 f0 77 10 80 	movzbl -0x7fef8810(%edx),%edx
  }while((x /= base) != 0);
801005b8:	85 c0                	test   %eax,%eax
    buf[i++] = digits[x % base];
801005ba:	88 14 3e             	mov    %dl,(%esi,%edi,1)
  }while((x /= base) != 0);
801005bd:	75 e9                	jne    801005a8 <printint+0x28>
  if(sign)
801005bf:	8b 45 d4             	mov    -0x2c(%ebp),%eax
801005c2:	85 c0                	test   %eax,%eax
801005c4:	74 08                	je     801005ce <printint+0x4e>
    buf[i++] = '-';
801005c6:	c6 44 3d d8 2d       	movb   $0x2d,-0x28(%ebp,%edi,1)
801005cb:	8d 79 02             	lea    0x2(%ecx),%edi
801005ce:	8d 5c 3d d7          	lea    -0x29(%ebp,%edi,1),%ebx
801005d2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    consputc(buf[i]);
801005d8:	0f be 03             	movsbl (%ebx),%eax
801005db:	83 eb 01             	sub    $0x1,%ebx
801005de:	e8 2d fe ff ff       	call   80100410 <consputc>
  while(--i >= 0)
801005e3:	39 f3                	cmp    %esi,%ebx
801005e5:	75 f1                	jne    801005d8 <printint+0x58>
}
801005e7:	83 c4 2c             	add    $0x2c,%esp
801005ea:	5b                   	pop    %ebx
801005eb:	5e                   	pop    %esi
801005ec:	5f                   	pop    %edi
801005ed:	5d                   	pop    %ebp
801005ee:	c3                   	ret    
801005ef:	90                   	nop
    x = -xx;
801005f0:	f7 d8                	neg    %eax
801005f2:	eb a9                	jmp    8010059d <printint+0x1d>
801005f4:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801005fa:	8d bf 00 00 00 00    	lea    0x0(%edi),%edi

80100600 <consolewrite>:

int
consolewrite(struct inode *ip, char *buf, int n)
{
80100600:	55                   	push   %ebp
80100601:	89 e5                	mov    %esp,%ebp
80100603:	57                   	push   %edi
80100604:	56                   	push   %esi
80100605:	53                   	push   %ebx
80100606:	83 ec 18             	sub    $0x18,%esp
80100609:	8b 75 10             	mov    0x10(%ebp),%esi
  int i;

  iunlock(ip);
8010060c:	ff 75 08             	pushl  0x8(%ebp)
8010060f:	e8 2c 13 00 00       	call   80101940 <iunlock>
  acquire(&cons.lock);
80100614:	c7 04 24 20 b5 10 80 	movl   $0x8010b520,(%esp)
8010061b:	e8 a0 45 00 00       	call   80104bc0 <acquire>
  for(i = 0; i < n; i++)
80100620:	83 c4 10             	add    $0x10,%esp
80100623:	85 f6                	test   %esi,%esi
80100625:	7e 18                	jle    8010063f <consolewrite+0x3f>
80100627:	8b 7d 0c             	mov    0xc(%ebp),%edi
8010062a:	8d 1c 37             	lea    (%edi,%esi,1),%ebx
8010062d:	8d 76 00             	lea    0x0(%esi),%esi
    consputc(buf[i] & 0xff);
80100630:	0f b6 07             	movzbl (%edi),%eax
80100633:	83 c7 01             	add    $0x1,%edi
80100636:	e8 d5 fd ff ff       	call   80100410 <consputc>
  for(i = 0; i < n; i++)
8010063b:	39 fb                	cmp    %edi,%ebx
8010063d:	75 f1                	jne    80100630 <consolewrite+0x30>
  release(&cons.lock);
8010063f:	83 ec 0c             	sub    $0xc,%esp
80100642:	68 20 b5 10 80       	push   $0x8010b520
80100647:	e8 34 46 00 00       	call   80104c80 <release>
  ilock(ip);
8010064c:	58                   	pop    %eax
8010064d:	ff 75 08             	pushl  0x8(%ebp)
80100650:	e8 0b 12 00 00       	call   80101860 <ilock>

  return n;
}
80100655:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100658:	89 f0                	mov    %esi,%eax
8010065a:	5b                   	pop    %ebx
8010065b:	5e                   	pop    %esi
8010065c:	5f                   	pop    %edi
8010065d:	5d                   	pop    %ebp
8010065e:	c3                   	ret    
8010065f:	90                   	nop

80100660 <cprintf>:
{
80100660:	55                   	push   %ebp
80100661:	89 e5                	mov    %esp,%ebp
80100663:	57                   	push   %edi
80100664:	56                   	push   %esi
80100665:	53                   	push   %ebx
80100666:	83 ec 1c             	sub    $0x1c,%esp
  locking = cons.locking;
80100669:	a1 54 b5 10 80       	mov    0x8010b554,%eax
  if(locking)
8010066e:	85 c0                	test   %eax,%eax
  locking = cons.locking;
80100670:	89 45 dc             	mov    %eax,-0x24(%ebp)
  if(locking)
80100673:	0f 85 6f 01 00 00    	jne    801007e8 <cprintf+0x188>
  if (fmt == 0)
80100679:	8b 45 08             	mov    0x8(%ebp),%eax
8010067c:	85 c0                	test   %eax,%eax
8010067e:	89 c7                	mov    %eax,%edi
80100680:	0f 84 77 01 00 00    	je     801007fd <cprintf+0x19d>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
80100686:	0f b6 00             	movzbl (%eax),%eax
  argp = (uint*)(void*)(&fmt + 1);
80100689:	8d 4d 0c             	lea    0xc(%ebp),%ecx
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
8010068c:	31 db                	xor    %ebx,%ebx
  argp = (uint*)(void*)(&fmt + 1);
8010068e:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
80100691:	85 c0                	test   %eax,%eax
80100693:	75 56                	jne    801006eb <cprintf+0x8b>
80100695:	eb 79                	jmp    80100710 <cprintf+0xb0>
80100697:	89 f6                	mov    %esi,%esi
80100699:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    c = fmt[++i] & 0xff;
801006a0:	0f b6 16             	movzbl (%esi),%edx
    if(c == 0)
801006a3:	85 d2                	test   %edx,%edx
801006a5:	74 69                	je     80100710 <cprintf+0xb0>
801006a7:	83 c3 02             	add    $0x2,%ebx
    switch(c){
801006aa:	83 fa 70             	cmp    $0x70,%edx
801006ad:	8d 34 1f             	lea    (%edi,%ebx,1),%esi
801006b0:	0f 84 84 00 00 00    	je     8010073a <cprintf+0xda>
801006b6:	7f 78                	jg     80100730 <cprintf+0xd0>
801006b8:	83 fa 25             	cmp    $0x25,%edx
801006bb:	0f 84 ff 00 00 00    	je     801007c0 <cprintf+0x160>
801006c1:	83 fa 64             	cmp    $0x64,%edx
801006c4:	0f 85 8e 00 00 00    	jne    80100758 <cprintf+0xf8>
      printint(*argp++, 10, 1);
801006ca:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801006cd:	ba 0a 00 00 00       	mov    $0xa,%edx
801006d2:	8d 48 04             	lea    0x4(%eax),%ecx
801006d5:	8b 00                	mov    (%eax),%eax
801006d7:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
801006da:	b9 01 00 00 00       	mov    $0x1,%ecx
801006df:	e8 9c fe ff ff       	call   80100580 <printint>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
801006e4:	0f b6 06             	movzbl (%esi),%eax
801006e7:	85 c0                	test   %eax,%eax
801006e9:	74 25                	je     80100710 <cprintf+0xb0>
801006eb:	8d 53 01             	lea    0x1(%ebx),%edx
    if(c != '%'){
801006ee:	83 f8 25             	cmp    $0x25,%eax
801006f1:	8d 34 17             	lea    (%edi,%edx,1),%esi
801006f4:	74 aa                	je     801006a0 <cprintf+0x40>
801006f6:	89 55 e0             	mov    %edx,-0x20(%ebp)
      consputc(c);
801006f9:	e8 12 fd ff ff       	call   80100410 <consputc>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
801006fe:	0f b6 06             	movzbl (%esi),%eax
      continue;
80100701:	8b 55 e0             	mov    -0x20(%ebp),%edx
80100704:	89 d3                	mov    %edx,%ebx
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
80100706:	85 c0                	test   %eax,%eax
80100708:	75 e1                	jne    801006eb <cprintf+0x8b>
8010070a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  if(locking)
80100710:	8b 45 dc             	mov    -0x24(%ebp),%eax
80100713:	85 c0                	test   %eax,%eax
80100715:	74 10                	je     80100727 <cprintf+0xc7>
    release(&cons.lock);
80100717:	83 ec 0c             	sub    $0xc,%esp
8010071a:	68 20 b5 10 80       	push   $0x8010b520
8010071f:	e8 5c 45 00 00       	call   80104c80 <release>
80100724:	83 c4 10             	add    $0x10,%esp
}
80100727:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010072a:	5b                   	pop    %ebx
8010072b:	5e                   	pop    %esi
8010072c:	5f                   	pop    %edi
8010072d:	5d                   	pop    %ebp
8010072e:	c3                   	ret    
8010072f:	90                   	nop
    switch(c){
80100730:	83 fa 73             	cmp    $0x73,%edx
80100733:	74 43                	je     80100778 <cprintf+0x118>
80100735:	83 fa 78             	cmp    $0x78,%edx
80100738:	75 1e                	jne    80100758 <cprintf+0xf8>
      printint(*argp++, 16, 0);
8010073a:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010073d:	ba 10 00 00 00       	mov    $0x10,%edx
80100742:	8d 48 04             	lea    0x4(%eax),%ecx
80100745:	8b 00                	mov    (%eax),%eax
80100747:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
8010074a:	31 c9                	xor    %ecx,%ecx
8010074c:	e8 2f fe ff ff       	call   80100580 <printint>
      break;
80100751:	eb 91                	jmp    801006e4 <cprintf+0x84>
80100753:	90                   	nop
80100754:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      consputc('%');
80100758:	b8 25 00 00 00       	mov    $0x25,%eax
8010075d:	89 55 e0             	mov    %edx,-0x20(%ebp)
80100760:	e8 ab fc ff ff       	call   80100410 <consputc>
      consputc(c);
80100765:	8b 55 e0             	mov    -0x20(%ebp),%edx
80100768:	89 d0                	mov    %edx,%eax
8010076a:	e8 a1 fc ff ff       	call   80100410 <consputc>
      break;
8010076f:	e9 70 ff ff ff       	jmp    801006e4 <cprintf+0x84>
80100774:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      if((s = (char*)*argp++) == 0)
80100778:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010077b:	8b 10                	mov    (%eax),%edx
8010077d:	8d 48 04             	lea    0x4(%eax),%ecx
80100780:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80100783:	85 d2                	test   %edx,%edx
80100785:	74 49                	je     801007d0 <cprintf+0x170>
      for(; *s; s++)
80100787:	0f be 02             	movsbl (%edx),%eax
      if((s = (char*)*argp++) == 0)
8010078a:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
      for(; *s; s++)
8010078d:	84 c0                	test   %al,%al
8010078f:	0f 84 4f ff ff ff    	je     801006e4 <cprintf+0x84>
80100795:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
80100798:	89 d3                	mov    %edx,%ebx
8010079a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801007a0:	83 c3 01             	add    $0x1,%ebx
        consputc(*s);
801007a3:	e8 68 fc ff ff       	call   80100410 <consputc>
      for(; *s; s++)
801007a8:	0f be 03             	movsbl (%ebx),%eax
801007ab:	84 c0                	test   %al,%al
801007ad:	75 f1                	jne    801007a0 <cprintf+0x140>
      if((s = (char*)*argp++) == 0)
801007af:	8b 45 e0             	mov    -0x20(%ebp),%eax
801007b2:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
801007b5:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801007b8:	e9 27 ff ff ff       	jmp    801006e4 <cprintf+0x84>
801007bd:	8d 76 00             	lea    0x0(%esi),%esi
      consputc('%');
801007c0:	b8 25 00 00 00       	mov    $0x25,%eax
801007c5:	e8 46 fc ff ff       	call   80100410 <consputc>
      break;
801007ca:	e9 15 ff ff ff       	jmp    801006e4 <cprintf+0x84>
801007cf:	90                   	nop
        s = "(null)";
801007d0:	ba d8 77 10 80       	mov    $0x801077d8,%edx
      for(; *s; s++)
801007d5:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
801007d8:	b8 28 00 00 00       	mov    $0x28,%eax
801007dd:	89 d3                	mov    %edx,%ebx
801007df:	eb bf                	jmp    801007a0 <cprintf+0x140>
801007e1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    acquire(&cons.lock);
801007e8:	83 ec 0c             	sub    $0xc,%esp
801007eb:	68 20 b5 10 80       	push   $0x8010b520
801007f0:	e8 cb 43 00 00       	call   80104bc0 <acquire>
801007f5:	83 c4 10             	add    $0x10,%esp
801007f8:	e9 7c fe ff ff       	jmp    80100679 <cprintf+0x19>
    panic("null fmt");
801007fd:	83 ec 0c             	sub    $0xc,%esp
80100800:	68 df 77 10 80       	push   $0x801077df
80100805:	e8 86 fb ff ff       	call   80100390 <panic>
8010080a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80100810 <consoleintr>:
{
80100810:	55                   	push   %ebp
80100811:	89 e5                	mov    %esp,%ebp
80100813:	57                   	push   %edi
80100814:	56                   	push   %esi
80100815:	53                   	push   %ebx
  int c, doprocdump = 0;
80100816:	31 f6                	xor    %esi,%esi
{
80100818:	83 ec 18             	sub    $0x18,%esp
8010081b:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&cons.lock);
8010081e:	68 20 b5 10 80       	push   $0x8010b520
80100823:	e8 98 43 00 00       	call   80104bc0 <acquire>
  while((c = getc()) >= 0){
80100828:	83 c4 10             	add    $0x10,%esp
8010082b:	90                   	nop
8010082c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100830:	ff d3                	call   *%ebx
80100832:	85 c0                	test   %eax,%eax
80100834:	89 c7                	mov    %eax,%edi
80100836:	78 48                	js     80100880 <consoleintr+0x70>
    switch(c){
80100838:	83 ff 10             	cmp    $0x10,%edi
8010083b:	0f 84 e7 00 00 00    	je     80100928 <consoleintr+0x118>
80100841:	7e 5d                	jle    801008a0 <consoleintr+0x90>
80100843:	83 ff 15             	cmp    $0x15,%edi
80100846:	0f 84 ec 00 00 00    	je     80100938 <consoleintr+0x128>
8010084c:	83 ff 7f             	cmp    $0x7f,%edi
8010084f:	75 54                	jne    801008a5 <consoleintr+0x95>
      if(input.e != input.w){
80100851:	a1 a8 0f 11 80       	mov    0x80110fa8,%eax
80100856:	3b 05 a4 0f 11 80    	cmp    0x80110fa4,%eax
8010085c:	74 d2                	je     80100830 <consoleintr+0x20>
        input.e--;
8010085e:	83 e8 01             	sub    $0x1,%eax
80100861:	a3 a8 0f 11 80       	mov    %eax,0x80110fa8
        consputc(BACKSPACE);
80100866:	b8 00 01 00 00       	mov    $0x100,%eax
8010086b:	e8 a0 fb ff ff       	call   80100410 <consputc>
  while((c = getc()) >= 0){
80100870:	ff d3                	call   *%ebx
80100872:	85 c0                	test   %eax,%eax
80100874:	89 c7                	mov    %eax,%edi
80100876:	79 c0                	jns    80100838 <consoleintr+0x28>
80100878:	90                   	nop
80100879:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  release(&cons.lock);
80100880:	83 ec 0c             	sub    $0xc,%esp
80100883:	68 20 b5 10 80       	push   $0x8010b520
80100888:	e8 f3 43 00 00       	call   80104c80 <release>
  if(doprocdump) {
8010088d:	83 c4 10             	add    $0x10,%esp
80100890:	85 f6                	test   %esi,%esi
80100892:	0f 85 f8 00 00 00    	jne    80100990 <consoleintr+0x180>
}
80100898:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010089b:	5b                   	pop    %ebx
8010089c:	5e                   	pop    %esi
8010089d:	5f                   	pop    %edi
8010089e:	5d                   	pop    %ebp
8010089f:	c3                   	ret    
    switch(c){
801008a0:	83 ff 08             	cmp    $0x8,%edi
801008a3:	74 ac                	je     80100851 <consoleintr+0x41>
      if(c != 0 && input.e-input.r < INPUT_BUF){
801008a5:	85 ff                	test   %edi,%edi
801008a7:	74 87                	je     80100830 <consoleintr+0x20>
801008a9:	a1 a8 0f 11 80       	mov    0x80110fa8,%eax
801008ae:	89 c2                	mov    %eax,%edx
801008b0:	2b 15 a0 0f 11 80    	sub    0x80110fa0,%edx
801008b6:	83 fa 7f             	cmp    $0x7f,%edx
801008b9:	0f 87 71 ff ff ff    	ja     80100830 <consoleintr+0x20>
801008bf:	8d 50 01             	lea    0x1(%eax),%edx
801008c2:	83 e0 7f             	and    $0x7f,%eax
        c = (c == '\r') ? '\n' : c;
801008c5:	83 ff 0d             	cmp    $0xd,%edi
        input.buf[input.e++ % INPUT_BUF] = c;
801008c8:	89 15 a8 0f 11 80    	mov    %edx,0x80110fa8
        c = (c == '\r') ? '\n' : c;
801008ce:	0f 84 cc 00 00 00    	je     801009a0 <consoleintr+0x190>
        input.buf[input.e++ % INPUT_BUF] = c;
801008d4:	89 f9                	mov    %edi,%ecx
801008d6:	88 88 20 0f 11 80    	mov    %cl,-0x7feef0e0(%eax)
        consputc(c);
801008dc:	89 f8                	mov    %edi,%eax
801008de:	e8 2d fb ff ff       	call   80100410 <consputc>
        if(c == '\n' || c == C('D') || input.e == input.r+INPUT_BUF){
801008e3:	83 ff 0a             	cmp    $0xa,%edi
801008e6:	0f 84 c5 00 00 00    	je     801009b1 <consoleintr+0x1a1>
801008ec:	83 ff 04             	cmp    $0x4,%edi
801008ef:	0f 84 bc 00 00 00    	je     801009b1 <consoleintr+0x1a1>
801008f5:	a1 a0 0f 11 80       	mov    0x80110fa0,%eax
801008fa:	83 e8 80             	sub    $0xffffff80,%eax
801008fd:	39 05 a8 0f 11 80    	cmp    %eax,0x80110fa8
80100903:	0f 85 27 ff ff ff    	jne    80100830 <consoleintr+0x20>
          wakeup(&input.r);
80100909:	83 ec 0c             	sub    $0xc,%esp
          input.w = input.e;
8010090c:	a3 a4 0f 11 80       	mov    %eax,0x80110fa4
          wakeup(&input.r);
80100911:	68 a0 0f 11 80       	push   $0x80110fa0
80100916:	e8 95 3e 00 00       	call   801047b0 <wakeup>
8010091b:	83 c4 10             	add    $0x10,%esp
8010091e:	e9 0d ff ff ff       	jmp    80100830 <consoleintr+0x20>
80100923:	90                   	nop
80100924:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      doprocdump = 1;
80100928:	be 01 00 00 00       	mov    $0x1,%esi
8010092d:	e9 fe fe ff ff       	jmp    80100830 <consoleintr+0x20>
80100932:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      while(input.e != input.w &&
80100938:	a1 a8 0f 11 80       	mov    0x80110fa8,%eax
8010093d:	39 05 a4 0f 11 80    	cmp    %eax,0x80110fa4
80100943:	75 2b                	jne    80100970 <consoleintr+0x160>
80100945:	e9 e6 fe ff ff       	jmp    80100830 <consoleintr+0x20>
8010094a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
        input.e--;
80100950:	a3 a8 0f 11 80       	mov    %eax,0x80110fa8
        consputc(BACKSPACE);
80100955:	b8 00 01 00 00       	mov    $0x100,%eax
8010095a:	e8 b1 fa ff ff       	call   80100410 <consputc>
      while(input.e != input.w &&
8010095f:	a1 a8 0f 11 80       	mov    0x80110fa8,%eax
80100964:	3b 05 a4 0f 11 80    	cmp    0x80110fa4,%eax
8010096a:	0f 84 c0 fe ff ff    	je     80100830 <consoleintr+0x20>
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
80100970:	83 e8 01             	sub    $0x1,%eax
80100973:	89 c2                	mov    %eax,%edx
80100975:	83 e2 7f             	and    $0x7f,%edx
      while(input.e != input.w &&
80100978:	80 ba 20 0f 11 80 0a 	cmpb   $0xa,-0x7feef0e0(%edx)
8010097f:	75 cf                	jne    80100950 <consoleintr+0x140>
80100981:	e9 aa fe ff ff       	jmp    80100830 <consoleintr+0x20>
80100986:	8d 76 00             	lea    0x0(%esi),%esi
80100989:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
}
80100990:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100993:	5b                   	pop    %ebx
80100994:	5e                   	pop    %esi
80100995:	5f                   	pop    %edi
80100996:	5d                   	pop    %ebp
    procdump();  // now call procdump() wo. cons.lock held
80100997:	e9 f4 3e 00 00       	jmp    80104890 <procdump>
8010099c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
        input.buf[input.e++ % INPUT_BUF] = c;
801009a0:	c6 80 20 0f 11 80 0a 	movb   $0xa,-0x7feef0e0(%eax)
        consputc(c);
801009a7:	b8 0a 00 00 00       	mov    $0xa,%eax
801009ac:	e8 5f fa ff ff       	call   80100410 <consputc>
801009b1:	a1 a8 0f 11 80       	mov    0x80110fa8,%eax
801009b6:	e9 4e ff ff ff       	jmp    80100909 <consoleintr+0xf9>
801009bb:	90                   	nop
801009bc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

801009c0 <consoleinit>:

void
consoleinit(void)
{
801009c0:	55                   	push   %ebp
801009c1:	89 e5                	mov    %esp,%ebp
801009c3:	83 ec 10             	sub    $0x10,%esp
  initlock(&cons.lock, "console");
801009c6:	68 e8 77 10 80       	push   $0x801077e8
801009cb:	68 20 b5 10 80       	push   $0x8010b520
801009d0:	e8 ab 40 00 00       	call   80104a80 <initlock>

  devsw[CONSOLE].write = consolewrite;
  devsw[CONSOLE].read = consoleread;
  cons.locking = 1;

  ioapicenable(IRQ_KBD, 0);
801009d5:	58                   	pop    %eax
801009d6:	5a                   	pop    %edx
801009d7:	6a 00                	push   $0x0
801009d9:	6a 01                	push   $0x1
  devsw[CONSOLE].write = consolewrite;
801009db:	c7 05 6c 19 11 80 00 	movl   $0x80100600,0x8011196c
801009e2:	06 10 80 
  devsw[CONSOLE].read = consoleread;
801009e5:	c7 05 68 19 11 80 70 	movl   $0x80100270,0x80111968
801009ec:	02 10 80 
  cons.locking = 1;
801009ef:	c7 05 54 b5 10 80 01 	movl   $0x1,0x8010b554
801009f6:	00 00 00 
  ioapicenable(IRQ_KBD, 0);
801009f9:	e8 52 21 00 00       	call   80102b50 <ioapicenable>
}
801009fe:	83 c4 10             	add    $0x10,%esp
80100a01:	c9                   	leave  
80100a02:	c3                   	ret    
80100a03:	66 90                	xchg   %ax,%ax
80100a05:	66 90                	xchg   %ax,%ax
80100a07:	66 90                	xchg   %ax,%ax
80100a09:	66 90                	xchg   %ax,%ax
80100a0b:	66 90                	xchg   %ax,%ax
80100a0d:	66 90                	xchg   %ax,%ax
80100a0f:	90                   	nop

80100a10 <exec>:
#include "x86.h"
#include "elf.h"

int
exec(char *path, char **argv)
{
80100a10:	55                   	push   %ebp
80100a11:	89 e5                	mov    %esp,%ebp
80100a13:	57                   	push   %edi
80100a14:	56                   	push   %esi
80100a15:	53                   	push   %ebx
80100a16:	81 ec 0c 01 00 00    	sub    $0x10c,%esp
  uint argc, sz, sp, ustack[3+MAXARG+1];
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pde_t *pgdir, *oldpgdir;
  struct proc *curproc = myproc();
80100a1c:	e8 3f 36 00 00       	call   80104060 <myproc>
80100a21:	89 85 f4 fe ff ff    	mov    %eax,-0x10c(%ebp)

  begin_op();
80100a27:	e8 f4 29 00 00       	call   80103420 <begin_op>

  if((ip = namei(path)) == 0){
80100a2c:	83 ec 0c             	sub    $0xc,%esp
80100a2f:	ff 75 08             	pushl  0x8(%ebp)
80100a32:	e8 19 1d 00 00       	call   80102750 <namei>
80100a37:	83 c4 10             	add    $0x10,%esp
80100a3a:	85 c0                	test   %eax,%eax
80100a3c:	0f 84 91 01 00 00    	je     80100bd3 <exec+0x1c3>
    end_op();
    cprintf("exec: fail\n");
    return -1;
  }
  ilock(ip);
80100a42:	83 ec 0c             	sub    $0xc,%esp
80100a45:	89 c3                	mov    %eax,%ebx
80100a47:	50                   	push   %eax
80100a48:	e8 13 0e 00 00       	call   80101860 <ilock>
  pgdir = 0;

  // Check ELF header
  if(readi(ip, (char*)&elf, 0, sizeof(elf)) != sizeof(elf))
80100a4d:	8d 85 24 ff ff ff    	lea    -0xdc(%ebp),%eax
80100a53:	6a 34                	push   $0x34
80100a55:	6a 00                	push   $0x0
80100a57:	50                   	push   %eax
80100a58:	53                   	push   %ebx
80100a59:	e8 62 0f 00 00       	call   801019c0 <readi>
80100a5e:	83 c4 20             	add    $0x20,%esp
80100a61:	83 f8 34             	cmp    $0x34,%eax
80100a64:	74 22                	je     80100a88 <exec+0x78>

 bad:
  if(pgdir)
    freevm(pgdir);
  if(ip){
    iunlockput(ip);
80100a66:	83 ec 0c             	sub    $0xc,%esp
80100a69:	53                   	push   %ebx
80100a6a:	e8 01 14 00 00       	call   80101e70 <iunlockput>
    end_op();
80100a6f:	e8 1c 2a 00 00       	call   80103490 <end_op>
80100a74:	83 c4 10             	add    $0x10,%esp
  }
  return -1;
80100a77:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80100a7c:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100a7f:	5b                   	pop    %ebx
80100a80:	5e                   	pop    %esi
80100a81:	5f                   	pop    %edi
80100a82:	5d                   	pop    %ebp
80100a83:	c3                   	ret    
80100a84:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  if(elf.magic != ELF_MAGIC)
80100a88:	81 bd 24 ff ff ff 7f 	cmpl   $0x464c457f,-0xdc(%ebp)
80100a8f:	45 4c 46 
80100a92:	75 d2                	jne    80100a66 <exec+0x56>
  if((pgdir = setupkvm()) == 0)
80100a94:	e8 47 6a 00 00       	call   801074e0 <setupkvm>
80100a99:	85 c0                	test   %eax,%eax
80100a9b:	89 85 f0 fe ff ff    	mov    %eax,-0x110(%ebp)
80100aa1:	74 c3                	je     80100a66 <exec+0x56>
  sz = 0;
80100aa3:	31 ff                	xor    %edi,%edi
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100aa5:	66 83 bd 50 ff ff ff 	cmpw   $0x0,-0xb0(%ebp)
80100aac:	00 
80100aad:	8b 85 40 ff ff ff    	mov    -0xc0(%ebp),%eax
80100ab3:	89 85 ec fe ff ff    	mov    %eax,-0x114(%ebp)
80100ab9:	0f 84 8c 02 00 00    	je     80100d4b <exec+0x33b>
80100abf:	31 f6                	xor    %esi,%esi
80100ac1:	eb 7f                	jmp    80100b42 <exec+0x132>
80100ac3:	90                   	nop
80100ac4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(ph.type != ELF_PROG_LOAD)
80100ac8:	83 bd 04 ff ff ff 01 	cmpl   $0x1,-0xfc(%ebp)
80100acf:	75 63                	jne    80100b34 <exec+0x124>
    if(ph.memsz < ph.filesz)
80100ad1:	8b 85 18 ff ff ff    	mov    -0xe8(%ebp),%eax
80100ad7:	3b 85 14 ff ff ff    	cmp    -0xec(%ebp),%eax
80100add:	0f 82 86 00 00 00    	jb     80100b69 <exec+0x159>
80100ae3:	03 85 0c ff ff ff    	add    -0xf4(%ebp),%eax
80100ae9:	72 7e                	jb     80100b69 <exec+0x159>
    if((sz = allocuvm(pgdir, sz, ph.vaddr + ph.memsz)) == 0)
80100aeb:	83 ec 04             	sub    $0x4,%esp
80100aee:	50                   	push   %eax
80100aef:	57                   	push   %edi
80100af0:	ff b5 f0 fe ff ff    	pushl  -0x110(%ebp)
80100af6:	e8 05 68 00 00       	call   80107300 <allocuvm>
80100afb:	83 c4 10             	add    $0x10,%esp
80100afe:	85 c0                	test   %eax,%eax
80100b00:	89 c7                	mov    %eax,%edi
80100b02:	74 65                	je     80100b69 <exec+0x159>
    if(ph.vaddr % PGSIZE != 0)
80100b04:	8b 85 0c ff ff ff    	mov    -0xf4(%ebp),%eax
80100b0a:	a9 ff 0f 00 00       	test   $0xfff,%eax
80100b0f:	75 58                	jne    80100b69 <exec+0x159>
    if(loaduvm(pgdir, (char*)ph.vaddr, ip, ph.off, ph.filesz) < 0)
80100b11:	83 ec 0c             	sub    $0xc,%esp
80100b14:	ff b5 14 ff ff ff    	pushl  -0xec(%ebp)
80100b1a:	ff b5 08 ff ff ff    	pushl  -0xf8(%ebp)
80100b20:	53                   	push   %ebx
80100b21:	50                   	push   %eax
80100b22:	ff b5 f0 fe ff ff    	pushl  -0x110(%ebp)
80100b28:	e8 13 67 00 00       	call   80107240 <loaduvm>
80100b2d:	83 c4 20             	add    $0x20,%esp
80100b30:	85 c0                	test   %eax,%eax
80100b32:	78 35                	js     80100b69 <exec+0x159>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100b34:	0f b7 85 50 ff ff ff 	movzwl -0xb0(%ebp),%eax
80100b3b:	83 c6 01             	add    $0x1,%esi
80100b3e:	39 f0                	cmp    %esi,%eax
80100b40:	7e 3d                	jle    80100b7f <exec+0x16f>
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
80100b42:	89 f0                	mov    %esi,%eax
80100b44:	6a 20                	push   $0x20
80100b46:	c1 e0 05             	shl    $0x5,%eax
80100b49:	03 85 ec fe ff ff    	add    -0x114(%ebp),%eax
80100b4f:	50                   	push   %eax
80100b50:	8d 85 04 ff ff ff    	lea    -0xfc(%ebp),%eax
80100b56:	50                   	push   %eax
80100b57:	53                   	push   %ebx
80100b58:	e8 63 0e 00 00       	call   801019c0 <readi>
80100b5d:	83 c4 10             	add    $0x10,%esp
80100b60:	83 f8 20             	cmp    $0x20,%eax
80100b63:	0f 84 5f ff ff ff    	je     80100ac8 <exec+0xb8>
    freevm(pgdir);
80100b69:	83 ec 0c             	sub    $0xc,%esp
80100b6c:	ff b5 f0 fe ff ff    	pushl  -0x110(%ebp)
80100b72:	e8 e9 68 00 00       	call   80107460 <freevm>
80100b77:	83 c4 10             	add    $0x10,%esp
80100b7a:	e9 e7 fe ff ff       	jmp    80100a66 <exec+0x56>
80100b7f:	81 c7 ff 0f 00 00    	add    $0xfff,%edi
80100b85:	81 e7 00 f0 ff ff    	and    $0xfffff000,%edi
80100b8b:	8d b7 00 20 00 00    	lea    0x2000(%edi),%esi
  iunlockput(ip);
80100b91:	83 ec 0c             	sub    $0xc,%esp
80100b94:	53                   	push   %ebx
80100b95:	e8 d6 12 00 00       	call   80101e70 <iunlockput>
  end_op();
80100b9a:	e8 f1 28 00 00       	call   80103490 <end_op>
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
80100b9f:	83 c4 0c             	add    $0xc,%esp
80100ba2:	56                   	push   %esi
80100ba3:	57                   	push   %edi
80100ba4:	ff b5 f0 fe ff ff    	pushl  -0x110(%ebp)
80100baa:	e8 51 67 00 00       	call   80107300 <allocuvm>
80100baf:	83 c4 10             	add    $0x10,%esp
80100bb2:	85 c0                	test   %eax,%eax
80100bb4:	89 c6                	mov    %eax,%esi
80100bb6:	75 3a                	jne    80100bf2 <exec+0x1e2>
    freevm(pgdir);
80100bb8:	83 ec 0c             	sub    $0xc,%esp
80100bbb:	ff b5 f0 fe ff ff    	pushl  -0x110(%ebp)
80100bc1:	e8 9a 68 00 00       	call   80107460 <freevm>
80100bc6:	83 c4 10             	add    $0x10,%esp
  return -1;
80100bc9:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80100bce:	e9 a9 fe ff ff       	jmp    80100a7c <exec+0x6c>
    end_op();
80100bd3:	e8 b8 28 00 00       	call   80103490 <end_op>
    cprintf("exec: fail\n");
80100bd8:	83 ec 0c             	sub    $0xc,%esp
80100bdb:	68 01 78 10 80       	push   $0x80107801
80100be0:	e8 7b fa ff ff       	call   80100660 <cprintf>
    return -1;
80100be5:	83 c4 10             	add    $0x10,%esp
80100be8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80100bed:	e9 8a fe ff ff       	jmp    80100a7c <exec+0x6c>
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100bf2:	8d 80 00 e0 ff ff    	lea    -0x2000(%eax),%eax
80100bf8:	83 ec 08             	sub    $0x8,%esp
  for(argc = 0; argv[argc]; argc++) {
80100bfb:	31 ff                	xor    %edi,%edi
80100bfd:	89 f3                	mov    %esi,%ebx
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100bff:	50                   	push   %eax
80100c00:	ff b5 f0 fe ff ff    	pushl  -0x110(%ebp)
80100c06:	e8 75 69 00 00       	call   80107580 <clearpteu>
  for(argc = 0; argv[argc]; argc++) {
80100c0b:	8b 45 0c             	mov    0xc(%ebp),%eax
80100c0e:	83 c4 10             	add    $0x10,%esp
80100c11:	8d 95 58 ff ff ff    	lea    -0xa8(%ebp),%edx
80100c17:	8b 00                	mov    (%eax),%eax
80100c19:	85 c0                	test   %eax,%eax
80100c1b:	74 70                	je     80100c8d <exec+0x27d>
80100c1d:	89 b5 ec fe ff ff    	mov    %esi,-0x114(%ebp)
80100c23:	8b b5 f0 fe ff ff    	mov    -0x110(%ebp),%esi
80100c29:	eb 0a                	jmp    80100c35 <exec+0x225>
80100c2b:	90                   	nop
80100c2c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(argc >= MAXARG)
80100c30:	83 ff 20             	cmp    $0x20,%edi
80100c33:	74 83                	je     80100bb8 <exec+0x1a8>
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80100c35:	83 ec 0c             	sub    $0xc,%esp
80100c38:	50                   	push   %eax
80100c39:	e8 b2 42 00 00       	call   80104ef0 <strlen>
80100c3e:	f7 d0                	not    %eax
80100c40:	01 c3                	add    %eax,%ebx
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
80100c42:	8b 45 0c             	mov    0xc(%ebp),%eax
80100c45:	5a                   	pop    %edx
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80100c46:	83 e3 fc             	and    $0xfffffffc,%ebx
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
80100c49:	ff 34 b8             	pushl  (%eax,%edi,4)
80100c4c:	e8 9f 42 00 00       	call   80104ef0 <strlen>
80100c51:	83 c0 01             	add    $0x1,%eax
80100c54:	50                   	push   %eax
80100c55:	8b 45 0c             	mov    0xc(%ebp),%eax
80100c58:	ff 34 b8             	pushl  (%eax,%edi,4)
80100c5b:	53                   	push   %ebx
80100c5c:	56                   	push   %esi
80100c5d:	e8 7e 6a 00 00       	call   801076e0 <copyout>
80100c62:	83 c4 20             	add    $0x20,%esp
80100c65:	85 c0                	test   %eax,%eax
80100c67:	0f 88 4b ff ff ff    	js     80100bb8 <exec+0x1a8>
  for(argc = 0; argv[argc]; argc++) {
80100c6d:	8b 45 0c             	mov    0xc(%ebp),%eax
    ustack[3+argc] = sp;
80100c70:	89 9c bd 64 ff ff ff 	mov    %ebx,-0x9c(%ebp,%edi,4)
  for(argc = 0; argv[argc]; argc++) {
80100c77:	83 c7 01             	add    $0x1,%edi
    ustack[3+argc] = sp;
80100c7a:	8d 95 58 ff ff ff    	lea    -0xa8(%ebp),%edx
  for(argc = 0; argv[argc]; argc++) {
80100c80:	8b 04 b8             	mov    (%eax,%edi,4),%eax
80100c83:	85 c0                	test   %eax,%eax
80100c85:	75 a9                	jne    80100c30 <exec+0x220>
80100c87:	8b b5 ec fe ff ff    	mov    -0x114(%ebp),%esi
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100c8d:	8d 04 bd 04 00 00 00 	lea    0x4(,%edi,4),%eax
80100c94:	89 d9                	mov    %ebx,%ecx
  ustack[3+argc] = 0;
80100c96:	c7 84 bd 64 ff ff ff 	movl   $0x0,-0x9c(%ebp,%edi,4)
80100c9d:	00 00 00 00 
  ustack[0] = 0xffffffff;  // fake return PC
80100ca1:	c7 85 58 ff ff ff ff 	movl   $0xffffffff,-0xa8(%ebp)
80100ca8:	ff ff ff 
  ustack[1] = argc;
80100cab:	89 bd 5c ff ff ff    	mov    %edi,-0xa4(%ebp)
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100cb1:	29 c1                	sub    %eax,%ecx
  sp -= (3+argc+1) * 4;
80100cb3:	83 c0 0c             	add    $0xc,%eax
80100cb6:	29 c3                	sub    %eax,%ebx
  if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)
80100cb8:	50                   	push   %eax
80100cb9:	52                   	push   %edx
80100cba:	53                   	push   %ebx
80100cbb:	ff b5 f0 fe ff ff    	pushl  -0x110(%ebp)
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100cc1:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%ebp)
  if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)
80100cc7:	e8 14 6a 00 00       	call   801076e0 <copyout>
80100ccc:	83 c4 10             	add    $0x10,%esp
80100ccf:	85 c0                	test   %eax,%eax
80100cd1:	0f 88 e1 fe ff ff    	js     80100bb8 <exec+0x1a8>
  for(last=s=path; *s; s++)
80100cd7:	8b 45 08             	mov    0x8(%ebp),%eax
80100cda:	0f b6 00             	movzbl (%eax),%eax
80100cdd:	84 c0                	test   %al,%al
80100cdf:	74 17                	je     80100cf8 <exec+0x2e8>
80100ce1:	8b 55 08             	mov    0x8(%ebp),%edx
80100ce4:	89 d1                	mov    %edx,%ecx
80100ce6:	83 c1 01             	add    $0x1,%ecx
80100ce9:	3c 2f                	cmp    $0x2f,%al
80100ceb:	0f b6 01             	movzbl (%ecx),%eax
80100cee:	0f 44 d1             	cmove  %ecx,%edx
80100cf1:	84 c0                	test   %al,%al
80100cf3:	75 f1                	jne    80100ce6 <exec+0x2d6>
80100cf5:	89 55 08             	mov    %edx,0x8(%ebp)
  safestrcpy(curproc->name, last, sizeof(curproc->name));
80100cf8:	8b bd f4 fe ff ff    	mov    -0x10c(%ebp),%edi
80100cfe:	50                   	push   %eax
80100cff:	6a 10                	push   $0x10
80100d01:	ff 75 08             	pushl  0x8(%ebp)
80100d04:	89 f8                	mov    %edi,%eax
80100d06:	83 c0 6c             	add    $0x6c,%eax
80100d09:	50                   	push   %eax
80100d0a:	e8 a1 41 00 00       	call   80104eb0 <safestrcpy>
  curproc->pgdir = pgdir;
80100d0f:	8b 95 f0 fe ff ff    	mov    -0x110(%ebp),%edx
  oldpgdir = curproc->pgdir;
80100d15:	89 f9                	mov    %edi,%ecx
80100d17:	8b 7f 04             	mov    0x4(%edi),%edi
  curproc->tf->eip = elf.entry;  // main
80100d1a:	8b 41 18             	mov    0x18(%ecx),%eax
  curproc->sz = sz;
80100d1d:	89 31                	mov    %esi,(%ecx)
  curproc->pgdir = pgdir;
80100d1f:	89 51 04             	mov    %edx,0x4(%ecx)
  curproc->tf->eip = elf.entry;  // main
80100d22:	8b 95 3c ff ff ff    	mov    -0xc4(%ebp),%edx
80100d28:	89 50 38             	mov    %edx,0x38(%eax)
  curproc->tf->esp = sp;
80100d2b:	8b 41 18             	mov    0x18(%ecx),%eax
80100d2e:	89 58 44             	mov    %ebx,0x44(%eax)
  switchuvm(curproc);
80100d31:	89 0c 24             	mov    %ecx,(%esp)
80100d34:	e8 77 63 00 00       	call   801070b0 <switchuvm>
  freevm(oldpgdir);
80100d39:	89 3c 24             	mov    %edi,(%esp)
80100d3c:	e8 1f 67 00 00       	call   80107460 <freevm>
  return 0;
80100d41:	83 c4 10             	add    $0x10,%esp
80100d44:	31 c0                	xor    %eax,%eax
80100d46:	e9 31 fd ff ff       	jmp    80100a7c <exec+0x6c>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100d4b:	be 00 20 00 00       	mov    $0x2000,%esi
80100d50:	e9 3c fe ff ff       	jmp    80100b91 <exec+0x181>
80100d55:	66 90                	xchg   %ax,%ax
80100d57:	66 90                	xchg   %ax,%ax
80100d59:	66 90                	xchg   %ax,%ax
80100d5b:	66 90                	xchg   %ax,%ax
80100d5d:	66 90                	xchg   %ax,%ax
80100d5f:	90                   	nop

80100d60 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
80100d60:	55                   	push   %ebp
80100d61:	89 e5                	mov    %esp,%ebp
80100d63:	83 ec 10             	sub    $0x10,%esp
  initlock(&ftable.lock, "ftable");
80100d66:	68 0d 78 10 80       	push   $0x8010780d
80100d6b:	68 c0 0f 11 80       	push   $0x80110fc0
80100d70:	e8 0b 3d 00 00       	call   80104a80 <initlock>
}
80100d75:	83 c4 10             	add    $0x10,%esp
80100d78:	c9                   	leave  
80100d79:	c3                   	ret    
80100d7a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80100d80 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
80100d80:	55                   	push   %ebp
80100d81:	89 e5                	mov    %esp,%ebp
80100d83:	53                   	push   %ebx
  struct file *f;

  acquire(&ftable.lock);
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100d84:	bb f4 0f 11 80       	mov    $0x80110ff4,%ebx
{
80100d89:	83 ec 10             	sub    $0x10,%esp
  acquire(&ftable.lock);
80100d8c:	68 c0 0f 11 80       	push   $0x80110fc0
80100d91:	e8 2a 3e 00 00       	call   80104bc0 <acquire>
80100d96:	83 c4 10             	add    $0x10,%esp
80100d99:	eb 10                	jmp    80100dab <filealloc+0x2b>
80100d9b:	90                   	nop
80100d9c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100da0:	83 c3 18             	add    $0x18,%ebx
80100da3:	81 fb 54 19 11 80    	cmp    $0x80111954,%ebx
80100da9:	73 25                	jae    80100dd0 <filealloc+0x50>
    if(f->ref == 0){
80100dab:	8b 43 04             	mov    0x4(%ebx),%eax
80100dae:	85 c0                	test   %eax,%eax
80100db0:	75 ee                	jne    80100da0 <filealloc+0x20>
      f->ref = 1;
      release(&ftable.lock);
80100db2:	83 ec 0c             	sub    $0xc,%esp
      f->ref = 1;
80100db5:	c7 43 04 01 00 00 00 	movl   $0x1,0x4(%ebx)
      release(&ftable.lock);
80100dbc:	68 c0 0f 11 80       	push   $0x80110fc0
80100dc1:	e8 ba 3e 00 00       	call   80104c80 <release>
      return f;
    }
  }
  release(&ftable.lock);
  return 0;
}
80100dc6:	89 d8                	mov    %ebx,%eax
      return f;
80100dc8:	83 c4 10             	add    $0x10,%esp
}
80100dcb:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100dce:	c9                   	leave  
80100dcf:	c3                   	ret    
  release(&ftable.lock);
80100dd0:	83 ec 0c             	sub    $0xc,%esp
  return 0;
80100dd3:	31 db                	xor    %ebx,%ebx
  release(&ftable.lock);
80100dd5:	68 c0 0f 11 80       	push   $0x80110fc0
80100dda:	e8 a1 3e 00 00       	call   80104c80 <release>
}
80100ddf:	89 d8                	mov    %ebx,%eax
  return 0;
80100de1:	83 c4 10             	add    $0x10,%esp
}
80100de4:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100de7:	c9                   	leave  
80100de8:	c3                   	ret    
80100de9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80100df0 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
80100df0:	55                   	push   %ebp
80100df1:	89 e5                	mov    %esp,%ebp
80100df3:	53                   	push   %ebx
80100df4:	83 ec 10             	sub    $0x10,%esp
80100df7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&ftable.lock);
80100dfa:	68 c0 0f 11 80       	push   $0x80110fc0
80100dff:	e8 bc 3d 00 00       	call   80104bc0 <acquire>
  if(f->ref < 1)
80100e04:	8b 43 04             	mov    0x4(%ebx),%eax
80100e07:	83 c4 10             	add    $0x10,%esp
80100e0a:	85 c0                	test   %eax,%eax
80100e0c:	7e 1a                	jle    80100e28 <filedup+0x38>
    panic("filedup");
  f->ref++;
80100e0e:	83 c0 01             	add    $0x1,%eax
  release(&ftable.lock);
80100e11:	83 ec 0c             	sub    $0xc,%esp
  f->ref++;
80100e14:	89 43 04             	mov    %eax,0x4(%ebx)
  release(&ftable.lock);
80100e17:	68 c0 0f 11 80       	push   $0x80110fc0
80100e1c:	e8 5f 3e 00 00       	call   80104c80 <release>
  return f;
}
80100e21:	89 d8                	mov    %ebx,%eax
80100e23:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100e26:	c9                   	leave  
80100e27:	c3                   	ret    
    panic("filedup");
80100e28:	83 ec 0c             	sub    $0xc,%esp
80100e2b:	68 14 78 10 80       	push   $0x80107814
80100e30:	e8 5b f5 ff ff       	call   80100390 <panic>
80100e35:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100e39:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80100e40 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
80100e40:	55                   	push   %ebp
80100e41:	89 e5                	mov    %esp,%ebp
80100e43:	57                   	push   %edi
80100e44:	56                   	push   %esi
80100e45:	53                   	push   %ebx
80100e46:	83 ec 28             	sub    $0x28,%esp
80100e49:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct file ff;

  acquire(&ftable.lock);
80100e4c:	68 c0 0f 11 80       	push   $0x80110fc0
80100e51:	e8 6a 3d 00 00       	call   80104bc0 <acquire>
  if(f->ref < 1)
80100e56:	8b 43 04             	mov    0x4(%ebx),%eax
80100e59:	83 c4 10             	add    $0x10,%esp
80100e5c:	85 c0                	test   %eax,%eax
80100e5e:	0f 8e 9b 00 00 00    	jle    80100eff <fileclose+0xbf>
    panic("fileclose");
  if(--f->ref > 0){
80100e64:	83 e8 01             	sub    $0x1,%eax
80100e67:	85 c0                	test   %eax,%eax
80100e69:	89 43 04             	mov    %eax,0x4(%ebx)
80100e6c:	74 1a                	je     80100e88 <fileclose+0x48>
    release(&ftable.lock);
80100e6e:	c7 45 08 c0 0f 11 80 	movl   $0x80110fc0,0x8(%ebp)
  else if(ff.type == FD_INODE){
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
80100e75:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100e78:	5b                   	pop    %ebx
80100e79:	5e                   	pop    %esi
80100e7a:	5f                   	pop    %edi
80100e7b:	5d                   	pop    %ebp
    release(&ftable.lock);
80100e7c:	e9 ff 3d 00 00       	jmp    80104c80 <release>
80100e81:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  ff = *f;
80100e88:	0f b6 43 09          	movzbl 0x9(%ebx),%eax
80100e8c:	8b 3b                	mov    (%ebx),%edi
  release(&ftable.lock);
80100e8e:	83 ec 0c             	sub    $0xc,%esp
  ff = *f;
80100e91:	8b 73 0c             	mov    0xc(%ebx),%esi
  f->type = FD_NONE;
80100e94:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  ff = *f;
80100e9a:	88 45 e7             	mov    %al,-0x19(%ebp)
80100e9d:	8b 43 10             	mov    0x10(%ebx),%eax
  release(&ftable.lock);
80100ea0:	68 c0 0f 11 80       	push   $0x80110fc0
  ff = *f;
80100ea5:	89 45 e0             	mov    %eax,-0x20(%ebp)
  release(&ftable.lock);
80100ea8:	e8 d3 3d 00 00       	call   80104c80 <release>
  if(ff.type == FD_PIPE)
80100ead:	83 c4 10             	add    $0x10,%esp
80100eb0:	83 ff 01             	cmp    $0x1,%edi
80100eb3:	74 13                	je     80100ec8 <fileclose+0x88>
  else if(ff.type == FD_INODE){
80100eb5:	83 ff 02             	cmp    $0x2,%edi
80100eb8:	74 26                	je     80100ee0 <fileclose+0xa0>
}
80100eba:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100ebd:	5b                   	pop    %ebx
80100ebe:	5e                   	pop    %esi
80100ebf:	5f                   	pop    %edi
80100ec0:	5d                   	pop    %ebp
80100ec1:	c3                   	ret    
80100ec2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    pipeclose(ff.pipe, ff.writable);
80100ec8:	0f be 5d e7          	movsbl -0x19(%ebp),%ebx
80100ecc:	83 ec 08             	sub    $0x8,%esp
80100ecf:	53                   	push   %ebx
80100ed0:	56                   	push   %esi
80100ed1:	e8 fa 2c 00 00       	call   80103bd0 <pipeclose>
80100ed6:	83 c4 10             	add    $0x10,%esp
80100ed9:	eb df                	jmp    80100eba <fileclose+0x7a>
80100edb:	90                   	nop
80100edc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    begin_op();
80100ee0:	e8 3b 25 00 00       	call   80103420 <begin_op>
    iput(ff.ip);
80100ee5:	83 ec 0c             	sub    $0xc,%esp
80100ee8:	ff 75 e0             	pushl  -0x20(%ebp)
80100eeb:	e8 a0 0c 00 00       	call   80101b90 <iput>
    end_op();
80100ef0:	83 c4 10             	add    $0x10,%esp
}
80100ef3:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100ef6:	5b                   	pop    %ebx
80100ef7:	5e                   	pop    %esi
80100ef8:	5f                   	pop    %edi
80100ef9:	5d                   	pop    %ebp
    end_op();
80100efa:	e9 91 25 00 00       	jmp    80103490 <end_op>
    panic("fileclose");
80100eff:	83 ec 0c             	sub    $0xc,%esp
80100f02:	68 1c 78 10 80       	push   $0x8010781c
80100f07:	e8 84 f4 ff ff       	call   80100390 <panic>
80100f0c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80100f10 <filestat>:

// Get metadata about file f.
int
filestat(struct file *f, struct stat *st)
{
80100f10:	55                   	push   %ebp
80100f11:	89 e5                	mov    %esp,%ebp
80100f13:	53                   	push   %ebx
80100f14:	83 ec 04             	sub    $0x4,%esp
80100f17:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(f->type == FD_INODE){
80100f1a:	83 3b 02             	cmpl   $0x2,(%ebx)
80100f1d:	75 31                	jne    80100f50 <filestat+0x40>
    ilock(f->ip);
80100f1f:	83 ec 0c             	sub    $0xc,%esp
80100f22:	ff 73 10             	pushl  0x10(%ebx)
80100f25:	e8 36 09 00 00       	call   80101860 <ilock>
    stati(f->ip, st);
80100f2a:	58                   	pop    %eax
80100f2b:	5a                   	pop    %edx
80100f2c:	ff 75 0c             	pushl  0xc(%ebp)
80100f2f:	ff 73 10             	pushl  0x10(%ebx)
80100f32:	e8 59 0a 00 00       	call   80101990 <stati>
    iunlock(f->ip);
80100f37:	59                   	pop    %ecx
80100f38:	ff 73 10             	pushl  0x10(%ebx)
80100f3b:	e8 00 0a 00 00       	call   80101940 <iunlock>
    return 0;
80100f40:	83 c4 10             	add    $0x10,%esp
80100f43:	31 c0                	xor    %eax,%eax
  }
  return -1;
}
80100f45:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100f48:	c9                   	leave  
80100f49:	c3                   	ret    
80100f4a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  return -1;
80100f50:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80100f55:	eb ee                	jmp    80100f45 <filestat+0x35>
80100f57:	89 f6                	mov    %esi,%esi
80100f59:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80100f60 <fileread>:

// Read from file f.
int
fileread(struct file *f, char *addr, int n)
{
80100f60:	55                   	push   %ebp
80100f61:	89 e5                	mov    %esp,%ebp
80100f63:	57                   	push   %edi
80100f64:	56                   	push   %esi
80100f65:	53                   	push   %ebx
80100f66:	83 ec 0c             	sub    $0xc,%esp
80100f69:	8b 5d 08             	mov    0x8(%ebp),%ebx
80100f6c:	8b 75 0c             	mov    0xc(%ebp),%esi
80100f6f:	8b 7d 10             	mov    0x10(%ebp),%edi
  int r;

  if(f->readable == 0)
80100f72:	80 7b 08 00          	cmpb   $0x0,0x8(%ebx)
80100f76:	74 60                	je     80100fd8 <fileread+0x78>
    return -1;
  if(f->type == FD_PIPE)
80100f78:	8b 03                	mov    (%ebx),%eax
80100f7a:	83 f8 01             	cmp    $0x1,%eax
80100f7d:	74 41                	je     80100fc0 <fileread+0x60>
    return piperead(f->pipe, addr, n);
  if(f->type == FD_INODE){
80100f7f:	83 f8 02             	cmp    $0x2,%eax
80100f82:	75 5b                	jne    80100fdf <fileread+0x7f>
    ilock(f->ip);
80100f84:	83 ec 0c             	sub    $0xc,%esp
80100f87:	ff 73 10             	pushl  0x10(%ebx)
80100f8a:	e8 d1 08 00 00       	call   80101860 <ilock>
    if((r = readi(f->ip, addr, f->off, n)) > 0)
80100f8f:	57                   	push   %edi
80100f90:	ff 73 14             	pushl  0x14(%ebx)
80100f93:	56                   	push   %esi
80100f94:	ff 73 10             	pushl  0x10(%ebx)
80100f97:	e8 24 0a 00 00       	call   801019c0 <readi>
80100f9c:	83 c4 20             	add    $0x20,%esp
80100f9f:	85 c0                	test   %eax,%eax
80100fa1:	89 c6                	mov    %eax,%esi
80100fa3:	7e 03                	jle    80100fa8 <fileread+0x48>
      f->off += r;
80100fa5:	01 43 14             	add    %eax,0x14(%ebx)
    iunlock(f->ip);
80100fa8:	83 ec 0c             	sub    $0xc,%esp
80100fab:	ff 73 10             	pushl  0x10(%ebx)
80100fae:	e8 8d 09 00 00       	call   80101940 <iunlock>
    return r;
80100fb3:	83 c4 10             	add    $0x10,%esp
  }
  panic("fileread");
}
80100fb6:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100fb9:	89 f0                	mov    %esi,%eax
80100fbb:	5b                   	pop    %ebx
80100fbc:	5e                   	pop    %esi
80100fbd:	5f                   	pop    %edi
80100fbe:	5d                   	pop    %ebp
80100fbf:	c3                   	ret    
    return piperead(f->pipe, addr, n);
80100fc0:	8b 43 0c             	mov    0xc(%ebx),%eax
80100fc3:	89 45 08             	mov    %eax,0x8(%ebp)
}
80100fc6:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100fc9:	5b                   	pop    %ebx
80100fca:	5e                   	pop    %esi
80100fcb:	5f                   	pop    %edi
80100fcc:	5d                   	pop    %ebp
    return piperead(f->pipe, addr, n);
80100fcd:	e9 ae 2d 00 00       	jmp    80103d80 <piperead>
80100fd2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return -1;
80100fd8:	be ff ff ff ff       	mov    $0xffffffff,%esi
80100fdd:	eb d7                	jmp    80100fb6 <fileread+0x56>
  panic("fileread");
80100fdf:	83 ec 0c             	sub    $0xc,%esp
80100fe2:	68 26 78 10 80       	push   $0x80107826
80100fe7:	e8 a4 f3 ff ff       	call   80100390 <panic>
80100fec:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80100ff0 <filewrite>:

//PAGEBREAK!
// Write to file f.
int
filewrite(struct file *f, char *addr, int n)
{
80100ff0:	55                   	push   %ebp
80100ff1:	89 e5                	mov    %esp,%ebp
80100ff3:	57                   	push   %edi
80100ff4:	56                   	push   %esi
80100ff5:	53                   	push   %ebx
80100ff6:	83 ec 1c             	sub    $0x1c,%esp
80100ff9:	8b 75 08             	mov    0x8(%ebp),%esi
80100ffc:	8b 45 0c             	mov    0xc(%ebp),%eax
  int r;

  if(f->writable == 0)
80100fff:	80 7e 09 00          	cmpb   $0x0,0x9(%esi)
{
80101003:	89 45 dc             	mov    %eax,-0x24(%ebp)
80101006:	8b 45 10             	mov    0x10(%ebp),%eax
80101009:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(f->writable == 0)
8010100c:	0f 84 aa 00 00 00    	je     801010bc <filewrite+0xcc>
    return -1;
  if(f->type == FD_PIPE)
80101012:	8b 06                	mov    (%esi),%eax
80101014:	83 f8 01             	cmp    $0x1,%eax
80101017:	0f 84 c3 00 00 00    	je     801010e0 <filewrite+0xf0>
    return pipewrite(f->pipe, addr, n);
  if(f->type == FD_INODE){
8010101d:	83 f8 02             	cmp    $0x2,%eax
80101020:	0f 85 d9 00 00 00    	jne    801010ff <filewrite+0x10f>
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    // cprintf("COWCOUNTER : %d\n", f->ip->cowcounter);
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * 512;
    int i = 0;
    while(i < n){
80101026:	8b 45 e4             	mov    -0x1c(%ebp),%eax
    int i = 0;
80101029:	31 ff                	xor    %edi,%edi
    while(i < n){
8010102b:	85 c0                	test   %eax,%eax
8010102d:	7f 34                	jg     80101063 <filewrite+0x73>
8010102f:	e9 9c 00 00 00       	jmp    801010d0 <filewrite+0xe0>
80101034:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
        n1 = max;
      // if(f->ip->cowcounter >0) cprintf("GGGG\n");
      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
        f->off += r;
80101038:	01 46 14             	add    %eax,0x14(%esi)
      iunlock(f->ip);
8010103b:	83 ec 0c             	sub    $0xc,%esp
8010103e:	ff 76 10             	pushl  0x10(%esi)
        f->off += r;
80101041:	89 45 e0             	mov    %eax,-0x20(%ebp)
      iunlock(f->ip);
80101044:	e8 f7 08 00 00       	call   80101940 <iunlock>
      end_op();
80101049:	e8 42 24 00 00       	call   80103490 <end_op>
8010104e:	8b 45 e0             	mov    -0x20(%ebp),%eax
80101051:	83 c4 10             	add    $0x10,%esp

      if(r < 0)
        break;
      if(r != n1)
80101054:	39 c3                	cmp    %eax,%ebx
80101056:	0f 85 96 00 00 00    	jne    801010f2 <filewrite+0x102>
        panic("short filewrite");
      i += r;
8010105c:	01 df                	add    %ebx,%edi
    while(i < n){
8010105e:	39 7d e4             	cmp    %edi,-0x1c(%ebp)
80101061:	7e 6d                	jle    801010d0 <filewrite+0xe0>
      int n1 = n - i;
80101063:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80101066:	b8 00 06 00 00       	mov    $0x600,%eax
8010106b:	29 fb                	sub    %edi,%ebx
8010106d:	81 fb 00 06 00 00    	cmp    $0x600,%ebx
80101073:	0f 4f d8             	cmovg  %eax,%ebx
      begin_op();
80101076:	e8 a5 23 00 00       	call   80103420 <begin_op>
      ilock(f->ip);
8010107b:	83 ec 0c             	sub    $0xc,%esp
8010107e:	ff 76 10             	pushl  0x10(%esi)
80101081:	e8 da 07 00 00       	call   80101860 <ilock>
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
80101086:	8b 45 dc             	mov    -0x24(%ebp),%eax
80101089:	53                   	push   %ebx
8010108a:	ff 76 14             	pushl  0x14(%esi)
8010108d:	01 f8                	add    %edi,%eax
8010108f:	50                   	push   %eax
80101090:	ff 76 10             	pushl  0x10(%esi)
80101093:	e8 f8 0d 00 00       	call   80101e90 <writei>
80101098:	83 c4 20             	add    $0x20,%esp
8010109b:	85 c0                	test   %eax,%eax
8010109d:	7f 99                	jg     80101038 <filewrite+0x48>
      iunlock(f->ip);
8010109f:	83 ec 0c             	sub    $0xc,%esp
801010a2:	ff 76 10             	pushl  0x10(%esi)
801010a5:	89 45 e0             	mov    %eax,-0x20(%ebp)
801010a8:	e8 93 08 00 00       	call   80101940 <iunlock>
      end_op();
801010ad:	e8 de 23 00 00       	call   80103490 <end_op>
      if(r < 0)
801010b2:	8b 45 e0             	mov    -0x20(%ebp),%eax
801010b5:	83 c4 10             	add    $0x10,%esp
801010b8:	85 c0                	test   %eax,%eax
801010ba:	74 98                	je     80101054 <filewrite+0x64>
    }
    return i == n ? n : -1;
  }
  panic("filewrite");
}
801010bc:	8d 65 f4             	lea    -0xc(%ebp),%esp
    return -1;
801010bf:	bf ff ff ff ff       	mov    $0xffffffff,%edi
}
801010c4:	89 f8                	mov    %edi,%eax
801010c6:	5b                   	pop    %ebx
801010c7:	5e                   	pop    %esi
801010c8:	5f                   	pop    %edi
801010c9:	5d                   	pop    %ebp
801010ca:	c3                   	ret    
801010cb:	90                   	nop
801010cc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    return i == n ? n : -1;
801010d0:	39 7d e4             	cmp    %edi,-0x1c(%ebp)
801010d3:	75 e7                	jne    801010bc <filewrite+0xcc>
}
801010d5:	8d 65 f4             	lea    -0xc(%ebp),%esp
801010d8:	89 f8                	mov    %edi,%eax
801010da:	5b                   	pop    %ebx
801010db:	5e                   	pop    %esi
801010dc:	5f                   	pop    %edi
801010dd:	5d                   	pop    %ebp
801010de:	c3                   	ret    
801010df:	90                   	nop
    return pipewrite(f->pipe, addr, n);
801010e0:	8b 46 0c             	mov    0xc(%esi),%eax
801010e3:	89 45 08             	mov    %eax,0x8(%ebp)
}
801010e6:	8d 65 f4             	lea    -0xc(%ebp),%esp
801010e9:	5b                   	pop    %ebx
801010ea:	5e                   	pop    %esi
801010eb:	5f                   	pop    %edi
801010ec:	5d                   	pop    %ebp
    return pipewrite(f->pipe, addr, n);
801010ed:	e9 7e 2b 00 00       	jmp    80103c70 <pipewrite>
        panic("short filewrite");
801010f2:	83 ec 0c             	sub    $0xc,%esp
801010f5:	68 2f 78 10 80       	push   $0x8010782f
801010fa:	e8 91 f2 ff ff       	call   80100390 <panic>
  panic("filewrite");
801010ff:	83 ec 0c             	sub    $0xc,%esp
80101102:	68 35 78 10 80       	push   $0x80107835
80101107:	e8 84 f2 ff ff       	call   80100390 <panic>
8010110c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80101110 <filecopy>:

// SJ
int
filecopy(struct file *fds, struct file *fdd){
80101110:	55                   	push   %ebp
80101111:	89 e5                	mov    %esp,%ebp
80101113:	57                   	push   %edi
80101114:	56                   	push   %esi
80101115:	53                   	push   %ebx
80101116:	81 ec 1c 02 00 00    	sub    $0x21c,%esp
  int r, n;
  char buffer[512];

  if(fds->readable == 0 || fdd->writable == 0){
8010111c:	8b 45 08             	mov    0x8(%ebp),%eax
filecopy(struct file *fds, struct file *fdd){
8010111f:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  if(fds->readable == 0 || fdd->writable == 0){
80101122:	80 78 08 00          	cmpb   $0x0,0x8(%eax)
80101126:	0f 84 3f 01 00 00    	je     8010126b <filecopy+0x15b>
8010112c:	80 7b 09 00          	cmpb   $0x0,0x9(%ebx)
80101130:	0f 84 35 01 00 00    	je     8010126b <filecopy+0x15b>
    return -1;
  }
  if(fds->type == FD_PIPE || fdd->type == FD_PIPE)
80101136:	8b 45 08             	mov    0x8(%ebp),%eax
80101139:	8b 00                	mov    (%eax),%eax
8010113b:	83 f8 01             	cmp    $0x1,%eax
8010113e:	0f 84 27 01 00 00    	je     8010126b <filecopy+0x15b>
    return -1; // EZE 
  if(fds->type == FD_INODE && fdd->type == FD_INODE){
80101144:	83 3b 02             	cmpl   $0x2,(%ebx)
80101147:	0f 85 1e 01 00 00    	jne    8010126b <filecopy+0x15b>
8010114d:	83 f8 02             	cmp    $0x2,%eax
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * 512;
    
    int total_bytes_copied = 0;
80101150:	c7 85 dc fd ff ff 00 	movl   $0x0,-0x224(%ebp)
80101157:	00 00 00 
  if(fds->type == FD_INODE && fdd->type == FD_INODE){
8010115a:	0f 85 0b 01 00 00    	jne    8010126b <filecopy+0x15b>

    while((n = readi(fds->ip, buffer, fds->off , sizeof(buffer))) > 0){
80101160:	8b 45 08             	mov    0x8(%ebp),%eax
80101163:	68 00 02 00 00       	push   $0x200
80101168:	ff 70 14             	pushl  0x14(%eax)
8010116b:	8d 85 e8 fd ff ff    	lea    -0x218(%ebp),%eax
80101171:	50                   	push   %eax
80101172:	8b 45 08             	mov    0x8(%ebp),%eax
80101175:	ff 70 10             	pushl  0x10(%eax)
80101178:	e8 43 08 00 00       	call   801019c0 <readi>
8010117d:	83 c4 10             	add    $0x10,%esp
80101180:	85 c0                	test   %eax,%eax
80101182:	89 85 e4 fd ff ff    	mov    %eax,-0x21c(%ebp)
80101188:	0f 8e f5 00 00 00    	jle    80101283 <filecopy+0x173>
      fds->off += n; //
8010118e:	8b 45 08             	mov    0x8(%ebp),%eax
80101191:	8b 8d e4 fd ff ff    	mov    -0x21c(%ebp),%ecx
      int i = 0;
80101197:	31 ff                	xor    %edi,%edi
      fds->off += n; //
80101199:	01 48 14             	add    %ecx,0x14(%eax)
8010119c:	eb 3c                	jmp    801011da <filecopy+0xca>
8010119e:	66 90                	xchg   %ax,%ax

          begin_op();
          ilock(fdd->ip);
          sync_inode(fdd->ip, fds->ip,buffer +i, fdd->off,n1);
          if ((r = writei(fdd->ip, buffer + i, fdd->off, n1)) > 0)
              fdd->off += r;
801011a0:	01 43 14             	add    %eax,0x14(%ebx)
          iunlock(fdd->ip);
801011a3:	83 ec 0c             	sub    $0xc,%esp
801011a6:	ff 73 10             	pushl  0x10(%ebx)
              fdd->off += r;
801011a9:	89 85 e0 fd ff ff    	mov    %eax,-0x220(%ebp)
          iunlock(fdd->ip);
801011af:	e8 8c 07 00 00       	call   80101940 <iunlock>
          end_op();
801011b4:	e8 d7 22 00 00       	call   80103490 <end_op>
801011b9:	8b 85 e0 fd ff ff    	mov    -0x220(%ebp),%eax
801011bf:	83 c4 10             	add    $0x10,%esp

          if(r < 0)
              return -1;
          if(r != n1)
801011c2:	39 f0                	cmp    %esi,%eax
801011c4:	0f 85 d6 00 00 00    	jne    801012a0 <filecopy+0x190>
              panic("short filewrite");

          i += r;
801011ca:	01 c7                	add    %eax,%edi
          total_bytes_copied += r;
801011cc:	01 85 dc fd ff ff    	add    %eax,-0x224(%ebp)
      while(i < n){
801011d2:	39 bd e4 fd ff ff    	cmp    %edi,-0x21c(%ebp)
801011d8:	7e 86                	jle    80101160 <filecopy+0x50>
          int n1 = n - i;
801011da:	8b b5 e4 fd ff ff    	mov    -0x21c(%ebp),%esi
801011e0:	b8 00 06 00 00       	mov    $0x600,%eax
801011e5:	29 fe                	sub    %edi,%esi
801011e7:	81 fe 00 06 00 00    	cmp    $0x600,%esi
801011ed:	0f 4f f0             	cmovg  %eax,%esi
          begin_op();
801011f0:	e8 2b 22 00 00       	call   80103420 <begin_op>
          ilock(fdd->ip);
801011f5:	83 ec 0c             	sub    $0xc,%esp
801011f8:	ff 73 10             	pushl  0x10(%ebx)
801011fb:	e8 60 06 00 00       	call   80101860 <ilock>
          sync_inode(fdd->ip, fds->ip,buffer +i, fdd->off,n1);
80101200:	8d 85 e8 fd ff ff    	lea    -0x218(%ebp),%eax
80101206:	89 34 24             	mov    %esi,(%esp)
80101209:	ff 73 14             	pushl  0x14(%ebx)
8010120c:	01 f8                	add    %edi,%eax
8010120e:	50                   	push   %eax
8010120f:	89 85 e0 fd ff ff    	mov    %eax,-0x220(%ebp)
80101215:	8b 45 08             	mov    0x8(%ebp),%eax
80101218:	ff 70 10             	pushl  0x10(%eax)
8010121b:	ff 73 10             	pushl  0x10(%ebx)
8010121e:	e8 ad 10 00 00       	call   801022d0 <sync_inode>
          if ((r = writei(fdd->ip, buffer + i, fdd->off, n1)) > 0)
80101223:	8b 85 e0 fd ff ff    	mov    -0x220(%ebp),%eax
80101229:	83 c4 20             	add    $0x20,%esp
8010122c:	56                   	push   %esi
8010122d:	ff 73 14             	pushl  0x14(%ebx)
80101230:	50                   	push   %eax
80101231:	ff 73 10             	pushl  0x10(%ebx)
80101234:	e8 57 0c 00 00       	call   80101e90 <writei>
80101239:	83 c4 10             	add    $0x10,%esp
8010123c:	85 c0                	test   %eax,%eax
8010123e:	0f 8f 5c ff ff ff    	jg     801011a0 <filecopy+0x90>
          iunlock(fdd->ip);
80101244:	83 ec 0c             	sub    $0xc,%esp
80101247:	ff 73 10             	pushl  0x10(%ebx)
8010124a:	89 85 e0 fd ff ff    	mov    %eax,-0x220(%ebp)
80101250:	e8 eb 06 00 00       	call   80101940 <iunlock>
          end_op();
80101255:	e8 36 22 00 00       	call   80103490 <end_op>
          if(r < 0)
8010125a:	8b 85 e0 fd ff ff    	mov    -0x220(%ebp),%eax
80101260:	83 c4 10             	add    $0x10,%esp
80101263:	85 c0                	test   %eax,%eax
80101265:	0f 84 57 ff ff ff    	je     801011c2 <filecopy+0xb2>
    return -1;
8010126b:	c7 85 dc fd ff ff ff 	movl   $0xffffffff,-0x224(%ebp)
80101272:	ff ff ff 
    // 3. [inode cache likedlist] 구현 필요 ----- 
    // 4. [test case] 추가 구현 필요  ------- 

  }
  return -1;
}
80101275:	8b 85 dc fd ff ff    	mov    -0x224(%ebp),%eax
8010127b:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010127e:	5b                   	pop    %ebx
8010127f:	5e                   	pop    %esi
80101280:	5f                   	pop    %edi
80101281:	5d                   	pop    %ebp
80101282:	c3                   	ret    
    fdd->ip->cowcounter +=1;
80101283:	8b 43 10             	mov    0x10(%ebx),%eax
80101286:	83 40 50 01          	addl   $0x1,0x50(%eax)
    fds->ip->cowcounter +=2;
8010128a:	8b 45 08             	mov    0x8(%ebp),%eax
8010128d:	8b 40 10             	mov    0x10(%eax),%eax
80101290:	83 40 50 02          	addl   $0x2,0x50(%eax)
    if(n < 0) return -1;
80101294:	8b 85 e4 fd ff ff    	mov    -0x21c(%ebp),%eax
8010129a:	85 c0                	test   %eax,%eax
8010129c:	74 d7                	je     80101275 <filecopy+0x165>
8010129e:	eb cb                	jmp    8010126b <filecopy+0x15b>
              panic("short filewrite");
801012a0:	83 ec 0c             	sub    $0xc,%esp
801012a3:	68 2f 78 10 80       	push   $0x8010782f
801012a8:	e8 e3 f0 ff ff       	call   80100390 <panic>
801012ad:	66 90                	xchg   %ax,%ax
801012af:	90                   	nop

801012b0 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
801012b0:	55                   	push   %ebp
801012b1:	89 e5                	mov    %esp,%ebp
801012b3:	56                   	push   %esi
801012b4:	53                   	push   %ebx
801012b5:	89 d3                	mov    %edx,%ebx
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
801012b7:	c1 ea 0c             	shr    $0xc,%edx
801012ba:	03 15 d8 19 11 80    	add    0x801119d8,%edx
801012c0:	83 ec 08             	sub    $0x8,%esp
801012c3:	52                   	push   %edx
801012c4:	50                   	push   %eax
801012c5:	e8 06 ee ff ff       	call   801000d0 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
801012ca:	89 d9                	mov    %ebx,%ecx
  if((bp->data[bi/8] & m) == 0)
801012cc:	c1 fb 03             	sar    $0x3,%ebx
  m = 1 << (bi % 8);
801012cf:	ba 01 00 00 00       	mov    $0x1,%edx
801012d4:	83 e1 07             	and    $0x7,%ecx
  if((bp->data[bi/8] & m) == 0)
801012d7:	81 e3 ff 01 00 00    	and    $0x1ff,%ebx
801012dd:	83 c4 10             	add    $0x10,%esp
  m = 1 << (bi % 8);
801012e0:	d3 e2                	shl    %cl,%edx
  if((bp->data[bi/8] & m) == 0)
801012e2:	0f b6 4c 18 5c       	movzbl 0x5c(%eax,%ebx,1),%ecx
801012e7:	85 d1                	test   %edx,%ecx
801012e9:	74 25                	je     80101310 <bfree+0x60>
    panic("freeing free block"); // EZE 
  bp->data[bi/8] &= ~m;
801012eb:	f7 d2                	not    %edx
801012ed:	89 c6                	mov    %eax,%esi
  log_write(bp);
801012ef:	83 ec 0c             	sub    $0xc,%esp
  bp->data[bi/8] &= ~m;
801012f2:	21 ca                	and    %ecx,%edx
801012f4:	88 54 1e 5c          	mov    %dl,0x5c(%esi,%ebx,1)
  log_write(bp);
801012f8:	56                   	push   %esi
801012f9:	e8 f2 22 00 00       	call   801035f0 <log_write>
  brelse(bp);
801012fe:	89 34 24             	mov    %esi,(%esp)
80101301:	e8 da ee ff ff       	call   801001e0 <brelse>
}
80101306:	83 c4 10             	add    $0x10,%esp
80101309:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010130c:	5b                   	pop    %ebx
8010130d:	5e                   	pop    %esi
8010130e:	5d                   	pop    %ebp
8010130f:	c3                   	ret    
    panic("freeing free block"); // EZE 
80101310:	83 ec 0c             	sub    $0xc,%esp
80101313:	68 3f 78 10 80       	push   $0x8010783f
80101318:	e8 73 f0 ff ff       	call   80100390 <panic>
8010131d:	8d 76 00             	lea    0x0(%esi),%esi

80101320 <balloc>:
{
80101320:	55                   	push   %ebp
80101321:	89 e5                	mov    %esp,%ebp
80101323:	57                   	push   %edi
80101324:	56                   	push   %esi
80101325:	53                   	push   %ebx
80101326:	83 ec 1c             	sub    $0x1c,%esp
  for(b = 0; b < sb.size; b += BPB){
80101329:	8b 0d c0 19 11 80    	mov    0x801119c0,%ecx
{
8010132f:	89 45 d8             	mov    %eax,-0x28(%ebp)
  for(b = 0; b < sb.size; b += BPB){
80101332:	85 c9                	test   %ecx,%ecx
80101334:	0f 84 87 00 00 00    	je     801013c1 <balloc+0xa1>
8010133a:	c7 45 dc 00 00 00 00 	movl   $0x0,-0x24(%ebp)
    bp = bread(dev, BBLOCK(b, sb));
80101341:	8b 75 dc             	mov    -0x24(%ebp),%esi
80101344:	83 ec 08             	sub    $0x8,%esp
80101347:	89 f0                	mov    %esi,%eax
80101349:	c1 f8 0c             	sar    $0xc,%eax
8010134c:	03 05 d8 19 11 80    	add    0x801119d8,%eax
80101352:	50                   	push   %eax
80101353:	ff 75 d8             	pushl  -0x28(%ebp)
80101356:	e8 75 ed ff ff       	call   801000d0 <bread>
8010135b:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
8010135e:	a1 c0 19 11 80       	mov    0x801119c0,%eax
80101363:	83 c4 10             	add    $0x10,%esp
80101366:	89 45 e0             	mov    %eax,-0x20(%ebp)
80101369:	31 c0                	xor    %eax,%eax
8010136b:	eb 2f                	jmp    8010139c <balloc+0x7c>
8010136d:	8d 76 00             	lea    0x0(%esi),%esi
      m = 1 << (bi % 8);
80101370:	89 c1                	mov    %eax,%ecx
      if((bp->data[bi/8] & m) == 0){  // Is block free?
80101372:	8b 55 e4             	mov    -0x1c(%ebp),%edx
      m = 1 << (bi % 8);
80101375:	bb 01 00 00 00       	mov    $0x1,%ebx
8010137a:	83 e1 07             	and    $0x7,%ecx
8010137d:	d3 e3                	shl    %cl,%ebx
      if((bp->data[bi/8] & m) == 0){  // Is block free?
8010137f:	89 c1                	mov    %eax,%ecx
80101381:	c1 f9 03             	sar    $0x3,%ecx
80101384:	0f b6 7c 0a 5c       	movzbl 0x5c(%edx,%ecx,1),%edi
80101389:	85 df                	test   %ebx,%edi
8010138b:	89 fa                	mov    %edi,%edx
8010138d:	74 41                	je     801013d0 <balloc+0xb0>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
8010138f:	83 c0 01             	add    $0x1,%eax
80101392:	83 c6 01             	add    $0x1,%esi
80101395:	3d 00 10 00 00       	cmp    $0x1000,%eax
8010139a:	74 05                	je     801013a1 <balloc+0x81>
8010139c:	39 75 e0             	cmp    %esi,-0x20(%ebp)
8010139f:	77 cf                	ja     80101370 <balloc+0x50>
    brelse(bp);
801013a1:	83 ec 0c             	sub    $0xc,%esp
801013a4:	ff 75 e4             	pushl  -0x1c(%ebp)
801013a7:	e8 34 ee ff ff       	call   801001e0 <brelse>
  for(b = 0; b < sb.size; b += BPB){
801013ac:	81 45 dc 00 10 00 00 	addl   $0x1000,-0x24(%ebp)
801013b3:	83 c4 10             	add    $0x10,%esp
801013b6:	8b 45 dc             	mov    -0x24(%ebp),%eax
801013b9:	39 05 c0 19 11 80    	cmp    %eax,0x801119c0
801013bf:	77 80                	ja     80101341 <balloc+0x21>
  panic("balloc: out of blocks");
801013c1:	83 ec 0c             	sub    $0xc,%esp
801013c4:	68 52 78 10 80       	push   $0x80107852
801013c9:	e8 c2 ef ff ff       	call   80100390 <panic>
801013ce:	66 90                	xchg   %ax,%ax
        bp->data[bi/8] |= m;  // Mark block in use.
801013d0:	8b 7d e4             	mov    -0x1c(%ebp),%edi
        log_write(bp);
801013d3:	83 ec 0c             	sub    $0xc,%esp
        bp->data[bi/8] |= m;  // Mark block in use.
801013d6:	09 da                	or     %ebx,%edx
801013d8:	88 54 0f 5c          	mov    %dl,0x5c(%edi,%ecx,1)
        log_write(bp);
801013dc:	57                   	push   %edi
801013dd:	e8 0e 22 00 00       	call   801035f0 <log_write>
        brelse(bp);
801013e2:	89 3c 24             	mov    %edi,(%esp)
801013e5:	e8 f6 ed ff ff       	call   801001e0 <brelse>
  bp = bread(dev, bno);
801013ea:	58                   	pop    %eax
801013eb:	5a                   	pop    %edx
801013ec:	56                   	push   %esi
801013ed:	ff 75 d8             	pushl  -0x28(%ebp)
801013f0:	e8 db ec ff ff       	call   801000d0 <bread>
801013f5:	89 c3                	mov    %eax,%ebx
  memset(bp->data, 0, BSIZE);
801013f7:	8d 40 5c             	lea    0x5c(%eax),%eax
801013fa:	83 c4 0c             	add    $0xc,%esp
801013fd:	68 00 02 00 00       	push   $0x200
80101402:	6a 00                	push   $0x0
80101404:	50                   	push   %eax
80101405:	e8 c6 38 00 00       	call   80104cd0 <memset>
  log_write(bp);
8010140a:	89 1c 24             	mov    %ebx,(%esp)
8010140d:	e8 de 21 00 00       	call   801035f0 <log_write>
  brelse(bp);
80101412:	89 1c 24             	mov    %ebx,(%esp)
80101415:	e8 c6 ed ff ff       	call   801001e0 <brelse>
}
8010141a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010141d:	89 f0                	mov    %esi,%eax
8010141f:	5b                   	pop    %ebx
80101420:	5e                   	pop    %esi
80101421:	5f                   	pop    %edi
80101422:	5d                   	pop    %ebp
80101423:	c3                   	ret    
80101424:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
8010142a:	8d bf 00 00 00 00    	lea    0x0(%edi),%edi

80101430 <iget>:
// Find the inode with number inum on device dev
// and return the in-memory copy. Does not lock
// the inode and does not read it from disk.
static struct inode*
iget(uint dev, uint inum)
{
80101430:	55                   	push   %ebp
80101431:	89 e5                	mov    %esp,%ebp
80101433:	57                   	push   %edi
80101434:	56                   	push   %esi
80101435:	53                   	push   %ebx
80101436:	89 c7                	mov    %eax,%edi
  struct inode *ip, *empty;

  acquire(&icache.lock);

  // Is the inode already cached?
  empty = 0;
80101438:	31 f6                	xor    %esi,%esi
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
8010143a:	bb 14 1a 11 80       	mov    $0x80111a14,%ebx
{
8010143f:	83 ec 28             	sub    $0x28,%esp
80101442:	89 55 e4             	mov    %edx,-0x1c(%ebp)
  acquire(&icache.lock);
80101445:	68 e0 19 11 80       	push   $0x801119e0
8010144a:	e8 71 37 00 00       	call   80104bc0 <acquire>
8010144f:	83 c4 10             	add    $0x10,%esp
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101452:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80101455:	eb 17                	jmp    8010146e <iget+0x3e>
80101457:	89 f6                	mov    %esi,%esi
80101459:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
80101460:	81 c3 94 00 00 00    	add    $0x94,%ebx
80101466:	81 fb e4 53 11 80    	cmp    $0x801153e4,%ebx
8010146c:	73 22                	jae    80101490 <iget+0x60>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
8010146e:	8b 4b 08             	mov    0x8(%ebx),%ecx
80101471:	85 c9                	test   %ecx,%ecx
80101473:	7e 04                	jle    80101479 <iget+0x49>
80101475:	39 3b                	cmp    %edi,(%ebx)
80101477:	74 67                	je     801014e0 <iget+0xb0>
      ip->ref++;
      release(&icache.lock);
      return ip;
    }
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
80101479:	85 f6                	test   %esi,%esi
8010147b:	75 e3                	jne    80101460 <iget+0x30>
8010147d:	85 c9                	test   %ecx,%ecx
8010147f:	0f 44 f3             	cmove  %ebx,%esi
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101482:	81 c3 94 00 00 00    	add    $0x94,%ebx
80101488:	81 fb e4 53 11 80    	cmp    $0x801153e4,%ebx
8010148e:	72 de                	jb     8010146e <iget+0x3e>
      empty = ip;
  }

  // Recycle an inode cache entry.
  if(empty == 0)
80101490:	85 f6                	test   %esi,%esi
80101492:	74 71                	je     80101505 <iget+0xd5>
  ip->cowcounter = 0; // EZE 
  icache.ic=0; // EZE
  icache.status=0; // EZE
  // for(int i=0;i<10;i++) icache.inode_table1[i]=0;
  // for(int i=0;i<10;i++) icache.inode_table2[i]=0;
  release(&icache.lock);
80101494:	83 ec 0c             	sub    $0xc,%esp
  ip->dev = dev;
80101497:	89 3e                	mov    %edi,(%esi)
  ip->inum = inum;
80101499:	89 56 04             	mov    %edx,0x4(%esi)
  ip->ref = 1;
8010149c:	c7 46 08 01 00 00 00 	movl   $0x1,0x8(%esi)
  ip->valid = 0;
801014a3:	c7 46 4c 00 00 00 00 	movl   $0x0,0x4c(%esi)

  return ip;
801014aa:	89 f3                	mov    %esi,%ebx
  ip->cowcounter = 0; // EZE 
801014ac:	c7 46 50 00 00 00 00 	movl   $0x0,0x50(%esi)
  release(&icache.lock);
801014b3:	68 e0 19 11 80       	push   $0x801119e0
  icache.ic=0; // EZE
801014b8:	c7 05 34 54 11 80 00 	movl   $0x0,0x80115434
801014bf:	00 00 00 
  icache.status=0; // EZE
801014c2:	c7 05 38 54 11 80 00 	movl   $0x0,0x80115438
801014c9:	00 00 00 
  release(&icache.lock);
801014cc:	e8 af 37 00 00       	call   80104c80 <release>
  return ip;
801014d1:	83 c4 10             	add    $0x10,%esp
}
801014d4:	8d 65 f4             	lea    -0xc(%ebp),%esp
801014d7:	89 d8                	mov    %ebx,%eax
801014d9:	5b                   	pop    %ebx
801014da:	5e                   	pop    %esi
801014db:	5f                   	pop    %edi
801014dc:	5d                   	pop    %ebp
801014dd:	c3                   	ret    
801014de:	66 90                	xchg   %ax,%ax
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
801014e0:	39 53 04             	cmp    %edx,0x4(%ebx)
801014e3:	75 94                	jne    80101479 <iget+0x49>
      release(&icache.lock);
801014e5:	83 ec 0c             	sub    $0xc,%esp
      ip->ref++;
801014e8:	83 c1 01             	add    $0x1,%ecx
801014eb:	89 4b 08             	mov    %ecx,0x8(%ebx)
      release(&icache.lock);
801014ee:	68 e0 19 11 80       	push   $0x801119e0
801014f3:	e8 88 37 00 00       	call   80104c80 <release>
      return ip;
801014f8:	83 c4 10             	add    $0x10,%esp
}
801014fb:	8d 65 f4             	lea    -0xc(%ebp),%esp
801014fe:	89 d8                	mov    %ebx,%eax
80101500:	5b                   	pop    %ebx
80101501:	5e                   	pop    %esi
80101502:	5f                   	pop    %edi
80101503:	5d                   	pop    %ebp
80101504:	c3                   	ret    
    panic("iget: no inodes");
80101505:	83 ec 0c             	sub    $0xc,%esp
80101508:	68 68 78 10 80       	push   $0x80107868
8010150d:	e8 7e ee ff ff       	call   80100390 <panic>
80101512:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80101519:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80101520 <bmap>:

// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
static uint
bmap(struct inode *ip, uint bn)
{
80101520:	55                   	push   %ebp
80101521:	89 e5                	mov    %esp,%ebp
80101523:	57                   	push   %edi
80101524:	56                   	push   %esi
80101525:	53                   	push   %ebx
80101526:	89 c6                	mov    %eax,%esi
80101528:	83 ec 1c             	sub    $0x1c,%esp
  uint addr, *a;
  struct buf *bp;
 
  if(bn < NDIRECT){
8010152b:	83 fa 0b             	cmp    $0xb,%edx
8010152e:	77 18                	ja     80101548 <bmap+0x28>
80101530:	8d 3c 90             	lea    (%eax,%edx,4),%edi
    if((addr = ip->addrs[bn]) == 0){
80101533:	8b 5f 60             	mov    0x60(%edi),%ebx
80101536:	85 db                	test   %ebx,%ebx
80101538:	74 76                	je     801015b0 <bmap+0x90>
    }
    brelse(bp);
    return addr;
  }
  panic("bmap: out of range");
}
8010153a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010153d:	89 d8                	mov    %ebx,%eax
8010153f:	5b                   	pop    %ebx
80101540:	5e                   	pop    %esi
80101541:	5f                   	pop    %edi
80101542:	5d                   	pop    %ebp
80101543:	c3                   	ret    
80101544:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  bn -= NDIRECT;
80101548:	8d 5a f4             	lea    -0xc(%edx),%ebx
  if(bn < NINDIRECT){
8010154b:	83 fb 7f             	cmp    $0x7f,%ebx
8010154e:	0f 87 b0 00 00 00    	ja     80101604 <bmap+0xe4>
    if((addr = ip->addrs[NDIRECT]) == 0){
80101554:	8b b8 90 00 00 00    	mov    0x90(%eax),%edi
8010155a:	8b 00                	mov    (%eax),%eax
8010155c:	85 ff                	test   %edi,%edi
8010155e:	0f 84 7c 00 00 00    	je     801015e0 <bmap+0xc0>
    bp = bread(ip->dev, addr);
80101564:	83 ec 08             	sub    $0x8,%esp
80101567:	57                   	push   %edi
80101568:	50                   	push   %eax
80101569:	e8 62 eb ff ff       	call   801000d0 <bread>
    if((addr = a[bn]) == 0){
8010156e:	8d 54 98 5c          	lea    0x5c(%eax,%ebx,4),%edx
80101572:	83 c4 10             	add    $0x10,%esp
    bp = bread(ip->dev, addr);
80101575:	89 c7                	mov    %eax,%edi
    if((addr = a[bn]) == 0){
80101577:	8b 1a                	mov    (%edx),%ebx
80101579:	85 db                	test   %ebx,%ebx
8010157b:	75 1d                	jne    8010159a <bmap+0x7a>
      a[bn] = addr = balloc(ip->dev);
8010157d:	8b 06                	mov    (%esi),%eax
8010157f:	89 55 e4             	mov    %edx,-0x1c(%ebp)
80101582:	e8 99 fd ff ff       	call   80101320 <balloc>
80101587:	8b 55 e4             	mov    -0x1c(%ebp),%edx
      log_write(bp);
8010158a:	83 ec 0c             	sub    $0xc,%esp
      a[bn] = addr = balloc(ip->dev);
8010158d:	89 c3                	mov    %eax,%ebx
8010158f:	89 02                	mov    %eax,(%edx)
      log_write(bp);
80101591:	57                   	push   %edi
80101592:	e8 59 20 00 00       	call   801035f0 <log_write>
80101597:	83 c4 10             	add    $0x10,%esp
    brelse(bp);
8010159a:	83 ec 0c             	sub    $0xc,%esp
8010159d:	57                   	push   %edi
8010159e:	e8 3d ec ff ff       	call   801001e0 <brelse>
801015a3:	83 c4 10             	add    $0x10,%esp
}
801015a6:	8d 65 f4             	lea    -0xc(%ebp),%esp
801015a9:	89 d8                	mov    %ebx,%eax
801015ab:	5b                   	pop    %ebx
801015ac:	5e                   	pop    %esi
801015ad:	5f                   	pop    %edi
801015ae:	5d                   	pop    %ebp
801015af:	c3                   	ret    
      ip->addrs[bn] = addr = balloc(ip->dev);
801015b0:	8b 00                	mov    (%eax),%eax
801015b2:	e8 69 fd ff ff       	call   80101320 <balloc>
      cprintf("[Block allocate by direct inode]\n"); // EZE
801015b7:	83 ec 0c             	sub    $0xc,%esp
      ip->addrs[bn] = addr = balloc(ip->dev);
801015ba:	89 47 60             	mov    %eax,0x60(%edi)
801015bd:	89 c3                	mov    %eax,%ebx
      cprintf("[Block allocate by direct inode]\n"); // EZE
801015bf:	68 64 79 10 80       	push   $0x80107964
801015c4:	e8 97 f0 ff ff       	call   80100660 <cprintf>
801015c9:	83 c4 10             	add    $0x10,%esp
}
801015cc:	8d 65 f4             	lea    -0xc(%ebp),%esp
801015cf:	89 d8                	mov    %ebx,%eax
801015d1:	5b                   	pop    %ebx
801015d2:	5e                   	pop    %esi
801015d3:	5f                   	pop    %edi
801015d4:	5d                   	pop    %ebp
801015d5:	c3                   	ret    
801015d6:	8d 76 00             	lea    0x0(%esi),%esi
801015d9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
801015e0:	e8 3b fd ff ff       	call   80101320 <balloc>
      cprintf("[Block allocate by indirect inode]\n"); // EZE
801015e5:	83 ec 0c             	sub    $0xc,%esp
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
801015e8:	89 86 90 00 00 00    	mov    %eax,0x90(%esi)
801015ee:	89 c7                	mov    %eax,%edi
      cprintf("[Block allocate by indirect inode]\n"); // EZE
801015f0:	68 88 79 10 80       	push   $0x80107988
801015f5:	e8 66 f0 ff ff       	call   80100660 <cprintf>
801015fa:	8b 06                	mov    (%esi),%eax
801015fc:	83 c4 10             	add    $0x10,%esp
801015ff:	e9 60 ff ff ff       	jmp    80101564 <bmap+0x44>
  panic("bmap: out of range");
80101604:	83 ec 0c             	sub    $0xc,%esp
80101607:	68 78 78 10 80       	push   $0x80107878
8010160c:	e8 7f ed ff ff       	call   80100390 <panic>
80101611:	eb 0d                	jmp    80101620 <readsb>
80101613:	90                   	nop
80101614:	90                   	nop
80101615:	90                   	nop
80101616:	90                   	nop
80101617:	90                   	nop
80101618:	90                   	nop
80101619:	90                   	nop
8010161a:	90                   	nop
8010161b:	90                   	nop
8010161c:	90                   	nop
8010161d:	90                   	nop
8010161e:	90                   	nop
8010161f:	90                   	nop

80101620 <readsb>:
{
80101620:	55                   	push   %ebp
80101621:	89 e5                	mov    %esp,%ebp
80101623:	56                   	push   %esi
80101624:	53                   	push   %ebx
80101625:	8b 75 0c             	mov    0xc(%ebp),%esi
  bp = bread(dev, 1);
80101628:	83 ec 08             	sub    $0x8,%esp
8010162b:	6a 01                	push   $0x1
8010162d:	ff 75 08             	pushl  0x8(%ebp)
80101630:	e8 9b ea ff ff       	call   801000d0 <bread>
80101635:	89 c3                	mov    %eax,%ebx
  memmove(sb, bp->data, sizeof(*sb));
80101637:	8d 40 5c             	lea    0x5c(%eax),%eax
8010163a:	83 c4 0c             	add    $0xc,%esp
8010163d:	6a 1c                	push   $0x1c
8010163f:	50                   	push   %eax
80101640:	56                   	push   %esi
80101641:	e8 3a 37 00 00       	call   80104d80 <memmove>
  brelse(bp);
80101646:	89 5d 08             	mov    %ebx,0x8(%ebp)
80101649:	83 c4 10             	add    $0x10,%esp
}
8010164c:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010164f:	5b                   	pop    %ebx
80101650:	5e                   	pop    %esi
80101651:	5d                   	pop    %ebp
  brelse(bp);
80101652:	e9 89 eb ff ff       	jmp    801001e0 <brelse>
80101657:	89 f6                	mov    %esi,%esi
80101659:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80101660 <iinit>:
{
80101660:	55                   	push   %ebp
80101661:	89 e5                	mov    %esp,%ebp
80101663:	53                   	push   %ebx
80101664:	bb 20 1a 11 80       	mov    $0x80111a20,%ebx
80101669:	83 ec 0c             	sub    $0xc,%esp
  initlock(&icache.lock, "icache");
8010166c:	68 8b 78 10 80       	push   $0x8010788b
80101671:	68 e0 19 11 80       	push   $0x801119e0
80101676:	e8 05 34 00 00       	call   80104a80 <initlock>
8010167b:	83 c4 10             	add    $0x10,%esp
8010167e:	66 90                	xchg   %ax,%ax
    initsleeplock(&icache.inode[i].lock, "inode");
80101680:	83 ec 08             	sub    $0x8,%esp
80101683:	68 92 78 10 80       	push   $0x80107892
80101688:	53                   	push   %ebx
80101689:	81 c3 94 00 00 00    	add    $0x94,%ebx
8010168f:	e8 bc 32 00 00       	call   80104950 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
80101694:	83 c4 10             	add    $0x10,%esp
80101697:	81 fb f0 53 11 80    	cmp    $0x801153f0,%ebx
8010169d:	75 e1                	jne    80101680 <iinit+0x20>
  readsb(dev, &sb);
8010169f:	83 ec 08             	sub    $0x8,%esp
801016a2:	68 c0 19 11 80       	push   $0x801119c0
801016a7:	ff 75 08             	pushl  0x8(%ebp)
801016aa:	e8 71 ff ff ff       	call   80101620 <readsb>
  cprintf("sb: size %d nblocks %d ninodes %d nlog %d logstart %d\
801016af:	ff 35 d8 19 11 80    	pushl  0x801119d8
801016b5:	ff 35 d4 19 11 80    	pushl  0x801119d4
801016bb:	ff 35 d0 19 11 80    	pushl  0x801119d0
801016c1:	ff 35 cc 19 11 80    	pushl  0x801119cc
801016c7:	ff 35 c8 19 11 80    	pushl  0x801119c8
801016cd:	ff 35 c4 19 11 80    	pushl  0x801119c4
801016d3:	ff 35 c0 19 11 80    	pushl  0x801119c0
801016d9:	68 ac 79 10 80       	push   $0x801079ac
801016de:	e8 7d ef ff ff       	call   80100660 <cprintf>
}
801016e3:	83 c4 30             	add    $0x30,%esp
801016e6:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801016e9:	c9                   	leave  
801016ea:	c3                   	ret    
801016eb:	90                   	nop
801016ec:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

801016f0 <ialloc>:
{
801016f0:	55                   	push   %ebp
801016f1:	89 e5                	mov    %esp,%ebp
801016f3:	57                   	push   %edi
801016f4:	56                   	push   %esi
801016f5:	53                   	push   %ebx
801016f6:	83 ec 1c             	sub    $0x1c,%esp
  for(inum = 1; inum < sb.ninodes; inum++){
801016f9:	83 3d c8 19 11 80 01 	cmpl   $0x1,0x801119c8
{
80101700:	8b 45 0c             	mov    0xc(%ebp),%eax
80101703:	8b 75 08             	mov    0x8(%ebp),%esi
80101706:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  for(inum = 1; inum < sb.ninodes; inum++){
80101709:	0f 86 91 00 00 00    	jbe    801017a0 <ialloc+0xb0>
8010170f:	bb 01 00 00 00       	mov    $0x1,%ebx
80101714:	eb 21                	jmp    80101737 <ialloc+0x47>
80101716:	8d 76 00             	lea    0x0(%esi),%esi
80101719:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    brelse(bp);
80101720:	83 ec 0c             	sub    $0xc,%esp
  for(inum = 1; inum < sb.ninodes; inum++){
80101723:	83 c3 01             	add    $0x1,%ebx
    brelse(bp);
80101726:	57                   	push   %edi
80101727:	e8 b4 ea ff ff       	call   801001e0 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
8010172c:	83 c4 10             	add    $0x10,%esp
8010172f:	39 1d c8 19 11 80    	cmp    %ebx,0x801119c8
80101735:	76 69                	jbe    801017a0 <ialloc+0xb0>
    bp = bread(dev, IBLOCK(inum, sb));
80101737:	89 d8                	mov    %ebx,%eax
80101739:	83 ec 08             	sub    $0x8,%esp
8010173c:	c1 e8 03             	shr    $0x3,%eax
8010173f:	03 05 d4 19 11 80    	add    0x801119d4,%eax
80101745:	50                   	push   %eax
80101746:	56                   	push   %esi
80101747:	e8 84 e9 ff ff       	call   801000d0 <bread>
8010174c:	89 c7                	mov    %eax,%edi
    dip = (struct dinode*)bp->data + inum%IPB;
8010174e:	89 d8                	mov    %ebx,%eax
    if(dip->type == 0){  // a free inode
80101750:	83 c4 10             	add    $0x10,%esp
    dip = (struct dinode*)bp->data + inum%IPB;
80101753:	83 e0 07             	and    $0x7,%eax
80101756:	c1 e0 06             	shl    $0x6,%eax
80101759:	8d 4c 07 5c          	lea    0x5c(%edi,%eax,1),%ecx
    if(dip->type == 0){  // a free inode
8010175d:	66 83 39 00          	cmpw   $0x0,(%ecx)
80101761:	75 bd                	jne    80101720 <ialloc+0x30>
      memset(dip, 0, sizeof(*dip));
80101763:	83 ec 04             	sub    $0x4,%esp
80101766:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80101769:	6a 40                	push   $0x40
8010176b:	6a 00                	push   $0x0
8010176d:	51                   	push   %ecx
8010176e:	e8 5d 35 00 00       	call   80104cd0 <memset>
      dip->type = type;
80101773:	0f b7 45 e4          	movzwl -0x1c(%ebp),%eax
80101777:	8b 4d e0             	mov    -0x20(%ebp),%ecx
8010177a:	66 89 01             	mov    %ax,(%ecx)
      log_write(bp);   // mark it allocated on the disk
8010177d:	89 3c 24             	mov    %edi,(%esp)
80101780:	e8 6b 1e 00 00       	call   801035f0 <log_write>
      brelse(bp);
80101785:	89 3c 24             	mov    %edi,(%esp)
80101788:	e8 53 ea ff ff       	call   801001e0 <brelse>
      return iget(dev, inum);
8010178d:	83 c4 10             	add    $0x10,%esp
}
80101790:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return iget(dev, inum);
80101793:	89 da                	mov    %ebx,%edx
80101795:	89 f0                	mov    %esi,%eax
}
80101797:	5b                   	pop    %ebx
80101798:	5e                   	pop    %esi
80101799:	5f                   	pop    %edi
8010179a:	5d                   	pop    %ebp
      return iget(dev, inum);
8010179b:	e9 90 fc ff ff       	jmp    80101430 <iget>
  panic("ialloc: no inodes");
801017a0:	83 ec 0c             	sub    $0xc,%esp
801017a3:	68 98 78 10 80       	push   $0x80107898
801017a8:	e8 e3 eb ff ff       	call   80100390 <panic>
801017ad:	8d 76 00             	lea    0x0(%esi),%esi

801017b0 <iupdate>:
{
801017b0:	55                   	push   %ebp
801017b1:	89 e5                	mov    %esp,%ebp
801017b3:	56                   	push   %esi
801017b4:	53                   	push   %ebx
801017b5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801017b8:	83 ec 08             	sub    $0x8,%esp
801017bb:	8b 43 04             	mov    0x4(%ebx),%eax
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
801017be:	83 c3 60             	add    $0x60,%ebx
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801017c1:	c1 e8 03             	shr    $0x3,%eax
801017c4:	03 05 d4 19 11 80    	add    0x801119d4,%eax
801017ca:	50                   	push   %eax
801017cb:	ff 73 a0             	pushl  -0x60(%ebx)
801017ce:	e8 fd e8 ff ff       	call   801000d0 <bread>
801017d3:	89 c6                	mov    %eax,%esi
  dip = (struct dinode*)bp->data + ip->inum%IPB;
801017d5:	8b 43 a4             	mov    -0x5c(%ebx),%eax
  dip->type = ip->type;
801017d8:	0f b7 53 f4          	movzwl -0xc(%ebx),%edx
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
801017dc:	83 c4 0c             	add    $0xc,%esp
  dip = (struct dinode*)bp->data + ip->inum%IPB;
801017df:	83 e0 07             	and    $0x7,%eax
801017e2:	c1 e0 06             	shl    $0x6,%eax
801017e5:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
  dip->type = ip->type;
801017e9:	66 89 10             	mov    %dx,(%eax)
  dip->major = ip->major;
801017ec:	0f b7 53 f6          	movzwl -0xa(%ebx),%edx
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
801017f0:	83 c0 0c             	add    $0xc,%eax
  dip->major = ip->major;
801017f3:	66 89 50 f6          	mov    %dx,-0xa(%eax)
  dip->minor = ip->minor;
801017f7:	0f b7 53 f8          	movzwl -0x8(%ebx),%edx
801017fb:	66 89 50 f8          	mov    %dx,-0x8(%eax)
  dip->nlink = ip->nlink;
801017ff:	0f b7 53 fa          	movzwl -0x6(%ebx),%edx
80101803:	66 89 50 fa          	mov    %dx,-0x6(%eax)
  dip->size = ip->size;
80101807:	8b 53 fc             	mov    -0x4(%ebx),%edx
8010180a:	89 50 fc             	mov    %edx,-0x4(%eax)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
8010180d:	6a 34                	push   $0x34
8010180f:	53                   	push   %ebx
80101810:	50                   	push   %eax
80101811:	e8 6a 35 00 00       	call   80104d80 <memmove>
  log_write(bp);
80101816:	89 34 24             	mov    %esi,(%esp)
80101819:	e8 d2 1d 00 00       	call   801035f0 <log_write>
  brelse(bp);
8010181e:	89 75 08             	mov    %esi,0x8(%ebp)
80101821:	83 c4 10             	add    $0x10,%esp
}
80101824:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101827:	5b                   	pop    %ebx
80101828:	5e                   	pop    %esi
80101829:	5d                   	pop    %ebp
  brelse(bp);
8010182a:	e9 b1 e9 ff ff       	jmp    801001e0 <brelse>
8010182f:	90                   	nop

80101830 <idup>:
{
80101830:	55                   	push   %ebp
80101831:	89 e5                	mov    %esp,%ebp
80101833:	53                   	push   %ebx
80101834:	83 ec 10             	sub    $0x10,%esp
80101837:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&icache.lock);
8010183a:	68 e0 19 11 80       	push   $0x801119e0
8010183f:	e8 7c 33 00 00       	call   80104bc0 <acquire>
  ip->ref++;
80101844:	83 43 08 01          	addl   $0x1,0x8(%ebx)
  release(&icache.lock);
80101848:	c7 04 24 e0 19 11 80 	movl   $0x801119e0,(%esp)
8010184f:	e8 2c 34 00 00       	call   80104c80 <release>
}
80101854:	89 d8                	mov    %ebx,%eax
80101856:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101859:	c9                   	leave  
8010185a:	c3                   	ret    
8010185b:	90                   	nop
8010185c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80101860 <ilock>:
{
80101860:	55                   	push   %ebp
80101861:	89 e5                	mov    %esp,%ebp
80101863:	56                   	push   %esi
80101864:	53                   	push   %ebx
80101865:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || ip->ref < 1)
80101868:	85 db                	test   %ebx,%ebx
8010186a:	0f 84 b7 00 00 00    	je     80101927 <ilock+0xc7>
80101870:	8b 53 08             	mov    0x8(%ebx),%edx
80101873:	85 d2                	test   %edx,%edx
80101875:	0f 8e ac 00 00 00    	jle    80101927 <ilock+0xc7>
  acquiresleep(&ip->lock);
8010187b:	8d 43 0c             	lea    0xc(%ebx),%eax
8010187e:	83 ec 0c             	sub    $0xc,%esp
80101881:	50                   	push   %eax
80101882:	e8 09 31 00 00       	call   80104990 <acquiresleep>
  if(ip->valid == 0){
80101887:	8b 43 4c             	mov    0x4c(%ebx),%eax
8010188a:	83 c4 10             	add    $0x10,%esp
8010188d:	85 c0                	test   %eax,%eax
8010188f:	74 0f                	je     801018a0 <ilock+0x40>
}
80101891:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101894:	5b                   	pop    %ebx
80101895:	5e                   	pop    %esi
80101896:	5d                   	pop    %ebp
80101897:	c3                   	ret    
80101898:	90                   	nop
80101899:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801018a0:	8b 43 04             	mov    0x4(%ebx),%eax
801018a3:	83 ec 08             	sub    $0x8,%esp
801018a6:	c1 e8 03             	shr    $0x3,%eax
801018a9:	03 05 d4 19 11 80    	add    0x801119d4,%eax
801018af:	50                   	push   %eax
801018b0:	ff 33                	pushl  (%ebx)
801018b2:	e8 19 e8 ff ff       	call   801000d0 <bread>
801018b7:	89 c6                	mov    %eax,%esi
    dip = (struct dinode*)bp->data + ip->inum%IPB;
801018b9:	8b 43 04             	mov    0x4(%ebx),%eax
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
801018bc:	83 c4 0c             	add    $0xc,%esp
    dip = (struct dinode*)bp->data + ip->inum%IPB;
801018bf:	83 e0 07             	and    $0x7,%eax
801018c2:	c1 e0 06             	shl    $0x6,%eax
801018c5:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
    ip->type = dip->type;
801018c9:	0f b7 10             	movzwl (%eax),%edx
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
801018cc:	83 c0 0c             	add    $0xc,%eax
    ip->type = dip->type;
801018cf:	66 89 53 54          	mov    %dx,0x54(%ebx)
    ip->major = dip->major;
801018d3:	0f b7 50 f6          	movzwl -0xa(%eax),%edx
801018d7:	66 89 53 56          	mov    %dx,0x56(%ebx)
    ip->minor = dip->minor;
801018db:	0f b7 50 f8          	movzwl -0x8(%eax),%edx
801018df:	66 89 53 58          	mov    %dx,0x58(%ebx)
    ip->nlink = dip->nlink;
801018e3:	0f b7 50 fa          	movzwl -0x6(%eax),%edx
801018e7:	66 89 53 5a          	mov    %dx,0x5a(%ebx)
    ip->size = dip->size;
801018eb:	8b 50 fc             	mov    -0x4(%eax),%edx
801018ee:	89 53 5c             	mov    %edx,0x5c(%ebx)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
801018f1:	6a 34                	push   $0x34
801018f3:	50                   	push   %eax
801018f4:	8d 43 60             	lea    0x60(%ebx),%eax
801018f7:	50                   	push   %eax
801018f8:	e8 83 34 00 00       	call   80104d80 <memmove>
    brelse(bp);
801018fd:	89 34 24             	mov    %esi,(%esp)
80101900:	e8 db e8 ff ff       	call   801001e0 <brelse>
    if(ip->type == 0)
80101905:	83 c4 10             	add    $0x10,%esp
80101908:	66 83 7b 54 00       	cmpw   $0x0,0x54(%ebx)
    ip->valid = 1;
8010190d:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
    if(ip->type == 0)
80101914:	0f 85 77 ff ff ff    	jne    80101891 <ilock+0x31>
      panic("ilock: no type");
8010191a:	83 ec 0c             	sub    $0xc,%esp
8010191d:	68 b0 78 10 80       	push   $0x801078b0
80101922:	e8 69 ea ff ff       	call   80100390 <panic>
    panic("ilock");
80101927:	83 ec 0c             	sub    $0xc,%esp
8010192a:	68 aa 78 10 80       	push   $0x801078aa
8010192f:	e8 5c ea ff ff       	call   80100390 <panic>
80101934:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
8010193a:	8d bf 00 00 00 00    	lea    0x0(%edi),%edi

80101940 <iunlock>:
{
80101940:	55                   	push   %ebp
80101941:	89 e5                	mov    %esp,%ebp
80101943:	56                   	push   %esi
80101944:	53                   	push   %ebx
80101945:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80101948:	85 db                	test   %ebx,%ebx
8010194a:	74 28                	je     80101974 <iunlock+0x34>
8010194c:	8d 73 0c             	lea    0xc(%ebx),%esi
8010194f:	83 ec 0c             	sub    $0xc,%esp
80101952:	56                   	push   %esi
80101953:	e8 d8 30 00 00       	call   80104a30 <holdingsleep>
80101958:	83 c4 10             	add    $0x10,%esp
8010195b:	85 c0                	test   %eax,%eax
8010195d:	74 15                	je     80101974 <iunlock+0x34>
8010195f:	8b 43 08             	mov    0x8(%ebx),%eax
80101962:	85 c0                	test   %eax,%eax
80101964:	7e 0e                	jle    80101974 <iunlock+0x34>
  releasesleep(&ip->lock);
80101966:	89 75 08             	mov    %esi,0x8(%ebp)
}
80101969:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010196c:	5b                   	pop    %ebx
8010196d:	5e                   	pop    %esi
8010196e:	5d                   	pop    %ebp
  releasesleep(&ip->lock);
8010196f:	e9 7c 30 00 00       	jmp    801049f0 <releasesleep>
    panic("iunlock");
80101974:	83 ec 0c             	sub    $0xc,%esp
80101977:	68 bf 78 10 80       	push   $0x801078bf
8010197c:	e8 0f ea ff ff       	call   80100390 <panic>
80101981:	eb 0d                	jmp    80101990 <stati>
80101983:	90                   	nop
80101984:	90                   	nop
80101985:	90                   	nop
80101986:	90                   	nop
80101987:	90                   	nop
80101988:	90                   	nop
80101989:	90                   	nop
8010198a:	90                   	nop
8010198b:	90                   	nop
8010198c:	90                   	nop
8010198d:	90                   	nop
8010198e:	90                   	nop
8010198f:	90                   	nop

80101990 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
80101990:	55                   	push   %ebp
80101991:	89 e5                	mov    %esp,%ebp
80101993:	8b 55 08             	mov    0x8(%ebp),%edx
80101996:	8b 45 0c             	mov    0xc(%ebp),%eax
  st->dev = ip->dev;
80101999:	8b 0a                	mov    (%edx),%ecx
8010199b:	89 48 04             	mov    %ecx,0x4(%eax)
  st->ino = ip->inum;
8010199e:	8b 4a 04             	mov    0x4(%edx),%ecx
801019a1:	89 48 08             	mov    %ecx,0x8(%eax)
  st->type = ip->type;
801019a4:	0f b7 4a 54          	movzwl 0x54(%edx),%ecx
801019a8:	66 89 08             	mov    %cx,(%eax)
  st->nlink = ip->nlink;
801019ab:	0f b7 4a 5a          	movzwl 0x5a(%edx),%ecx
801019af:	66 89 48 0c          	mov    %cx,0xc(%eax)
  st->size = ip->size;
801019b3:	8b 52 5c             	mov    0x5c(%edx),%edx
801019b6:	89 50 10             	mov    %edx,0x10(%eax)
}
801019b9:	5d                   	pop    %ebp
801019ba:	c3                   	ret    
801019bb:	90                   	nop
801019bc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

801019c0 <readi>:
//PAGEBREAK!
// Read data from inode.
// Caller must hold ip->lock.
int
readi(struct inode *ip, char *dst, uint off, uint n)
{
801019c0:	55                   	push   %ebp
801019c1:	89 e5                	mov    %esp,%ebp
801019c3:	57                   	push   %edi
801019c4:	56                   	push   %esi
801019c5:	53                   	push   %ebx
801019c6:	83 ec 1c             	sub    $0x1c,%esp
801019c9:	8b 45 08             	mov    0x8(%ebp),%eax
801019cc:	8b 75 0c             	mov    0xc(%ebp),%esi
801019cf:	8b 7d 14             	mov    0x14(%ebp),%edi
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
801019d2:	66 83 78 54 03       	cmpw   $0x3,0x54(%eax)
{
801019d7:	89 75 e0             	mov    %esi,-0x20(%ebp)
801019da:	89 45 d8             	mov    %eax,-0x28(%ebp)
801019dd:	8b 75 10             	mov    0x10(%ebp),%esi
801019e0:	89 7d e4             	mov    %edi,-0x1c(%ebp)
  if(ip->type == T_DEV){
801019e3:	0f 84 a7 00 00 00    	je     80101a90 <readi+0xd0>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
      return -1;
    return devsw[ip->major].read(ip, dst, n);
  }

  if(off > ip->size || off + n < off)
801019e9:	8b 45 d8             	mov    -0x28(%ebp),%eax
801019ec:	8b 40 5c             	mov    0x5c(%eax),%eax
801019ef:	39 c6                	cmp    %eax,%esi
801019f1:	0f 87 ba 00 00 00    	ja     80101ab1 <readi+0xf1>
801019f7:	8b 7d e4             	mov    -0x1c(%ebp),%edi
801019fa:	89 f9                	mov    %edi,%ecx
801019fc:	01 f1                	add    %esi,%ecx
801019fe:	0f 82 ad 00 00 00    	jb     80101ab1 <readi+0xf1>
    return -1;
  if(off + n > ip->size)
    n = ip->size - off;
80101a04:	89 c2                	mov    %eax,%edx
80101a06:	29 f2                	sub    %esi,%edx
80101a08:	39 c8                	cmp    %ecx,%eax
80101a0a:	0f 43 d7             	cmovae %edi,%edx

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101a0d:	31 ff                	xor    %edi,%edi
80101a0f:	85 d2                	test   %edx,%edx
    n = ip->size - off;
80101a11:	89 55 e4             	mov    %edx,-0x1c(%ebp)
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101a14:	74 6c                	je     80101a82 <readi+0xc2>
80101a16:	8d 76 00             	lea    0x0(%esi),%esi
80101a19:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101a20:	8b 5d d8             	mov    -0x28(%ebp),%ebx
80101a23:	89 f2                	mov    %esi,%edx
80101a25:	c1 ea 09             	shr    $0x9,%edx
80101a28:	89 d8                	mov    %ebx,%eax
80101a2a:	e8 f1 fa ff ff       	call   80101520 <bmap>
80101a2f:	83 ec 08             	sub    $0x8,%esp
80101a32:	50                   	push   %eax
80101a33:	ff 33                	pushl  (%ebx)
80101a35:	e8 96 e6 ff ff       	call   801000d0 <bread>
    m = min(n - tot, BSIZE - off%BSIZE);
80101a3a:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101a3d:	89 c2                	mov    %eax,%edx
    m = min(n - tot, BSIZE - off%BSIZE);
80101a3f:	89 f0                	mov    %esi,%eax
80101a41:	25 ff 01 00 00       	and    $0x1ff,%eax
80101a46:	b9 00 02 00 00       	mov    $0x200,%ecx
80101a4b:	83 c4 0c             	add    $0xc,%esp
80101a4e:	29 c1                	sub    %eax,%ecx
    memmove(dst, bp->data + off%BSIZE, m);
80101a50:	8d 44 02 5c          	lea    0x5c(%edx,%eax,1),%eax
80101a54:	89 55 dc             	mov    %edx,-0x24(%ebp)
    m = min(n - tot, BSIZE - off%BSIZE);
80101a57:	29 fb                	sub    %edi,%ebx
80101a59:	39 d9                	cmp    %ebx,%ecx
80101a5b:	0f 46 d9             	cmovbe %ecx,%ebx
    memmove(dst, bp->data + off%BSIZE, m);
80101a5e:	53                   	push   %ebx
80101a5f:	50                   	push   %eax
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101a60:	01 df                	add    %ebx,%edi
    memmove(dst, bp->data + off%BSIZE, m);
80101a62:	ff 75 e0             	pushl  -0x20(%ebp)
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101a65:	01 de                	add    %ebx,%esi
    memmove(dst, bp->data + off%BSIZE, m);
80101a67:	e8 14 33 00 00       	call   80104d80 <memmove>
    brelse(bp);
80101a6c:	8b 55 dc             	mov    -0x24(%ebp),%edx
80101a6f:	89 14 24             	mov    %edx,(%esp)
80101a72:	e8 69 e7 ff ff       	call   801001e0 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101a77:	01 5d e0             	add    %ebx,-0x20(%ebp)
80101a7a:	83 c4 10             	add    $0x10,%esp
80101a7d:	39 7d e4             	cmp    %edi,-0x1c(%ebp)
80101a80:	77 9e                	ja     80101a20 <readi+0x60>
  }
  return n;
80101a82:	8b 45 e4             	mov    -0x1c(%ebp),%eax
}
80101a85:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101a88:	5b                   	pop    %ebx
80101a89:	5e                   	pop    %esi
80101a8a:	5f                   	pop    %edi
80101a8b:	5d                   	pop    %ebp
80101a8c:	c3                   	ret    
80101a8d:	8d 76 00             	lea    0x0(%esi),%esi
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
80101a90:	0f bf 40 56          	movswl 0x56(%eax),%eax
80101a94:	66 83 f8 09          	cmp    $0x9,%ax
80101a98:	77 17                	ja     80101ab1 <readi+0xf1>
80101a9a:	8b 04 c5 60 19 11 80 	mov    -0x7feee6a0(,%eax,8),%eax
80101aa1:	85 c0                	test   %eax,%eax
80101aa3:	74 0c                	je     80101ab1 <readi+0xf1>
    return devsw[ip->major].read(ip, dst, n);
80101aa5:	89 7d 10             	mov    %edi,0x10(%ebp)
}
80101aa8:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101aab:	5b                   	pop    %ebx
80101aac:	5e                   	pop    %esi
80101aad:	5f                   	pop    %edi
80101aae:	5d                   	pop    %ebp
    return devsw[ip->major].read(ip, dst, n);
80101aaf:	ff e0                	jmp    *%eax
      return -1;
80101ab1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101ab6:	eb cd                	jmp    80101a85 <readi+0xc5>
80101ab8:	90                   	nop
80101ab9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80101ac0 <clear_inode>:
  //////////////////////////////////////////////////////
  return n;
}

void clear_inode(struct inode *ip)
{
80101ac0:	55                   	push   %ebp
80101ac1:	89 e5                	mov    %esp,%ebp
80101ac3:	57                   	push   %edi
80101ac4:	56                   	push   %esi
80101ac5:	53                   	push   %ebx
80101ac6:	83 ec 0c             	sub    $0xc,%esp
80101ac9:	8b 75 08             	mov    0x8(%ebp),%esi
80101acc:	8d 5e 60             	lea    0x60(%esi),%ebx
80101acf:	8d be 90 00 00 00    	lea    0x90(%esi),%edi
80101ad5:	eb 10                	jmp    80101ae7 <clear_inode+0x27>
80101ad7:	89 f6                	mov    %esi,%esi
80101ad9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
80101ae0:	83 c3 04             	add    $0x4,%ebx
  int i, j;
  struct buf *bp;
  uint *a;
  for(i = 0; i < NDIRECT; i++){
80101ae3:	39 fb                	cmp    %edi,%ebx
80101ae5:	74 24                	je     80101b0b <clear_inode+0x4b>
    if(ip->addrs[i]){
80101ae7:	8b 13                	mov    (%ebx),%edx
80101ae9:	85 d2                	test   %edx,%edx
80101aeb:	74 f3                	je     80101ae0 <clear_inode+0x20>
      cprintf("CLEAR DIRECT IONDE\n");
80101aed:	83 ec 0c             	sub    $0xc,%esp
80101af0:	83 c3 04             	add    $0x4,%ebx
80101af3:	68 c7 78 10 80       	push   $0x801078c7
80101af8:	e8 63 eb ff ff       	call   80100660 <cprintf>
      ip->addrs[i] = 0;
80101afd:	c7 43 fc 00 00 00 00 	movl   $0x0,-0x4(%ebx)
80101b04:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < NDIRECT; i++){
80101b07:	39 fb                	cmp    %edi,%ebx
80101b09:	75 dc                	jne    80101ae7 <clear_inode+0x27>
    }
  }
  if(ip->addrs[NDIRECT]){
80101b0b:	8b 86 90 00 00 00    	mov    0x90(%esi),%eax
80101b11:	85 c0                	test   %eax,%eax
80101b13:	75 1b                	jne    80101b30 <clear_inode+0x70>
      if(a[j]) a[j]= 0;
    }
    brelse(bp);
    ip->addrs[NDIRECT] = 0;
  }
  icache.status = 2; // EZE
80101b15:	c7 05 38 54 11 80 02 	movl   $0x2,0x80115438
80101b1c:	00 00 00 
}
80101b1f:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101b22:	5b                   	pop    %ebx
80101b23:	5e                   	pop    %esi
80101b24:	5f                   	pop    %edi
80101b25:	5d                   	pop    %ebp
80101b26:	c3                   	ret    
80101b27:	89 f6                	mov    %esi,%esi
80101b29:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
80101b30:	83 ec 08             	sub    $0x8,%esp
80101b33:	50                   	push   %eax
80101b34:	ff 36                	pushl  (%esi)
80101b36:	e8 95 e5 ff ff       	call   801000d0 <bread>
80101b3b:	89 c3                	mov    %eax,%ebx
          cprintf("CLEAR INDIRECT IONDE\n");
80101b3d:	c7 04 24 db 78 10 80 	movl   $0x801078db,(%esp)
80101b44:	e8 17 eb ff ff       	call   80100660 <cprintf>
    a = (uint*)bp->data;
80101b49:	8d 53 5c             	lea    0x5c(%ebx),%edx
80101b4c:	8d 8b 5c 02 00 00    	lea    0x25c(%ebx),%ecx
80101b52:	83 c4 10             	add    $0x10,%esp
80101b55:	8d 76 00             	lea    0x0(%esi),%esi
      if(a[j]) a[j]= 0;
80101b58:	8b 02                	mov    (%edx),%eax
80101b5a:	85 c0                	test   %eax,%eax
80101b5c:	74 06                	je     80101b64 <clear_inode+0xa4>
80101b5e:	c7 02 00 00 00 00    	movl   $0x0,(%edx)
80101b64:	83 c2 04             	add    $0x4,%edx
    for(j = 0; j < NINDIRECT; j++){
80101b67:	39 ca                	cmp    %ecx,%edx
80101b69:	75 ed                	jne    80101b58 <clear_inode+0x98>
    brelse(bp);
80101b6b:	83 ec 0c             	sub    $0xc,%esp
80101b6e:	53                   	push   %ebx
80101b6f:	e8 6c e6 ff ff       	call   801001e0 <brelse>
    ip->addrs[NDIRECT] = 0;
80101b74:	c7 86 90 00 00 00 00 	movl   $0x0,0x90(%esi)
80101b7b:	00 00 00 
80101b7e:	83 c4 10             	add    $0x10,%esp
80101b81:	eb 92                	jmp    80101b15 <clear_inode+0x55>
80101b83:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80101b89:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80101b90 <iput>:
{
80101b90:	55                   	push   %ebp
80101b91:	89 e5                	mov    %esp,%ebp
80101b93:	57                   	push   %edi
80101b94:	56                   	push   %esi
80101b95:	53                   	push   %ebx
80101b96:	83 ec 28             	sub    $0x28,%esp
80101b99:	8b 75 08             	mov    0x8(%ebp),%esi
  acquiresleep(&ip->lock);
80101b9c:	8d 7e 0c             	lea    0xc(%esi),%edi
80101b9f:	57                   	push   %edi
80101ba0:	e8 eb 2d 00 00       	call   80104990 <acquiresleep>
  if(ip->valid && ip->nlink == 0){
80101ba5:	8b 56 4c             	mov    0x4c(%esi),%edx
80101ba8:	83 c4 10             	add    $0x10,%esp
80101bab:	85 d2                	test   %edx,%edx
80101bad:	74 07                	je     80101bb6 <iput+0x26>
80101baf:	66 83 7e 5a 00       	cmpw   $0x0,0x5a(%esi)
80101bb4:	74 32                	je     80101be8 <iput+0x58>
  releasesleep(&ip->lock);
80101bb6:	83 ec 0c             	sub    $0xc,%esp
80101bb9:	57                   	push   %edi
80101bba:	e8 31 2e 00 00       	call   801049f0 <releasesleep>
  acquire(&icache.lock);
80101bbf:	c7 04 24 e0 19 11 80 	movl   $0x801119e0,(%esp)
80101bc6:	e8 f5 2f 00 00       	call   80104bc0 <acquire>
  ip->ref--;
80101bcb:	83 6e 08 01          	subl   $0x1,0x8(%esi)
  release(&icache.lock);
80101bcf:	83 c4 10             	add    $0x10,%esp
80101bd2:	c7 45 08 e0 19 11 80 	movl   $0x801119e0,0x8(%ebp)
}
80101bd9:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101bdc:	5b                   	pop    %ebx
80101bdd:	5e                   	pop    %esi
80101bde:	5f                   	pop    %edi
80101bdf:	5d                   	pop    %ebp
  release(&icache.lock);
80101be0:	e9 9b 30 00 00       	jmp    80104c80 <release>
80101be5:	8d 76 00             	lea    0x0(%esi),%esi
    acquire(&icache.lock);
80101be8:	83 ec 0c             	sub    $0xc,%esp
80101beb:	bb e4 53 11 80       	mov    $0x801153e4,%ebx
80101bf0:	68 e0 19 11 80       	push   $0x801119e0
80101bf5:	e8 c6 2f 00 00       	call   80104bc0 <acquire>
80101bfa:	83 c4 10             	add    $0x10,%esp
80101bfd:	8d 76 00             	lea    0x0(%esi),%esi
      cprintf("[%d] ", icache.inode_table1[i]);
80101c00:	83 ec 08             	sub    $0x8,%esp
80101c03:	ff 33                	pushl  (%ebx)
80101c05:	83 c3 04             	add    $0x4,%ebx
80101c08:	68 f1 78 10 80       	push   $0x801078f1
80101c0d:	e8 4e ea ff ff       	call   80100660 <cprintf>
     for(int i=0;i<10;i++){
80101c12:	83 c4 10             	add    $0x10,%esp
80101c15:	81 fb 0c 54 11 80    	cmp    $0x8011540c,%ebx
80101c1b:	75 e3                	jne    80101c00 <iput+0x70>
    cprintf("\n");
80101c1d:	83 ec 0c             	sub    $0xc,%esp
80101c20:	bb 0c 54 11 80       	mov    $0x8011540c,%ebx
80101c25:	68 db 81 10 80       	push   $0x801081db
80101c2a:	e8 31 ea ff ff       	call   80100660 <cprintf>
80101c2f:	83 c4 10             	add    $0x10,%esp
80101c32:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      cprintf("[%d] ", icache.inode_table2[i]);
80101c38:	83 ec 08             	sub    $0x8,%esp
80101c3b:	ff 33                	pushl  (%ebx)
80101c3d:	83 c3 04             	add    $0x4,%ebx
80101c40:	68 f1 78 10 80       	push   $0x801078f1
80101c45:	e8 16 ea ff ff       	call   80100660 <cprintf>
     for(int i=0;i<10;i++){
80101c4a:	83 c4 10             	add    $0x10,%esp
80101c4d:	81 fb 34 54 11 80    	cmp    $0x80115434,%ebx
80101c53:	75 e3                	jne    80101c38 <iput+0xa8>
    cprintf("\n");
80101c55:	83 ec 0c             	sub    $0xc,%esp
    for(int i=0;i<10;i++){
80101c58:	31 db                	xor    %ebx,%ebx
    cprintf("\n");
80101c5a:	68 db 81 10 80       	push   $0x801081db
80101c5f:	e8 fc e9 ff ff       	call   80100660 <cprintf>
80101c64:	8b 46 04             	mov    0x4(%esi),%eax
80101c67:	83 c4 10             	add    $0x10,%esp
    int tmp=10;
80101c6a:	ba 0a 00 00 00       	mov    $0xa,%edx
80101c6f:	90                   	nop
      if(icache.inode_table1[i] == ip->inum) {
80101c70:	39 04 9d e4 53 11 80 	cmp    %eax,-0x7feeac1c(,%ebx,4)
80101c77:	75 10                	jne    80101c89 <iput+0xf9>
          icache.inode_table1[i]=0;
80101c79:	c7 04 9d e4 53 11 80 	movl   $0x0,-0x7feeac1c(,%ebx,4)
80101c80:	00 00 00 00 
80101c84:	8b 46 04             	mov    0x4(%esi),%eax
80101c87:	89 da                	mov    %ebx,%edx
    for(int i=0;i<10;i++){
80101c89:	83 c3 01             	add    $0x1,%ebx
80101c8c:	83 fb 0a             	cmp    $0xa,%ebx
80101c8f:	75 df                	jne    80101c70 <iput+0xe0>
    for(int i=tmp+1;i<10;i++){
80101c91:	83 fa 08             	cmp    $0x8,%edx
80101c94:	89 55 e4             	mov    %edx,-0x1c(%ebp)
80101c97:	0f 8f 93 01 00 00    	jg     80101e30 <iput+0x2a0>
80101c9d:	8d 0c 95 e0 19 11 80 	lea    -0x7feee620(,%edx,4),%ecx
      if(icache.inode_table1[i] !=0)  result = 1;
80101ca4:	89 45 e0             	mov    %eax,-0x20(%ebp)
    int result=0; // 0 : truncate 1 : just clear
80101ca7:	31 d2                	xor    %edx,%edx
80101ca9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      if(icache.inode_table1[i] !=0)  result = 1;
80101cb0:	8b 81 08 3a 00 00    	mov    0x3a08(%ecx),%eax
80101cb6:	85 c0                	test   %eax,%eax
80101cb8:	b8 01 00 00 00       	mov    $0x1,%eax
80101cbd:	0f 45 d0             	cmovne %eax,%edx
80101cc0:	83 c1 04             	add    $0x4,%ecx
    for(int i=tmp+1;i<10;i++){
80101cc3:	81 f9 04 1a 11 80    	cmp    $0x80111a04,%ecx
80101cc9:	75 e5                	jne    80101cb0 <iput+0x120>
80101ccb:	8b 45 e0             	mov    -0x20(%ebp),%eax
    for(int i=0;i<10;i++){
80101cce:	31 c9                	xor    %ecx,%ecx
80101cd0:	eb 09                	jmp    80101cdb <iput+0x14b>
80101cd2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80101cd8:	8b 46 04             	mov    0x4(%esi),%eax
      if(icache.inode_table2[i] == ip->inum) {
80101cdb:	39 04 8d 0c 54 11 80 	cmp    %eax,-0x7feeabf4(,%ecx,4)
80101ce2:	75 0d                	jne    80101cf1 <iput+0x161>
          icache.inode_table2[i]=0;
80101ce4:	c7 04 8d 0c 54 11 80 	movl   $0x0,-0x7feeabf4(,%ecx,4)
80101ceb:	00 00 00 00 
80101cef:	89 cb                	mov    %ecx,%ebx
    for(int i=0;i<10;i++){
80101cf1:	83 c1 01             	add    $0x1,%ecx
80101cf4:	83 f9 0a             	cmp    $0xa,%ecx
80101cf7:	75 df                	jne    80101cd8 <iput+0x148>
    for(int i=tmp2+1;i<10;i++){
80101cf9:	83 fb 08             	cmp    $0x8,%ebx
80101cfc:	7f 26                	jg     80101d24 <iput+0x194>
80101cfe:	8d 04 9d e0 19 11 80 	lea    -0x7feee620(,%ebx,4),%eax
      if(icache.inode_table2[i] !=0)  result = 1;
80101d05:	b9 01 00 00 00       	mov    $0x1,%ecx
80101d0a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80101d10:	83 b8 30 3a 00 00 00 	cmpl   $0x0,0x3a30(%eax)
80101d17:	0f 45 d1             	cmovne %ecx,%edx
80101d1a:	83 c0 04             	add    $0x4,%eax
    for(int i=tmp2+1;i<10;i++){
80101d1d:	3d 04 1a 11 80       	cmp    $0x80111a04,%eax
80101d22:	75 ec                	jne    80101d10 <iput+0x180>
    release(&icache.lock);
80101d24:	83 ec 0c             	sub    $0xc,%esp
80101d27:	89 55 e0             	mov    %edx,-0x20(%ebp)
80101d2a:	68 e0 19 11 80       	push   $0x801119e0
80101d2f:	e8 4c 2f 00 00       	call   80104c80 <release>
    cprintf("TMP1 : %d, TMP2 : %d\n",tmp, tmp2); 
80101d34:	83 c4 0c             	add    $0xc,%esp
80101d37:	53                   	push   %ebx
80101d38:	ff 75 e4             	pushl  -0x1c(%ebp)
80101d3b:	68 f7 78 10 80       	push   $0x801078f7
80101d40:	e8 1b e9 ff ff       	call   80100660 <cprintf>
    if(result ==0){ 
80101d45:	8b 55 e0             	mov    -0x20(%ebp),%edx
80101d48:	83 c4 10             	add    $0x10,%esp
80101d4b:	85 d2                	test   %edx,%edx
80101d4d:	74 29                	je     80101d78 <iput+0x1e8>
      clear_inode(ip);
80101d4f:	83 ec 0c             	sub    $0xc,%esp
80101d52:	56                   	push   %esi
80101d53:	e8 68 fd ff ff       	call   80101ac0 <clear_inode>
      ip->type = 0;
80101d58:	31 c0                	xor    %eax,%eax
80101d5a:	66 89 46 54          	mov    %ax,0x54(%esi)
      iupdate(ip);
80101d5e:	89 34 24             	mov    %esi,(%esp)
80101d61:	e8 4a fa ff ff       	call   801017b0 <iupdate>
      ip->valid = 0;
80101d66:	c7 46 4c 00 00 00 00 	movl   $0x0,0x4c(%esi)
80101d6d:	83 c4 10             	add    $0x10,%esp
80101d70:	e9 41 fe ff ff       	jmp    80101bb6 <iput+0x26>
80101d75:	8d 76 00             	lea    0x0(%esi),%esi
80101d78:	8d 8e 90 00 00 00    	lea    0x90(%esi),%ecx
80101d7e:	89 7d e4             	mov    %edi,-0x1c(%ebp)
80101d81:	8d 5e 60             	lea    0x60(%esi),%ebx
80101d84:	89 cf                	mov    %ecx,%edi
80101d86:	eb 0f                	jmp    80101d97 <iput+0x207>
80101d88:	90                   	nop
80101d89:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80101d90:	83 c3 04             	add    $0x4,%ebx
  for(i = 0; i < NDIRECT; i++){
80101d93:	39 df                	cmp    %ebx,%edi
80101d95:	74 29                	je     80101dc0 <iput+0x230>
    if(ip->addrs[i]){
80101d97:	8b 13                	mov    (%ebx),%edx
80101d99:	85 d2                	test   %edx,%edx
80101d9b:	74 f3                	je     80101d90 <iput+0x200>
      bfree(ip->dev, ip->addrs[i]);
80101d9d:	8b 06                	mov    (%esi),%eax
80101d9f:	e8 0c f5 ff ff       	call   801012b0 <bfree>
      cprintf("BFREE\n"); // EZE
80101da4:	83 ec 0c             	sub    $0xc,%esp
80101da7:	68 0d 79 10 80       	push   $0x8010790d
80101dac:	e8 af e8 ff ff       	call   80100660 <cprintf>
      ip->addrs[i] = 0;
80101db1:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
80101db7:	83 c4 10             	add    $0x10,%esp
80101dba:	eb d4                	jmp    80101d90 <iput+0x200>
80101dbc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  if(ip->addrs[NDIRECT]){
80101dc0:	8b 86 90 00 00 00    	mov    0x90(%esi),%eax
80101dc6:	8b 7d e4             	mov    -0x1c(%ebp),%edi
80101dc9:	85 c0                	test   %eax,%eax
80101dcb:	75 1b                	jne    80101de8 <iput+0x258>
  iupdate(ip);
80101dcd:	83 ec 0c             	sub    $0xc,%esp
  ip->size = 0;
80101dd0:	c7 46 5c 00 00 00 00 	movl   $0x0,0x5c(%esi)
  iupdate(ip);
80101dd7:	56                   	push   %esi
80101dd8:	e8 d3 f9 ff ff       	call   801017b0 <iupdate>
80101ddd:	e9 76 ff ff ff       	jmp    80101d58 <iput+0x1c8>
80101de2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
80101de8:	83 ec 08             	sub    $0x8,%esp
80101deb:	50                   	push   %eax
80101dec:	ff 36                	pushl  (%esi)
80101dee:	e8 dd e2 ff ff       	call   801000d0 <bread>
80101df3:	8d 88 5c 02 00 00    	lea    0x25c(%eax),%ecx
80101df9:	89 7d e0             	mov    %edi,-0x20(%ebp)
80101dfc:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    a = (uint*)bp->data;
80101dff:	8d 58 5c             	lea    0x5c(%eax),%ebx
80101e02:	83 c4 10             	add    $0x10,%esp
80101e05:	89 cf                	mov    %ecx,%edi
80101e07:	eb 0e                	jmp    80101e17 <iput+0x287>
80101e09:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80101e10:	83 c3 04             	add    $0x4,%ebx
    for(j = 0; j < NINDIRECT; j++){
80101e13:	39 fb                	cmp    %edi,%ebx
80101e15:	74 20                	je     80101e37 <iput+0x2a7>
      if(a[j]){
80101e17:	8b 13                	mov    (%ebx),%edx
80101e19:	85 d2                	test   %edx,%edx
80101e1b:	74 f3                	je     80101e10 <iput+0x280>
        bfree(ip->dev, a[j]);
80101e1d:	8b 06                	mov    (%esi),%eax
80101e1f:	e8 8c f4 ff ff       	call   801012b0 <bfree>
80101e24:	eb ea                	jmp    80101e10 <iput+0x280>
80101e26:	8d 76 00             	lea    0x0(%esi),%esi
80101e29:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    int result=0; // 0 : truncate 1 : just clear
80101e30:	31 d2                	xor    %edx,%edx
80101e32:	e9 97 fe ff ff       	jmp    80101cce <iput+0x13e>
    brelse(bp);
80101e37:	83 ec 0c             	sub    $0xc,%esp
80101e3a:	ff 75 e4             	pushl  -0x1c(%ebp)
80101e3d:	8b 7d e0             	mov    -0x20(%ebp),%edi
80101e40:	e8 9b e3 ff ff       	call   801001e0 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
80101e45:	8b 96 90 00 00 00    	mov    0x90(%esi),%edx
80101e4b:	8b 06                	mov    (%esi),%eax
80101e4d:	e8 5e f4 ff ff       	call   801012b0 <bfree>
          cprintf("BFREE\n");  // EZE
80101e52:	c7 04 24 0d 79 10 80 	movl   $0x8010790d,(%esp)
80101e59:	e8 02 e8 ff ff       	call   80100660 <cprintf>
    ip->addrs[NDIRECT] = 0;
80101e5e:	c7 86 90 00 00 00 00 	movl   $0x0,0x90(%esi)
80101e65:	00 00 00 
80101e68:	83 c4 10             	add    $0x10,%esp
80101e6b:	e9 5d ff ff ff       	jmp    80101dcd <iput+0x23d>

80101e70 <iunlockput>:
{
80101e70:	55                   	push   %ebp
80101e71:	89 e5                	mov    %esp,%ebp
80101e73:	53                   	push   %ebx
80101e74:	83 ec 10             	sub    $0x10,%esp
80101e77:	8b 5d 08             	mov    0x8(%ebp),%ebx
  iunlock(ip);
80101e7a:	53                   	push   %ebx
80101e7b:	e8 c0 fa ff ff       	call   80101940 <iunlock>
  iput(ip);
80101e80:	89 5d 08             	mov    %ebx,0x8(%ebp)
80101e83:	83 c4 10             	add    $0x10,%esp
}
80101e86:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101e89:	c9                   	leave  
  iput(ip);
80101e8a:	e9 01 fd ff ff       	jmp    80101b90 <iput>
80101e8f:	90                   	nop

80101e90 <writei>:
{
80101e90:	55                   	push   %ebp
80101e91:	89 e5                	mov    %esp,%ebp
80101e93:	57                   	push   %edi
80101e94:	56                   	push   %esi
80101e95:	53                   	push   %ebx
80101e96:	83 ec 1c             	sub    $0x1c,%esp
80101e99:	8b 45 08             	mov    0x8(%ebp),%eax
80101e9c:	8b 75 0c             	mov    0xc(%ebp),%esi
80101e9f:	8b 55 14             	mov    0x14(%ebp),%edx
  if(ip->type == T_DEV){
80101ea2:	66 83 78 54 03       	cmpw   $0x3,0x54(%eax)
{
80101ea7:	89 75 dc             	mov    %esi,-0x24(%ebp)
80101eaa:	89 45 d8             	mov    %eax,-0x28(%ebp)
80101ead:	8b 75 10             	mov    0x10(%ebp),%esi
80101eb0:	89 55 e0             	mov    %edx,-0x20(%ebp)
  if(ip->type == T_DEV){
80101eb3:	0f 84 f7 00 00 00    	je     80101fb0 <writei+0x120>
  if(off > ip->size || off + n < off)
80101eb9:	8b 7d d8             	mov    -0x28(%ebp),%edi
80101ebc:	39 77 5c             	cmp    %esi,0x5c(%edi)
80101ebf:	0f 82 cb 03 00 00    	jb     80102290 <writei+0x400>
80101ec5:	8b 45 e0             	mov    -0x20(%ebp),%eax
80101ec8:	31 d2                	xor    %edx,%edx
80101eca:	01 f0                	add    %esi,%eax
80101ecc:	0f 92 c2             	setb   %dl
  if(off + n > MAXFILE*BSIZE)
80101ecf:	3d 00 18 01 00       	cmp    $0x11800,%eax
80101ed4:	0f 87 b6 03 00 00    	ja     80102290 <writei+0x400>
80101eda:	85 d2                	test   %edx,%edx
80101edc:	0f 85 ae 03 00 00    	jne    80102290 <writei+0x400>
  if (ip->cowcounter>=1 && off ==0){
80101ee2:	8b 47 50             	mov    0x50(%edi),%eax
80101ee5:	85 c0                	test   %eax,%eax
80101ee7:	7e 08                	jle    80101ef1 <writei+0x61>
80101ee9:	85 f6                	test   %esi,%esi
80101eeb:	0f 84 0f 01 00 00    	je     80102000 <writei+0x170>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80101ef1:	8b 7d e0             	mov    -0x20(%ebp),%edi
80101ef4:	85 ff                	test   %edi,%edi
80101ef6:	74 79                	je     80101f71 <writei+0xe1>
80101ef8:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
80101eff:	90                   	nop
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101f00:	8b 7d d8             	mov    -0x28(%ebp),%edi
80101f03:	89 f2                	mov    %esi,%edx
80101f05:	c1 ea 09             	shr    $0x9,%edx
80101f08:	89 f8                	mov    %edi,%eax
80101f0a:	e8 11 f6 ff ff       	call   80101520 <bmap>
80101f0f:	83 ec 08             	sub    $0x8,%esp
80101f12:	50                   	push   %eax
80101f13:	ff 37                	pushl  (%edi)
80101f15:	e8 b6 e1 ff ff       	call   801000d0 <bread>
    m = min(n - tot, BSIZE - off%BSIZE);
80101f1a:	8b 5d e0             	mov    -0x20(%ebp),%ebx
80101f1d:	2b 5d e4             	sub    -0x1c(%ebp),%ebx
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101f20:	89 c7                	mov    %eax,%edi
    m = min(n - tot, BSIZE - off%BSIZE);
80101f22:	89 f0                	mov    %esi,%eax
80101f24:	b9 00 02 00 00       	mov    $0x200,%ecx
80101f29:	83 c4 0c             	add    $0xc,%esp
80101f2c:	25 ff 01 00 00       	and    $0x1ff,%eax
80101f31:	29 c1                	sub    %eax,%ecx
    memmove(bp->data + off%BSIZE, src, m);
80101f33:	8d 44 07 5c          	lea    0x5c(%edi,%eax,1),%eax
    m = min(n - tot, BSIZE - off%BSIZE);
80101f37:	39 d9                	cmp    %ebx,%ecx
80101f39:	0f 46 d9             	cmovbe %ecx,%ebx
    memmove(bp->data + off%BSIZE, src, m);
80101f3c:	53                   	push   %ebx
80101f3d:	ff 75 dc             	pushl  -0x24(%ebp)
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80101f40:	01 de                	add    %ebx,%esi
    memmove(bp->data + off%BSIZE, src, m);
80101f42:	50                   	push   %eax
80101f43:	e8 38 2e 00 00       	call   80104d80 <memmove>
    log_write(bp);
80101f48:	89 3c 24             	mov    %edi,(%esp)
80101f4b:	e8 a0 16 00 00       	call   801035f0 <log_write>
    brelse(bp);
80101f50:	89 3c 24             	mov    %edi,(%esp)
80101f53:	e8 88 e2 ff ff       	call   801001e0 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80101f58:	01 5d e4             	add    %ebx,-0x1c(%ebp)
80101f5b:	01 5d dc             	add    %ebx,-0x24(%ebp)
80101f5e:	83 c4 10             	add    $0x10,%esp
80101f61:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80101f64:	39 45 e0             	cmp    %eax,-0x20(%ebp)
80101f67:	77 97                	ja     80101f00 <writei+0x70>
  if(n > 0 && off > ip->size){
80101f69:	8b 45 d8             	mov    -0x28(%ebp),%eax
80101f6c:	3b 70 5c             	cmp    0x5c(%eax),%esi
80101f6f:	77 6f                	ja     80101fe0 <writei+0x150>
  if (icache.status ==0 && off == LAST_OFF){
80101f71:	a1 38 54 11 80       	mov    0x80115438,%eax
80101f76:	81 fe 00 18 01 00    	cmp    $0x11800,%esi
80101f7c:	0f 94 c1             	sete   %cl
80101f7f:	89 ce                	mov    %ecx,%esi
80101f81:	85 c0                	test   %eax,%eax
80101f83:	75 08                	jne    80101f8d <writei+0xfd>
80101f85:	84 c9                	test   %cl,%cl
80101f87:	0f 85 53 01 00 00    	jne    801020e0 <writei+0x250>
  if (icache.status ==1){
80101f8d:	83 f8 01             	cmp    $0x1,%eax
80101f90:	0f 84 82 00 00 00    	je     80102018 <writei+0x188>
  if (icache.status ==2 && off == LAST_OFF){
80101f96:	83 f8 02             	cmp    $0x2,%eax
80101f99:	75 0a                	jne    80101fa5 <writei+0x115>
80101f9b:	89 f0                	mov    %esi,%eax
80101f9d:	84 c0                	test   %al,%al
80101f9f:	0f 85 13 02 00 00    	jne    801021b8 <writei+0x328>
  return n;
80101fa5:	8b 45 e0             	mov    -0x20(%ebp),%eax
}
80101fa8:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101fab:	5b                   	pop    %ebx
80101fac:	5e                   	pop    %esi
80101fad:	5f                   	pop    %edi
80101fae:	5d                   	pop    %ebp
80101faf:	c3                   	ret    
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].write)
80101fb0:	0f bf 40 56          	movswl 0x56(%eax),%eax
80101fb4:	66 83 f8 09          	cmp    $0x9,%ax
80101fb8:	0f 87 d2 02 00 00    	ja     80102290 <writei+0x400>
80101fbe:	8b 04 c5 64 19 11 80 	mov    -0x7feee69c(,%eax,8),%eax
80101fc5:	85 c0                	test   %eax,%eax
80101fc7:	0f 84 c3 02 00 00    	je     80102290 <writei+0x400>
    return devsw[ip->major].write(ip, src, n);
80101fcd:	89 55 10             	mov    %edx,0x10(%ebp)
}
80101fd0:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101fd3:	5b                   	pop    %ebx
80101fd4:	5e                   	pop    %esi
80101fd5:	5f                   	pop    %edi
80101fd6:	5d                   	pop    %ebp
    return devsw[ip->major].write(ip, src, n);
80101fd7:	ff e0                	jmp    *%eax
80101fd9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    ip->size = off;
80101fe0:	8b 45 d8             	mov    -0x28(%ebp),%eax
    iupdate(ip);
80101fe3:	83 ec 0c             	sub    $0xc,%esp
    ip->size = off;
80101fe6:	89 70 5c             	mov    %esi,0x5c(%eax)
    iupdate(ip);
80101fe9:	50                   	push   %eax
80101fea:	e8 c1 f7 ff ff       	call   801017b0 <iupdate>
80101fef:	83 c4 10             	add    $0x10,%esp
80101ff2:	e9 7a ff ff ff       	jmp    80101f71 <writei+0xe1>
80101ff7:	89 f6                	mov    %esi,%esi
80101ff9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    clear_inode(ip); // EZE DONE
80102000:	83 ec 0c             	sub    $0xc,%esp
80102003:	57                   	push   %edi
80102004:	e8 b7 fa ff ff       	call   80101ac0 <clear_inode>
80102009:	83 c4 10             	add    $0x10,%esp
8010200c:	e9 e0 fe ff ff       	jmp    80101ef1 <writei+0x61>
80102011:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    cprintf("STATUS B\n");
80102018:	83 ec 0c             	sub    $0xc,%esp
8010201b:	68 1f 79 10 80       	push   $0x8010791f
80102020:	e8 3b e6 ff ff       	call   80100660 <cprintf>
80102025:	83 c4 10             	add    $0x10,%esp
     for(int i=9;i>=0;i--){
80102028:	b8 09 00 00 00       	mov    $0x9,%eax
8010202d:	8d 76 00             	lea    0x0(%esi),%esi
      if(icache.inode_table1[i] !=0) {
80102030:	8b 0c 85 e4 53 11 80 	mov    -0x7feeac1c(,%eax,4),%ecx
80102037:	85 c9                	test   %ecx,%ecx
80102039:	0f 85 61 01 00 00    	jne    801021a0 <writei+0x310>
     for(int i=9;i>=0;i--){
8010203f:	83 e8 01             	sub    $0x1,%eax
80102042:	83 f8 ff             	cmp    $0xffffffff,%eax
80102045:	75 e9                	jne    80102030 <writei+0x1a0>
        cprintf("\n");
80102047:	83 ec 0c             	sub    $0xc,%esp
8010204a:	bf e4 53 11 80       	mov    $0x801153e4,%edi
8010204f:	bb 0c 54 11 80       	mov    $0x8011540c,%ebx
80102054:	68 db 81 10 80       	push   $0x801081db
80102059:	e8 02 e6 ff ff       	call   80100660 <cprintf>
8010205e:	83 c4 10             	add    $0x10,%esp
80102061:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        cprintf("[%d] ", icache.inode_table1[i]);
80102068:	83 ec 08             	sub    $0x8,%esp
8010206b:	ff 37                	pushl  (%edi)
8010206d:	83 c7 04             	add    $0x4,%edi
80102070:	68 f1 78 10 80       	push   $0x801078f1
80102075:	e8 e6 e5 ff ff       	call   80100660 <cprintf>
      for(int i=0;i<10;i++){
8010207a:	83 c4 10             	add    $0x10,%esp
8010207d:	39 fb                	cmp    %edi,%ebx
8010207f:	75 e7                	jne    80102068 <writei+0x1d8>
        cprintf("\n");
80102081:	83 ec 0c             	sub    $0xc,%esp
80102084:	bf 0c 54 11 80       	mov    $0x8011540c,%edi
80102089:	bb 34 54 11 80       	mov    $0x80115434,%ebx
8010208e:	68 db 81 10 80       	push   $0x801081db
80102093:	e8 c8 e5 ff ff       	call   80100660 <cprintf>
80102098:	83 c4 10             	add    $0x10,%esp
8010209b:	90                   	nop
8010209c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
        cprintf("[%d] ", icache.inode_table2[i]);
801020a0:	83 ec 08             	sub    $0x8,%esp
801020a3:	ff 37                	pushl  (%edi)
801020a5:	83 c7 04             	add    $0x4,%edi
801020a8:	68 f1 78 10 80       	push   $0x801078f1
801020ad:	e8 ae e5 ff ff       	call   80100660 <cprintf>
     for(int i=0;i<10;i++){
801020b2:	83 c4 10             	add    $0x10,%esp
801020b5:	39 fb                	cmp    %edi,%ebx
801020b7:	75 e7                	jne    801020a0 <writei+0x210>
        cprintf("\n");
801020b9:	83 ec 0c             	sub    $0xc,%esp
801020bc:	68 db 81 10 80       	push   $0x801081db
801020c1:	e8 9a e5 ff ff       	call   80100660 <cprintf>
801020c6:	a1 38 54 11 80       	mov    0x80115438,%eax
801020cb:	83 c4 10             	add    $0x10,%esp
  if (icache.status ==2 && off == LAST_OFF){
801020ce:	83 f8 02             	cmp    $0x2,%eax
801020d1:	0f 84 c4 fe ff ff    	je     80101f9b <writei+0x10b>
801020d7:	e9 c9 fe ff ff       	jmp    80101fa5 <writei+0x115>
801020dc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    cprintf("\nSTATUS A\n");
801020e0:	83 ec 0c             	sub    $0xc,%esp
801020e3:	68 14 79 10 80       	push   $0x80107914
801020e8:	e8 73 e5 ff ff       	call   80100660 <cprintf>
801020ed:	83 c4 10             	add    $0x10,%esp
    for(int i=0;i<10;i++){
801020f0:	31 c0                	xor    %eax,%eax
801020f2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(icache.inode_table1[i] ==0) {
801020f8:	8b 1c 85 e4 53 11 80 	mov    -0x7feeac1c(,%eax,4),%ebx
801020ff:	85 db                	test   %ebx,%ebx
80102101:	0f 84 93 01 00 00    	je     8010229a <writei+0x40a>
    for(int i=0;i<10;i++){
80102107:	83 c0 01             	add    $0x1,%eax
8010210a:	83 f8 0a             	cmp    $0xa,%eax
8010210d:	75 e9                	jne    801020f8 <writei+0x268>
    cprintf("\n");
8010210f:	83 ec 0c             	sub    $0xc,%esp
80102112:	bb e4 53 11 80       	mov    $0x801153e4,%ebx
80102117:	68 db 81 10 80       	push   $0x801081db
8010211c:	e8 3f e5 ff ff       	call   80100660 <cprintf>
80102121:	83 c4 10             	add    $0x10,%esp
80102124:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
        cprintf("[%d] ", icache.inode_table1[i]);
80102128:	83 ec 08             	sub    $0x8,%esp
8010212b:	ff 33                	pushl  (%ebx)
8010212d:	83 c3 04             	add    $0x4,%ebx
80102130:	68 f1 78 10 80       	push   $0x801078f1
80102135:	e8 26 e5 ff ff       	call   80100660 <cprintf>
    for(int i=0;i<10;i++){
8010213a:	83 c4 10             	add    $0x10,%esp
8010213d:	81 fb 0c 54 11 80    	cmp    $0x8011540c,%ebx
80102143:	75 e3                	jne    80102128 <writei+0x298>
        cprintf("\n");
80102145:	83 ec 0c             	sub    $0xc,%esp
80102148:	bb 0c 54 11 80       	mov    $0x8011540c,%ebx
8010214d:	68 db 81 10 80       	push   $0x801081db
80102152:	e8 09 e5 ff ff       	call   80100660 <cprintf>
80102157:	83 c4 10             	add    $0x10,%esp
8010215a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
        cprintf("[%d] ", icache.inode_table2[i]);
80102160:	83 ec 08             	sub    $0x8,%esp
80102163:	ff 33                	pushl  (%ebx)
80102165:	83 c3 04             	add    $0x4,%ebx
80102168:	68 f1 78 10 80       	push   $0x801078f1
8010216d:	e8 ee e4 ff ff       	call   80100660 <cprintf>
     for(int i=0;i<10;i++){
80102172:	83 c4 10             	add    $0x10,%esp
80102175:	81 fb 34 54 11 80    	cmp    $0x80115434,%ebx
8010217b:	75 e3                	jne    80102160 <writei+0x2d0>
        cprintf("\n");
8010217d:	83 ec 0c             	sub    $0xc,%esp
80102180:	68 db 81 10 80       	push   $0x801081db
80102185:	e8 d6 e4 ff ff       	call   80100660 <cprintf>
8010218a:	a1 38 54 11 80       	mov    0x80115438,%eax
8010218f:	83 c4 10             	add    $0x10,%esp
80102192:	e9 f6 fd ff ff       	jmp    80101f8d <writei+0xfd>
80102197:	89 f6                	mov    %esi,%esi
80102199:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
        icache.inode_table1[i+1]=ip->inum;
801021a0:	8b 55 d8             	mov    -0x28(%ebp),%edx
801021a3:	8b 52 04             	mov    0x4(%edx),%edx
801021a6:	89 14 85 e8 53 11 80 	mov    %edx,-0x7feeac18(,%eax,4)
801021ad:	e9 95 fe ff ff       	jmp    80102047 <writei+0x1b7>
801021b2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    cprintf("STATUS C\n");
801021b8:	83 ec 0c             	sub    $0xc,%esp
801021bb:	68 29 79 10 80       	push   $0x80107929
801021c0:	e8 9b e4 ff ff       	call   80100660 <cprintf>
      if(icache.inode_table1[i] ==ip->inum) {
801021c5:	8b 45 d8             	mov    -0x28(%ebp),%eax
801021c8:	83 c4 10             	add    $0x10,%esp
801021cb:	8b 50 04             	mov    0x4(%eax),%edx
    for(int i=9;i>=0;i--){
801021ce:	b8 09 00 00 00       	mov    $0x9,%eax
801021d3:	90                   	nop
801021d4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      if(icache.inode_table1[i] ==ip->inum) {
801021d8:	39 14 85 e4 53 11 80 	cmp    %edx,-0x7feeac1c(,%eax,4)
801021df:	0f 84 d9 00 00 00    	je     801022be <writei+0x42e>
    for(int i=9;i>=0;i--){
801021e5:	83 e8 01             	sub    $0x1,%eax
801021e8:	83 f8 ff             	cmp    $0xffffffff,%eax
801021eb:	75 eb                	jne    801021d8 <writei+0x348>
801021ed:	31 c0                	xor    %eax,%eax
801021ef:	90                   	nop
      if(icache.inode_table2[i] ==0) {
801021f0:	8b 14 85 0c 54 11 80 	mov    -0x7feeabf4(,%eax,4),%edx
801021f7:	85 d2                	test   %edx,%edx
801021f9:	0f 84 ad 00 00 00    	je     801022ac <writei+0x41c>
    for(int i=0;i<10;i++){
801021ff:	83 c0 01             	add    $0x1,%eax
80102202:	83 f8 0a             	cmp    $0xa,%eax
80102205:	75 e9                	jne    801021f0 <writei+0x360>
        cprintf("\n");
80102207:	83 ec 0c             	sub    $0xc,%esp
8010220a:	bb e4 53 11 80       	mov    $0x801153e4,%ebx
8010220f:	be 0c 54 11 80       	mov    $0x8011540c,%esi
80102214:	68 db 81 10 80       	push   $0x801081db
80102219:	e8 42 e4 ff ff       	call   80100660 <cprintf>
8010221e:	83 c4 10             	add    $0x10,%esp
80102221:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        cprintf("[%d] ", icache.inode_table1[i]);
80102228:	83 ec 08             	sub    $0x8,%esp
8010222b:	ff 33                	pushl  (%ebx)
8010222d:	83 c3 04             	add    $0x4,%ebx
80102230:	68 f1 78 10 80       	push   $0x801078f1
80102235:	e8 26 e4 ff ff       	call   80100660 <cprintf>
      for(int i=0;i<10;i++){
8010223a:	83 c4 10             	add    $0x10,%esp
8010223d:	39 de                	cmp    %ebx,%esi
8010223f:	75 e7                	jne    80102228 <writei+0x398>
        cprintf("\n");
80102241:	83 ec 0c             	sub    $0xc,%esp
80102244:	bb 0c 54 11 80       	mov    $0x8011540c,%ebx
80102249:	be 34 54 11 80       	mov    $0x80115434,%esi
8010224e:	68 db 81 10 80       	push   $0x801081db
80102253:	e8 08 e4 ff ff       	call   80100660 <cprintf>
80102258:	83 c4 10             	add    $0x10,%esp
8010225b:	90                   	nop
8010225c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
        cprintf("[%d] ", icache.inode_table2[i]);
80102260:	83 ec 08             	sub    $0x8,%esp
80102263:	ff 33                	pushl  (%ebx)
80102265:	83 c3 04             	add    $0x4,%ebx
80102268:	68 f1 78 10 80       	push   $0x801078f1
8010226d:	e8 ee e3 ff ff       	call   80100660 <cprintf>
     for(int i=0;i<10;i++){
80102272:	83 c4 10             	add    $0x10,%esp
80102275:	39 de                	cmp    %ebx,%esi
80102277:	75 e7                	jne    80102260 <writei+0x3d0>
        cprintf("\n");
80102279:	83 ec 0c             	sub    $0xc,%esp
8010227c:	68 db 81 10 80       	push   $0x801081db
80102281:	e8 da e3 ff ff       	call   80100660 <cprintf>
80102286:	83 c4 10             	add    $0x10,%esp
80102289:	e9 17 fd ff ff       	jmp    80101fa5 <writei+0x115>
8010228e:	66 90                	xchg   %ax,%ax
      return -1;
80102290:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80102295:	e9 0e fd ff ff       	jmp    80101fa8 <writei+0x118>
        icache.inode_table1[i]=ip->inum;
8010229a:	8b 55 d8             	mov    -0x28(%ebp),%edx
8010229d:	8b 52 04             	mov    0x4(%edx),%edx
801022a0:	89 14 85 e4 53 11 80 	mov    %edx,-0x7feeac1c(,%eax,4)
801022a7:	e9 63 fe ff ff       	jmp    8010210f <writei+0x27f>
        icache.inode_table2[i]=ip->inum;
801022ac:	8b 75 d8             	mov    -0x28(%ebp),%esi
801022af:	8b 56 04             	mov    0x4(%esi),%edx
801022b2:	89 14 85 0c 54 11 80 	mov    %edx,-0x7feeabf4(,%eax,4)
801022b9:	e9 49 ff ff ff       	jmp    80102207 <writei+0x377>
        icache.inode_table1[i]=0;
801022be:	c7 04 85 e4 53 11 80 	movl   $0x0,-0x7feeac1c(,%eax,4)
801022c5:	00 00 00 00 
801022c9:	e9 1f ff ff ff       	jmp    801021ed <writei+0x35d>
801022ce:	66 90                	xchg   %ax,%ax

801022d0 <sync_inode>:

void sync_inode(struct inode *ipd, struct inode *ips,char *src, uint off, uint n){
801022d0:	55                   	push   %ebp
801022d1:	89 e5                	mov    %esp,%ebp
801022d3:	57                   	push   %edi
801022d4:	56                   	push   %esi
801022d5:	53                   	push   %ebx
801022d6:	83 ec 1c             	sub    $0x1c,%esp
  
  uint tot, m;
  uint addr, *a;
  struct buf *bp;
  if(off > ipd->size || off + n < off)
801022d9:	8b 45 08             	mov    0x8(%ebp),%eax
void sync_inode(struct inode *ipd, struct inode *ips,char *src, uint off, uint n){
801022dc:	8b 5d 14             	mov    0x14(%ebp),%ebx
  if(off > ipd->size || off + n < off)
801022df:	39 58 5c             	cmp    %ebx,0x5c(%eax)
801022e2:	72 15                	jb     801022f9 <sync_inode+0x29>
801022e4:	31 d2                	xor    %edx,%edx
801022e6:	89 d8                	mov    %ebx,%eax
801022e8:	03 45 18             	add    0x18(%ebp),%eax
801022eb:	0f 92 c2             	setb   %dl
    return;
  if(off + n > MAXFILE*BSIZE)
801022ee:	3d 00 18 01 00       	cmp    $0x11800,%eax
801022f3:	77 04                	ja     801022f9 <sync_inode+0x29>
801022f5:	85 d2                	test   %edx,%edx
801022f7:	74 0f                	je     80102308 <sync_inode+0x38>
      brelse(bp);
    }
    m = min(n - tot, BSIZE - off%BSIZE); 
  }
  if(off == LAST_OFF) icache.status = 1; // EZE
}
801022f9:	8d 65 f4             	lea    -0xc(%ebp),%esp
801022fc:	5b                   	pop    %ebx
801022fd:	5e                   	pop    %esi
801022fe:	5f                   	pop    %edi
801022ff:	5d                   	pop    %ebp
80102300:	c3                   	ret    
80102301:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80102308:	8b 75 18             	mov    0x18(%ebp),%esi
8010230b:	85 f6                	test   %esi,%esi
8010230d:	0f 84 cd 00 00 00    	je     801023e0 <sync_inode+0x110>
80102313:	31 ff                	xor    %edi,%edi
80102315:	eb 3c                	jmp    80102353 <sync_inode+0x83>
80102317:	89 f6                	mov    %esi,%esi
80102319:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
      brelse(bp);
80102320:	83 ec 0c             	sub    $0xc,%esp
80102323:	50                   	push   %eax
80102324:	e8 b7 de ff ff       	call   801001e0 <brelse>
80102329:	83 c4 10             	add    $0x10,%esp
    m = min(n - tot, BSIZE - off%BSIZE); 
8010232c:	8b 4d 18             	mov    0x18(%ebp),%ecx
8010232f:	89 d8                	mov    %ebx,%eax
80102331:	ba 00 02 00 00       	mov    $0x200,%edx
80102336:	25 ff 01 00 00       	and    $0x1ff,%eax
8010233b:	29 c2                	sub    %eax,%edx
8010233d:	29 f9                	sub    %edi,%ecx
8010233f:	89 d0                	mov    %edx,%eax
80102341:	39 ca                	cmp    %ecx,%edx
80102343:	0f 47 c1             	cmova  %ecx,%eax
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80102346:	01 c7                	add    %eax,%edi
80102348:	01 c3                	add    %eax,%ebx
8010234a:	39 7d 18             	cmp    %edi,0x18(%ebp)
8010234d:	0f 86 8d 00 00 00    	jbe    801023e0 <sync_inode+0x110>
    uint bn = off/BSIZE;
80102353:	89 de                	mov    %ebx,%esi
80102355:	c1 ee 09             	shr    $0x9,%esi
    if(bn < NDIRECT){
80102358:	83 fe 0b             	cmp    $0xb,%esi
8010235b:	77 17                	ja     80102374 <sync_inode+0xa4>
8010235d:	8b 45 08             	mov    0x8(%ebp),%eax
80102360:	8d 04 b0             	lea    (%eax,%esi,4),%eax
    if((addr = ipd->addrs[bn]) == 0)
80102363:	8b 48 60             	mov    0x60(%eax),%ecx
80102366:	85 c9                	test   %ecx,%ecx
80102368:	75 0a                	jne    80102374 <sync_inode+0xa4>
      ipd->addrs[bn] = addr = ips->addrs[bn];
8010236a:	8b 55 0c             	mov    0xc(%ebp),%edx
8010236d:	8b 4c b2 60          	mov    0x60(%edx,%esi,4),%ecx
80102371:	89 48 60             	mov    %ecx,0x60(%eax)
    bn -= NDIRECT;
80102374:	83 ee 0c             	sub    $0xc,%esi
    if(bn < NINDIRECT){
80102377:	83 fe 7f             	cmp    $0x7f,%esi
8010237a:	77 b0                	ja     8010232c <sync_inode+0x5c>
      if((addr = ipd->addrs[NDIRECT]) == 0)
8010237c:	8b 45 08             	mov    0x8(%ebp),%eax
8010237f:	8b 80 90 00 00 00    	mov    0x90(%eax),%eax
80102385:	85 c0                	test   %eax,%eax
80102387:	75 12                	jne    8010239b <sync_inode+0xcb>
        ipd->addrs[NDIRECT] = addr = ips->addrs[NDIRECT];
80102389:	8b 45 0c             	mov    0xc(%ebp),%eax
8010238c:	8b 55 08             	mov    0x8(%ebp),%edx
8010238f:	8b 80 90 00 00 00    	mov    0x90(%eax),%eax
80102395:	89 82 90 00 00 00    	mov    %eax,0x90(%edx)
      bp = bread(ipd->dev, addr);
8010239b:	83 ec 08             	sub    $0x8,%esp
8010239e:	50                   	push   %eax
8010239f:	8b 45 08             	mov    0x8(%ebp),%eax
801023a2:	ff 30                	pushl  (%eax)
801023a4:	e8 27 dd ff ff       	call   801000d0 <bread>
      if((addr = a[bn]) == 0){
801023a9:	8d 4c b0 5c          	lea    0x5c(%eax,%esi,4),%ecx
801023ad:	83 c4 10             	add    $0x10,%esp
801023b0:	8b 11                	mov    (%ecx),%edx
801023b2:	85 d2                	test   %edx,%edx
801023b4:	0f 85 66 ff ff ff    	jne    80102320 <sync_inode+0x50>
        a[bn] = addr = ips->addrs[bn];
801023ba:	8b 55 0c             	mov    0xc(%ebp),%edx
        log_write(bp);
801023bd:	83 ec 0c             	sub    $0xc,%esp
801023c0:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        a[bn] = addr = ips->addrs[bn];
801023c3:	8b 74 b2 60          	mov    0x60(%edx,%esi,4),%esi
801023c7:	89 31                	mov    %esi,(%ecx)
        log_write(bp);
801023c9:	50                   	push   %eax
801023ca:	e8 21 12 00 00       	call   801035f0 <log_write>
801023cf:	83 c4 10             	add    $0x10,%esp
801023d2:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801023d5:	e9 46 ff ff ff       	jmp    80102320 <sync_inode+0x50>
801023da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  if(off == LAST_OFF) icache.status = 1; // EZE
801023e0:	81 fb 00 18 01 00    	cmp    $0x11800,%ebx
801023e6:	0f 85 0d ff ff ff    	jne    801022f9 <sync_inode+0x29>
801023ec:	c7 05 38 54 11 80 01 	movl   $0x1,0x80115438
801023f3:	00 00 00 
801023f6:	e9 fe fe ff ff       	jmp    801022f9 <sync_inode+0x29>
801023fb:	90                   	nop
801023fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80102400 <namecmp>:
///////////////////////////////////////////////////////////////////////////////

int
namecmp(const char *s, const char *t)
{
80102400:	55                   	push   %ebp
80102401:	89 e5                	mov    %esp,%ebp
80102403:	83 ec 0c             	sub    $0xc,%esp
  return strncmp(s, t, DIRSIZ);
80102406:	6a 0e                	push   $0xe
80102408:	ff 75 0c             	pushl  0xc(%ebp)
8010240b:	ff 75 08             	pushl  0x8(%ebp)
8010240e:	e8 dd 29 00 00       	call   80104df0 <strncmp>
}
80102413:	c9                   	leave  
80102414:	c3                   	ret    
80102415:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80102419:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80102420 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
80102420:	55                   	push   %ebp
80102421:	89 e5                	mov    %esp,%ebp
80102423:	57                   	push   %edi
80102424:	56                   	push   %esi
80102425:	53                   	push   %ebx
80102426:	83 ec 1c             	sub    $0x1c,%esp
80102429:	8b 5d 08             	mov    0x8(%ebp),%ebx
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
8010242c:	66 83 7b 54 01       	cmpw   $0x1,0x54(%ebx)
80102431:	0f 85 85 00 00 00    	jne    801024bc <dirlookup+0x9c>
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
80102437:	8b 53 5c             	mov    0x5c(%ebx),%edx
8010243a:	31 ff                	xor    %edi,%edi
8010243c:	8d 75 d8             	lea    -0x28(%ebp),%esi
8010243f:	85 d2                	test   %edx,%edx
80102441:	74 3e                	je     80102481 <dirlookup+0x61>
80102443:	90                   	nop
80102444:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80102448:	6a 10                	push   $0x10
8010244a:	57                   	push   %edi
8010244b:	56                   	push   %esi
8010244c:	53                   	push   %ebx
8010244d:	e8 6e f5 ff ff       	call   801019c0 <readi>
80102452:	83 c4 10             	add    $0x10,%esp
80102455:	83 f8 10             	cmp    $0x10,%eax
80102458:	75 55                	jne    801024af <dirlookup+0x8f>
      panic("dirlookup read");
    if(de.inum == 0)
8010245a:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
8010245f:	74 18                	je     80102479 <dirlookup+0x59>
  return strncmp(s, t, DIRSIZ);
80102461:	8d 45 da             	lea    -0x26(%ebp),%eax
80102464:	83 ec 04             	sub    $0x4,%esp
80102467:	6a 0e                	push   $0xe
80102469:	50                   	push   %eax
8010246a:	ff 75 0c             	pushl  0xc(%ebp)
8010246d:	e8 7e 29 00 00       	call   80104df0 <strncmp>
      continue;
    if(namecmp(name, de.name) == 0){
80102472:	83 c4 10             	add    $0x10,%esp
80102475:	85 c0                	test   %eax,%eax
80102477:	74 17                	je     80102490 <dirlookup+0x70>
  for(off = 0; off < dp->size; off += sizeof(de)){
80102479:	83 c7 10             	add    $0x10,%edi
8010247c:	3b 7b 5c             	cmp    0x5c(%ebx),%edi
8010247f:	72 c7                	jb     80102448 <dirlookup+0x28>
      return iget(dp->dev, inum);
    }
  }

  return 0;
}
80102481:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
80102484:	31 c0                	xor    %eax,%eax
}
80102486:	5b                   	pop    %ebx
80102487:	5e                   	pop    %esi
80102488:	5f                   	pop    %edi
80102489:	5d                   	pop    %ebp
8010248a:	c3                   	ret    
8010248b:	90                   	nop
8010248c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      if(poff)
80102490:	8b 45 10             	mov    0x10(%ebp),%eax
80102493:	85 c0                	test   %eax,%eax
80102495:	74 05                	je     8010249c <dirlookup+0x7c>
        *poff = off;
80102497:	8b 45 10             	mov    0x10(%ebp),%eax
8010249a:	89 38                	mov    %edi,(%eax)
      inum = de.inum;
8010249c:	0f b7 55 d8          	movzwl -0x28(%ebp),%edx
      return iget(dp->dev, inum);
801024a0:	8b 03                	mov    (%ebx),%eax
801024a2:	e8 89 ef ff ff       	call   80101430 <iget>
}
801024a7:	8d 65 f4             	lea    -0xc(%ebp),%esp
801024aa:	5b                   	pop    %ebx
801024ab:	5e                   	pop    %esi
801024ac:	5f                   	pop    %edi
801024ad:	5d                   	pop    %ebp
801024ae:	c3                   	ret    
      panic("dirlookup read");
801024af:	83 ec 0c             	sub    $0xc,%esp
801024b2:	68 45 79 10 80       	push   $0x80107945
801024b7:	e8 d4 de ff ff       	call   80100390 <panic>
    panic("dirlookup not DIR");
801024bc:	83 ec 0c             	sub    $0xc,%esp
801024bf:	68 33 79 10 80       	push   $0x80107933
801024c4:	e8 c7 de ff ff       	call   80100390 <panic>
801024c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

801024d0 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
801024d0:	55                   	push   %ebp
801024d1:	89 e5                	mov    %esp,%ebp
801024d3:	57                   	push   %edi
801024d4:	56                   	push   %esi
801024d5:	53                   	push   %ebx
801024d6:	89 cf                	mov    %ecx,%edi
801024d8:	89 c3                	mov    %eax,%ebx
801024da:	83 ec 1c             	sub    $0x1c,%esp
  struct inode *ip, *next;

  if(*path == '/')
801024dd:	80 38 2f             	cmpb   $0x2f,(%eax)
{
801024e0:	89 55 e0             	mov    %edx,-0x20(%ebp)
  if(*path == '/')
801024e3:	0f 84 67 01 00 00    	je     80102650 <namex+0x180>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
801024e9:	e8 72 1b 00 00       	call   80104060 <myproc>
  acquire(&icache.lock);
801024ee:	83 ec 0c             	sub    $0xc,%esp
    ip = idup(myproc()->cwd);
801024f1:	8b 70 68             	mov    0x68(%eax),%esi
  acquire(&icache.lock);
801024f4:	68 e0 19 11 80       	push   $0x801119e0
801024f9:	e8 c2 26 00 00       	call   80104bc0 <acquire>
  ip->ref++;
801024fe:	83 46 08 01          	addl   $0x1,0x8(%esi)
  release(&icache.lock);
80102502:	c7 04 24 e0 19 11 80 	movl   $0x801119e0,(%esp)
80102509:	e8 72 27 00 00       	call   80104c80 <release>
8010250e:	83 c4 10             	add    $0x10,%esp
80102511:	eb 08                	jmp    8010251b <namex+0x4b>
80102513:	90                   	nop
80102514:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    path++;
80102518:	83 c3 01             	add    $0x1,%ebx
  while(*path == '/')
8010251b:	0f b6 03             	movzbl (%ebx),%eax
8010251e:	3c 2f                	cmp    $0x2f,%al
80102520:	74 f6                	je     80102518 <namex+0x48>
  if(*path == 0)
80102522:	84 c0                	test   %al,%al
80102524:	0f 84 ee 00 00 00    	je     80102618 <namex+0x148>
  while(*path != '/' && *path != 0)
8010252a:	0f b6 03             	movzbl (%ebx),%eax
8010252d:	3c 2f                	cmp    $0x2f,%al
8010252f:	0f 84 b3 00 00 00    	je     801025e8 <namex+0x118>
80102535:	84 c0                	test   %al,%al
80102537:	89 da                	mov    %ebx,%edx
80102539:	75 09                	jne    80102544 <namex+0x74>
8010253b:	e9 a8 00 00 00       	jmp    801025e8 <namex+0x118>
80102540:	84 c0                	test   %al,%al
80102542:	74 0a                	je     8010254e <namex+0x7e>
    path++;
80102544:	83 c2 01             	add    $0x1,%edx
  while(*path != '/' && *path != 0)
80102547:	0f b6 02             	movzbl (%edx),%eax
8010254a:	3c 2f                	cmp    $0x2f,%al
8010254c:	75 f2                	jne    80102540 <namex+0x70>
8010254e:	89 d1                	mov    %edx,%ecx
80102550:	29 d9                	sub    %ebx,%ecx
  if(len >= DIRSIZ)
80102552:	83 f9 0d             	cmp    $0xd,%ecx
80102555:	0f 8e 91 00 00 00    	jle    801025ec <namex+0x11c>
    memmove(name, s, DIRSIZ);
8010255b:	83 ec 04             	sub    $0x4,%esp
8010255e:	89 55 e4             	mov    %edx,-0x1c(%ebp)
80102561:	6a 0e                	push   $0xe
80102563:	53                   	push   %ebx
80102564:	57                   	push   %edi
80102565:	e8 16 28 00 00       	call   80104d80 <memmove>
    path++;
8010256a:	8b 55 e4             	mov    -0x1c(%ebp),%edx
    memmove(name, s, DIRSIZ);
8010256d:	83 c4 10             	add    $0x10,%esp
    path++;
80102570:	89 d3                	mov    %edx,%ebx
  while(*path == '/')
80102572:	80 3a 2f             	cmpb   $0x2f,(%edx)
80102575:	75 11                	jne    80102588 <namex+0xb8>
80102577:	89 f6                	mov    %esi,%esi
80102579:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    path++;
80102580:	83 c3 01             	add    $0x1,%ebx
  while(*path == '/')
80102583:	80 3b 2f             	cmpb   $0x2f,(%ebx)
80102586:	74 f8                	je     80102580 <namex+0xb0>

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
80102588:	83 ec 0c             	sub    $0xc,%esp
8010258b:	56                   	push   %esi
8010258c:	e8 cf f2 ff ff       	call   80101860 <ilock>
    if(ip->type != T_DIR){
80102591:	83 c4 10             	add    $0x10,%esp
80102594:	66 83 7e 54 01       	cmpw   $0x1,0x54(%esi)
80102599:	0f 85 91 00 00 00    	jne    80102630 <namex+0x160>
      iunlockput(ip);
      return 0;
    }
    if(nameiparent && *path == '\0'){
8010259f:	8b 55 e0             	mov    -0x20(%ebp),%edx
801025a2:	85 d2                	test   %edx,%edx
801025a4:	74 09                	je     801025af <namex+0xdf>
801025a6:	80 3b 00             	cmpb   $0x0,(%ebx)
801025a9:	0f 84 b7 00 00 00    	je     80102666 <namex+0x196>
      // Stop one level early.
      iunlock(ip);
      return ip;
    }
    if((next = dirlookup(ip, name, 0)) == 0){
801025af:	83 ec 04             	sub    $0x4,%esp
801025b2:	6a 00                	push   $0x0
801025b4:	57                   	push   %edi
801025b5:	56                   	push   %esi
801025b6:	e8 65 fe ff ff       	call   80102420 <dirlookup>
801025bb:	83 c4 10             	add    $0x10,%esp
801025be:	85 c0                	test   %eax,%eax
801025c0:	74 6e                	je     80102630 <namex+0x160>
  iunlock(ip);
801025c2:	83 ec 0c             	sub    $0xc,%esp
801025c5:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801025c8:	56                   	push   %esi
801025c9:	e8 72 f3 ff ff       	call   80101940 <iunlock>
  iput(ip);
801025ce:	89 34 24             	mov    %esi,(%esp)
801025d1:	e8 ba f5 ff ff       	call   80101b90 <iput>
801025d6:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801025d9:	83 c4 10             	add    $0x10,%esp
801025dc:	89 c6                	mov    %eax,%esi
801025de:	e9 38 ff ff ff       	jmp    8010251b <namex+0x4b>
801025e3:	90                   	nop
801025e4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while(*path != '/' && *path != 0)
801025e8:	89 da                	mov    %ebx,%edx
801025ea:	31 c9                	xor    %ecx,%ecx
    memmove(name, s, len);
801025ec:	83 ec 04             	sub    $0x4,%esp
801025ef:	89 55 dc             	mov    %edx,-0x24(%ebp)
801025f2:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
801025f5:	51                   	push   %ecx
801025f6:	53                   	push   %ebx
801025f7:	57                   	push   %edi
801025f8:	e8 83 27 00 00       	call   80104d80 <memmove>
    name[len] = 0;
801025fd:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80102600:	8b 55 dc             	mov    -0x24(%ebp),%edx
80102603:	83 c4 10             	add    $0x10,%esp
80102606:	c6 04 0f 00          	movb   $0x0,(%edi,%ecx,1)
8010260a:	89 d3                	mov    %edx,%ebx
8010260c:	e9 61 ff ff ff       	jmp    80102572 <namex+0xa2>
80102611:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      return 0;
    }
    iunlockput(ip);
    ip = next;
  }
  if(nameiparent){
80102618:	8b 45 e0             	mov    -0x20(%ebp),%eax
8010261b:	85 c0                	test   %eax,%eax
8010261d:	75 5d                	jne    8010267c <namex+0x1ac>
    iput(ip);
    return 0;
  }
  return ip;
}
8010261f:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102622:	89 f0                	mov    %esi,%eax
80102624:	5b                   	pop    %ebx
80102625:	5e                   	pop    %esi
80102626:	5f                   	pop    %edi
80102627:	5d                   	pop    %ebp
80102628:	c3                   	ret    
80102629:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  iunlock(ip);
80102630:	83 ec 0c             	sub    $0xc,%esp
80102633:	56                   	push   %esi
80102634:	e8 07 f3 ff ff       	call   80101940 <iunlock>
  iput(ip);
80102639:	89 34 24             	mov    %esi,(%esp)
      return 0;
8010263c:	31 f6                	xor    %esi,%esi
  iput(ip);
8010263e:	e8 4d f5 ff ff       	call   80101b90 <iput>
      return 0;
80102643:	83 c4 10             	add    $0x10,%esp
}
80102646:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102649:	89 f0                	mov    %esi,%eax
8010264b:	5b                   	pop    %ebx
8010264c:	5e                   	pop    %esi
8010264d:	5f                   	pop    %edi
8010264e:	5d                   	pop    %ebp
8010264f:	c3                   	ret    
    ip = iget(ROOTDEV, ROOTINO);
80102650:	ba 01 00 00 00       	mov    $0x1,%edx
80102655:	b8 01 00 00 00       	mov    $0x1,%eax
8010265a:	e8 d1 ed ff ff       	call   80101430 <iget>
8010265f:	89 c6                	mov    %eax,%esi
80102661:	e9 b5 fe ff ff       	jmp    8010251b <namex+0x4b>
      iunlock(ip);
80102666:	83 ec 0c             	sub    $0xc,%esp
80102669:	56                   	push   %esi
8010266a:	e8 d1 f2 ff ff       	call   80101940 <iunlock>
      return ip;
8010266f:	83 c4 10             	add    $0x10,%esp
}
80102672:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102675:	89 f0                	mov    %esi,%eax
80102677:	5b                   	pop    %ebx
80102678:	5e                   	pop    %esi
80102679:	5f                   	pop    %edi
8010267a:	5d                   	pop    %ebp
8010267b:	c3                   	ret    
    iput(ip);
8010267c:	83 ec 0c             	sub    $0xc,%esp
8010267f:	56                   	push   %esi
    return 0;
80102680:	31 f6                	xor    %esi,%esi
    iput(ip);
80102682:	e8 09 f5 ff ff       	call   80101b90 <iput>
    return 0;
80102687:	83 c4 10             	add    $0x10,%esp
8010268a:	eb 93                	jmp    8010261f <namex+0x14f>
8010268c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80102690 <dirlink>:
{
80102690:	55                   	push   %ebp
80102691:	89 e5                	mov    %esp,%ebp
80102693:	57                   	push   %edi
80102694:	56                   	push   %esi
80102695:	53                   	push   %ebx
80102696:	83 ec 20             	sub    $0x20,%esp
80102699:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if((ip = dirlookup(dp, name, 0)) != 0){
8010269c:	6a 00                	push   $0x0
8010269e:	ff 75 0c             	pushl  0xc(%ebp)
801026a1:	53                   	push   %ebx
801026a2:	e8 79 fd ff ff       	call   80102420 <dirlookup>
801026a7:	83 c4 10             	add    $0x10,%esp
801026aa:	85 c0                	test   %eax,%eax
801026ac:	75 67                	jne    80102715 <dirlink+0x85>
  for(off = 0; off < dp->size; off += sizeof(de)){
801026ae:	8b 7b 5c             	mov    0x5c(%ebx),%edi
801026b1:	8d 75 d8             	lea    -0x28(%ebp),%esi
801026b4:	85 ff                	test   %edi,%edi
801026b6:	74 29                	je     801026e1 <dirlink+0x51>
801026b8:	31 ff                	xor    %edi,%edi
801026ba:	8d 75 d8             	lea    -0x28(%ebp),%esi
801026bd:	eb 09                	jmp    801026c8 <dirlink+0x38>
801026bf:	90                   	nop
801026c0:	83 c7 10             	add    $0x10,%edi
801026c3:	3b 7b 5c             	cmp    0x5c(%ebx),%edi
801026c6:	73 19                	jae    801026e1 <dirlink+0x51>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
801026c8:	6a 10                	push   $0x10
801026ca:	57                   	push   %edi
801026cb:	56                   	push   %esi
801026cc:	53                   	push   %ebx
801026cd:	e8 ee f2 ff ff       	call   801019c0 <readi>
801026d2:	83 c4 10             	add    $0x10,%esp
801026d5:	83 f8 10             	cmp    $0x10,%eax
801026d8:	75 4e                	jne    80102728 <dirlink+0x98>
    if(de.inum == 0)
801026da:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
801026df:	75 df                	jne    801026c0 <dirlink+0x30>
  strncpy(de.name, name, DIRSIZ);
801026e1:	8d 45 da             	lea    -0x26(%ebp),%eax
801026e4:	83 ec 04             	sub    $0x4,%esp
801026e7:	6a 0e                	push   $0xe
801026e9:	ff 75 0c             	pushl  0xc(%ebp)
801026ec:	50                   	push   %eax
801026ed:	e8 5e 27 00 00       	call   80104e50 <strncpy>
  de.inum = inum;
801026f2:	8b 45 10             	mov    0x10(%ebp),%eax
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
801026f5:	6a 10                	push   $0x10
801026f7:	57                   	push   %edi
801026f8:	56                   	push   %esi
801026f9:	53                   	push   %ebx
  de.inum = inum;
801026fa:	66 89 45 d8          	mov    %ax,-0x28(%ebp)
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
801026fe:	e8 8d f7 ff ff       	call   80101e90 <writei>
80102703:	83 c4 20             	add    $0x20,%esp
80102706:	83 f8 10             	cmp    $0x10,%eax
80102709:	75 2a                	jne    80102735 <dirlink+0xa5>
  return 0;
8010270b:	31 c0                	xor    %eax,%eax
}
8010270d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102710:	5b                   	pop    %ebx
80102711:	5e                   	pop    %esi
80102712:	5f                   	pop    %edi
80102713:	5d                   	pop    %ebp
80102714:	c3                   	ret    
    iput(ip);
80102715:	83 ec 0c             	sub    $0xc,%esp
80102718:	50                   	push   %eax
80102719:	e8 72 f4 ff ff       	call   80101b90 <iput>
    return -1;
8010271e:	83 c4 10             	add    $0x10,%esp
80102721:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80102726:	eb e5                	jmp    8010270d <dirlink+0x7d>
      panic("dirlink read");
80102728:	83 ec 0c             	sub    $0xc,%esp
8010272b:	68 54 79 10 80       	push   $0x80107954
80102730:	e8 5b dc ff ff       	call   80100390 <panic>
    panic("dirlink");
80102735:	83 ec 0c             	sub    $0xc,%esp
80102738:	68 c2 7f 10 80       	push   $0x80107fc2
8010273d:	e8 4e dc ff ff       	call   80100390 <panic>
80102742:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80102749:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80102750 <namei>:

struct inode*
namei(char *path)
{
80102750:	55                   	push   %ebp
  char name[DIRSIZ];
  return namex(path, 0, name);
80102751:	31 d2                	xor    %edx,%edx
{
80102753:	89 e5                	mov    %esp,%ebp
80102755:	83 ec 18             	sub    $0x18,%esp
  return namex(path, 0, name);
80102758:	8b 45 08             	mov    0x8(%ebp),%eax
8010275b:	8d 4d ea             	lea    -0x16(%ebp),%ecx
8010275e:	e8 6d fd ff ff       	call   801024d0 <namex>
}
80102763:	c9                   	leave  
80102764:	c3                   	ret    
80102765:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80102769:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80102770 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
80102770:	55                   	push   %ebp
  return namex(path, 1, name);
80102771:	ba 01 00 00 00       	mov    $0x1,%edx
{
80102776:	89 e5                	mov    %esp,%ebp
  return namex(path, 1, name);
80102778:	8b 4d 0c             	mov    0xc(%ebp),%ecx
8010277b:	8b 45 08             	mov    0x8(%ebp),%eax
}
8010277e:	5d                   	pop    %ebp
  return namex(path, 1, name);
8010277f:	e9 4c fd ff ff       	jmp    801024d0 <namex>
80102784:	66 90                	xchg   %ax,%ax
80102786:	66 90                	xchg   %ax,%ax
80102788:	66 90                	xchg   %ax,%ax
8010278a:	66 90                	xchg   %ax,%ax
8010278c:	66 90                	xchg   %ax,%ax
8010278e:	66 90                	xchg   %ax,%ax

80102790 <idestart>:
}

// Start the request for b.  Caller must hold idelock.
static void
idestart(struct buf *b)
{
80102790:	55                   	push   %ebp
80102791:	89 e5                	mov    %esp,%ebp
80102793:	57                   	push   %edi
80102794:	56                   	push   %esi
80102795:	53                   	push   %ebx
80102796:	83 ec 0c             	sub    $0xc,%esp
  if(b == 0)
80102799:	85 c0                	test   %eax,%eax
8010279b:	0f 84 c4 00 00 00    	je     80102865 <idestart+0xd5>
    panic("idestart");
  if(b->blockno >= FSSIZE){
801027a1:	8b 58 08             	mov    0x8(%eax),%ebx
801027a4:	89 c6                	mov    %eax,%esi
801027a6:	81 fb b7 0b 00 00    	cmp    $0xbb7,%ebx
801027ac:	0f 87 96 00 00 00    	ja     80102848 <idestart+0xb8>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801027b2:	b9 f7 01 00 00       	mov    $0x1f7,%ecx
801027b7:	89 f6                	mov    %esi,%esi
801027b9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
801027c0:	89 ca                	mov    %ecx,%edx
801027c2:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
801027c3:	83 e0 c0             	and    $0xffffffc0,%eax
801027c6:	3c 40                	cmp    $0x40,%al
801027c8:	75 f6                	jne    801027c0 <idestart+0x30>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801027ca:	31 ff                	xor    %edi,%edi
801027cc:	ba f6 03 00 00       	mov    $0x3f6,%edx
801027d1:	89 f8                	mov    %edi,%eax
801027d3:	ee                   	out    %al,(%dx)
801027d4:	b8 01 00 00 00       	mov    $0x1,%eax
801027d9:	ba f2 01 00 00       	mov    $0x1f2,%edx
801027de:	ee                   	out    %al,(%dx)
801027df:	ba f3 01 00 00       	mov    $0x1f3,%edx
801027e4:	89 d8                	mov    %ebx,%eax
801027e6:	ee                   	out    %al,(%dx)

  idewait(0);
  outb(0x3f6, 0);  // generate interrupt
  outb(0x1f2, sector_per_block);  // number of sectors
  outb(0x1f3, sector & 0xff);
  outb(0x1f4, (sector >> 8) & 0xff);
801027e7:	89 d8                	mov    %ebx,%eax
801027e9:	ba f4 01 00 00       	mov    $0x1f4,%edx
801027ee:	c1 f8 08             	sar    $0x8,%eax
801027f1:	ee                   	out    %al,(%dx)
801027f2:	ba f5 01 00 00       	mov    $0x1f5,%edx
801027f7:	89 f8                	mov    %edi,%eax
801027f9:	ee                   	out    %al,(%dx)
  outb(0x1f5, (sector >> 16) & 0xff);
  outb(0x1f6, 0xe0 | ((b->dev&1)<<4) | ((sector>>24)&0x0f));
801027fa:	0f b6 46 04          	movzbl 0x4(%esi),%eax
801027fe:	ba f6 01 00 00       	mov    $0x1f6,%edx
80102803:	c1 e0 04             	shl    $0x4,%eax
80102806:	83 e0 10             	and    $0x10,%eax
80102809:	83 c8 e0             	or     $0xffffffe0,%eax
8010280c:	ee                   	out    %al,(%dx)
  if(b->flags & B_DIRTY){
8010280d:	f6 06 04             	testb  $0x4,(%esi)
80102810:	75 16                	jne    80102828 <idestart+0x98>
80102812:	b8 20 00 00 00       	mov    $0x20,%eax
80102817:	89 ca                	mov    %ecx,%edx
80102819:	ee                   	out    %al,(%dx)
    outb(0x1f7, write_cmd);
    outsl(0x1f0, b->data, BSIZE/4);
  } else {
    outb(0x1f7, read_cmd);
  }
}
8010281a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010281d:	5b                   	pop    %ebx
8010281e:	5e                   	pop    %esi
8010281f:	5f                   	pop    %edi
80102820:	5d                   	pop    %ebp
80102821:	c3                   	ret    
80102822:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80102828:	b8 30 00 00 00       	mov    $0x30,%eax
8010282d:	89 ca                	mov    %ecx,%edx
8010282f:	ee                   	out    %al,(%dx)
  asm volatile("cld; rep outsl" :
80102830:	b9 80 00 00 00       	mov    $0x80,%ecx
    outsl(0x1f0, b->data, BSIZE/4);
80102835:	83 c6 5c             	add    $0x5c,%esi
80102838:	ba f0 01 00 00       	mov    $0x1f0,%edx
8010283d:	fc                   	cld    
8010283e:	f3 6f                	rep outsl %ds:(%esi),(%dx)
}
80102840:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102843:	5b                   	pop    %ebx
80102844:	5e                   	pop    %esi
80102845:	5f                   	pop    %edi
80102846:	5d                   	pop    %ebp
80102847:	c3                   	ret    
		cprintf("blockno = %d, FSSIZE = %d\n", b->blockno, FSSIZE);
80102848:	50                   	push   %eax
80102849:	68 b8 0b 00 00       	push   $0xbb8
8010284e:	53                   	push   %ebx
8010284f:	68 08 7a 10 80       	push   $0x80107a08
80102854:	e8 07 de ff ff       	call   80100660 <cprintf>
    panic("incorrect blockno");
80102859:	c7 04 24 23 7a 10 80 	movl   $0x80107a23,(%esp)
80102860:	e8 2b db ff ff       	call   80100390 <panic>
    panic("idestart");
80102865:	83 ec 0c             	sub    $0xc,%esp
80102868:	68 ff 79 10 80       	push   $0x801079ff
8010286d:	e8 1e db ff ff       	call   80100390 <panic>
80102872:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80102879:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80102880 <ideinit>:
{
80102880:	55                   	push   %ebp
80102881:	89 e5                	mov    %esp,%ebp
80102883:	83 ec 10             	sub    $0x10,%esp
  initlock(&idelock, "ide");
80102886:	68 35 7a 10 80       	push   $0x80107a35
8010288b:	68 80 b5 10 80       	push   $0x8010b580
80102890:	e8 eb 21 00 00       	call   80104a80 <initlock>
  ioapicenable(IRQ_IDE, ncpu - 1);
80102895:	58                   	pop    %eax
80102896:	a1 00 5b 11 80       	mov    0x80115b00,%eax
8010289b:	5a                   	pop    %edx
8010289c:	83 e8 01             	sub    $0x1,%eax
8010289f:	50                   	push   %eax
801028a0:	6a 0e                	push   $0xe
801028a2:	e8 a9 02 00 00       	call   80102b50 <ioapicenable>
801028a7:	83 c4 10             	add    $0x10,%esp
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801028aa:	ba f7 01 00 00       	mov    $0x1f7,%edx
801028af:	90                   	nop
801028b0:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
801028b1:	83 e0 c0             	and    $0xffffffc0,%eax
801028b4:	3c 40                	cmp    $0x40,%al
801028b6:	75 f8                	jne    801028b0 <ideinit+0x30>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801028b8:	b8 f0 ff ff ff       	mov    $0xfffffff0,%eax
801028bd:	ba f6 01 00 00       	mov    $0x1f6,%edx
801028c2:	ee                   	out    %al,(%dx)
801028c3:	b9 e8 03 00 00       	mov    $0x3e8,%ecx
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801028c8:	ba f7 01 00 00       	mov    $0x1f7,%edx
801028cd:	eb 06                	jmp    801028d5 <ideinit+0x55>
801028cf:	90                   	nop
  for(i=0; i<1000; i++){
801028d0:	83 e9 01             	sub    $0x1,%ecx
801028d3:	74 0f                	je     801028e4 <ideinit+0x64>
801028d5:	ec                   	in     (%dx),%al
    if(inb(0x1f7) != 0){
801028d6:	84 c0                	test   %al,%al
801028d8:	74 f6                	je     801028d0 <ideinit+0x50>
      havedisk1 = 1;
801028da:	c7 05 60 b5 10 80 01 	movl   $0x1,0x8010b560
801028e1:	00 00 00 
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801028e4:	b8 e0 ff ff ff       	mov    $0xffffffe0,%eax
801028e9:	ba f6 01 00 00       	mov    $0x1f6,%edx
801028ee:	ee                   	out    %al,(%dx)
}
801028ef:	c9                   	leave  
801028f0:	c3                   	ret    
801028f1:	eb 0d                	jmp    80102900 <ideintr>
801028f3:	90                   	nop
801028f4:	90                   	nop
801028f5:	90                   	nop
801028f6:	90                   	nop
801028f7:	90                   	nop
801028f8:	90                   	nop
801028f9:	90                   	nop
801028fa:	90                   	nop
801028fb:	90                   	nop
801028fc:	90                   	nop
801028fd:	90                   	nop
801028fe:	90                   	nop
801028ff:	90                   	nop

80102900 <ideintr>:

// Interrupt handler.
void
ideintr(void)
{
80102900:	55                   	push   %ebp
80102901:	89 e5                	mov    %esp,%ebp
80102903:	57                   	push   %edi
80102904:	56                   	push   %esi
80102905:	53                   	push   %ebx
80102906:	83 ec 18             	sub    $0x18,%esp
  struct buf *b;

  // First queued buffer is the active request.
  acquire(&idelock);
80102909:	68 80 b5 10 80       	push   $0x8010b580
8010290e:	e8 ad 22 00 00       	call   80104bc0 <acquire>

  if((b = idequeue) == 0){
80102913:	8b 1d 64 b5 10 80    	mov    0x8010b564,%ebx
80102919:	83 c4 10             	add    $0x10,%esp
8010291c:	85 db                	test   %ebx,%ebx
8010291e:	74 67                	je     80102987 <ideintr+0x87>
    release(&idelock);
    return;
  }
  idequeue = b->qnext;
80102920:	8b 43 58             	mov    0x58(%ebx),%eax
80102923:	a3 64 b5 10 80       	mov    %eax,0x8010b564

  // Read data if needed.
  if(!(b->flags & B_DIRTY) && idewait(1) >= 0)
80102928:	8b 3b                	mov    (%ebx),%edi
8010292a:	f7 c7 04 00 00 00    	test   $0x4,%edi
80102930:	75 31                	jne    80102963 <ideintr+0x63>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102932:	ba f7 01 00 00       	mov    $0x1f7,%edx
80102937:	89 f6                	mov    %esi,%esi
80102939:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
80102940:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80102941:	89 c6                	mov    %eax,%esi
80102943:	83 e6 c0             	and    $0xffffffc0,%esi
80102946:	89 f1                	mov    %esi,%ecx
80102948:	80 f9 40             	cmp    $0x40,%cl
8010294b:	75 f3                	jne    80102940 <ideintr+0x40>
  if(checkerr && (r & (IDE_DF|IDE_ERR)) != 0)
8010294d:	a8 21                	test   $0x21,%al
8010294f:	75 12                	jne    80102963 <ideintr+0x63>
    insl(0x1f0, b->data, BSIZE/4);
80102951:	8d 7b 5c             	lea    0x5c(%ebx),%edi
  asm volatile("cld; rep insl" :
80102954:	b9 80 00 00 00       	mov    $0x80,%ecx
80102959:	ba f0 01 00 00       	mov    $0x1f0,%edx
8010295e:	fc                   	cld    
8010295f:	f3 6d                	rep insl (%dx),%es:(%edi)
80102961:	8b 3b                	mov    (%ebx),%edi

  // Wake process waiting for this buf.
  b->flags |= B_VALID;
  b->flags &= ~B_DIRTY;
80102963:	83 e7 fb             	and    $0xfffffffb,%edi
  wakeup(b);
80102966:	83 ec 0c             	sub    $0xc,%esp
  b->flags &= ~B_DIRTY;
80102969:	89 f9                	mov    %edi,%ecx
8010296b:	83 c9 02             	or     $0x2,%ecx
8010296e:	89 0b                	mov    %ecx,(%ebx)
  wakeup(b);
80102970:	53                   	push   %ebx
80102971:	e8 3a 1e 00 00       	call   801047b0 <wakeup>

  // Start disk on next buf in queue.
  if(idequeue != 0)
80102976:	a1 64 b5 10 80       	mov    0x8010b564,%eax
8010297b:	83 c4 10             	add    $0x10,%esp
8010297e:	85 c0                	test   %eax,%eax
80102980:	74 05                	je     80102987 <ideintr+0x87>
    idestart(idequeue);
80102982:	e8 09 fe ff ff       	call   80102790 <idestart>
    release(&idelock);
80102987:	83 ec 0c             	sub    $0xc,%esp
8010298a:	68 80 b5 10 80       	push   $0x8010b580
8010298f:	e8 ec 22 00 00       	call   80104c80 <release>

  release(&idelock);
}
80102994:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102997:	5b                   	pop    %ebx
80102998:	5e                   	pop    %esi
80102999:	5f                   	pop    %edi
8010299a:	5d                   	pop    %ebp
8010299b:	c3                   	ret    
8010299c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

801029a0 <iderw>:
// Sync buf with disk.
// If B_DIRTY is set, write buf to disk, clear B_DIRTY, set B_VALID.
// Else if B_VALID is not set, read buf from disk, set B_VALID.
void
iderw(struct buf *b)
{
801029a0:	55                   	push   %ebp
801029a1:	89 e5                	mov    %esp,%ebp
801029a3:	53                   	push   %ebx
801029a4:	83 ec 10             	sub    $0x10,%esp
801029a7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct buf **pp;

  if(!holdingsleep(&b->lock))
801029aa:	8d 43 0c             	lea    0xc(%ebx),%eax
801029ad:	50                   	push   %eax
801029ae:	e8 7d 20 00 00       	call   80104a30 <holdingsleep>
801029b3:	83 c4 10             	add    $0x10,%esp
801029b6:	85 c0                	test   %eax,%eax
801029b8:	0f 84 c6 00 00 00    	je     80102a84 <iderw+0xe4>
    panic("iderw: buf not locked");
  if((b->flags & (B_VALID|B_DIRTY)) == B_VALID)
801029be:	8b 03                	mov    (%ebx),%eax
801029c0:	83 e0 06             	and    $0x6,%eax
801029c3:	83 f8 02             	cmp    $0x2,%eax
801029c6:	0f 84 ab 00 00 00    	je     80102a77 <iderw+0xd7>
    panic("iderw: nothing to do");
  if(b->dev != 0 && !havedisk1)
801029cc:	8b 53 04             	mov    0x4(%ebx),%edx
801029cf:	85 d2                	test   %edx,%edx
801029d1:	74 0d                	je     801029e0 <iderw+0x40>
801029d3:	a1 60 b5 10 80       	mov    0x8010b560,%eax
801029d8:	85 c0                	test   %eax,%eax
801029da:	0f 84 b1 00 00 00    	je     80102a91 <iderw+0xf1>
    panic("iderw: ide disk 1 not present");

  acquire(&idelock);  //DOC:acquire-lock
801029e0:	83 ec 0c             	sub    $0xc,%esp
801029e3:	68 80 b5 10 80       	push   $0x8010b580
801029e8:	e8 d3 21 00 00       	call   80104bc0 <acquire>

  // Append b to idequeue.
  b->qnext = 0;
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
801029ed:	8b 15 64 b5 10 80    	mov    0x8010b564,%edx
801029f3:	83 c4 10             	add    $0x10,%esp
  b->qnext = 0;
801029f6:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
801029fd:	85 d2                	test   %edx,%edx
801029ff:	75 09                	jne    80102a0a <iderw+0x6a>
80102a01:	eb 6d                	jmp    80102a70 <iderw+0xd0>
80102a03:	90                   	nop
80102a04:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80102a08:	89 c2                	mov    %eax,%edx
80102a0a:	8b 42 58             	mov    0x58(%edx),%eax
80102a0d:	85 c0                	test   %eax,%eax
80102a0f:	75 f7                	jne    80102a08 <iderw+0x68>
80102a11:	83 c2 58             	add    $0x58,%edx
    ;
  *pp = b;
80102a14:	89 1a                	mov    %ebx,(%edx)

  // Start disk if necessary.
  if(idequeue == b)
80102a16:	39 1d 64 b5 10 80    	cmp    %ebx,0x8010b564
80102a1c:	74 42                	je     80102a60 <iderw+0xc0>
    idestart(b);

  // Wait for request to finish.
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
80102a1e:	8b 03                	mov    (%ebx),%eax
80102a20:	83 e0 06             	and    $0x6,%eax
80102a23:	83 f8 02             	cmp    $0x2,%eax
80102a26:	74 23                	je     80102a4b <iderw+0xab>
80102a28:	90                   	nop
80102a29:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    sleep(b, &idelock);
80102a30:	83 ec 08             	sub    $0x8,%esp
80102a33:	68 80 b5 10 80       	push   $0x8010b580
80102a38:	53                   	push   %ebx
80102a39:	e8 c2 1b 00 00       	call   80104600 <sleep>
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
80102a3e:	8b 03                	mov    (%ebx),%eax
80102a40:	83 c4 10             	add    $0x10,%esp
80102a43:	83 e0 06             	and    $0x6,%eax
80102a46:	83 f8 02             	cmp    $0x2,%eax
80102a49:	75 e5                	jne    80102a30 <iderw+0x90>
  }


  release(&idelock);
80102a4b:	c7 45 08 80 b5 10 80 	movl   $0x8010b580,0x8(%ebp)
}
80102a52:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102a55:	c9                   	leave  
  release(&idelock);
80102a56:	e9 25 22 00 00       	jmp    80104c80 <release>
80102a5b:	90                   	nop
80102a5c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    idestart(b);
80102a60:	89 d8                	mov    %ebx,%eax
80102a62:	e8 29 fd ff ff       	call   80102790 <idestart>
80102a67:	eb b5                	jmp    80102a1e <iderw+0x7e>
80102a69:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
80102a70:	ba 64 b5 10 80       	mov    $0x8010b564,%edx
80102a75:	eb 9d                	jmp    80102a14 <iderw+0x74>
    panic("iderw: nothing to do");
80102a77:	83 ec 0c             	sub    $0xc,%esp
80102a7a:	68 4f 7a 10 80       	push   $0x80107a4f
80102a7f:	e8 0c d9 ff ff       	call   80100390 <panic>
    panic("iderw: buf not locked");
80102a84:	83 ec 0c             	sub    $0xc,%esp
80102a87:	68 39 7a 10 80       	push   $0x80107a39
80102a8c:	e8 ff d8 ff ff       	call   80100390 <panic>
    panic("iderw: ide disk 1 not present");
80102a91:	83 ec 0c             	sub    $0xc,%esp
80102a94:	68 64 7a 10 80       	push   $0x80107a64
80102a99:	e8 f2 d8 ff ff       	call   80100390 <panic>
80102a9e:	66 90                	xchg   %ax,%ax

80102aa0 <ioapicinit>:
  ioapic->data = data;
}

void
ioapicinit(void)
{
80102aa0:	55                   	push   %ebp
  int i, id, maxintr;

  ioapic = (volatile struct ioapic*)IOAPIC;
80102aa1:	c7 05 3c 54 11 80 00 	movl   $0xfec00000,0x8011543c
80102aa8:	00 c0 fe 
{
80102aab:	89 e5                	mov    %esp,%ebp
80102aad:	56                   	push   %esi
80102aae:	53                   	push   %ebx
  ioapic->reg = reg;
80102aaf:	c7 05 00 00 c0 fe 01 	movl   $0x1,0xfec00000
80102ab6:	00 00 00 
  return ioapic->data;
80102ab9:	a1 3c 54 11 80       	mov    0x8011543c,%eax
80102abe:	8b 58 10             	mov    0x10(%eax),%ebx
  ioapic->reg = reg;
80102ac1:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  return ioapic->data;
80102ac7:	8b 0d 3c 54 11 80    	mov    0x8011543c,%ecx
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
  id = ioapicread(REG_ID) >> 24;
  if(id != ioapicid)
80102acd:	0f b6 15 60 55 11 80 	movzbl 0x80115560,%edx
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
80102ad4:	c1 eb 10             	shr    $0x10,%ebx
  return ioapic->data;
80102ad7:	8b 41 10             	mov    0x10(%ecx),%eax
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
80102ada:	0f b6 db             	movzbl %bl,%ebx
  id = ioapicread(REG_ID) >> 24;
80102add:	c1 e8 18             	shr    $0x18,%eax
  if(id != ioapicid)
80102ae0:	39 c2                	cmp    %eax,%edx
80102ae2:	74 16                	je     80102afa <ioapicinit+0x5a>
    cprintf("ioapicinit: id isn't equal to ioapicid; not a MP\n");
80102ae4:	83 ec 0c             	sub    $0xc,%esp
80102ae7:	68 84 7a 10 80       	push   $0x80107a84
80102aec:	e8 6f db ff ff       	call   80100660 <cprintf>
80102af1:	8b 0d 3c 54 11 80    	mov    0x8011543c,%ecx
80102af7:	83 c4 10             	add    $0x10,%esp
80102afa:	83 c3 21             	add    $0x21,%ebx
{
80102afd:	ba 10 00 00 00       	mov    $0x10,%edx
80102b02:	b8 20 00 00 00       	mov    $0x20,%eax
80102b07:	89 f6                	mov    %esi,%esi
80102b09:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
  ioapic->reg = reg;
80102b10:	89 11                	mov    %edx,(%ecx)
  ioapic->data = data;
80102b12:	8b 0d 3c 54 11 80    	mov    0x8011543c,%ecx

  // Mark all interrupts edge-triggered, active high, disabled,
  // and not routed to any CPUs.
  for(i = 0; i <= maxintr; i++){
    ioapicwrite(REG_TABLE+2*i, INT_DISABLED | (T_IRQ0 + i));
80102b18:	89 c6                	mov    %eax,%esi
80102b1a:	81 ce 00 00 01 00    	or     $0x10000,%esi
80102b20:	83 c0 01             	add    $0x1,%eax
  ioapic->data = data;
80102b23:	89 71 10             	mov    %esi,0x10(%ecx)
80102b26:	8d 72 01             	lea    0x1(%edx),%esi
80102b29:	83 c2 02             	add    $0x2,%edx
  for(i = 0; i <= maxintr; i++){
80102b2c:	39 d8                	cmp    %ebx,%eax
  ioapic->reg = reg;
80102b2e:	89 31                	mov    %esi,(%ecx)
  ioapic->data = data;
80102b30:	8b 0d 3c 54 11 80    	mov    0x8011543c,%ecx
80102b36:	c7 41 10 00 00 00 00 	movl   $0x0,0x10(%ecx)
  for(i = 0; i <= maxintr; i++){
80102b3d:	75 d1                	jne    80102b10 <ioapicinit+0x70>
    ioapicwrite(REG_TABLE+2*i+1, 0);
  }
}
80102b3f:	8d 65 f8             	lea    -0x8(%ebp),%esp
80102b42:	5b                   	pop    %ebx
80102b43:	5e                   	pop    %esi
80102b44:	5d                   	pop    %ebp
80102b45:	c3                   	ret    
80102b46:	8d 76 00             	lea    0x0(%esi),%esi
80102b49:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80102b50 <ioapicenable>:

void
ioapicenable(int irq, int cpunum)
{
80102b50:	55                   	push   %ebp
  ioapic->reg = reg;
80102b51:	8b 0d 3c 54 11 80    	mov    0x8011543c,%ecx
{
80102b57:	89 e5                	mov    %esp,%ebp
80102b59:	8b 45 08             	mov    0x8(%ebp),%eax
  // Mark interrupt edge-triggered, active high,
  // enabled, and routed to the given cpunum,
  // which happens to be that cpu's APIC ID.
  ioapicwrite(REG_TABLE+2*irq, T_IRQ0 + irq);
80102b5c:	8d 50 20             	lea    0x20(%eax),%edx
80102b5f:	8d 44 00 10          	lea    0x10(%eax,%eax,1),%eax
  ioapic->reg = reg;
80102b63:	89 01                	mov    %eax,(%ecx)
  ioapic->data = data;
80102b65:	8b 0d 3c 54 11 80    	mov    0x8011543c,%ecx
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
80102b6b:	83 c0 01             	add    $0x1,%eax
  ioapic->data = data;
80102b6e:	89 51 10             	mov    %edx,0x10(%ecx)
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
80102b71:	8b 55 0c             	mov    0xc(%ebp),%edx
  ioapic->reg = reg;
80102b74:	89 01                	mov    %eax,(%ecx)
  ioapic->data = data;
80102b76:	a1 3c 54 11 80       	mov    0x8011543c,%eax
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
80102b7b:	c1 e2 18             	shl    $0x18,%edx
  ioapic->data = data;
80102b7e:	89 50 10             	mov    %edx,0x10(%eax)
}
80102b81:	5d                   	pop    %ebp
80102b82:	c3                   	ret    
80102b83:	66 90                	xchg   %ax,%ax
80102b85:	66 90                	xchg   %ax,%ax
80102b87:	66 90                	xchg   %ax,%ax
80102b89:	66 90                	xchg   %ax,%ax
80102b8b:	66 90                	xchg   %ax,%ax
80102b8d:	66 90                	xchg   %ax,%ax
80102b8f:	90                   	nop

80102b90 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(char *v)
{
80102b90:	55                   	push   %ebp
80102b91:	89 e5                	mov    %esp,%ebp
80102b93:	53                   	push   %ebx
80102b94:	83 ec 04             	sub    $0x4,%esp
80102b97:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct run *r;

  if((uint)v % PGSIZE || v < end || V2P(v) >= PHYSTOP)
80102b9a:	f7 c3 ff 0f 00 00    	test   $0xfff,%ebx
80102ba0:	75 70                	jne    80102c12 <kfree+0x82>
80102ba2:	81 fb a8 82 11 80    	cmp    $0x801182a8,%ebx
80102ba8:	72 68                	jb     80102c12 <kfree+0x82>
80102baa:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
80102bb0:	3d ff ff ff 0d       	cmp    $0xdffffff,%eax
80102bb5:	77 5b                	ja     80102c12 <kfree+0x82>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(v, 1, PGSIZE);
80102bb7:	83 ec 04             	sub    $0x4,%esp
80102bba:	68 00 10 00 00       	push   $0x1000
80102bbf:	6a 01                	push   $0x1
80102bc1:	53                   	push   %ebx
80102bc2:	e8 09 21 00 00       	call   80104cd0 <memset>

  if(kmem.use_lock)
80102bc7:	8b 15 74 54 11 80    	mov    0x80115474,%edx
80102bcd:	83 c4 10             	add    $0x10,%esp
80102bd0:	85 d2                	test   %edx,%edx
80102bd2:	75 2c                	jne    80102c00 <kfree+0x70>
    acquire(&kmem.lock);
  r = (struct run*)v;
  r->next = kmem.freelist;
80102bd4:	a1 78 54 11 80       	mov    0x80115478,%eax
80102bd9:	89 03                	mov    %eax,(%ebx)
  kmem.freelist = r;
  if(kmem.use_lock)
80102bdb:	a1 74 54 11 80       	mov    0x80115474,%eax
  kmem.freelist = r;
80102be0:	89 1d 78 54 11 80    	mov    %ebx,0x80115478
  if(kmem.use_lock)
80102be6:	85 c0                	test   %eax,%eax
80102be8:	75 06                	jne    80102bf0 <kfree+0x60>
    release(&kmem.lock);
}
80102bea:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102bed:	c9                   	leave  
80102bee:	c3                   	ret    
80102bef:	90                   	nop
    release(&kmem.lock);
80102bf0:	c7 45 08 40 54 11 80 	movl   $0x80115440,0x8(%ebp)
}
80102bf7:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102bfa:	c9                   	leave  
    release(&kmem.lock);
80102bfb:	e9 80 20 00 00       	jmp    80104c80 <release>
    acquire(&kmem.lock);
80102c00:	83 ec 0c             	sub    $0xc,%esp
80102c03:	68 40 54 11 80       	push   $0x80115440
80102c08:	e8 b3 1f 00 00       	call   80104bc0 <acquire>
80102c0d:	83 c4 10             	add    $0x10,%esp
80102c10:	eb c2                	jmp    80102bd4 <kfree+0x44>
    panic("kfree");
80102c12:	83 ec 0c             	sub    $0xc,%esp
80102c15:	68 b6 7a 10 80       	push   $0x80107ab6
80102c1a:	e8 71 d7 ff ff       	call   80100390 <panic>
80102c1f:	90                   	nop

80102c20 <freerange>:
{
80102c20:	55                   	push   %ebp
80102c21:	89 e5                	mov    %esp,%ebp
80102c23:	56                   	push   %esi
80102c24:	53                   	push   %ebx
  p = (char*)PGROUNDUP((uint)vstart);
80102c25:	8b 45 08             	mov    0x8(%ebp),%eax
{
80102c28:	8b 75 0c             	mov    0xc(%ebp),%esi
  p = (char*)PGROUNDUP((uint)vstart);
80102c2b:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
80102c31:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102c37:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80102c3d:	39 de                	cmp    %ebx,%esi
80102c3f:	72 23                	jb     80102c64 <freerange+0x44>
80102c41:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    kfree(p);
80102c48:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
80102c4e:	83 ec 0c             	sub    $0xc,%esp
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102c51:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
80102c57:	50                   	push   %eax
80102c58:	e8 33 ff ff ff       	call   80102b90 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102c5d:	83 c4 10             	add    $0x10,%esp
80102c60:	39 f3                	cmp    %esi,%ebx
80102c62:	76 e4                	jbe    80102c48 <freerange+0x28>
}
80102c64:	8d 65 f8             	lea    -0x8(%ebp),%esp
80102c67:	5b                   	pop    %ebx
80102c68:	5e                   	pop    %esi
80102c69:	5d                   	pop    %ebp
80102c6a:	c3                   	ret    
80102c6b:	90                   	nop
80102c6c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80102c70 <kinit1>:
{
80102c70:	55                   	push   %ebp
80102c71:	89 e5                	mov    %esp,%ebp
80102c73:	56                   	push   %esi
80102c74:	53                   	push   %ebx
80102c75:	8b 75 0c             	mov    0xc(%ebp),%esi
  initlock(&kmem.lock, "kmem");
80102c78:	83 ec 08             	sub    $0x8,%esp
80102c7b:	68 bc 7a 10 80       	push   $0x80107abc
80102c80:	68 40 54 11 80       	push   $0x80115440
80102c85:	e8 f6 1d 00 00       	call   80104a80 <initlock>
  p = (char*)PGROUNDUP((uint)vstart);
80102c8a:	8b 45 08             	mov    0x8(%ebp),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102c8d:	83 c4 10             	add    $0x10,%esp
  kmem.use_lock = 0;
80102c90:	c7 05 74 54 11 80 00 	movl   $0x0,0x80115474
80102c97:	00 00 00 
  p = (char*)PGROUNDUP((uint)vstart);
80102c9a:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
80102ca0:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102ca6:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80102cac:	39 de                	cmp    %ebx,%esi
80102cae:	72 1c                	jb     80102ccc <kinit1+0x5c>
    kfree(p);
80102cb0:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
80102cb6:	83 ec 0c             	sub    $0xc,%esp
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102cb9:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
80102cbf:	50                   	push   %eax
80102cc0:	e8 cb fe ff ff       	call   80102b90 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102cc5:	83 c4 10             	add    $0x10,%esp
80102cc8:	39 de                	cmp    %ebx,%esi
80102cca:	73 e4                	jae    80102cb0 <kinit1+0x40>
}
80102ccc:	8d 65 f8             	lea    -0x8(%ebp),%esp
80102ccf:	5b                   	pop    %ebx
80102cd0:	5e                   	pop    %esi
80102cd1:	5d                   	pop    %ebp
80102cd2:	c3                   	ret    
80102cd3:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80102cd9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80102ce0 <kinit2>:
{
80102ce0:	55                   	push   %ebp
80102ce1:	89 e5                	mov    %esp,%ebp
80102ce3:	56                   	push   %esi
80102ce4:	53                   	push   %ebx
  p = (char*)PGROUNDUP((uint)vstart);
80102ce5:	8b 45 08             	mov    0x8(%ebp),%eax
{
80102ce8:	8b 75 0c             	mov    0xc(%ebp),%esi
  p = (char*)PGROUNDUP((uint)vstart);
80102ceb:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
80102cf1:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102cf7:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80102cfd:	39 de                	cmp    %ebx,%esi
80102cff:	72 23                	jb     80102d24 <kinit2+0x44>
80102d01:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    kfree(p);
80102d08:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
80102d0e:	83 ec 0c             	sub    $0xc,%esp
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102d11:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
80102d17:	50                   	push   %eax
80102d18:	e8 73 fe ff ff       	call   80102b90 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102d1d:	83 c4 10             	add    $0x10,%esp
80102d20:	39 de                	cmp    %ebx,%esi
80102d22:	73 e4                	jae    80102d08 <kinit2+0x28>
  kmem.use_lock = 1;
80102d24:	c7 05 74 54 11 80 01 	movl   $0x1,0x80115474
80102d2b:	00 00 00 
}
80102d2e:	8d 65 f8             	lea    -0x8(%ebp),%esp
80102d31:	5b                   	pop    %ebx
80102d32:	5e                   	pop    %esi
80102d33:	5d                   	pop    %ebp
80102d34:	c3                   	ret    
80102d35:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80102d39:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80102d40 <kalloc>:
char*
kalloc(void)
{
  struct run *r;

  if(kmem.use_lock)
80102d40:	a1 74 54 11 80       	mov    0x80115474,%eax
80102d45:	85 c0                	test   %eax,%eax
80102d47:	75 1f                	jne    80102d68 <kalloc+0x28>
    acquire(&kmem.lock);
  r = kmem.freelist;
80102d49:	a1 78 54 11 80       	mov    0x80115478,%eax
  if(r)
80102d4e:	85 c0                	test   %eax,%eax
80102d50:	74 0e                	je     80102d60 <kalloc+0x20>
    kmem.freelist = r->next;
80102d52:	8b 10                	mov    (%eax),%edx
80102d54:	89 15 78 54 11 80    	mov    %edx,0x80115478
80102d5a:	c3                   	ret    
80102d5b:	90                   	nop
80102d5c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  if(kmem.use_lock)
    release(&kmem.lock);
  return (char*)r;
}
80102d60:	f3 c3                	repz ret 
80102d62:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
{
80102d68:	55                   	push   %ebp
80102d69:	89 e5                	mov    %esp,%ebp
80102d6b:	83 ec 24             	sub    $0x24,%esp
    acquire(&kmem.lock);
80102d6e:	68 40 54 11 80       	push   $0x80115440
80102d73:	e8 48 1e 00 00       	call   80104bc0 <acquire>
  r = kmem.freelist;
80102d78:	a1 78 54 11 80       	mov    0x80115478,%eax
  if(r)
80102d7d:	83 c4 10             	add    $0x10,%esp
80102d80:	8b 15 74 54 11 80    	mov    0x80115474,%edx
80102d86:	85 c0                	test   %eax,%eax
80102d88:	74 08                	je     80102d92 <kalloc+0x52>
    kmem.freelist = r->next;
80102d8a:	8b 08                	mov    (%eax),%ecx
80102d8c:	89 0d 78 54 11 80    	mov    %ecx,0x80115478
  if(kmem.use_lock)
80102d92:	85 d2                	test   %edx,%edx
80102d94:	74 16                	je     80102dac <kalloc+0x6c>
    release(&kmem.lock);
80102d96:	83 ec 0c             	sub    $0xc,%esp
80102d99:	89 45 f4             	mov    %eax,-0xc(%ebp)
80102d9c:	68 40 54 11 80       	push   $0x80115440
80102da1:	e8 da 1e 00 00       	call   80104c80 <release>
  return (char*)r;
80102da6:	8b 45 f4             	mov    -0xc(%ebp),%eax
    release(&kmem.lock);
80102da9:	83 c4 10             	add    $0x10,%esp
}
80102dac:	c9                   	leave  
80102dad:	c3                   	ret    
80102dae:	66 90                	xchg   %ax,%ax

80102db0 <kbdgetc>:
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102db0:	ba 64 00 00 00       	mov    $0x64,%edx
80102db5:	ec                   	in     (%dx),%al
    normalmap, shiftmap, ctlmap, ctlmap
  };
  uint st, data, c;

  st = inb(KBSTATP);
  if((st & KBS_DIB) == 0)
80102db6:	a8 01                	test   $0x1,%al
80102db8:	0f 84 c2 00 00 00    	je     80102e80 <kbdgetc+0xd0>
80102dbe:	ba 60 00 00 00       	mov    $0x60,%edx
80102dc3:	ec                   	in     (%dx),%al
    return -1;
  data = inb(KBDATAP);
80102dc4:	0f b6 d0             	movzbl %al,%edx
80102dc7:	8b 0d b4 b5 10 80    	mov    0x8010b5b4,%ecx

  if(data == 0xE0){
80102dcd:	81 fa e0 00 00 00    	cmp    $0xe0,%edx
80102dd3:	0f 84 7f 00 00 00    	je     80102e58 <kbdgetc+0xa8>
{
80102dd9:	55                   	push   %ebp
80102dda:	89 e5                	mov    %esp,%ebp
80102ddc:	53                   	push   %ebx
80102ddd:	89 cb                	mov    %ecx,%ebx
80102ddf:	83 e3 40             	and    $0x40,%ebx
    shift |= E0ESC;
    return 0;
  } else if(data & 0x80){
80102de2:	84 c0                	test   %al,%al
80102de4:	78 4a                	js     80102e30 <kbdgetc+0x80>
    // Key released
    data = (shift & E0ESC ? data : data & 0x7F);
    shift &= ~(shiftcode[data] | E0ESC);
    return 0;
  } else if(shift & E0ESC){
80102de6:	85 db                	test   %ebx,%ebx
80102de8:	74 09                	je     80102df3 <kbdgetc+0x43>
    // Last character was an E0 escape; or with 0x80
    data |= 0x80;
80102dea:	83 c8 80             	or     $0xffffff80,%eax
    shift &= ~E0ESC;
80102ded:	83 e1 bf             	and    $0xffffffbf,%ecx
    data |= 0x80;
80102df0:	0f b6 d0             	movzbl %al,%edx
  }

  shift |= shiftcode[data];
80102df3:	0f b6 82 00 7c 10 80 	movzbl -0x7fef8400(%edx),%eax
80102dfa:	09 c1                	or     %eax,%ecx
  shift ^= togglecode[data];
80102dfc:	0f b6 82 00 7b 10 80 	movzbl -0x7fef8500(%edx),%eax
80102e03:	31 c1                	xor    %eax,%ecx
  c = charcode[shift & (CTL | SHIFT)][data];
80102e05:	89 c8                	mov    %ecx,%eax
  shift ^= togglecode[data];
80102e07:	89 0d b4 b5 10 80    	mov    %ecx,0x8010b5b4
  c = charcode[shift & (CTL | SHIFT)][data];
80102e0d:	83 e0 03             	and    $0x3,%eax
  if(shift & CAPSLOCK){
80102e10:	83 e1 08             	and    $0x8,%ecx
  c = charcode[shift & (CTL | SHIFT)][data];
80102e13:	8b 04 85 e0 7a 10 80 	mov    -0x7fef8520(,%eax,4),%eax
80102e1a:	0f b6 04 10          	movzbl (%eax,%edx,1),%eax
  if(shift & CAPSLOCK){
80102e1e:	74 31                	je     80102e51 <kbdgetc+0xa1>
    if('a' <= c && c <= 'z')
80102e20:	8d 50 9f             	lea    -0x61(%eax),%edx
80102e23:	83 fa 19             	cmp    $0x19,%edx
80102e26:	77 40                	ja     80102e68 <kbdgetc+0xb8>
      c += 'A' - 'a';
80102e28:	83 e8 20             	sub    $0x20,%eax
    else if('A' <= c && c <= 'Z')
      c += 'a' - 'A';
  }
  return c;
}
80102e2b:	5b                   	pop    %ebx
80102e2c:	5d                   	pop    %ebp
80102e2d:	c3                   	ret    
80102e2e:	66 90                	xchg   %ax,%ax
    data = (shift & E0ESC ? data : data & 0x7F);
80102e30:	83 e0 7f             	and    $0x7f,%eax
80102e33:	85 db                	test   %ebx,%ebx
80102e35:	0f 44 d0             	cmove  %eax,%edx
    shift &= ~(shiftcode[data] | E0ESC);
80102e38:	0f b6 82 00 7c 10 80 	movzbl -0x7fef8400(%edx),%eax
80102e3f:	83 c8 40             	or     $0x40,%eax
80102e42:	0f b6 c0             	movzbl %al,%eax
80102e45:	f7 d0                	not    %eax
80102e47:	21 c1                	and    %eax,%ecx
    return 0;
80102e49:	31 c0                	xor    %eax,%eax
    shift &= ~(shiftcode[data] | E0ESC);
80102e4b:	89 0d b4 b5 10 80    	mov    %ecx,0x8010b5b4
}
80102e51:	5b                   	pop    %ebx
80102e52:	5d                   	pop    %ebp
80102e53:	c3                   	ret    
80102e54:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    shift |= E0ESC;
80102e58:	83 c9 40             	or     $0x40,%ecx
    return 0;
80102e5b:	31 c0                	xor    %eax,%eax
    shift |= E0ESC;
80102e5d:	89 0d b4 b5 10 80    	mov    %ecx,0x8010b5b4
    return 0;
80102e63:	c3                   	ret    
80102e64:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    else if('A' <= c && c <= 'Z')
80102e68:	8d 48 bf             	lea    -0x41(%eax),%ecx
      c += 'a' - 'A';
80102e6b:	8d 50 20             	lea    0x20(%eax),%edx
}
80102e6e:	5b                   	pop    %ebx
      c += 'a' - 'A';
80102e6f:	83 f9 1a             	cmp    $0x1a,%ecx
80102e72:	0f 42 c2             	cmovb  %edx,%eax
}
80102e75:	5d                   	pop    %ebp
80102e76:	c3                   	ret    
80102e77:	89 f6                	mov    %esi,%esi
80102e79:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    return -1;
80102e80:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80102e85:	c3                   	ret    
80102e86:	8d 76 00             	lea    0x0(%esi),%esi
80102e89:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80102e90 <kbdintr>:

void
kbdintr(void)
{
80102e90:	55                   	push   %ebp
80102e91:	89 e5                	mov    %esp,%ebp
80102e93:	83 ec 14             	sub    $0x14,%esp
  consoleintr(kbdgetc);
80102e96:	68 b0 2d 10 80       	push   $0x80102db0
80102e9b:	e8 70 d9 ff ff       	call   80100810 <consoleintr>
}
80102ea0:	83 c4 10             	add    $0x10,%esp
80102ea3:	c9                   	leave  
80102ea4:	c3                   	ret    
80102ea5:	66 90                	xchg   %ax,%ax
80102ea7:	66 90                	xchg   %ax,%ax
80102ea9:	66 90                	xchg   %ax,%ax
80102eab:	66 90                	xchg   %ax,%ax
80102ead:	66 90                	xchg   %ax,%ax
80102eaf:	90                   	nop

80102eb0 <lapicinit>:
}

void
lapicinit(void)
{
  if(!lapic)
80102eb0:	a1 7c 54 11 80       	mov    0x8011547c,%eax
{
80102eb5:	55                   	push   %ebp
80102eb6:	89 e5                	mov    %esp,%ebp
  if(!lapic)
80102eb8:	85 c0                	test   %eax,%eax
80102eba:	0f 84 c8 00 00 00    	je     80102f88 <lapicinit+0xd8>
  lapic[index] = value;
80102ec0:	c7 80 f0 00 00 00 3f 	movl   $0x13f,0xf0(%eax)
80102ec7:	01 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102eca:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102ecd:	c7 80 e0 03 00 00 0b 	movl   $0xb,0x3e0(%eax)
80102ed4:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102ed7:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102eda:	c7 80 20 03 00 00 20 	movl   $0x20020,0x320(%eax)
80102ee1:	00 02 00 
  lapic[ID];  // wait for write to finish, by reading
80102ee4:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102ee7:	c7 80 80 03 00 00 80 	movl   $0x989680,0x380(%eax)
80102eee:	96 98 00 
  lapic[ID];  // wait for write to finish, by reading
80102ef1:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102ef4:	c7 80 50 03 00 00 00 	movl   $0x10000,0x350(%eax)
80102efb:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
80102efe:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102f01:	c7 80 60 03 00 00 00 	movl   $0x10000,0x360(%eax)
80102f08:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
80102f0b:	8b 50 20             	mov    0x20(%eax),%edx
  lapicw(LINT0, MASKED);
  lapicw(LINT1, MASKED);

  // Disable performance counter overflow interrupts
  // on machines that provide that interrupt entry.
  if(((lapic[VER]>>16) & 0xFF) >= 4)
80102f0e:	8b 50 30             	mov    0x30(%eax),%edx
80102f11:	c1 ea 10             	shr    $0x10,%edx
80102f14:	80 fa 03             	cmp    $0x3,%dl
80102f17:	77 77                	ja     80102f90 <lapicinit+0xe0>
  lapic[index] = value;
80102f19:	c7 80 70 03 00 00 33 	movl   $0x33,0x370(%eax)
80102f20:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102f23:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102f26:	c7 80 80 02 00 00 00 	movl   $0x0,0x280(%eax)
80102f2d:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102f30:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102f33:	c7 80 80 02 00 00 00 	movl   $0x0,0x280(%eax)
80102f3a:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102f3d:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102f40:	c7 80 b0 00 00 00 00 	movl   $0x0,0xb0(%eax)
80102f47:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102f4a:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102f4d:	c7 80 10 03 00 00 00 	movl   $0x0,0x310(%eax)
80102f54:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102f57:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102f5a:	c7 80 00 03 00 00 00 	movl   $0x88500,0x300(%eax)
80102f61:	85 08 00 
  lapic[ID];  // wait for write to finish, by reading
80102f64:	8b 50 20             	mov    0x20(%eax),%edx
80102f67:	89 f6                	mov    %esi,%esi
80102f69:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
  lapicw(EOI, 0);

  // Send an Init Level De-Assert to synchronise arbitration ID's.
  lapicw(ICRHI, 0);
  lapicw(ICRLO, BCAST | INIT | LEVEL);
  while(lapic[ICRLO] & DELIVS)
80102f70:	8b 90 00 03 00 00    	mov    0x300(%eax),%edx
80102f76:	80 e6 10             	and    $0x10,%dh
80102f79:	75 f5                	jne    80102f70 <lapicinit+0xc0>
  lapic[index] = value;
80102f7b:	c7 80 80 00 00 00 00 	movl   $0x0,0x80(%eax)
80102f82:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102f85:	8b 40 20             	mov    0x20(%eax),%eax
    ;

  // Enable interrupts on the APIC (but not on the processor).
  lapicw(TPR, 0);
}
80102f88:	5d                   	pop    %ebp
80102f89:	c3                   	ret    
80102f8a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  lapic[index] = value;
80102f90:	c7 80 40 03 00 00 00 	movl   $0x10000,0x340(%eax)
80102f97:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
80102f9a:	8b 50 20             	mov    0x20(%eax),%edx
80102f9d:	e9 77 ff ff ff       	jmp    80102f19 <lapicinit+0x69>
80102fa2:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80102fa9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80102fb0 <lapicid>:

int
lapicid(void)
{
  if (!lapic)
80102fb0:	8b 15 7c 54 11 80    	mov    0x8011547c,%edx
{
80102fb6:	55                   	push   %ebp
80102fb7:	31 c0                	xor    %eax,%eax
80102fb9:	89 e5                	mov    %esp,%ebp
  if (!lapic)
80102fbb:	85 d2                	test   %edx,%edx
80102fbd:	74 06                	je     80102fc5 <lapicid+0x15>
    return 0;
  return lapic[ID] >> 24;
80102fbf:	8b 42 20             	mov    0x20(%edx),%eax
80102fc2:	c1 e8 18             	shr    $0x18,%eax
}
80102fc5:	5d                   	pop    %ebp
80102fc6:	c3                   	ret    
80102fc7:	89 f6                	mov    %esi,%esi
80102fc9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80102fd0 <lapiceoi>:

// Acknowledge interrupt.
void
lapiceoi(void)
{
  if(lapic)
80102fd0:	a1 7c 54 11 80       	mov    0x8011547c,%eax
{
80102fd5:	55                   	push   %ebp
80102fd6:	89 e5                	mov    %esp,%ebp
  if(lapic)
80102fd8:	85 c0                	test   %eax,%eax
80102fda:	74 0d                	je     80102fe9 <lapiceoi+0x19>
  lapic[index] = value;
80102fdc:	c7 80 b0 00 00 00 00 	movl   $0x0,0xb0(%eax)
80102fe3:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102fe6:	8b 40 20             	mov    0x20(%eax),%eax
    lapicw(EOI, 0);
}
80102fe9:	5d                   	pop    %ebp
80102fea:	c3                   	ret    
80102feb:	90                   	nop
80102fec:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80102ff0 <microdelay>:

// Spin for a given number of microseconds.
// On real hardware would want to tune this dynamically.
void
microdelay(int us)
{
80102ff0:	55                   	push   %ebp
80102ff1:	89 e5                	mov    %esp,%ebp
}
80102ff3:	5d                   	pop    %ebp
80102ff4:	c3                   	ret    
80102ff5:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80102ff9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80103000 <lapicstartap>:

// Start additional processor running entry code at addr.
// See Appendix B of MultiProcessor Specification.
void
lapicstartap(uchar apicid, uint addr)
{
80103000:	55                   	push   %ebp
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103001:	b8 0f 00 00 00       	mov    $0xf,%eax
80103006:	ba 70 00 00 00       	mov    $0x70,%edx
8010300b:	89 e5                	mov    %esp,%ebp
8010300d:	53                   	push   %ebx
8010300e:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80103011:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103014:	ee                   	out    %al,(%dx)
80103015:	b8 0a 00 00 00       	mov    $0xa,%eax
8010301a:	ba 71 00 00 00       	mov    $0x71,%edx
8010301f:	ee                   	out    %al,(%dx)
  // and the warm reset vector (DWORD based at 40:67) to point at
  // the AP startup code prior to the [universal startup algorithm]."
  outb(CMOS_PORT, 0xF);  // offset 0xF is shutdown code
  outb(CMOS_PORT+1, 0x0A);
  wrv = (ushort*)P2V((0x40<<4 | 0x67));  // Warm reset vector
  wrv[0] = 0;
80103020:	31 c0                	xor    %eax,%eax
  wrv[1] = addr >> 4;

  // "Universal startup algorithm."
  // Send INIT (level-triggered) interrupt to reset other CPU.
  lapicw(ICRHI, apicid<<24);
80103022:	c1 e3 18             	shl    $0x18,%ebx
  wrv[0] = 0;
80103025:	66 a3 67 04 00 80    	mov    %ax,0x80000467
  wrv[1] = addr >> 4;
8010302b:	89 c8                	mov    %ecx,%eax
  // when it is in the halted state due to an INIT.  So the second
  // should be ignored, but it is part of the official Intel algorithm.
  // Bochs complains about the second one.  Too bad for Bochs.
  for(i = 0; i < 2; i++){
    lapicw(ICRHI, apicid<<24);
    lapicw(ICRLO, STARTUP | (addr>>12));
8010302d:	c1 e9 0c             	shr    $0xc,%ecx
  wrv[1] = addr >> 4;
80103030:	c1 e8 04             	shr    $0x4,%eax
  lapicw(ICRHI, apicid<<24);
80103033:	89 da                	mov    %ebx,%edx
    lapicw(ICRLO, STARTUP | (addr>>12));
80103035:	80 cd 06             	or     $0x6,%ch
  wrv[1] = addr >> 4;
80103038:	66 a3 69 04 00 80    	mov    %ax,0x80000469
  lapic[index] = value;
8010303e:	a1 7c 54 11 80       	mov    0x8011547c,%eax
80103043:	89 98 10 03 00 00    	mov    %ebx,0x310(%eax)
  lapic[ID];  // wait for write to finish, by reading
80103049:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
8010304c:	c7 80 00 03 00 00 00 	movl   $0xc500,0x300(%eax)
80103053:	c5 00 00 
  lapic[ID];  // wait for write to finish, by reading
80103056:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
80103059:	c7 80 00 03 00 00 00 	movl   $0x8500,0x300(%eax)
80103060:	85 00 00 
  lapic[ID];  // wait for write to finish, by reading
80103063:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
80103066:	89 90 10 03 00 00    	mov    %edx,0x310(%eax)
  lapic[ID];  // wait for write to finish, by reading
8010306c:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
8010306f:	89 88 00 03 00 00    	mov    %ecx,0x300(%eax)
  lapic[ID];  // wait for write to finish, by reading
80103075:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
80103078:	89 90 10 03 00 00    	mov    %edx,0x310(%eax)
  lapic[ID];  // wait for write to finish, by reading
8010307e:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80103081:	89 88 00 03 00 00    	mov    %ecx,0x300(%eax)
  lapic[ID];  // wait for write to finish, by reading
80103087:	8b 40 20             	mov    0x20(%eax),%eax
    microdelay(200);
  }
}
8010308a:	5b                   	pop    %ebx
8010308b:	5d                   	pop    %ebp
8010308c:	c3                   	ret    
8010308d:	8d 76 00             	lea    0x0(%esi),%esi

80103090 <cmostime>:
}

// qemu seems to use 24-hour GWT and the values are BCD encoded
void
cmostime(struct rtcdate *r)
{
80103090:	55                   	push   %ebp
80103091:	b8 0b 00 00 00       	mov    $0xb,%eax
80103096:	ba 70 00 00 00       	mov    $0x70,%edx
8010309b:	89 e5                	mov    %esp,%ebp
8010309d:	57                   	push   %edi
8010309e:	56                   	push   %esi
8010309f:	53                   	push   %ebx
801030a0:	83 ec 4c             	sub    $0x4c,%esp
801030a3:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801030a4:	ba 71 00 00 00       	mov    $0x71,%edx
801030a9:	ec                   	in     (%dx),%al
801030aa:	83 e0 04             	and    $0x4,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801030ad:	bb 70 00 00 00       	mov    $0x70,%ebx
801030b2:	88 45 b3             	mov    %al,-0x4d(%ebp)
801030b5:	8d 76 00             	lea    0x0(%esi),%esi
801030b8:	31 c0                	xor    %eax,%eax
801030ba:	89 da                	mov    %ebx,%edx
801030bc:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801030bd:	b9 71 00 00 00       	mov    $0x71,%ecx
801030c2:	89 ca                	mov    %ecx,%edx
801030c4:	ec                   	in     (%dx),%al
801030c5:	88 45 b7             	mov    %al,-0x49(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801030c8:	89 da                	mov    %ebx,%edx
801030ca:	b8 02 00 00 00       	mov    $0x2,%eax
801030cf:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801030d0:	89 ca                	mov    %ecx,%edx
801030d2:	ec                   	in     (%dx),%al
801030d3:	88 45 b6             	mov    %al,-0x4a(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801030d6:	89 da                	mov    %ebx,%edx
801030d8:	b8 04 00 00 00       	mov    $0x4,%eax
801030dd:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801030de:	89 ca                	mov    %ecx,%edx
801030e0:	ec                   	in     (%dx),%al
801030e1:	88 45 b5             	mov    %al,-0x4b(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801030e4:	89 da                	mov    %ebx,%edx
801030e6:	b8 07 00 00 00       	mov    $0x7,%eax
801030eb:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801030ec:	89 ca                	mov    %ecx,%edx
801030ee:	ec                   	in     (%dx),%al
801030ef:	88 45 b4             	mov    %al,-0x4c(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801030f2:	89 da                	mov    %ebx,%edx
801030f4:	b8 08 00 00 00       	mov    $0x8,%eax
801030f9:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801030fa:	89 ca                	mov    %ecx,%edx
801030fc:	ec                   	in     (%dx),%al
801030fd:	89 c7                	mov    %eax,%edi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801030ff:	89 da                	mov    %ebx,%edx
80103101:	b8 09 00 00 00       	mov    $0x9,%eax
80103106:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80103107:	89 ca                	mov    %ecx,%edx
80103109:	ec                   	in     (%dx),%al
8010310a:	89 c6                	mov    %eax,%esi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010310c:	89 da                	mov    %ebx,%edx
8010310e:	b8 0a 00 00 00       	mov    $0xa,%eax
80103113:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80103114:	89 ca                	mov    %ecx,%edx
80103116:	ec                   	in     (%dx),%al
  bcd = (sb & (1 << 2)) == 0;

  // make sure CMOS doesn't modify time while we read it
  for(;;) {
    fill_rtcdate(&t1);
    if(cmos_read(CMOS_STATA) & CMOS_UIP)
80103117:	84 c0                	test   %al,%al
80103119:	78 9d                	js     801030b8 <cmostime+0x28>
  return inb(CMOS_RETURN);
8010311b:	0f b6 45 b7          	movzbl -0x49(%ebp),%eax
8010311f:	89 fa                	mov    %edi,%edx
80103121:	0f b6 fa             	movzbl %dl,%edi
80103124:	89 f2                	mov    %esi,%edx
80103126:	0f b6 f2             	movzbl %dl,%esi
80103129:	89 7d c8             	mov    %edi,-0x38(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010312c:	89 da                	mov    %ebx,%edx
8010312e:	89 75 cc             	mov    %esi,-0x34(%ebp)
80103131:	89 45 b8             	mov    %eax,-0x48(%ebp)
80103134:	0f b6 45 b6          	movzbl -0x4a(%ebp),%eax
80103138:	89 45 bc             	mov    %eax,-0x44(%ebp)
8010313b:	0f b6 45 b5          	movzbl -0x4b(%ebp),%eax
8010313f:	89 45 c0             	mov    %eax,-0x40(%ebp)
80103142:	0f b6 45 b4          	movzbl -0x4c(%ebp),%eax
80103146:	89 45 c4             	mov    %eax,-0x3c(%ebp)
80103149:	31 c0                	xor    %eax,%eax
8010314b:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010314c:	89 ca                	mov    %ecx,%edx
8010314e:	ec                   	in     (%dx),%al
8010314f:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103152:	89 da                	mov    %ebx,%edx
80103154:	89 45 d0             	mov    %eax,-0x30(%ebp)
80103157:	b8 02 00 00 00       	mov    $0x2,%eax
8010315c:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010315d:	89 ca                	mov    %ecx,%edx
8010315f:	ec                   	in     (%dx),%al
80103160:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103163:	89 da                	mov    %ebx,%edx
80103165:	89 45 d4             	mov    %eax,-0x2c(%ebp)
80103168:	b8 04 00 00 00       	mov    $0x4,%eax
8010316d:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010316e:	89 ca                	mov    %ecx,%edx
80103170:	ec                   	in     (%dx),%al
80103171:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103174:	89 da                	mov    %ebx,%edx
80103176:	89 45 d8             	mov    %eax,-0x28(%ebp)
80103179:	b8 07 00 00 00       	mov    $0x7,%eax
8010317e:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010317f:	89 ca                	mov    %ecx,%edx
80103181:	ec                   	in     (%dx),%al
80103182:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103185:	89 da                	mov    %ebx,%edx
80103187:	89 45 dc             	mov    %eax,-0x24(%ebp)
8010318a:	b8 08 00 00 00       	mov    $0x8,%eax
8010318f:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80103190:	89 ca                	mov    %ecx,%edx
80103192:	ec                   	in     (%dx),%al
80103193:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103196:	89 da                	mov    %ebx,%edx
80103198:	89 45 e0             	mov    %eax,-0x20(%ebp)
8010319b:	b8 09 00 00 00       	mov    $0x9,%eax
801031a0:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801031a1:	89 ca                	mov    %ecx,%edx
801031a3:	ec                   	in     (%dx),%al
801031a4:	0f b6 c0             	movzbl %al,%eax
        continue;
    fill_rtcdate(&t2);
    if(memcmp(&t1, &t2, sizeof(t1)) == 0)
801031a7:	83 ec 04             	sub    $0x4,%esp
  return inb(CMOS_RETURN);
801031aa:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    if(memcmp(&t1, &t2, sizeof(t1)) == 0)
801031ad:	8d 45 d0             	lea    -0x30(%ebp),%eax
801031b0:	6a 18                	push   $0x18
801031b2:	50                   	push   %eax
801031b3:	8d 45 b8             	lea    -0x48(%ebp),%eax
801031b6:	50                   	push   %eax
801031b7:	e8 64 1b 00 00       	call   80104d20 <memcmp>
801031bc:	83 c4 10             	add    $0x10,%esp
801031bf:	85 c0                	test   %eax,%eax
801031c1:	0f 85 f1 fe ff ff    	jne    801030b8 <cmostime+0x28>
      break;
  }

  // convert
  if(bcd) {
801031c7:	80 7d b3 00          	cmpb   $0x0,-0x4d(%ebp)
801031cb:	75 78                	jne    80103245 <cmostime+0x1b5>
#define    CONV(x)     (t1.x = ((t1.x >> 4) * 10) + (t1.x & 0xf))
    CONV(second);
801031cd:	8b 45 b8             	mov    -0x48(%ebp),%eax
801031d0:	89 c2                	mov    %eax,%edx
801031d2:	83 e0 0f             	and    $0xf,%eax
801031d5:	c1 ea 04             	shr    $0x4,%edx
801031d8:	8d 14 92             	lea    (%edx,%edx,4),%edx
801031db:	8d 04 50             	lea    (%eax,%edx,2),%eax
801031de:	89 45 b8             	mov    %eax,-0x48(%ebp)
    CONV(minute);
801031e1:	8b 45 bc             	mov    -0x44(%ebp),%eax
801031e4:	89 c2                	mov    %eax,%edx
801031e6:	83 e0 0f             	and    $0xf,%eax
801031e9:	c1 ea 04             	shr    $0x4,%edx
801031ec:	8d 14 92             	lea    (%edx,%edx,4),%edx
801031ef:	8d 04 50             	lea    (%eax,%edx,2),%eax
801031f2:	89 45 bc             	mov    %eax,-0x44(%ebp)
    CONV(hour  );
801031f5:	8b 45 c0             	mov    -0x40(%ebp),%eax
801031f8:	89 c2                	mov    %eax,%edx
801031fa:	83 e0 0f             	and    $0xf,%eax
801031fd:	c1 ea 04             	shr    $0x4,%edx
80103200:	8d 14 92             	lea    (%edx,%edx,4),%edx
80103203:	8d 04 50             	lea    (%eax,%edx,2),%eax
80103206:	89 45 c0             	mov    %eax,-0x40(%ebp)
    CONV(day   );
80103209:	8b 45 c4             	mov    -0x3c(%ebp),%eax
8010320c:	89 c2                	mov    %eax,%edx
8010320e:	83 e0 0f             	and    $0xf,%eax
80103211:	c1 ea 04             	shr    $0x4,%edx
80103214:	8d 14 92             	lea    (%edx,%edx,4),%edx
80103217:	8d 04 50             	lea    (%eax,%edx,2),%eax
8010321a:	89 45 c4             	mov    %eax,-0x3c(%ebp)
    CONV(month );
8010321d:	8b 45 c8             	mov    -0x38(%ebp),%eax
80103220:	89 c2                	mov    %eax,%edx
80103222:	83 e0 0f             	and    $0xf,%eax
80103225:	c1 ea 04             	shr    $0x4,%edx
80103228:	8d 14 92             	lea    (%edx,%edx,4),%edx
8010322b:	8d 04 50             	lea    (%eax,%edx,2),%eax
8010322e:	89 45 c8             	mov    %eax,-0x38(%ebp)
    CONV(year  );
80103231:	8b 45 cc             	mov    -0x34(%ebp),%eax
80103234:	89 c2                	mov    %eax,%edx
80103236:	83 e0 0f             	and    $0xf,%eax
80103239:	c1 ea 04             	shr    $0x4,%edx
8010323c:	8d 14 92             	lea    (%edx,%edx,4),%edx
8010323f:	8d 04 50             	lea    (%eax,%edx,2),%eax
80103242:	89 45 cc             	mov    %eax,-0x34(%ebp)
#undef     CONV
  }

  *r = t1;
80103245:	8b 75 08             	mov    0x8(%ebp),%esi
80103248:	8b 45 b8             	mov    -0x48(%ebp),%eax
8010324b:	89 06                	mov    %eax,(%esi)
8010324d:	8b 45 bc             	mov    -0x44(%ebp),%eax
80103250:	89 46 04             	mov    %eax,0x4(%esi)
80103253:	8b 45 c0             	mov    -0x40(%ebp),%eax
80103256:	89 46 08             	mov    %eax,0x8(%esi)
80103259:	8b 45 c4             	mov    -0x3c(%ebp),%eax
8010325c:	89 46 0c             	mov    %eax,0xc(%esi)
8010325f:	8b 45 c8             	mov    -0x38(%ebp),%eax
80103262:	89 46 10             	mov    %eax,0x10(%esi)
80103265:	8b 45 cc             	mov    -0x34(%ebp),%eax
80103268:	89 46 14             	mov    %eax,0x14(%esi)
  r->year += 2000;
8010326b:	81 46 14 d0 07 00 00 	addl   $0x7d0,0x14(%esi)
}
80103272:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103275:	5b                   	pop    %ebx
80103276:	5e                   	pop    %esi
80103277:	5f                   	pop    %edi
80103278:	5d                   	pop    %ebp
80103279:	c3                   	ret    
8010327a:	66 90                	xchg   %ax,%ax
8010327c:	66 90                	xchg   %ax,%ax
8010327e:	66 90                	xchg   %ax,%ax

80103280 <install_trans>:
static void
install_trans(void)
{
  int tail;

  for (tail = 0; tail < log.lh.n; tail++) {
80103280:	8b 0d c8 54 11 80    	mov    0x801154c8,%ecx
80103286:	85 c9                	test   %ecx,%ecx
80103288:	0f 8e 8a 00 00 00    	jle    80103318 <install_trans+0x98>
{
8010328e:	55                   	push   %ebp
8010328f:	89 e5                	mov    %esp,%ebp
80103291:	57                   	push   %edi
80103292:	56                   	push   %esi
80103293:	53                   	push   %ebx
  for (tail = 0; tail < log.lh.n; tail++) {
80103294:	31 db                	xor    %ebx,%ebx
{
80103296:	83 ec 0c             	sub    $0xc,%esp
80103299:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
801032a0:	a1 b4 54 11 80       	mov    0x801154b4,%eax
801032a5:	83 ec 08             	sub    $0x8,%esp
801032a8:	01 d8                	add    %ebx,%eax
801032aa:	83 c0 01             	add    $0x1,%eax
801032ad:	50                   	push   %eax
801032ae:	ff 35 c4 54 11 80    	pushl  0x801154c4
801032b4:	e8 17 ce ff ff       	call   801000d0 <bread>
801032b9:	89 c7                	mov    %eax,%edi
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
801032bb:	58                   	pop    %eax
801032bc:	5a                   	pop    %edx
801032bd:	ff 34 9d cc 54 11 80 	pushl  -0x7feeab34(,%ebx,4)
801032c4:	ff 35 c4 54 11 80    	pushl  0x801154c4
  for (tail = 0; tail < log.lh.n; tail++) {
801032ca:	83 c3 01             	add    $0x1,%ebx
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
801032cd:	e8 fe cd ff ff       	call   801000d0 <bread>
801032d2:	89 c6                	mov    %eax,%esi
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
801032d4:	8d 47 5c             	lea    0x5c(%edi),%eax
801032d7:	83 c4 0c             	add    $0xc,%esp
801032da:	68 00 02 00 00       	push   $0x200
801032df:	50                   	push   %eax
801032e0:	8d 46 5c             	lea    0x5c(%esi),%eax
801032e3:	50                   	push   %eax
801032e4:	e8 97 1a 00 00       	call   80104d80 <memmove>
    bwrite(dbuf);  // write dst to disk
801032e9:	89 34 24             	mov    %esi,(%esp)
801032ec:	e8 af ce ff ff       	call   801001a0 <bwrite>
    brelse(lbuf);
801032f1:	89 3c 24             	mov    %edi,(%esp)
801032f4:	e8 e7 ce ff ff       	call   801001e0 <brelse>
    brelse(dbuf);
801032f9:	89 34 24             	mov    %esi,(%esp)
801032fc:	e8 df ce ff ff       	call   801001e0 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
80103301:	83 c4 10             	add    $0x10,%esp
80103304:	39 1d c8 54 11 80    	cmp    %ebx,0x801154c8
8010330a:	7f 94                	jg     801032a0 <install_trans+0x20>
  }
}
8010330c:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010330f:	5b                   	pop    %ebx
80103310:	5e                   	pop    %esi
80103311:	5f                   	pop    %edi
80103312:	5d                   	pop    %ebp
80103313:	c3                   	ret    
80103314:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80103318:	f3 c3                	repz ret 
8010331a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80103320 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
80103320:	55                   	push   %ebp
80103321:	89 e5                	mov    %esp,%ebp
80103323:	56                   	push   %esi
80103324:	53                   	push   %ebx
  struct buf *buf = bread(log.dev, log.start);
80103325:	83 ec 08             	sub    $0x8,%esp
80103328:	ff 35 b4 54 11 80    	pushl  0x801154b4
8010332e:	ff 35 c4 54 11 80    	pushl  0x801154c4
80103334:	e8 97 cd ff ff       	call   801000d0 <bread>
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
80103339:	8b 1d c8 54 11 80    	mov    0x801154c8,%ebx
  for (i = 0; i < log.lh.n; i++) {
8010333f:	83 c4 10             	add    $0x10,%esp
  struct buf *buf = bread(log.dev, log.start);
80103342:	89 c6                	mov    %eax,%esi
  for (i = 0; i < log.lh.n; i++) {
80103344:	85 db                	test   %ebx,%ebx
  hb->n = log.lh.n;
80103346:	89 58 5c             	mov    %ebx,0x5c(%eax)
  for (i = 0; i < log.lh.n; i++) {
80103349:	7e 16                	jle    80103361 <write_head+0x41>
8010334b:	c1 e3 02             	shl    $0x2,%ebx
8010334e:	31 d2                	xor    %edx,%edx
    hb->block[i] = log.lh.block[i];
80103350:	8b 8a cc 54 11 80    	mov    -0x7feeab34(%edx),%ecx
80103356:	89 4c 16 60          	mov    %ecx,0x60(%esi,%edx,1)
8010335a:	83 c2 04             	add    $0x4,%edx
  for (i = 0; i < log.lh.n; i++) {
8010335d:	39 da                	cmp    %ebx,%edx
8010335f:	75 ef                	jne    80103350 <write_head+0x30>
  }
  bwrite(buf);
80103361:	83 ec 0c             	sub    $0xc,%esp
80103364:	56                   	push   %esi
80103365:	e8 36 ce ff ff       	call   801001a0 <bwrite>
  brelse(buf);
8010336a:	89 34 24             	mov    %esi,(%esp)
8010336d:	e8 6e ce ff ff       	call   801001e0 <brelse>
}
80103372:	83 c4 10             	add    $0x10,%esp
80103375:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103378:	5b                   	pop    %ebx
80103379:	5e                   	pop    %esi
8010337a:	5d                   	pop    %ebp
8010337b:	c3                   	ret    
8010337c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80103380 <initlog>:
{
80103380:	55                   	push   %ebp
80103381:	89 e5                	mov    %esp,%ebp
80103383:	53                   	push   %ebx
80103384:	83 ec 2c             	sub    $0x2c,%esp
80103387:	8b 5d 08             	mov    0x8(%ebp),%ebx
  initlock(&log.lock, "log");
8010338a:	68 00 7d 10 80       	push   $0x80107d00
8010338f:	68 80 54 11 80       	push   $0x80115480
80103394:	e8 e7 16 00 00       	call   80104a80 <initlock>
  readsb(dev, &sb);
80103399:	58                   	pop    %eax
8010339a:	8d 45 dc             	lea    -0x24(%ebp),%eax
8010339d:	5a                   	pop    %edx
8010339e:	50                   	push   %eax
8010339f:	53                   	push   %ebx
801033a0:	e8 7b e2 ff ff       	call   80101620 <readsb>
  log.size = sb.nlog;
801033a5:	8b 55 e8             	mov    -0x18(%ebp),%edx
  log.start = sb.logstart;
801033a8:	8b 45 ec             	mov    -0x14(%ebp),%eax
  struct buf *buf = bread(log.dev, log.start);
801033ab:	59                   	pop    %ecx
  log.dev = dev;
801033ac:	89 1d c4 54 11 80    	mov    %ebx,0x801154c4
  log.size = sb.nlog;
801033b2:	89 15 b8 54 11 80    	mov    %edx,0x801154b8
  log.start = sb.logstart;
801033b8:	a3 b4 54 11 80       	mov    %eax,0x801154b4
  struct buf *buf = bread(log.dev, log.start);
801033bd:	5a                   	pop    %edx
801033be:	50                   	push   %eax
801033bf:	53                   	push   %ebx
801033c0:	e8 0b cd ff ff       	call   801000d0 <bread>
  log.lh.n = lh->n;
801033c5:	8b 58 5c             	mov    0x5c(%eax),%ebx
  for (i = 0; i < log.lh.n; i++) {
801033c8:	83 c4 10             	add    $0x10,%esp
801033cb:	85 db                	test   %ebx,%ebx
  log.lh.n = lh->n;
801033cd:	89 1d c8 54 11 80    	mov    %ebx,0x801154c8
  for (i = 0; i < log.lh.n; i++) {
801033d3:	7e 1c                	jle    801033f1 <initlog+0x71>
801033d5:	c1 e3 02             	shl    $0x2,%ebx
801033d8:	31 d2                	xor    %edx,%edx
801033da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    log.lh.block[i] = lh->block[i];
801033e0:	8b 4c 10 60          	mov    0x60(%eax,%edx,1),%ecx
801033e4:	83 c2 04             	add    $0x4,%edx
801033e7:	89 8a c8 54 11 80    	mov    %ecx,-0x7feeab38(%edx)
  for (i = 0; i < log.lh.n; i++) {
801033ed:	39 d3                	cmp    %edx,%ebx
801033ef:	75 ef                	jne    801033e0 <initlog+0x60>
  brelse(buf);
801033f1:	83 ec 0c             	sub    $0xc,%esp
801033f4:	50                   	push   %eax
801033f5:	e8 e6 cd ff ff       	call   801001e0 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(); // if committed, copy from log to disk
801033fa:	e8 81 fe ff ff       	call   80103280 <install_trans>
  log.lh.n = 0;
801033ff:	c7 05 c8 54 11 80 00 	movl   $0x0,0x801154c8
80103406:	00 00 00 
  write_head(); // clear the log
80103409:	e8 12 ff ff ff       	call   80103320 <write_head>
}
8010340e:	83 c4 10             	add    $0x10,%esp
80103411:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103414:	c9                   	leave  
80103415:	c3                   	ret    
80103416:	8d 76 00             	lea    0x0(%esi),%esi
80103419:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80103420 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
80103420:	55                   	push   %ebp
80103421:	89 e5                	mov    %esp,%ebp
80103423:	83 ec 14             	sub    $0x14,%esp
  acquire(&log.lock);
80103426:	68 80 54 11 80       	push   $0x80115480
8010342b:	e8 90 17 00 00       	call   80104bc0 <acquire>
80103430:	83 c4 10             	add    $0x10,%esp
80103433:	eb 18                	jmp    8010344d <begin_op+0x2d>
80103435:	8d 76 00             	lea    0x0(%esi),%esi
  while(1){
    if(log.committing){
      sleep(&log, &log.lock);
80103438:	83 ec 08             	sub    $0x8,%esp
8010343b:	68 80 54 11 80       	push   $0x80115480
80103440:	68 80 54 11 80       	push   $0x80115480
80103445:	e8 b6 11 00 00       	call   80104600 <sleep>
8010344a:	83 c4 10             	add    $0x10,%esp
    if(log.committing){
8010344d:	a1 c0 54 11 80       	mov    0x801154c0,%eax
80103452:	85 c0                	test   %eax,%eax
80103454:	75 e2                	jne    80103438 <begin_op+0x18>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
80103456:	a1 bc 54 11 80       	mov    0x801154bc,%eax
8010345b:	8b 15 c8 54 11 80    	mov    0x801154c8,%edx
80103461:	83 c0 01             	add    $0x1,%eax
80103464:	8d 0c 80             	lea    (%eax,%eax,4),%ecx
80103467:	8d 14 4a             	lea    (%edx,%ecx,2),%edx
8010346a:	83 fa 1e             	cmp    $0x1e,%edx
8010346d:	7f c9                	jg     80103438 <begin_op+0x18>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    } else {
      log.outstanding += 1;
      release(&log.lock);
8010346f:	83 ec 0c             	sub    $0xc,%esp
      log.outstanding += 1;
80103472:	a3 bc 54 11 80       	mov    %eax,0x801154bc
      release(&log.lock);
80103477:	68 80 54 11 80       	push   $0x80115480
8010347c:	e8 ff 17 00 00       	call   80104c80 <release>
      break;
    }
  }
}
80103481:	83 c4 10             	add    $0x10,%esp
80103484:	c9                   	leave  
80103485:	c3                   	ret    
80103486:	8d 76 00             	lea    0x0(%esi),%esi
80103489:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80103490 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
80103490:	55                   	push   %ebp
80103491:	89 e5                	mov    %esp,%ebp
80103493:	57                   	push   %edi
80103494:	56                   	push   %esi
80103495:	53                   	push   %ebx
80103496:	83 ec 18             	sub    $0x18,%esp
  int do_commit = 0;

  acquire(&log.lock);
80103499:	68 80 54 11 80       	push   $0x80115480
8010349e:	e8 1d 17 00 00       	call   80104bc0 <acquire>
  log.outstanding -= 1;
801034a3:	a1 bc 54 11 80       	mov    0x801154bc,%eax
  if(log.committing)
801034a8:	8b 35 c0 54 11 80    	mov    0x801154c0,%esi
801034ae:	83 c4 10             	add    $0x10,%esp
  log.outstanding -= 1;
801034b1:	8d 58 ff             	lea    -0x1(%eax),%ebx
  if(log.committing)
801034b4:	85 f6                	test   %esi,%esi
  log.outstanding -= 1;
801034b6:	89 1d bc 54 11 80    	mov    %ebx,0x801154bc
  if(log.committing)
801034bc:	0f 85 1a 01 00 00    	jne    801035dc <end_op+0x14c>
    panic("log.committing");
  if(log.outstanding == 0){
801034c2:	85 db                	test   %ebx,%ebx
801034c4:	0f 85 ee 00 00 00    	jne    801035b8 <end_op+0x128>
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
801034ca:	83 ec 0c             	sub    $0xc,%esp
    log.committing = 1;
801034cd:	c7 05 c0 54 11 80 01 	movl   $0x1,0x801154c0
801034d4:	00 00 00 
  release(&log.lock);
801034d7:	68 80 54 11 80       	push   $0x80115480
801034dc:	e8 9f 17 00 00       	call   80104c80 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
801034e1:	8b 0d c8 54 11 80    	mov    0x801154c8,%ecx
801034e7:	83 c4 10             	add    $0x10,%esp
801034ea:	85 c9                	test   %ecx,%ecx
801034ec:	0f 8e 85 00 00 00    	jle    80103577 <end_op+0xe7>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
801034f2:	a1 b4 54 11 80       	mov    0x801154b4,%eax
801034f7:	83 ec 08             	sub    $0x8,%esp
801034fa:	01 d8                	add    %ebx,%eax
801034fc:	83 c0 01             	add    $0x1,%eax
801034ff:	50                   	push   %eax
80103500:	ff 35 c4 54 11 80    	pushl  0x801154c4
80103506:	e8 c5 cb ff ff       	call   801000d0 <bread>
8010350b:	89 c6                	mov    %eax,%esi
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
8010350d:	58                   	pop    %eax
8010350e:	5a                   	pop    %edx
8010350f:	ff 34 9d cc 54 11 80 	pushl  -0x7feeab34(,%ebx,4)
80103516:	ff 35 c4 54 11 80    	pushl  0x801154c4
  for (tail = 0; tail < log.lh.n; tail++) {
8010351c:	83 c3 01             	add    $0x1,%ebx
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
8010351f:	e8 ac cb ff ff       	call   801000d0 <bread>
80103524:	89 c7                	mov    %eax,%edi
    memmove(to->data, from->data, BSIZE);
80103526:	8d 40 5c             	lea    0x5c(%eax),%eax
80103529:	83 c4 0c             	add    $0xc,%esp
8010352c:	68 00 02 00 00       	push   $0x200
80103531:	50                   	push   %eax
80103532:	8d 46 5c             	lea    0x5c(%esi),%eax
80103535:	50                   	push   %eax
80103536:	e8 45 18 00 00       	call   80104d80 <memmove>
    bwrite(to);  // write the log
8010353b:	89 34 24             	mov    %esi,(%esp)
8010353e:	e8 5d cc ff ff       	call   801001a0 <bwrite>
    brelse(from);
80103543:	89 3c 24             	mov    %edi,(%esp)
80103546:	e8 95 cc ff ff       	call   801001e0 <brelse>
    brelse(to);
8010354b:	89 34 24             	mov    %esi,(%esp)
8010354e:	e8 8d cc ff ff       	call   801001e0 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
80103553:	83 c4 10             	add    $0x10,%esp
80103556:	3b 1d c8 54 11 80    	cmp    0x801154c8,%ebx
8010355c:	7c 94                	jl     801034f2 <end_op+0x62>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
8010355e:	e8 bd fd ff ff       	call   80103320 <write_head>
    install_trans(); // Now install writes to home locations
80103563:	e8 18 fd ff ff       	call   80103280 <install_trans>
    log.lh.n = 0;
80103568:	c7 05 c8 54 11 80 00 	movl   $0x0,0x801154c8
8010356f:	00 00 00 
    write_head();    // Erase the transaction from the log
80103572:	e8 a9 fd ff ff       	call   80103320 <write_head>
    acquire(&log.lock);
80103577:	83 ec 0c             	sub    $0xc,%esp
8010357a:	68 80 54 11 80       	push   $0x80115480
8010357f:	e8 3c 16 00 00       	call   80104bc0 <acquire>
    wakeup(&log);
80103584:	c7 04 24 80 54 11 80 	movl   $0x80115480,(%esp)
    log.committing = 0;
8010358b:	c7 05 c0 54 11 80 00 	movl   $0x0,0x801154c0
80103592:	00 00 00 
    wakeup(&log);
80103595:	e8 16 12 00 00       	call   801047b0 <wakeup>
    release(&log.lock);
8010359a:	c7 04 24 80 54 11 80 	movl   $0x80115480,(%esp)
801035a1:	e8 da 16 00 00       	call   80104c80 <release>
801035a6:	83 c4 10             	add    $0x10,%esp
}
801035a9:	8d 65 f4             	lea    -0xc(%ebp),%esp
801035ac:	5b                   	pop    %ebx
801035ad:	5e                   	pop    %esi
801035ae:	5f                   	pop    %edi
801035af:	5d                   	pop    %ebp
801035b0:	c3                   	ret    
801035b1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    wakeup(&log);
801035b8:	83 ec 0c             	sub    $0xc,%esp
801035bb:	68 80 54 11 80       	push   $0x80115480
801035c0:	e8 eb 11 00 00       	call   801047b0 <wakeup>
  release(&log.lock);
801035c5:	c7 04 24 80 54 11 80 	movl   $0x80115480,(%esp)
801035cc:	e8 af 16 00 00       	call   80104c80 <release>
801035d1:	83 c4 10             	add    $0x10,%esp
}
801035d4:	8d 65 f4             	lea    -0xc(%ebp),%esp
801035d7:	5b                   	pop    %ebx
801035d8:	5e                   	pop    %esi
801035d9:	5f                   	pop    %edi
801035da:	5d                   	pop    %ebp
801035db:	c3                   	ret    
    panic("log.committing");
801035dc:	83 ec 0c             	sub    $0xc,%esp
801035df:	68 04 7d 10 80       	push   $0x80107d04
801035e4:	e8 a7 cd ff ff       	call   80100390 <panic>
801035e9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

801035f0 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
801035f0:	55                   	push   %ebp
801035f1:	89 e5                	mov    %esp,%ebp
801035f3:	53                   	push   %ebx
801035f4:	83 ec 04             	sub    $0x4,%esp
  int i;

  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
801035f7:	8b 15 c8 54 11 80    	mov    0x801154c8,%edx
{
801035fd:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
80103600:	83 fa 1d             	cmp    $0x1d,%edx
80103603:	0f 8f 9d 00 00 00    	jg     801036a6 <log_write+0xb6>
80103609:	a1 b8 54 11 80       	mov    0x801154b8,%eax
8010360e:	83 e8 01             	sub    $0x1,%eax
80103611:	39 c2                	cmp    %eax,%edx
80103613:	0f 8d 8d 00 00 00    	jge    801036a6 <log_write+0xb6>
    panic("too big a transaction");
  if (log.outstanding < 1)
80103619:	a1 bc 54 11 80       	mov    0x801154bc,%eax
8010361e:	85 c0                	test   %eax,%eax
80103620:	0f 8e 8d 00 00 00    	jle    801036b3 <log_write+0xc3>
    panic("log_write outside of trans");

  acquire(&log.lock);
80103626:	83 ec 0c             	sub    $0xc,%esp
80103629:	68 80 54 11 80       	push   $0x80115480
8010362e:	e8 8d 15 00 00       	call   80104bc0 <acquire>
  for (i = 0; i < log.lh.n; i++) {
80103633:	8b 0d c8 54 11 80    	mov    0x801154c8,%ecx
80103639:	83 c4 10             	add    $0x10,%esp
8010363c:	83 f9 00             	cmp    $0x0,%ecx
8010363f:	7e 57                	jle    80103698 <log_write+0xa8>
    if (log.lh.block[i] == b->blockno)   // log absorbtion
80103641:	8b 53 08             	mov    0x8(%ebx),%edx
  for (i = 0; i < log.lh.n; i++) {
80103644:	31 c0                	xor    %eax,%eax
    if (log.lh.block[i] == b->blockno)   // log absorbtion
80103646:	3b 15 cc 54 11 80    	cmp    0x801154cc,%edx
8010364c:	75 0b                	jne    80103659 <log_write+0x69>
8010364e:	eb 38                	jmp    80103688 <log_write+0x98>
80103650:	39 14 85 cc 54 11 80 	cmp    %edx,-0x7feeab34(,%eax,4)
80103657:	74 2f                	je     80103688 <log_write+0x98>
  for (i = 0; i < log.lh.n; i++) {
80103659:	83 c0 01             	add    $0x1,%eax
8010365c:	39 c1                	cmp    %eax,%ecx
8010365e:	75 f0                	jne    80103650 <log_write+0x60>
      break;
  }
  log.lh.block[i] = b->blockno;
80103660:	89 14 85 cc 54 11 80 	mov    %edx,-0x7feeab34(,%eax,4)
  if (i == log.lh.n)
    log.lh.n++;
80103667:	83 c0 01             	add    $0x1,%eax
8010366a:	a3 c8 54 11 80       	mov    %eax,0x801154c8
  b->flags |= B_DIRTY; // prevent eviction
8010366f:	83 0b 04             	orl    $0x4,(%ebx)
  release(&log.lock);
80103672:	c7 45 08 80 54 11 80 	movl   $0x80115480,0x8(%ebp)
}
80103679:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010367c:	c9                   	leave  
  release(&log.lock);
8010367d:	e9 fe 15 00 00       	jmp    80104c80 <release>
80103682:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  log.lh.block[i] = b->blockno;
80103688:	89 14 85 cc 54 11 80 	mov    %edx,-0x7feeab34(,%eax,4)
8010368f:	eb de                	jmp    8010366f <log_write+0x7f>
80103691:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80103698:	8b 43 08             	mov    0x8(%ebx),%eax
8010369b:	a3 cc 54 11 80       	mov    %eax,0x801154cc
  if (i == log.lh.n)
801036a0:	75 cd                	jne    8010366f <log_write+0x7f>
801036a2:	31 c0                	xor    %eax,%eax
801036a4:	eb c1                	jmp    80103667 <log_write+0x77>
    panic("too big a transaction");
801036a6:	83 ec 0c             	sub    $0xc,%esp
801036a9:	68 13 7d 10 80       	push   $0x80107d13
801036ae:	e8 dd cc ff ff       	call   80100390 <panic>
    panic("log_write outside of trans");
801036b3:	83 ec 0c             	sub    $0xc,%esp
801036b6:	68 29 7d 10 80       	push   $0x80107d29
801036bb:	e8 d0 cc ff ff       	call   80100390 <panic>

801036c0 <mpmain>:
}

// Common CPU setup code.
static void
mpmain(void)
{
801036c0:	55                   	push   %ebp
801036c1:	89 e5                	mov    %esp,%ebp
801036c3:	53                   	push   %ebx
801036c4:	83 ec 04             	sub    $0x4,%esp
  cprintf("cpu%d: starting %d\n", cpuid(), cpuid());
801036c7:	e8 74 09 00 00       	call   80104040 <cpuid>
801036cc:	89 c3                	mov    %eax,%ebx
801036ce:	e8 6d 09 00 00       	call   80104040 <cpuid>
801036d3:	83 ec 04             	sub    $0x4,%esp
801036d6:	53                   	push   %ebx
801036d7:	50                   	push   %eax
801036d8:	68 44 7d 10 80       	push   $0x80107d44
801036dd:	e8 7e cf ff ff       	call   80100660 <cprintf>
  idtinit();       // load idt register
801036e2:	e8 b9 28 00 00       	call   80105fa0 <idtinit>
  xchg(&(mycpu()->started), 1); // tell startothers() we're up
801036e7:	e8 d4 08 00 00       	call   80103fc0 <mycpu>
801036ec:	89 c2                	mov    %eax,%edx
xchg(volatile uint *addr, uint newval)
{
  uint result;

  // The + in "+m" denotes a read-modify-write operand.
  asm volatile("lock; xchgl %0, %1" :
801036ee:	b8 01 00 00 00       	mov    $0x1,%eax
801036f3:	f0 87 82 a0 00 00 00 	lock xchg %eax,0xa0(%edx)
  scheduler();     // start running processes
801036fa:	e8 21 0c 00 00       	call   80104320 <scheduler>
801036ff:	90                   	nop

80103700 <mpenter>:
{
80103700:	55                   	push   %ebp
80103701:	89 e5                	mov    %esp,%ebp
80103703:	83 ec 08             	sub    $0x8,%esp
  switchkvm();
80103706:	e8 85 39 00 00       	call   80107090 <switchkvm>
  seginit();
8010370b:	e8 f0 38 00 00       	call   80107000 <seginit>
  lapicinit();
80103710:	e8 9b f7 ff ff       	call   80102eb0 <lapicinit>
  mpmain();
80103715:	e8 a6 ff ff ff       	call   801036c0 <mpmain>
8010371a:	66 90                	xchg   %ax,%ax
8010371c:	66 90                	xchg   %ax,%ax
8010371e:	66 90                	xchg   %ax,%ax

80103720 <main>:
{
80103720:	8d 4c 24 04          	lea    0x4(%esp),%ecx
80103724:	83 e4 f0             	and    $0xfffffff0,%esp
80103727:	ff 71 fc             	pushl  -0x4(%ecx)
8010372a:	55                   	push   %ebp
8010372b:	89 e5                	mov    %esp,%ebp
8010372d:	53                   	push   %ebx
8010372e:	51                   	push   %ecx
  kinit1(end, P2V(4*1024*1024)); // phys page allocator
8010372f:	83 ec 08             	sub    $0x8,%esp
80103732:	68 00 00 40 80       	push   $0x80400000
80103737:	68 a8 82 11 80       	push   $0x801182a8
8010373c:	e8 2f f5 ff ff       	call   80102c70 <kinit1>
  kvmalloc();      // kernel page table
80103741:	e8 1a 3e 00 00       	call   80107560 <kvmalloc>
  mpinit();        // detect other processors
80103746:	e8 75 01 00 00       	call   801038c0 <mpinit>
  lapicinit();     // interrupt controller
8010374b:	e8 60 f7 ff ff       	call   80102eb0 <lapicinit>
  seginit();       // segment descriptors
80103750:	e8 ab 38 00 00       	call   80107000 <seginit>
  picinit();       // disable pic
80103755:	e8 46 03 00 00       	call   80103aa0 <picinit>
  ioapicinit();    // another interrupt controller
8010375a:	e8 41 f3 ff ff       	call   80102aa0 <ioapicinit>
  consoleinit();   // console hardware
8010375f:	e8 5c d2 ff ff       	call   801009c0 <consoleinit>
  uartinit();      // serial port
80103764:	e8 67 2b 00 00       	call   801062d0 <uartinit>
  pinit();         // process table
80103769:	e8 32 08 00 00       	call   80103fa0 <pinit>
  tvinit();        // trap vectors
8010376e:	e8 ad 27 00 00       	call   80105f20 <tvinit>
  binit();         // buffer cache
80103773:	e8 c8 c8 ff ff       	call   80100040 <binit>
  fileinit();      // file table
80103778:	e8 e3 d5 ff ff       	call   80100d60 <fileinit>
  ideinit();       // disk 
8010377d:	e8 fe f0 ff ff       	call   80102880 <ideinit>

  // Write entry code to unused memory at 0x7000.
  // The linker has placed the image of entryother.S in
  // _binary_entryother_start.
  code = P2V(0x7000);
  memmove(code, _binary_entryother_start, (uint)_binary_entryother_size);
80103782:	83 c4 0c             	add    $0xc,%esp
80103785:	68 8a 00 00 00       	push   $0x8a
8010378a:	68 8c b4 10 80       	push   $0x8010b48c
8010378f:	68 00 70 00 80       	push   $0x80007000
80103794:	e8 e7 15 00 00       	call   80104d80 <memmove>

  for(c = cpus; c < cpus+ncpu; c++){
80103799:	69 05 00 5b 11 80 b0 	imul   $0xb0,0x80115b00,%eax
801037a0:	00 00 00 
801037a3:	83 c4 10             	add    $0x10,%esp
801037a6:	05 80 55 11 80       	add    $0x80115580,%eax
801037ab:	3d 80 55 11 80       	cmp    $0x80115580,%eax
801037b0:	76 71                	jbe    80103823 <main+0x103>
801037b2:	bb 80 55 11 80       	mov    $0x80115580,%ebx
801037b7:	89 f6                	mov    %esi,%esi
801037b9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    if(c == mycpu())  // We've started already.
801037c0:	e8 fb 07 00 00       	call   80103fc0 <mycpu>
801037c5:	39 d8                	cmp    %ebx,%eax
801037c7:	74 41                	je     8010380a <main+0xea>
      continue;

    // Tell entryother.S what stack to use, where to enter, and what
    // pgdir to use. We cannot use kpgdir yet, because the AP processor
    // is running in low  memory, so we use entrypgdir for the APs too.
    stack = kalloc();
801037c9:	e8 72 f5 ff ff       	call   80102d40 <kalloc>
    *(void**)(code-4) = stack + KSTACKSIZE;
801037ce:	05 00 10 00 00       	add    $0x1000,%eax
    *(void(**)(void))(code-8) = mpenter;
801037d3:	c7 05 f8 6f 00 80 00 	movl   $0x80103700,0x80006ff8
801037da:	37 10 80 
    *(int**)(code-12) = (void *) V2P(entrypgdir);
801037dd:	c7 05 f4 6f 00 80 00 	movl   $0x10a000,0x80006ff4
801037e4:	a0 10 00 
    *(void**)(code-4) = stack + KSTACKSIZE;
801037e7:	a3 fc 6f 00 80       	mov    %eax,0x80006ffc

    lapicstartap(c->apicid, V2P(code));
801037ec:	0f b6 03             	movzbl (%ebx),%eax
801037ef:	83 ec 08             	sub    $0x8,%esp
801037f2:	68 00 70 00 00       	push   $0x7000
801037f7:	50                   	push   %eax
801037f8:	e8 03 f8 ff ff       	call   80103000 <lapicstartap>
801037fd:	83 c4 10             	add    $0x10,%esp

    // wait for cpu to finish mpmain()
    while(c->started == 0)
80103800:	8b 83 a0 00 00 00    	mov    0xa0(%ebx),%eax
80103806:	85 c0                	test   %eax,%eax
80103808:	74 f6                	je     80103800 <main+0xe0>
  for(c = cpus; c < cpus+ncpu; c++){
8010380a:	69 05 00 5b 11 80 b0 	imul   $0xb0,0x80115b00,%eax
80103811:	00 00 00 
80103814:	81 c3 b0 00 00 00    	add    $0xb0,%ebx
8010381a:	05 80 55 11 80       	add    $0x80115580,%eax
8010381f:	39 c3                	cmp    %eax,%ebx
80103821:	72 9d                	jb     801037c0 <main+0xa0>
  kinit2(P2V(4*1024*1024), P2V(PHYSTOP)); // must come after startothers()
80103823:	83 ec 08             	sub    $0x8,%esp
80103826:	68 00 00 00 8e       	push   $0x8e000000
8010382b:	68 00 00 40 80       	push   $0x80400000
80103830:	e8 ab f4 ff ff       	call   80102ce0 <kinit2>
  userinit();      // first user process
80103835:	e8 56 08 00 00       	call   80104090 <userinit>
  mpmain();        // finish this processor's setup
8010383a:	e8 81 fe ff ff       	call   801036c0 <mpmain>
8010383f:	90                   	nop

80103840 <mpsearch1>:
}

// Look for an MP structure in the len bytes at addr.
static struct mp*
mpsearch1(uint a, int len)
{
80103840:	55                   	push   %ebp
80103841:	89 e5                	mov    %esp,%ebp
80103843:	57                   	push   %edi
80103844:	56                   	push   %esi
  uchar *e, *p, *addr;

  addr = P2V(a);
80103845:	8d b0 00 00 00 80    	lea    -0x80000000(%eax),%esi
{
8010384b:	53                   	push   %ebx
  e = addr+len;
8010384c:	8d 1c 16             	lea    (%esi,%edx,1),%ebx
{
8010384f:	83 ec 0c             	sub    $0xc,%esp
  for(p = addr; p < e; p += sizeof(struct mp))
80103852:	39 de                	cmp    %ebx,%esi
80103854:	72 10                	jb     80103866 <mpsearch1+0x26>
80103856:	eb 50                	jmp    801038a8 <mpsearch1+0x68>
80103858:	90                   	nop
80103859:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80103860:	39 fb                	cmp    %edi,%ebx
80103862:	89 fe                	mov    %edi,%esi
80103864:	76 42                	jbe    801038a8 <mpsearch1+0x68>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
80103866:	83 ec 04             	sub    $0x4,%esp
80103869:	8d 7e 10             	lea    0x10(%esi),%edi
8010386c:	6a 04                	push   $0x4
8010386e:	68 58 7d 10 80       	push   $0x80107d58
80103873:	56                   	push   %esi
80103874:	e8 a7 14 00 00       	call   80104d20 <memcmp>
80103879:	83 c4 10             	add    $0x10,%esp
8010387c:	85 c0                	test   %eax,%eax
8010387e:	75 e0                	jne    80103860 <mpsearch1+0x20>
80103880:	89 f1                	mov    %esi,%ecx
80103882:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    sum += addr[i];
80103888:	0f b6 11             	movzbl (%ecx),%edx
8010388b:	83 c1 01             	add    $0x1,%ecx
8010388e:	01 d0                	add    %edx,%eax
  for(i=0; i<len; i++)
80103890:	39 f9                	cmp    %edi,%ecx
80103892:	75 f4                	jne    80103888 <mpsearch1+0x48>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
80103894:	84 c0                	test   %al,%al
80103896:	75 c8                	jne    80103860 <mpsearch1+0x20>
      return (struct mp*)p;
  return 0;
}
80103898:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010389b:	89 f0                	mov    %esi,%eax
8010389d:	5b                   	pop    %ebx
8010389e:	5e                   	pop    %esi
8010389f:	5f                   	pop    %edi
801038a0:	5d                   	pop    %ebp
801038a1:	c3                   	ret    
801038a2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801038a8:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
801038ab:	31 f6                	xor    %esi,%esi
}
801038ad:	89 f0                	mov    %esi,%eax
801038af:	5b                   	pop    %ebx
801038b0:	5e                   	pop    %esi
801038b1:	5f                   	pop    %edi
801038b2:	5d                   	pop    %ebp
801038b3:	c3                   	ret    
801038b4:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801038ba:	8d bf 00 00 00 00    	lea    0x0(%edi),%edi

801038c0 <mpinit>:
  return conf;
}

void
mpinit(void)
{
801038c0:	55                   	push   %ebp
801038c1:	89 e5                	mov    %esp,%ebp
801038c3:	57                   	push   %edi
801038c4:	56                   	push   %esi
801038c5:	53                   	push   %ebx
801038c6:	83 ec 1c             	sub    $0x1c,%esp
  if((p = ((bda[0x0F]<<8)| bda[0x0E]) << 4)){
801038c9:	0f b6 05 0f 04 00 80 	movzbl 0x8000040f,%eax
801038d0:	0f b6 15 0e 04 00 80 	movzbl 0x8000040e,%edx
801038d7:	c1 e0 08             	shl    $0x8,%eax
801038da:	09 d0                	or     %edx,%eax
801038dc:	c1 e0 04             	shl    $0x4,%eax
801038df:	85 c0                	test   %eax,%eax
801038e1:	75 1b                	jne    801038fe <mpinit+0x3e>
    p = ((bda[0x14]<<8)|bda[0x13])*1024;
801038e3:	0f b6 05 14 04 00 80 	movzbl 0x80000414,%eax
801038ea:	0f b6 15 13 04 00 80 	movzbl 0x80000413,%edx
801038f1:	c1 e0 08             	shl    $0x8,%eax
801038f4:	09 d0                	or     %edx,%eax
801038f6:	c1 e0 0a             	shl    $0xa,%eax
    if((mp = mpsearch1(p-1024, 1024)))
801038f9:	2d 00 04 00 00       	sub    $0x400,%eax
    if((mp = mpsearch1(p, 1024)))
801038fe:	ba 00 04 00 00       	mov    $0x400,%edx
80103903:	e8 38 ff ff ff       	call   80103840 <mpsearch1>
80103908:	85 c0                	test   %eax,%eax
8010390a:	89 45 e4             	mov    %eax,-0x1c(%ebp)
8010390d:	0f 84 3d 01 00 00    	je     80103a50 <mpinit+0x190>
  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
80103913:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80103916:	8b 58 04             	mov    0x4(%eax),%ebx
80103919:	85 db                	test   %ebx,%ebx
8010391b:	0f 84 4f 01 00 00    	je     80103a70 <mpinit+0x1b0>
  conf = (struct mpconf*) P2V((uint) mp->physaddr);
80103921:	8d b3 00 00 00 80    	lea    -0x80000000(%ebx),%esi
  if(memcmp(conf, "PCMP", 4) != 0)
80103927:	83 ec 04             	sub    $0x4,%esp
8010392a:	6a 04                	push   $0x4
8010392c:	68 75 7d 10 80       	push   $0x80107d75
80103931:	56                   	push   %esi
80103932:	e8 e9 13 00 00       	call   80104d20 <memcmp>
80103937:	83 c4 10             	add    $0x10,%esp
8010393a:	85 c0                	test   %eax,%eax
8010393c:	0f 85 2e 01 00 00    	jne    80103a70 <mpinit+0x1b0>
  if(conf->version != 1 && conf->version != 4)
80103942:	0f b6 83 06 00 00 80 	movzbl -0x7ffffffa(%ebx),%eax
80103949:	3c 01                	cmp    $0x1,%al
8010394b:	0f 95 c2             	setne  %dl
8010394e:	3c 04                	cmp    $0x4,%al
80103950:	0f 95 c0             	setne  %al
80103953:	20 c2                	and    %al,%dl
80103955:	0f 85 15 01 00 00    	jne    80103a70 <mpinit+0x1b0>
  if(sum((uchar*)conf, conf->length) != 0)
8010395b:	0f b7 bb 04 00 00 80 	movzwl -0x7ffffffc(%ebx),%edi
  for(i=0; i<len; i++)
80103962:	66 85 ff             	test   %di,%di
80103965:	74 1a                	je     80103981 <mpinit+0xc1>
80103967:	89 f0                	mov    %esi,%eax
80103969:	01 f7                	add    %esi,%edi
  sum = 0;
8010396b:	31 d2                	xor    %edx,%edx
8010396d:	8d 76 00             	lea    0x0(%esi),%esi
    sum += addr[i];
80103970:	0f b6 08             	movzbl (%eax),%ecx
80103973:	83 c0 01             	add    $0x1,%eax
80103976:	01 ca                	add    %ecx,%edx
  for(i=0; i<len; i++)
80103978:	39 c7                	cmp    %eax,%edi
8010397a:	75 f4                	jne    80103970 <mpinit+0xb0>
8010397c:	84 d2                	test   %dl,%dl
8010397e:	0f 95 c2             	setne  %dl
  struct mp *mp;
  struct mpconf *conf;
  struct mpproc *proc;
  struct mpioapic *ioapic;

  if((conf = mpconfig(&mp)) == 0)
80103981:	85 f6                	test   %esi,%esi
80103983:	0f 84 e7 00 00 00    	je     80103a70 <mpinit+0x1b0>
80103989:	84 d2                	test   %dl,%dl
8010398b:	0f 85 df 00 00 00    	jne    80103a70 <mpinit+0x1b0>
    panic("Expect to run on an SMP");
  ismp = 1;
  lapic = (uint*)conf->lapicaddr;
80103991:	8b 83 24 00 00 80    	mov    -0x7fffffdc(%ebx),%eax
80103997:	a3 7c 54 11 80       	mov    %eax,0x8011547c
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
8010399c:	0f b7 93 04 00 00 80 	movzwl -0x7ffffffc(%ebx),%edx
801039a3:	8d 83 2c 00 00 80    	lea    -0x7fffffd4(%ebx),%eax
  ismp = 1;
801039a9:	bb 01 00 00 00       	mov    $0x1,%ebx
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
801039ae:	01 d6                	add    %edx,%esi
801039b0:	39 c6                	cmp    %eax,%esi
801039b2:	76 23                	jbe    801039d7 <mpinit+0x117>
    switch(*p){
801039b4:	0f b6 10             	movzbl (%eax),%edx
801039b7:	80 fa 04             	cmp    $0x4,%dl
801039ba:	0f 87 ca 00 00 00    	ja     80103a8a <mpinit+0x1ca>
801039c0:	ff 24 95 9c 7d 10 80 	jmp    *-0x7fef8264(,%edx,4)
801039c7:	89 f6                	mov    %esi,%esi
801039c9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
      p += sizeof(struct mpioapic);
      continue;
    case MPBUS:
    case MPIOINTR:
    case MPLINTR:
      p += 8;
801039d0:	83 c0 08             	add    $0x8,%eax
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
801039d3:	39 c6                	cmp    %eax,%esi
801039d5:	77 dd                	ja     801039b4 <mpinit+0xf4>
    default:
      ismp = 0;
      break;
    }
  }
  if(!ismp)
801039d7:	85 db                	test   %ebx,%ebx
801039d9:	0f 84 9e 00 00 00    	je     80103a7d <mpinit+0x1bd>
    panic("Didn't find a suitable machine");

  if(mp->imcrp){
801039df:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801039e2:	80 78 0c 00          	cmpb   $0x0,0xc(%eax)
801039e6:	74 15                	je     801039fd <mpinit+0x13d>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801039e8:	b8 70 00 00 00       	mov    $0x70,%eax
801039ed:	ba 22 00 00 00       	mov    $0x22,%edx
801039f2:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801039f3:	ba 23 00 00 00       	mov    $0x23,%edx
801039f8:	ec                   	in     (%dx),%al
    // Bochs doesn't support IMCR, so this doesn't run on Bochs.
    // But it would on real hardware.
    outb(0x22, 0x70);   // Select IMCR
    outb(0x23, inb(0x23) | 1);  // Mask external interrupts.
801039f9:	83 c8 01             	or     $0x1,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801039fc:	ee                   	out    %al,(%dx)
  }
}
801039fd:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103a00:	5b                   	pop    %ebx
80103a01:	5e                   	pop    %esi
80103a02:	5f                   	pop    %edi
80103a03:	5d                   	pop    %ebp
80103a04:	c3                   	ret    
80103a05:	8d 76 00             	lea    0x0(%esi),%esi
      if(ncpu < NCPU) {
80103a08:	8b 0d 00 5b 11 80    	mov    0x80115b00,%ecx
80103a0e:	83 f9 07             	cmp    $0x7,%ecx
80103a11:	7f 19                	jg     80103a2c <mpinit+0x16c>
        cpus[ncpu].apicid = proc->apicid;  // apicid may differ from ncpu
80103a13:	0f b6 50 01          	movzbl 0x1(%eax),%edx
80103a17:	69 f9 b0 00 00 00    	imul   $0xb0,%ecx,%edi
        ncpu++;
80103a1d:	83 c1 01             	add    $0x1,%ecx
80103a20:	89 0d 00 5b 11 80    	mov    %ecx,0x80115b00
        cpus[ncpu].apicid = proc->apicid;  // apicid may differ from ncpu
80103a26:	88 97 80 55 11 80    	mov    %dl,-0x7feeaa80(%edi)
      p += sizeof(struct mpproc);
80103a2c:	83 c0 14             	add    $0x14,%eax
      continue;
80103a2f:	e9 7c ff ff ff       	jmp    801039b0 <mpinit+0xf0>
80103a34:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      ioapicid = ioapic->apicno;
80103a38:	0f b6 50 01          	movzbl 0x1(%eax),%edx
      p += sizeof(struct mpioapic);
80103a3c:	83 c0 08             	add    $0x8,%eax
      ioapicid = ioapic->apicno;
80103a3f:	88 15 60 55 11 80    	mov    %dl,0x80115560
      continue;
80103a45:	e9 66 ff ff ff       	jmp    801039b0 <mpinit+0xf0>
80103a4a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  return mpsearch1(0xF0000, 0x10000);
80103a50:	ba 00 00 01 00       	mov    $0x10000,%edx
80103a55:	b8 00 00 0f 00       	mov    $0xf0000,%eax
80103a5a:	e8 e1 fd ff ff       	call   80103840 <mpsearch1>
  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
80103a5f:	85 c0                	test   %eax,%eax
  return mpsearch1(0xF0000, 0x10000);
80103a61:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
80103a64:	0f 85 a9 fe ff ff    	jne    80103913 <mpinit+0x53>
80103a6a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    panic("Expect to run on an SMP");
80103a70:	83 ec 0c             	sub    $0xc,%esp
80103a73:	68 5d 7d 10 80       	push   $0x80107d5d
80103a78:	e8 13 c9 ff ff       	call   80100390 <panic>
    panic("Didn't find a suitable machine");
80103a7d:	83 ec 0c             	sub    $0xc,%esp
80103a80:	68 7c 7d 10 80       	push   $0x80107d7c
80103a85:	e8 06 c9 ff ff       	call   80100390 <panic>
      ismp = 0;
80103a8a:	31 db                	xor    %ebx,%ebx
80103a8c:	e9 26 ff ff ff       	jmp    801039b7 <mpinit+0xf7>
80103a91:	66 90                	xchg   %ax,%ax
80103a93:	66 90                	xchg   %ax,%ax
80103a95:	66 90                	xchg   %ax,%ax
80103a97:	66 90                	xchg   %ax,%ax
80103a99:	66 90                	xchg   %ax,%ax
80103a9b:	66 90                	xchg   %ax,%ax
80103a9d:	66 90                	xchg   %ax,%ax
80103a9f:	90                   	nop

80103aa0 <picinit>:
#define IO_PIC2         0xA0    // Slave (IRQs 8-15)

// Don't use the 8259A interrupt controllers.  Xv6 assumes SMP hardware.
void
picinit(void)
{
80103aa0:	55                   	push   %ebp
80103aa1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80103aa6:	ba 21 00 00 00       	mov    $0x21,%edx
80103aab:	89 e5                	mov    %esp,%ebp
80103aad:	ee                   	out    %al,(%dx)
80103aae:	ba a1 00 00 00       	mov    $0xa1,%edx
80103ab3:	ee                   	out    %al,(%dx)
  // mask all interrupts
  outb(IO_PIC1+1, 0xFF);
  outb(IO_PIC2+1, 0xFF);
}
80103ab4:	5d                   	pop    %ebp
80103ab5:	c3                   	ret    
80103ab6:	66 90                	xchg   %ax,%ax
80103ab8:	66 90                	xchg   %ax,%ax
80103aba:	66 90                	xchg   %ax,%ax
80103abc:	66 90                	xchg   %ax,%ax
80103abe:	66 90                	xchg   %ax,%ax

80103ac0 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
80103ac0:	55                   	push   %ebp
80103ac1:	89 e5                	mov    %esp,%ebp
80103ac3:	57                   	push   %edi
80103ac4:	56                   	push   %esi
80103ac5:	53                   	push   %ebx
80103ac6:	83 ec 0c             	sub    $0xc,%esp
80103ac9:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103acc:	8b 75 0c             	mov    0xc(%ebp),%esi
  struct pipe *p;

  p = 0;
  *f0 = *f1 = 0;
80103acf:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
80103ad5:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
80103adb:	e8 a0 d2 ff ff       	call   80100d80 <filealloc>
80103ae0:	85 c0                	test   %eax,%eax
80103ae2:	89 03                	mov    %eax,(%ebx)
80103ae4:	74 22                	je     80103b08 <pipealloc+0x48>
80103ae6:	e8 95 d2 ff ff       	call   80100d80 <filealloc>
80103aeb:	85 c0                	test   %eax,%eax
80103aed:	89 06                	mov    %eax,(%esi)
80103aef:	74 3f                	je     80103b30 <pipealloc+0x70>
    goto bad;
  if((p = (struct pipe*)kalloc()) == 0)
80103af1:	e8 4a f2 ff ff       	call   80102d40 <kalloc>
80103af6:	85 c0                	test   %eax,%eax
80103af8:	89 c7                	mov    %eax,%edi
80103afa:	75 54                	jne    80103b50 <pipealloc+0x90>

//PAGEBREAK: 20
 bad:
  if(p)
    kfree((char*)p);
  if(*f0)
80103afc:	8b 03                	mov    (%ebx),%eax
80103afe:	85 c0                	test   %eax,%eax
80103b00:	75 34                	jne    80103b36 <pipealloc+0x76>
80103b02:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    fileclose(*f0);
  if(*f1)
80103b08:	8b 06                	mov    (%esi),%eax
80103b0a:	85 c0                	test   %eax,%eax
80103b0c:	74 0c                	je     80103b1a <pipealloc+0x5a>
    fileclose(*f1);
80103b0e:	83 ec 0c             	sub    $0xc,%esp
80103b11:	50                   	push   %eax
80103b12:	e8 29 d3 ff ff       	call   80100e40 <fileclose>
80103b17:	83 c4 10             	add    $0x10,%esp
  return -1;
}
80103b1a:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return -1;
80103b1d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80103b22:	5b                   	pop    %ebx
80103b23:	5e                   	pop    %esi
80103b24:	5f                   	pop    %edi
80103b25:	5d                   	pop    %ebp
80103b26:	c3                   	ret    
80103b27:	89 f6                	mov    %esi,%esi
80103b29:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
  if(*f0)
80103b30:	8b 03                	mov    (%ebx),%eax
80103b32:	85 c0                	test   %eax,%eax
80103b34:	74 e4                	je     80103b1a <pipealloc+0x5a>
    fileclose(*f0);
80103b36:	83 ec 0c             	sub    $0xc,%esp
80103b39:	50                   	push   %eax
80103b3a:	e8 01 d3 ff ff       	call   80100e40 <fileclose>
  if(*f1)
80103b3f:	8b 06                	mov    (%esi),%eax
    fileclose(*f0);
80103b41:	83 c4 10             	add    $0x10,%esp
  if(*f1)
80103b44:	85 c0                	test   %eax,%eax
80103b46:	75 c6                	jne    80103b0e <pipealloc+0x4e>
80103b48:	eb d0                	jmp    80103b1a <pipealloc+0x5a>
80103b4a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  initlock(&p->lock, "pipe");
80103b50:	83 ec 08             	sub    $0x8,%esp
  p->readopen = 1;
80103b53:	c7 80 3c 02 00 00 01 	movl   $0x1,0x23c(%eax)
80103b5a:	00 00 00 
  p->writeopen = 1;
80103b5d:	c7 80 40 02 00 00 01 	movl   $0x1,0x240(%eax)
80103b64:	00 00 00 
  p->nwrite = 0;
80103b67:	c7 80 38 02 00 00 00 	movl   $0x0,0x238(%eax)
80103b6e:	00 00 00 
  p->nread = 0;
80103b71:	c7 80 34 02 00 00 00 	movl   $0x0,0x234(%eax)
80103b78:	00 00 00 
  initlock(&p->lock, "pipe");
80103b7b:	68 b0 7d 10 80       	push   $0x80107db0
80103b80:	50                   	push   %eax
80103b81:	e8 fa 0e 00 00       	call   80104a80 <initlock>
  (*f0)->type = FD_PIPE;
80103b86:	8b 03                	mov    (%ebx),%eax
  return 0;
80103b88:	83 c4 10             	add    $0x10,%esp
  (*f0)->type = FD_PIPE;
80103b8b:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  (*f0)->readable = 1;
80103b91:	8b 03                	mov    (%ebx),%eax
80103b93:	c6 40 08 01          	movb   $0x1,0x8(%eax)
  (*f0)->writable = 0;
80103b97:	8b 03                	mov    (%ebx),%eax
80103b99:	c6 40 09 00          	movb   $0x0,0x9(%eax)
  (*f0)->pipe = p;
80103b9d:	8b 03                	mov    (%ebx),%eax
80103b9f:	89 78 0c             	mov    %edi,0xc(%eax)
  (*f1)->type = FD_PIPE;
80103ba2:	8b 06                	mov    (%esi),%eax
80103ba4:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  (*f1)->readable = 0;
80103baa:	8b 06                	mov    (%esi),%eax
80103bac:	c6 40 08 00          	movb   $0x0,0x8(%eax)
  (*f1)->writable = 1;
80103bb0:	8b 06                	mov    (%esi),%eax
80103bb2:	c6 40 09 01          	movb   $0x1,0x9(%eax)
  (*f1)->pipe = p;
80103bb6:	8b 06                	mov    (%esi),%eax
80103bb8:	89 78 0c             	mov    %edi,0xc(%eax)
}
80103bbb:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
80103bbe:	31 c0                	xor    %eax,%eax
}
80103bc0:	5b                   	pop    %ebx
80103bc1:	5e                   	pop    %esi
80103bc2:	5f                   	pop    %edi
80103bc3:	5d                   	pop    %ebp
80103bc4:	c3                   	ret    
80103bc5:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80103bc9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80103bd0 <pipeclose>:

void
pipeclose(struct pipe *p, int writable)
{
80103bd0:	55                   	push   %ebp
80103bd1:	89 e5                	mov    %esp,%ebp
80103bd3:	56                   	push   %esi
80103bd4:	53                   	push   %ebx
80103bd5:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103bd8:	8b 75 0c             	mov    0xc(%ebp),%esi
  acquire(&p->lock);
80103bdb:	83 ec 0c             	sub    $0xc,%esp
80103bde:	53                   	push   %ebx
80103bdf:	e8 dc 0f 00 00       	call   80104bc0 <acquire>
  if(writable){
80103be4:	83 c4 10             	add    $0x10,%esp
80103be7:	85 f6                	test   %esi,%esi
80103be9:	74 45                	je     80103c30 <pipeclose+0x60>
    p->writeopen = 0;
    wakeup(&p->nread);
80103beb:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
80103bf1:	83 ec 0c             	sub    $0xc,%esp
    p->writeopen = 0;
80103bf4:	c7 83 40 02 00 00 00 	movl   $0x0,0x240(%ebx)
80103bfb:	00 00 00 
    wakeup(&p->nread);
80103bfe:	50                   	push   %eax
80103bff:	e8 ac 0b 00 00       	call   801047b0 <wakeup>
80103c04:	83 c4 10             	add    $0x10,%esp
  } else {
    p->readopen = 0;
    wakeup(&p->nwrite);
  }
  if(p->readopen == 0 && p->writeopen == 0){
80103c07:	8b 93 3c 02 00 00    	mov    0x23c(%ebx),%edx
80103c0d:	85 d2                	test   %edx,%edx
80103c0f:	75 0a                	jne    80103c1b <pipeclose+0x4b>
80103c11:	8b 83 40 02 00 00    	mov    0x240(%ebx),%eax
80103c17:	85 c0                	test   %eax,%eax
80103c19:	74 35                	je     80103c50 <pipeclose+0x80>
    release(&p->lock);
    kfree((char*)p);
  } else
    release(&p->lock);
80103c1b:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
80103c1e:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103c21:	5b                   	pop    %ebx
80103c22:	5e                   	pop    %esi
80103c23:	5d                   	pop    %ebp
    release(&p->lock);
80103c24:	e9 57 10 00 00       	jmp    80104c80 <release>
80103c29:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    wakeup(&p->nwrite);
80103c30:	8d 83 38 02 00 00    	lea    0x238(%ebx),%eax
80103c36:	83 ec 0c             	sub    $0xc,%esp
    p->readopen = 0;
80103c39:	c7 83 3c 02 00 00 00 	movl   $0x0,0x23c(%ebx)
80103c40:	00 00 00 
    wakeup(&p->nwrite);
80103c43:	50                   	push   %eax
80103c44:	e8 67 0b 00 00       	call   801047b0 <wakeup>
80103c49:	83 c4 10             	add    $0x10,%esp
80103c4c:	eb b9                	jmp    80103c07 <pipeclose+0x37>
80103c4e:	66 90                	xchg   %ax,%ax
    release(&p->lock);
80103c50:	83 ec 0c             	sub    $0xc,%esp
80103c53:	53                   	push   %ebx
80103c54:	e8 27 10 00 00       	call   80104c80 <release>
    kfree((char*)p);
80103c59:	89 5d 08             	mov    %ebx,0x8(%ebp)
80103c5c:	83 c4 10             	add    $0x10,%esp
}
80103c5f:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103c62:	5b                   	pop    %ebx
80103c63:	5e                   	pop    %esi
80103c64:	5d                   	pop    %ebp
    kfree((char*)p);
80103c65:	e9 26 ef ff ff       	jmp    80102b90 <kfree>
80103c6a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80103c70 <pipewrite>:

//PAGEBREAK: 40
int
pipewrite(struct pipe *p, char *addr, int n)
{
80103c70:	55                   	push   %ebp
80103c71:	89 e5                	mov    %esp,%ebp
80103c73:	57                   	push   %edi
80103c74:	56                   	push   %esi
80103c75:	53                   	push   %ebx
80103c76:	83 ec 28             	sub    $0x28,%esp
80103c79:	8b 5d 08             	mov    0x8(%ebp),%ebx
  int i;

  acquire(&p->lock);
80103c7c:	53                   	push   %ebx
80103c7d:	e8 3e 0f 00 00       	call   80104bc0 <acquire>
  for(i = 0; i < n; i++){
80103c82:	8b 45 10             	mov    0x10(%ebp),%eax
80103c85:	83 c4 10             	add    $0x10,%esp
80103c88:	85 c0                	test   %eax,%eax
80103c8a:	0f 8e c9 00 00 00    	jle    80103d59 <pipewrite+0xe9>
80103c90:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80103c93:	8b 83 38 02 00 00    	mov    0x238(%ebx),%eax
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
      if(p->readopen == 0 || myproc()->killed){
        release(&p->lock);
        return -1;
      }
      wakeup(&p->nread);
80103c99:	8d bb 34 02 00 00    	lea    0x234(%ebx),%edi
80103c9f:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
80103ca2:	03 4d 10             	add    0x10(%ebp),%ecx
80103ca5:	89 4d e0             	mov    %ecx,-0x20(%ebp)
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
80103ca8:	8b 8b 34 02 00 00    	mov    0x234(%ebx),%ecx
80103cae:	8d 91 00 02 00 00    	lea    0x200(%ecx),%edx
80103cb4:	39 d0                	cmp    %edx,%eax
80103cb6:	75 71                	jne    80103d29 <pipewrite+0xb9>
      if(p->readopen == 0 || myproc()->killed){
80103cb8:	8b 83 3c 02 00 00    	mov    0x23c(%ebx),%eax
80103cbe:	85 c0                	test   %eax,%eax
80103cc0:	74 4e                	je     80103d10 <pipewrite+0xa0>
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
80103cc2:	8d b3 38 02 00 00    	lea    0x238(%ebx),%esi
80103cc8:	eb 3a                	jmp    80103d04 <pipewrite+0x94>
80103cca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      wakeup(&p->nread);
80103cd0:	83 ec 0c             	sub    $0xc,%esp
80103cd3:	57                   	push   %edi
80103cd4:	e8 d7 0a 00 00       	call   801047b0 <wakeup>
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
80103cd9:	5a                   	pop    %edx
80103cda:	59                   	pop    %ecx
80103cdb:	53                   	push   %ebx
80103cdc:	56                   	push   %esi
80103cdd:	e8 1e 09 00 00       	call   80104600 <sleep>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
80103ce2:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
80103ce8:	8b 93 38 02 00 00    	mov    0x238(%ebx),%edx
80103cee:	83 c4 10             	add    $0x10,%esp
80103cf1:	05 00 02 00 00       	add    $0x200,%eax
80103cf6:	39 c2                	cmp    %eax,%edx
80103cf8:	75 36                	jne    80103d30 <pipewrite+0xc0>
      if(p->readopen == 0 || myproc()->killed){
80103cfa:	8b 83 3c 02 00 00    	mov    0x23c(%ebx),%eax
80103d00:	85 c0                	test   %eax,%eax
80103d02:	74 0c                	je     80103d10 <pipewrite+0xa0>
80103d04:	e8 57 03 00 00       	call   80104060 <myproc>
80103d09:	8b 40 24             	mov    0x24(%eax),%eax
80103d0c:	85 c0                	test   %eax,%eax
80103d0e:	74 c0                	je     80103cd0 <pipewrite+0x60>
        release(&p->lock);
80103d10:	83 ec 0c             	sub    $0xc,%esp
80103d13:	53                   	push   %ebx
80103d14:	e8 67 0f 00 00       	call   80104c80 <release>
        return -1;
80103d19:	83 c4 10             	add    $0x10,%esp
80103d1c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
  }
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
  release(&p->lock);
  return n;
}
80103d21:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103d24:	5b                   	pop    %ebx
80103d25:	5e                   	pop    %esi
80103d26:	5f                   	pop    %edi
80103d27:	5d                   	pop    %ebp
80103d28:	c3                   	ret    
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
80103d29:	89 c2                	mov    %eax,%edx
80103d2b:	90                   	nop
80103d2c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
80103d30:	8b 75 e4             	mov    -0x1c(%ebp),%esi
80103d33:	8d 42 01             	lea    0x1(%edx),%eax
80103d36:	81 e2 ff 01 00 00    	and    $0x1ff,%edx
80103d3c:	89 83 38 02 00 00    	mov    %eax,0x238(%ebx)
80103d42:	83 c6 01             	add    $0x1,%esi
80103d45:	0f b6 4e ff          	movzbl -0x1(%esi),%ecx
  for(i = 0; i < n; i++){
80103d49:	3b 75 e0             	cmp    -0x20(%ebp),%esi
80103d4c:	89 75 e4             	mov    %esi,-0x1c(%ebp)
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
80103d4f:	88 4c 13 34          	mov    %cl,0x34(%ebx,%edx,1)
  for(i = 0; i < n; i++){
80103d53:	0f 85 4f ff ff ff    	jne    80103ca8 <pipewrite+0x38>
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
80103d59:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
80103d5f:	83 ec 0c             	sub    $0xc,%esp
80103d62:	50                   	push   %eax
80103d63:	e8 48 0a 00 00       	call   801047b0 <wakeup>
  release(&p->lock);
80103d68:	89 1c 24             	mov    %ebx,(%esp)
80103d6b:	e8 10 0f 00 00       	call   80104c80 <release>
  return n;
80103d70:	83 c4 10             	add    $0x10,%esp
80103d73:	8b 45 10             	mov    0x10(%ebp),%eax
80103d76:	eb a9                	jmp    80103d21 <pipewrite+0xb1>
80103d78:	90                   	nop
80103d79:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80103d80 <piperead>:

int
piperead(struct pipe *p, char *addr, int n)
{
80103d80:	55                   	push   %ebp
80103d81:	89 e5                	mov    %esp,%ebp
80103d83:	57                   	push   %edi
80103d84:	56                   	push   %esi
80103d85:	53                   	push   %ebx
80103d86:	83 ec 18             	sub    $0x18,%esp
80103d89:	8b 75 08             	mov    0x8(%ebp),%esi
80103d8c:	8b 7d 0c             	mov    0xc(%ebp),%edi
  int i;

  acquire(&p->lock);
80103d8f:	56                   	push   %esi
80103d90:	e8 2b 0e 00 00       	call   80104bc0 <acquire>
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
80103d95:	83 c4 10             	add    $0x10,%esp
80103d98:	8b 8e 34 02 00 00    	mov    0x234(%esi),%ecx
80103d9e:	3b 8e 38 02 00 00    	cmp    0x238(%esi),%ecx
80103da4:	75 6a                	jne    80103e10 <piperead+0x90>
80103da6:	8b 9e 40 02 00 00    	mov    0x240(%esi),%ebx
80103dac:	85 db                	test   %ebx,%ebx
80103dae:	0f 84 c4 00 00 00    	je     80103e78 <piperead+0xf8>
    if(myproc()->killed){
      release(&p->lock);
      return -1;
    }
    sleep(&p->nread, &p->lock); //DOC: piperead-sleep
80103db4:	8d 9e 34 02 00 00    	lea    0x234(%esi),%ebx
80103dba:	eb 2d                	jmp    80103de9 <piperead+0x69>
80103dbc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80103dc0:	83 ec 08             	sub    $0x8,%esp
80103dc3:	56                   	push   %esi
80103dc4:	53                   	push   %ebx
80103dc5:	e8 36 08 00 00       	call   80104600 <sleep>
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
80103dca:	83 c4 10             	add    $0x10,%esp
80103dcd:	8b 8e 34 02 00 00    	mov    0x234(%esi),%ecx
80103dd3:	3b 8e 38 02 00 00    	cmp    0x238(%esi),%ecx
80103dd9:	75 35                	jne    80103e10 <piperead+0x90>
80103ddb:	8b 96 40 02 00 00    	mov    0x240(%esi),%edx
80103de1:	85 d2                	test   %edx,%edx
80103de3:	0f 84 8f 00 00 00    	je     80103e78 <piperead+0xf8>
    if(myproc()->killed){
80103de9:	e8 72 02 00 00       	call   80104060 <myproc>
80103dee:	8b 48 24             	mov    0x24(%eax),%ecx
80103df1:	85 c9                	test   %ecx,%ecx
80103df3:	74 cb                	je     80103dc0 <piperead+0x40>
      release(&p->lock);
80103df5:	83 ec 0c             	sub    $0xc,%esp
      return -1;
80103df8:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
      release(&p->lock);
80103dfd:	56                   	push   %esi
80103dfe:	e8 7d 0e 00 00       	call   80104c80 <release>
      return -1;
80103e03:	83 c4 10             	add    $0x10,%esp
    addr[i] = p->data[p->nread++ % PIPESIZE];
  }
  wakeup(&p->nwrite);  //DOC: piperead-wakeup
  release(&p->lock);
  return i;
}
80103e06:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103e09:	89 d8                	mov    %ebx,%eax
80103e0b:	5b                   	pop    %ebx
80103e0c:	5e                   	pop    %esi
80103e0d:	5f                   	pop    %edi
80103e0e:	5d                   	pop    %ebp
80103e0f:	c3                   	ret    
  for(i = 0; i < n; i++){  //DOC: piperead-copy
80103e10:	8b 45 10             	mov    0x10(%ebp),%eax
80103e13:	85 c0                	test   %eax,%eax
80103e15:	7e 61                	jle    80103e78 <piperead+0xf8>
    if(p->nread == p->nwrite)
80103e17:	31 db                	xor    %ebx,%ebx
80103e19:	eb 13                	jmp    80103e2e <piperead+0xae>
80103e1b:	90                   	nop
80103e1c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80103e20:	8b 8e 34 02 00 00    	mov    0x234(%esi),%ecx
80103e26:	3b 8e 38 02 00 00    	cmp    0x238(%esi),%ecx
80103e2c:	74 1f                	je     80103e4d <piperead+0xcd>
    addr[i] = p->data[p->nread++ % PIPESIZE];
80103e2e:	8d 41 01             	lea    0x1(%ecx),%eax
80103e31:	81 e1 ff 01 00 00    	and    $0x1ff,%ecx
80103e37:	89 86 34 02 00 00    	mov    %eax,0x234(%esi)
80103e3d:	0f b6 44 0e 34       	movzbl 0x34(%esi,%ecx,1),%eax
80103e42:	88 04 1f             	mov    %al,(%edi,%ebx,1)
  for(i = 0; i < n; i++){  //DOC: piperead-copy
80103e45:	83 c3 01             	add    $0x1,%ebx
80103e48:	39 5d 10             	cmp    %ebx,0x10(%ebp)
80103e4b:	75 d3                	jne    80103e20 <piperead+0xa0>
  wakeup(&p->nwrite);  //DOC: piperead-wakeup
80103e4d:	8d 86 38 02 00 00    	lea    0x238(%esi),%eax
80103e53:	83 ec 0c             	sub    $0xc,%esp
80103e56:	50                   	push   %eax
80103e57:	e8 54 09 00 00       	call   801047b0 <wakeup>
  release(&p->lock);
80103e5c:	89 34 24             	mov    %esi,(%esp)
80103e5f:	e8 1c 0e 00 00       	call   80104c80 <release>
  return i;
80103e64:	83 c4 10             	add    $0x10,%esp
}
80103e67:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103e6a:	89 d8                	mov    %ebx,%eax
80103e6c:	5b                   	pop    %ebx
80103e6d:	5e                   	pop    %esi
80103e6e:	5f                   	pop    %edi
80103e6f:	5d                   	pop    %ebp
80103e70:	c3                   	ret    
80103e71:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80103e78:	31 db                	xor    %ebx,%ebx
80103e7a:	eb d1                	jmp    80103e4d <piperead+0xcd>
80103e7c:	66 90                	xchg   %ax,%ax
80103e7e:	66 90                	xchg   %ax,%ax

80103e80 <allocproc>:
// If found, change state to EMBRYO and initialize
// state required to run in the kernel.
// Otherwise return 0.
static struct proc*
allocproc(void)
{
80103e80:	55                   	push   %ebp
80103e81:	89 e5                	mov    %esp,%ebp
80103e83:	53                   	push   %ebx
  struct proc *p;
  char *sp;

  acquire(&ptable.lock);

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80103e84:	bb 54 5b 11 80       	mov    $0x80115b54,%ebx
{
80103e89:	83 ec 10             	sub    $0x10,%esp
  acquire(&ptable.lock);
80103e8c:	68 20 5b 11 80       	push   $0x80115b20
80103e91:	e8 2a 0d 00 00       	call   80104bc0 <acquire>
80103e96:	83 c4 10             	add    $0x10,%esp
80103e99:	eb 10                	jmp    80103eab <allocproc+0x2b>
80103e9b:	90                   	nop
80103e9c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80103ea0:	83 c3 7c             	add    $0x7c,%ebx
80103ea3:	81 fb 54 7a 11 80    	cmp    $0x80117a54,%ebx
80103ea9:	73 75                	jae    80103f20 <allocproc+0xa0>
    if(p->state == UNUSED)
80103eab:	8b 43 0c             	mov    0xc(%ebx),%eax
80103eae:	85 c0                	test   %eax,%eax
80103eb0:	75 ee                	jne    80103ea0 <allocproc+0x20>
  release(&ptable.lock);
  return 0;

found:
  p->state = EMBRYO;
  p->pid = nextpid++;
80103eb2:	a1 04 b0 10 80       	mov    0x8010b004,%eax

  release(&ptable.lock);
80103eb7:	83 ec 0c             	sub    $0xc,%esp
  p->state = EMBRYO;
80103eba:	c7 43 0c 01 00 00 00 	movl   $0x1,0xc(%ebx)
  p->pid = nextpid++;
80103ec1:	8d 50 01             	lea    0x1(%eax),%edx
80103ec4:	89 43 10             	mov    %eax,0x10(%ebx)
  release(&ptable.lock);
80103ec7:	68 20 5b 11 80       	push   $0x80115b20
  p->pid = nextpid++;
80103ecc:	89 15 04 b0 10 80    	mov    %edx,0x8010b004
  release(&ptable.lock);
80103ed2:	e8 a9 0d 00 00       	call   80104c80 <release>

  // Allocate kernel stack.
  if((p->kstack = kalloc()) == 0){
80103ed7:	e8 64 ee ff ff       	call   80102d40 <kalloc>
80103edc:	83 c4 10             	add    $0x10,%esp
80103edf:	85 c0                	test   %eax,%eax
80103ee1:	89 43 08             	mov    %eax,0x8(%ebx)
80103ee4:	74 53                	je     80103f39 <allocproc+0xb9>
    return 0;
  }
  sp = p->kstack + KSTACKSIZE;

  // Leave room for trap frame.
  sp -= sizeof *p->tf;
80103ee6:	8d 90 b4 0f 00 00    	lea    0xfb4(%eax),%edx
  sp -= 4;
  *(uint*)sp = (uint)trapret;

  sp -= sizeof *p->context;
  p->context = (struct context*)sp;
  memset(p->context, 0, sizeof *p->context);
80103eec:	83 ec 04             	sub    $0x4,%esp
  sp -= sizeof *p->context;
80103eef:	05 9c 0f 00 00       	add    $0xf9c,%eax
  sp -= sizeof *p->tf;
80103ef4:	89 53 18             	mov    %edx,0x18(%ebx)
  *(uint*)sp = (uint)trapret;
80103ef7:	c7 40 14 12 5f 10 80 	movl   $0x80105f12,0x14(%eax)
  p->context = (struct context*)sp;
80103efe:	89 43 1c             	mov    %eax,0x1c(%ebx)
  memset(p->context, 0, sizeof *p->context);
80103f01:	6a 14                	push   $0x14
80103f03:	6a 00                	push   $0x0
80103f05:	50                   	push   %eax
80103f06:	e8 c5 0d 00 00       	call   80104cd0 <memset>
  p->context->eip = (uint)forkret;
80103f0b:	8b 43 1c             	mov    0x1c(%ebx),%eax

  return p;
80103f0e:	83 c4 10             	add    $0x10,%esp
  p->context->eip = (uint)forkret;
80103f11:	c7 40 10 50 3f 10 80 	movl   $0x80103f50,0x10(%eax)
}
80103f18:	89 d8                	mov    %ebx,%eax
80103f1a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103f1d:	c9                   	leave  
80103f1e:	c3                   	ret    
80103f1f:	90                   	nop
  release(&ptable.lock);
80103f20:	83 ec 0c             	sub    $0xc,%esp
  return 0;
80103f23:	31 db                	xor    %ebx,%ebx
  release(&ptable.lock);
80103f25:	68 20 5b 11 80       	push   $0x80115b20
80103f2a:	e8 51 0d 00 00       	call   80104c80 <release>
}
80103f2f:	89 d8                	mov    %ebx,%eax
  return 0;
80103f31:	83 c4 10             	add    $0x10,%esp
}
80103f34:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103f37:	c9                   	leave  
80103f38:	c3                   	ret    
    p->state = UNUSED;
80103f39:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
    return 0;
80103f40:	31 db                	xor    %ebx,%ebx
80103f42:	eb d4                	jmp    80103f18 <allocproc+0x98>
80103f44:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80103f4a:	8d bf 00 00 00 00    	lea    0x0(%edi),%edi

80103f50 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch here.  "Return" to user space.
void
forkret(void)
{
80103f50:	55                   	push   %ebp
80103f51:	89 e5                	mov    %esp,%ebp
80103f53:	83 ec 14             	sub    $0x14,%esp
  static int first = 1;
  // Still holding ptable.lock from scheduler.
  release(&ptable.lock);
80103f56:	68 20 5b 11 80       	push   $0x80115b20
80103f5b:	e8 20 0d 00 00       	call   80104c80 <release>

  if (first) {
80103f60:	a1 00 b0 10 80       	mov    0x8010b000,%eax
80103f65:	83 c4 10             	add    $0x10,%esp
80103f68:	85 c0                	test   %eax,%eax
80103f6a:	75 04                	jne    80103f70 <forkret+0x20>
    iinit(ROOTDEV);
    initlog(ROOTDEV);
  }

  // Return to "caller", actually trapret (see allocproc).
}
80103f6c:	c9                   	leave  
80103f6d:	c3                   	ret    
80103f6e:	66 90                	xchg   %ax,%ax
    iinit(ROOTDEV);
80103f70:	83 ec 0c             	sub    $0xc,%esp
    first = 0;
80103f73:	c7 05 00 b0 10 80 00 	movl   $0x0,0x8010b000
80103f7a:	00 00 00 
    iinit(ROOTDEV);
80103f7d:	6a 01                	push   $0x1
80103f7f:	e8 dc d6 ff ff       	call   80101660 <iinit>
    initlog(ROOTDEV);
80103f84:	c7 04 24 01 00 00 00 	movl   $0x1,(%esp)
80103f8b:	e8 f0 f3 ff ff       	call   80103380 <initlog>
80103f90:	83 c4 10             	add    $0x10,%esp
}
80103f93:	c9                   	leave  
80103f94:	c3                   	ret    
80103f95:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80103f99:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80103fa0 <pinit>:
{
80103fa0:	55                   	push   %ebp
80103fa1:	89 e5                	mov    %esp,%ebp
80103fa3:	83 ec 10             	sub    $0x10,%esp
  initlock(&ptable.lock, "ptable");
80103fa6:	68 b5 7d 10 80       	push   $0x80107db5
80103fab:	68 20 5b 11 80       	push   $0x80115b20
80103fb0:	e8 cb 0a 00 00       	call   80104a80 <initlock>
}
80103fb5:	83 c4 10             	add    $0x10,%esp
80103fb8:	c9                   	leave  
80103fb9:	c3                   	ret    
80103fba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80103fc0 <mycpu>:
{
80103fc0:	55                   	push   %ebp
80103fc1:	89 e5                	mov    %esp,%ebp
80103fc3:	56                   	push   %esi
80103fc4:	53                   	push   %ebx
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80103fc5:	9c                   	pushf  
80103fc6:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80103fc7:	f6 c4 02             	test   $0x2,%ah
80103fca:	75 5e                	jne    8010402a <mycpu+0x6a>
  apicid = lapicid();
80103fcc:	e8 df ef ff ff       	call   80102fb0 <lapicid>
  for (i = 0; i < ncpu; ++i) {
80103fd1:	8b 35 00 5b 11 80    	mov    0x80115b00,%esi
80103fd7:	85 f6                	test   %esi,%esi
80103fd9:	7e 42                	jle    8010401d <mycpu+0x5d>
    if (cpus[i].apicid == apicid)
80103fdb:	0f b6 15 80 55 11 80 	movzbl 0x80115580,%edx
80103fe2:	39 d0                	cmp    %edx,%eax
80103fe4:	74 30                	je     80104016 <mycpu+0x56>
80103fe6:	b9 30 56 11 80       	mov    $0x80115630,%ecx
  for (i = 0; i < ncpu; ++i) {
80103feb:	31 d2                	xor    %edx,%edx
80103fed:	8d 76 00             	lea    0x0(%esi),%esi
80103ff0:	83 c2 01             	add    $0x1,%edx
80103ff3:	39 f2                	cmp    %esi,%edx
80103ff5:	74 26                	je     8010401d <mycpu+0x5d>
    if (cpus[i].apicid == apicid)
80103ff7:	0f b6 19             	movzbl (%ecx),%ebx
80103ffa:	81 c1 b0 00 00 00    	add    $0xb0,%ecx
80104000:	39 c3                	cmp    %eax,%ebx
80104002:	75 ec                	jne    80103ff0 <mycpu+0x30>
80104004:	69 c2 b0 00 00 00    	imul   $0xb0,%edx,%eax
8010400a:	05 80 55 11 80       	add    $0x80115580,%eax
}
8010400f:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104012:	5b                   	pop    %ebx
80104013:	5e                   	pop    %esi
80104014:	5d                   	pop    %ebp
80104015:	c3                   	ret    
    if (cpus[i].apicid == apicid)
80104016:	b8 80 55 11 80       	mov    $0x80115580,%eax
      return &cpus[i];
8010401b:	eb f2                	jmp    8010400f <mycpu+0x4f>
  panic("unknown apicid\n");
8010401d:	83 ec 0c             	sub    $0xc,%esp
80104020:	68 bc 7d 10 80       	push   $0x80107dbc
80104025:	e8 66 c3 ff ff       	call   80100390 <panic>
    panic("mycpu called with interrupts enabled\n");
8010402a:	83 ec 0c             	sub    $0xc,%esp
8010402d:	68 98 7e 10 80       	push   $0x80107e98
80104032:	e8 59 c3 ff ff       	call   80100390 <panic>
80104037:	89 f6                	mov    %esi,%esi
80104039:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80104040 <cpuid>:
cpuid() {
80104040:	55                   	push   %ebp
80104041:	89 e5                	mov    %esp,%ebp
80104043:	83 ec 08             	sub    $0x8,%esp
  return mycpu()-cpus;
80104046:	e8 75 ff ff ff       	call   80103fc0 <mycpu>
8010404b:	2d 80 55 11 80       	sub    $0x80115580,%eax
}
80104050:	c9                   	leave  
  return mycpu()-cpus;
80104051:	c1 f8 04             	sar    $0x4,%eax
80104054:	69 c0 a3 8b 2e ba    	imul   $0xba2e8ba3,%eax,%eax
}
8010405a:	c3                   	ret    
8010405b:	90                   	nop
8010405c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80104060 <myproc>:
myproc(void) {
80104060:	55                   	push   %ebp
80104061:	89 e5                	mov    %esp,%ebp
80104063:	53                   	push   %ebx
80104064:	83 ec 04             	sub    $0x4,%esp
  pushcli();
80104067:	e8 84 0a 00 00       	call   80104af0 <pushcli>
  c = mycpu();
8010406c:	e8 4f ff ff ff       	call   80103fc0 <mycpu>
  p = c->proc;
80104071:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80104077:	e8 b4 0a 00 00       	call   80104b30 <popcli>
}
8010407c:	83 c4 04             	add    $0x4,%esp
8010407f:	89 d8                	mov    %ebx,%eax
80104081:	5b                   	pop    %ebx
80104082:	5d                   	pop    %ebp
80104083:	c3                   	ret    
80104084:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
8010408a:	8d bf 00 00 00 00    	lea    0x0(%edi),%edi

80104090 <userinit>:
{
80104090:	55                   	push   %ebp
80104091:	89 e5                	mov    %esp,%ebp
80104093:	53                   	push   %ebx
80104094:	83 ec 04             	sub    $0x4,%esp
  p = allocproc();
80104097:	e8 e4 fd ff ff       	call   80103e80 <allocproc>
8010409c:	89 c3                	mov    %eax,%ebx
  initproc = p;
8010409e:	a3 b8 b5 10 80       	mov    %eax,0x8010b5b8
  if((p->pgdir = setupkvm()) == 0)
801040a3:	e8 38 34 00 00       	call   801074e0 <setupkvm>
801040a8:	85 c0                	test   %eax,%eax
801040aa:	89 43 04             	mov    %eax,0x4(%ebx)
801040ad:	0f 84 bd 00 00 00    	je     80104170 <userinit+0xe0>
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);
801040b3:	83 ec 04             	sub    $0x4,%esp
801040b6:	68 2c 00 00 00       	push   $0x2c
801040bb:	68 60 b4 10 80       	push   $0x8010b460
801040c0:	50                   	push   %eax
801040c1:	e8 fa 30 00 00       	call   801071c0 <inituvm>
  memset(p->tf, 0, sizeof(*p->tf));
801040c6:	83 c4 0c             	add    $0xc,%esp
  p->sz = PGSIZE;
801040c9:	c7 03 00 10 00 00    	movl   $0x1000,(%ebx)
  memset(p->tf, 0, sizeof(*p->tf));
801040cf:	6a 4c                	push   $0x4c
801040d1:	6a 00                	push   $0x0
801040d3:	ff 73 18             	pushl  0x18(%ebx)
801040d6:	e8 f5 0b 00 00       	call   80104cd0 <memset>
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
801040db:	8b 43 18             	mov    0x18(%ebx),%eax
801040de:	ba 1b 00 00 00       	mov    $0x1b,%edx
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
801040e3:	b9 23 00 00 00       	mov    $0x23,%ecx
  safestrcpy(p->name, "initcode", sizeof(p->name));
801040e8:	83 c4 0c             	add    $0xc,%esp
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
801040eb:	66 89 50 3c          	mov    %dx,0x3c(%eax)
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
801040ef:	8b 43 18             	mov    0x18(%ebx),%eax
801040f2:	66 89 48 2c          	mov    %cx,0x2c(%eax)
  p->tf->es = p->tf->ds;
801040f6:	8b 43 18             	mov    0x18(%ebx),%eax
801040f9:	0f b7 50 2c          	movzwl 0x2c(%eax),%edx
801040fd:	66 89 50 28          	mov    %dx,0x28(%eax)
  p->tf->ss = p->tf->ds;
80104101:	8b 43 18             	mov    0x18(%ebx),%eax
80104104:	0f b7 50 2c          	movzwl 0x2c(%eax),%edx
80104108:	66 89 50 48          	mov    %dx,0x48(%eax)
  p->tf->eflags = FL_IF;
8010410c:	8b 43 18             	mov    0x18(%ebx),%eax
8010410f:	c7 40 40 00 02 00 00 	movl   $0x200,0x40(%eax)
  p->tf->esp = PGSIZE;
80104116:	8b 43 18             	mov    0x18(%ebx),%eax
80104119:	c7 40 44 00 10 00 00 	movl   $0x1000,0x44(%eax)
  p->tf->eip = 0;  // beginning of initcode.S
80104120:	8b 43 18             	mov    0x18(%ebx),%eax
80104123:	c7 40 38 00 00 00 00 	movl   $0x0,0x38(%eax)
  safestrcpy(p->name, "initcode", sizeof(p->name));
8010412a:	8d 43 6c             	lea    0x6c(%ebx),%eax
8010412d:	6a 10                	push   $0x10
8010412f:	68 e5 7d 10 80       	push   $0x80107de5
80104134:	50                   	push   %eax
80104135:	e8 76 0d 00 00       	call   80104eb0 <safestrcpy>
  p->cwd = namei("/");
8010413a:	c7 04 24 ee 7d 10 80 	movl   $0x80107dee,(%esp)
80104141:	e8 0a e6 ff ff       	call   80102750 <namei>
80104146:	89 43 68             	mov    %eax,0x68(%ebx)
  acquire(&ptable.lock);
80104149:	c7 04 24 20 5b 11 80 	movl   $0x80115b20,(%esp)
80104150:	e8 6b 0a 00 00       	call   80104bc0 <acquire>
  p->state = RUNNABLE;
80104155:	c7 43 0c 03 00 00 00 	movl   $0x3,0xc(%ebx)
  release(&ptable.lock);
8010415c:	c7 04 24 20 5b 11 80 	movl   $0x80115b20,(%esp)
80104163:	e8 18 0b 00 00       	call   80104c80 <release>
}
80104168:	83 c4 10             	add    $0x10,%esp
8010416b:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010416e:	c9                   	leave  
8010416f:	c3                   	ret    
    panic("userinit: out of memory?");
80104170:	83 ec 0c             	sub    $0xc,%esp
80104173:	68 cc 7d 10 80       	push   $0x80107dcc
80104178:	e8 13 c2 ff ff       	call   80100390 <panic>
8010417d:	8d 76 00             	lea    0x0(%esi),%esi

80104180 <growproc>:
{
80104180:	55                   	push   %ebp
80104181:	89 e5                	mov    %esp,%ebp
80104183:	56                   	push   %esi
80104184:	53                   	push   %ebx
80104185:	8b 75 08             	mov    0x8(%ebp),%esi
  pushcli();
80104188:	e8 63 09 00 00       	call   80104af0 <pushcli>
  c = mycpu();
8010418d:	e8 2e fe ff ff       	call   80103fc0 <mycpu>
  p = c->proc;
80104192:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80104198:	e8 93 09 00 00       	call   80104b30 <popcli>
  if(n > 0){
8010419d:	83 fe 00             	cmp    $0x0,%esi
  sz = curproc->sz;
801041a0:	8b 03                	mov    (%ebx),%eax
  if(n > 0){
801041a2:	7f 1c                	jg     801041c0 <growproc+0x40>
  } else if(n < 0){
801041a4:	75 3a                	jne    801041e0 <growproc+0x60>
  switchuvm(curproc);
801041a6:	83 ec 0c             	sub    $0xc,%esp
  curproc->sz = sz;
801041a9:	89 03                	mov    %eax,(%ebx)
  switchuvm(curproc);
801041ab:	53                   	push   %ebx
801041ac:	e8 ff 2e 00 00       	call   801070b0 <switchuvm>
  return 0;
801041b1:	83 c4 10             	add    $0x10,%esp
801041b4:	31 c0                	xor    %eax,%eax
}
801041b6:	8d 65 f8             	lea    -0x8(%ebp),%esp
801041b9:	5b                   	pop    %ebx
801041ba:	5e                   	pop    %esi
801041bb:	5d                   	pop    %ebp
801041bc:	c3                   	ret    
801041bd:	8d 76 00             	lea    0x0(%esi),%esi
    if((sz = allocuvm(curproc->pgdir, sz, sz + n)) == 0)
801041c0:	83 ec 04             	sub    $0x4,%esp
801041c3:	01 c6                	add    %eax,%esi
801041c5:	56                   	push   %esi
801041c6:	50                   	push   %eax
801041c7:	ff 73 04             	pushl  0x4(%ebx)
801041ca:	e8 31 31 00 00       	call   80107300 <allocuvm>
801041cf:	83 c4 10             	add    $0x10,%esp
801041d2:	85 c0                	test   %eax,%eax
801041d4:	75 d0                	jne    801041a6 <growproc+0x26>
      return -1;
801041d6:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801041db:	eb d9                	jmp    801041b6 <growproc+0x36>
801041dd:	8d 76 00             	lea    0x0(%esi),%esi
    if((sz = deallocuvm(curproc->pgdir, sz, sz + n)) == 0)
801041e0:	83 ec 04             	sub    $0x4,%esp
801041e3:	01 c6                	add    %eax,%esi
801041e5:	56                   	push   %esi
801041e6:	50                   	push   %eax
801041e7:	ff 73 04             	pushl  0x4(%ebx)
801041ea:	e8 41 32 00 00       	call   80107430 <deallocuvm>
801041ef:	83 c4 10             	add    $0x10,%esp
801041f2:	85 c0                	test   %eax,%eax
801041f4:	75 b0                	jne    801041a6 <growproc+0x26>
801041f6:	eb de                	jmp    801041d6 <growproc+0x56>
801041f8:	90                   	nop
801041f9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80104200 <fork>:
{
80104200:	55                   	push   %ebp
80104201:	89 e5                	mov    %esp,%ebp
80104203:	57                   	push   %edi
80104204:	56                   	push   %esi
80104205:	53                   	push   %ebx
80104206:	83 ec 1c             	sub    $0x1c,%esp
  pushcli();
80104209:	e8 e2 08 00 00       	call   80104af0 <pushcli>
  c = mycpu();
8010420e:	e8 ad fd ff ff       	call   80103fc0 <mycpu>
  p = c->proc;
80104213:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80104219:	e8 12 09 00 00       	call   80104b30 <popcli>
  if((np = allocproc()) == 0){
8010421e:	e8 5d fc ff ff       	call   80103e80 <allocproc>
80104223:	85 c0                	test   %eax,%eax
80104225:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80104228:	0f 84 b7 00 00 00    	je     801042e5 <fork+0xe5>
  if((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0){
8010422e:	83 ec 08             	sub    $0x8,%esp
80104231:	ff 33                	pushl  (%ebx)
80104233:	ff 73 04             	pushl  0x4(%ebx)
80104236:	89 c7                	mov    %eax,%edi
80104238:	e8 73 33 00 00       	call   801075b0 <copyuvm>
8010423d:	83 c4 10             	add    $0x10,%esp
80104240:	85 c0                	test   %eax,%eax
80104242:	89 47 04             	mov    %eax,0x4(%edi)
80104245:	0f 84 a1 00 00 00    	je     801042ec <fork+0xec>
  np->sz = curproc->sz;
8010424b:	8b 03                	mov    (%ebx),%eax
8010424d:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80104250:	89 01                	mov    %eax,(%ecx)
  np->parent = curproc;
80104252:	89 59 14             	mov    %ebx,0x14(%ecx)
80104255:	89 c8                	mov    %ecx,%eax
  *np->tf = *curproc->tf;
80104257:	8b 79 18             	mov    0x18(%ecx),%edi
8010425a:	8b 73 18             	mov    0x18(%ebx),%esi
8010425d:	b9 13 00 00 00       	mov    $0x13,%ecx
80104262:	f3 a5                	rep movsl %ds:(%esi),%es:(%edi)
  for(i = 0; i < NOFILE; i++)
80104264:	31 f6                	xor    %esi,%esi
  np->tf->eax = 0;
80104266:	8b 40 18             	mov    0x18(%eax),%eax
80104269:	c7 40 1c 00 00 00 00 	movl   $0x0,0x1c(%eax)
    if(curproc->ofile[i])
80104270:	8b 44 b3 28          	mov    0x28(%ebx,%esi,4),%eax
80104274:	85 c0                	test   %eax,%eax
80104276:	74 13                	je     8010428b <fork+0x8b>
      np->ofile[i] = filedup(curproc->ofile[i]);
80104278:	83 ec 0c             	sub    $0xc,%esp
8010427b:	50                   	push   %eax
8010427c:	e8 6f cb ff ff       	call   80100df0 <filedup>
80104281:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80104284:	83 c4 10             	add    $0x10,%esp
80104287:	89 44 b2 28          	mov    %eax,0x28(%edx,%esi,4)
  for(i = 0; i < NOFILE; i++)
8010428b:	83 c6 01             	add    $0x1,%esi
8010428e:	83 fe 10             	cmp    $0x10,%esi
80104291:	75 dd                	jne    80104270 <fork+0x70>
  np->cwd = idup(curproc->cwd);
80104293:	83 ec 0c             	sub    $0xc,%esp
80104296:	ff 73 68             	pushl  0x68(%ebx)
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
80104299:	83 c3 6c             	add    $0x6c,%ebx
  np->cwd = idup(curproc->cwd);
8010429c:	e8 8f d5 ff ff       	call   80101830 <idup>
801042a1:	8b 7d e4             	mov    -0x1c(%ebp),%edi
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
801042a4:	83 c4 0c             	add    $0xc,%esp
  np->cwd = idup(curproc->cwd);
801042a7:	89 47 68             	mov    %eax,0x68(%edi)
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
801042aa:	8d 47 6c             	lea    0x6c(%edi),%eax
801042ad:	6a 10                	push   $0x10
801042af:	53                   	push   %ebx
801042b0:	50                   	push   %eax
801042b1:	e8 fa 0b 00 00       	call   80104eb0 <safestrcpy>
  pid = np->pid;
801042b6:	8b 5f 10             	mov    0x10(%edi),%ebx
  acquire(&ptable.lock);
801042b9:	c7 04 24 20 5b 11 80 	movl   $0x80115b20,(%esp)
801042c0:	e8 fb 08 00 00       	call   80104bc0 <acquire>
  np->state = RUNNABLE;
801042c5:	c7 47 0c 03 00 00 00 	movl   $0x3,0xc(%edi)
  release(&ptable.lock);
801042cc:	c7 04 24 20 5b 11 80 	movl   $0x80115b20,(%esp)
801042d3:	e8 a8 09 00 00       	call   80104c80 <release>
  return pid;
801042d8:	83 c4 10             	add    $0x10,%esp
}
801042db:	8d 65 f4             	lea    -0xc(%ebp),%esp
801042de:	89 d8                	mov    %ebx,%eax
801042e0:	5b                   	pop    %ebx
801042e1:	5e                   	pop    %esi
801042e2:	5f                   	pop    %edi
801042e3:	5d                   	pop    %ebp
801042e4:	c3                   	ret    
    return -1;
801042e5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
801042ea:	eb ef                	jmp    801042db <fork+0xdb>
    kfree(np->kstack);
801042ec:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
801042ef:	83 ec 0c             	sub    $0xc,%esp
801042f2:	ff 73 08             	pushl  0x8(%ebx)
801042f5:	e8 96 e8 ff ff       	call   80102b90 <kfree>
    np->kstack = 0;
801042fa:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
    np->state = UNUSED;
80104301:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
    return -1;
80104308:	83 c4 10             	add    $0x10,%esp
8010430b:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80104310:	eb c9                	jmp    801042db <fork+0xdb>
80104312:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80104319:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80104320 <scheduler>:
{
80104320:	55                   	push   %ebp
80104321:	89 e5                	mov    %esp,%ebp
80104323:	57                   	push   %edi
80104324:	56                   	push   %esi
80104325:	53                   	push   %ebx
80104326:	83 ec 0c             	sub    $0xc,%esp
  struct cpu *c = mycpu();
80104329:	e8 92 fc ff ff       	call   80103fc0 <mycpu>
8010432e:	8d 78 04             	lea    0x4(%eax),%edi
80104331:	89 c6                	mov    %eax,%esi
  c->proc = 0;
80104333:	c7 80 ac 00 00 00 00 	movl   $0x0,0xac(%eax)
8010433a:	00 00 00 
8010433d:	8d 76 00             	lea    0x0(%esi),%esi
  asm volatile("sti");
80104340:	fb                   	sti    
    acquire(&ptable.lock);
80104341:	83 ec 0c             	sub    $0xc,%esp
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104344:	bb 54 5b 11 80       	mov    $0x80115b54,%ebx
    acquire(&ptable.lock);
80104349:	68 20 5b 11 80       	push   $0x80115b20
8010434e:	e8 6d 08 00 00       	call   80104bc0 <acquire>
80104353:	83 c4 10             	add    $0x10,%esp
80104356:	8d 76 00             	lea    0x0(%esi),%esi
80104359:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
      if(p->state != RUNNABLE)
80104360:	83 7b 0c 03          	cmpl   $0x3,0xc(%ebx)
80104364:	75 33                	jne    80104399 <scheduler+0x79>
      switchuvm(p);
80104366:	83 ec 0c             	sub    $0xc,%esp
      c->proc = p;
80104369:	89 9e ac 00 00 00    	mov    %ebx,0xac(%esi)
      switchuvm(p);
8010436f:	53                   	push   %ebx
80104370:	e8 3b 2d 00 00       	call   801070b0 <switchuvm>
      swtch(&(c->scheduler), p->context);
80104375:	58                   	pop    %eax
80104376:	5a                   	pop    %edx
80104377:	ff 73 1c             	pushl  0x1c(%ebx)
8010437a:	57                   	push   %edi
      p->state = RUNNING;
8010437b:	c7 43 0c 04 00 00 00 	movl   $0x4,0xc(%ebx)
      swtch(&(c->scheduler), p->context);
80104382:	e8 84 0b 00 00       	call   80104f0b <swtch>
      switchkvm();
80104387:	e8 04 2d 00 00       	call   80107090 <switchkvm>
      c->proc = 0;
8010438c:	c7 86 ac 00 00 00 00 	movl   $0x0,0xac(%esi)
80104393:	00 00 00 
80104396:	83 c4 10             	add    $0x10,%esp
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104399:	83 c3 7c             	add    $0x7c,%ebx
8010439c:	81 fb 54 7a 11 80    	cmp    $0x80117a54,%ebx
801043a2:	72 bc                	jb     80104360 <scheduler+0x40>
    release(&ptable.lock);
801043a4:	83 ec 0c             	sub    $0xc,%esp
801043a7:	68 20 5b 11 80       	push   $0x80115b20
801043ac:	e8 cf 08 00 00       	call   80104c80 <release>
    sti();
801043b1:	83 c4 10             	add    $0x10,%esp
801043b4:	eb 8a                	jmp    80104340 <scheduler+0x20>
801043b6:	8d 76 00             	lea    0x0(%esi),%esi
801043b9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

801043c0 <sched>:
{
801043c0:	55                   	push   %ebp
801043c1:	89 e5                	mov    %esp,%ebp
801043c3:	56                   	push   %esi
801043c4:	53                   	push   %ebx
  pushcli();
801043c5:	e8 26 07 00 00       	call   80104af0 <pushcli>
  c = mycpu();
801043ca:	e8 f1 fb ff ff       	call   80103fc0 <mycpu>
  p = c->proc;
801043cf:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
801043d5:	e8 56 07 00 00       	call   80104b30 <popcli>
  if(!holding(&ptable.lock))
801043da:	83 ec 0c             	sub    $0xc,%esp
801043dd:	68 20 5b 11 80       	push   $0x80115b20
801043e2:	e8 a9 07 00 00       	call   80104b90 <holding>
801043e7:	83 c4 10             	add    $0x10,%esp
801043ea:	85 c0                	test   %eax,%eax
801043ec:	74 4f                	je     8010443d <sched+0x7d>
  if(mycpu()->ncli != 1)
801043ee:	e8 cd fb ff ff       	call   80103fc0 <mycpu>
801043f3:	83 b8 a4 00 00 00 01 	cmpl   $0x1,0xa4(%eax)
801043fa:	75 68                	jne    80104464 <sched+0xa4>
  if(p->state == RUNNING)
801043fc:	83 7b 0c 04          	cmpl   $0x4,0xc(%ebx)
80104400:	74 55                	je     80104457 <sched+0x97>
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80104402:	9c                   	pushf  
80104403:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80104404:	f6 c4 02             	test   $0x2,%ah
80104407:	75 41                	jne    8010444a <sched+0x8a>
  intena = mycpu()->intena;
80104409:	e8 b2 fb ff ff       	call   80103fc0 <mycpu>
  swtch(&p->context, mycpu()->scheduler);
8010440e:	83 c3 1c             	add    $0x1c,%ebx
  intena = mycpu()->intena;
80104411:	8b b0 a8 00 00 00    	mov    0xa8(%eax),%esi
  swtch(&p->context, mycpu()->scheduler);
80104417:	e8 a4 fb ff ff       	call   80103fc0 <mycpu>
8010441c:	83 ec 08             	sub    $0x8,%esp
8010441f:	ff 70 04             	pushl  0x4(%eax)
80104422:	53                   	push   %ebx
80104423:	e8 e3 0a 00 00       	call   80104f0b <swtch>
  mycpu()->intena = intena;
80104428:	e8 93 fb ff ff       	call   80103fc0 <mycpu>
}
8010442d:	83 c4 10             	add    $0x10,%esp
  mycpu()->intena = intena;
80104430:	89 b0 a8 00 00 00    	mov    %esi,0xa8(%eax)
}
80104436:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104439:	5b                   	pop    %ebx
8010443a:	5e                   	pop    %esi
8010443b:	5d                   	pop    %ebp
8010443c:	c3                   	ret    
    panic("sched ptable.lock");
8010443d:	83 ec 0c             	sub    $0xc,%esp
80104440:	68 f0 7d 10 80       	push   $0x80107df0
80104445:	e8 46 bf ff ff       	call   80100390 <panic>
    panic("sched interruptible");
8010444a:	83 ec 0c             	sub    $0xc,%esp
8010444d:	68 1c 7e 10 80       	push   $0x80107e1c
80104452:	e8 39 bf ff ff       	call   80100390 <panic>
    panic("sched running");
80104457:	83 ec 0c             	sub    $0xc,%esp
8010445a:	68 0e 7e 10 80       	push   $0x80107e0e
8010445f:	e8 2c bf ff ff       	call   80100390 <panic>
    panic("sched locks");
80104464:	83 ec 0c             	sub    $0xc,%esp
80104467:	68 02 7e 10 80       	push   $0x80107e02
8010446c:	e8 1f bf ff ff       	call   80100390 <panic>
80104471:	eb 0d                	jmp    80104480 <exit>
80104473:	90                   	nop
80104474:	90                   	nop
80104475:	90                   	nop
80104476:	90                   	nop
80104477:	90                   	nop
80104478:	90                   	nop
80104479:	90                   	nop
8010447a:	90                   	nop
8010447b:	90                   	nop
8010447c:	90                   	nop
8010447d:	90                   	nop
8010447e:	90                   	nop
8010447f:	90                   	nop

80104480 <exit>:
{
80104480:	55                   	push   %ebp
80104481:	89 e5                	mov    %esp,%ebp
80104483:	57                   	push   %edi
80104484:	56                   	push   %esi
80104485:	53                   	push   %ebx
80104486:	83 ec 0c             	sub    $0xc,%esp
  pushcli();
80104489:	e8 62 06 00 00       	call   80104af0 <pushcli>
  c = mycpu();
8010448e:	e8 2d fb ff ff       	call   80103fc0 <mycpu>
  p = c->proc;
80104493:	8b b0 ac 00 00 00    	mov    0xac(%eax),%esi
  popcli();
80104499:	e8 92 06 00 00       	call   80104b30 <popcli>
  if(curproc == initproc)
8010449e:	39 35 b8 b5 10 80    	cmp    %esi,0x8010b5b8
801044a4:	8d 5e 28             	lea    0x28(%esi),%ebx
801044a7:	8d 7e 68             	lea    0x68(%esi),%edi
801044aa:	0f 84 e7 00 00 00    	je     80104597 <exit+0x117>
    if(curproc->ofile[fd]){
801044b0:	8b 03                	mov    (%ebx),%eax
801044b2:	85 c0                	test   %eax,%eax
801044b4:	74 12                	je     801044c8 <exit+0x48>
      fileclose(curproc->ofile[fd]);
801044b6:	83 ec 0c             	sub    $0xc,%esp
801044b9:	50                   	push   %eax
801044ba:	e8 81 c9 ff ff       	call   80100e40 <fileclose>
      curproc->ofile[fd] = 0;
801044bf:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
801044c5:	83 c4 10             	add    $0x10,%esp
801044c8:	83 c3 04             	add    $0x4,%ebx
  for(fd = 0; fd < NOFILE; fd++){
801044cb:	39 fb                	cmp    %edi,%ebx
801044cd:	75 e1                	jne    801044b0 <exit+0x30>
  begin_op();
801044cf:	e8 4c ef ff ff       	call   80103420 <begin_op>
  iput(curproc->cwd);
801044d4:	83 ec 0c             	sub    $0xc,%esp
801044d7:	ff 76 68             	pushl  0x68(%esi)
801044da:	e8 b1 d6 ff ff       	call   80101b90 <iput>
  end_op();
801044df:	e8 ac ef ff ff       	call   80103490 <end_op>
  curproc->cwd = 0;
801044e4:	c7 46 68 00 00 00 00 	movl   $0x0,0x68(%esi)
  acquire(&ptable.lock);
801044eb:	c7 04 24 20 5b 11 80 	movl   $0x80115b20,(%esp)
801044f2:	e8 c9 06 00 00       	call   80104bc0 <acquire>
  wakeup1(curproc->parent);
801044f7:	8b 56 14             	mov    0x14(%esi),%edx
801044fa:	83 c4 10             	add    $0x10,%esp
static void
wakeup1(void *chan)
{
  struct proc *p;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801044fd:	b8 54 5b 11 80       	mov    $0x80115b54,%eax
80104502:	eb 0e                	jmp    80104512 <exit+0x92>
80104504:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80104508:	83 c0 7c             	add    $0x7c,%eax
8010450b:	3d 54 7a 11 80       	cmp    $0x80117a54,%eax
80104510:	73 1c                	jae    8010452e <exit+0xae>
    if(p->state == SLEEPING && p->chan == chan)
80104512:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
80104516:	75 f0                	jne    80104508 <exit+0x88>
80104518:	3b 50 20             	cmp    0x20(%eax),%edx
8010451b:	75 eb                	jne    80104508 <exit+0x88>
      p->state = RUNNABLE;
8010451d:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80104524:	83 c0 7c             	add    $0x7c,%eax
80104527:	3d 54 7a 11 80       	cmp    $0x80117a54,%eax
8010452c:	72 e4                	jb     80104512 <exit+0x92>
      p->parent = initproc;
8010452e:	8b 0d b8 b5 10 80    	mov    0x8010b5b8,%ecx
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104534:	ba 54 5b 11 80       	mov    $0x80115b54,%edx
80104539:	eb 10                	jmp    8010454b <exit+0xcb>
8010453b:	90                   	nop
8010453c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80104540:	83 c2 7c             	add    $0x7c,%edx
80104543:	81 fa 54 7a 11 80    	cmp    $0x80117a54,%edx
80104549:	73 33                	jae    8010457e <exit+0xfe>
    if(p->parent == curproc){
8010454b:	39 72 14             	cmp    %esi,0x14(%edx)
8010454e:	75 f0                	jne    80104540 <exit+0xc0>
      if(p->state == ZOMBIE)
80104550:	83 7a 0c 05          	cmpl   $0x5,0xc(%edx)
      p->parent = initproc;
80104554:	89 4a 14             	mov    %ecx,0x14(%edx)
      if(p->state == ZOMBIE)
80104557:	75 e7                	jne    80104540 <exit+0xc0>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80104559:	b8 54 5b 11 80       	mov    $0x80115b54,%eax
8010455e:	eb 0a                	jmp    8010456a <exit+0xea>
80104560:	83 c0 7c             	add    $0x7c,%eax
80104563:	3d 54 7a 11 80       	cmp    $0x80117a54,%eax
80104568:	73 d6                	jae    80104540 <exit+0xc0>
    if(p->state == SLEEPING && p->chan == chan)
8010456a:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
8010456e:	75 f0                	jne    80104560 <exit+0xe0>
80104570:	3b 48 20             	cmp    0x20(%eax),%ecx
80104573:	75 eb                	jne    80104560 <exit+0xe0>
      p->state = RUNNABLE;
80104575:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
8010457c:	eb e2                	jmp    80104560 <exit+0xe0>
  curproc->state = ZOMBIE;
8010457e:	c7 46 0c 05 00 00 00 	movl   $0x5,0xc(%esi)
  sched();
80104585:	e8 36 fe ff ff       	call   801043c0 <sched>
  panic("zombie exit");
8010458a:	83 ec 0c             	sub    $0xc,%esp
8010458d:	68 3d 7e 10 80       	push   $0x80107e3d
80104592:	e8 f9 bd ff ff       	call   80100390 <panic>
    panic("init exiting");
80104597:	83 ec 0c             	sub    $0xc,%esp
8010459a:	68 30 7e 10 80       	push   $0x80107e30
8010459f:	e8 ec bd ff ff       	call   80100390 <panic>
801045a4:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801045aa:	8d bf 00 00 00 00    	lea    0x0(%edi),%edi

801045b0 <yield>:
{
801045b0:	55                   	push   %ebp
801045b1:	89 e5                	mov    %esp,%ebp
801045b3:	53                   	push   %ebx
801045b4:	83 ec 10             	sub    $0x10,%esp
  acquire(&ptable.lock);  //DOC: yieldlock
801045b7:	68 20 5b 11 80       	push   $0x80115b20
801045bc:	e8 ff 05 00 00       	call   80104bc0 <acquire>
  pushcli();
801045c1:	e8 2a 05 00 00       	call   80104af0 <pushcli>
  c = mycpu();
801045c6:	e8 f5 f9 ff ff       	call   80103fc0 <mycpu>
  p = c->proc;
801045cb:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
801045d1:	e8 5a 05 00 00       	call   80104b30 <popcli>
  myproc()->state = RUNNABLE;
801045d6:	c7 43 0c 03 00 00 00 	movl   $0x3,0xc(%ebx)
  sched();
801045dd:	e8 de fd ff ff       	call   801043c0 <sched>
  release(&ptable.lock);
801045e2:	c7 04 24 20 5b 11 80 	movl   $0x80115b20,(%esp)
801045e9:	e8 92 06 00 00       	call   80104c80 <release>
}
801045ee:	83 c4 10             	add    $0x10,%esp
801045f1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801045f4:	c9                   	leave  
801045f5:	c3                   	ret    
801045f6:	8d 76 00             	lea    0x0(%esi),%esi
801045f9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80104600 <sleep>:
{
80104600:	55                   	push   %ebp
80104601:	89 e5                	mov    %esp,%ebp
80104603:	57                   	push   %edi
80104604:	56                   	push   %esi
80104605:	53                   	push   %ebx
80104606:	83 ec 0c             	sub    $0xc,%esp
80104609:	8b 7d 08             	mov    0x8(%ebp),%edi
8010460c:	8b 75 0c             	mov    0xc(%ebp),%esi
  pushcli();
8010460f:	e8 dc 04 00 00       	call   80104af0 <pushcli>
  c = mycpu();
80104614:	e8 a7 f9 ff ff       	call   80103fc0 <mycpu>
  p = c->proc;
80104619:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
8010461f:	e8 0c 05 00 00       	call   80104b30 <popcli>
  if(p == 0)
80104624:	85 db                	test   %ebx,%ebx
80104626:	0f 84 87 00 00 00    	je     801046b3 <sleep+0xb3>
  if(lk == 0)
8010462c:	85 f6                	test   %esi,%esi
8010462e:	74 76                	je     801046a6 <sleep+0xa6>
  if(lk != &ptable.lock){  //DOC: sleeplock0
80104630:	81 fe 20 5b 11 80    	cmp    $0x80115b20,%esi
80104636:	74 50                	je     80104688 <sleep+0x88>
    acquire(&ptable.lock);  //DOC: sleeplock1
80104638:	83 ec 0c             	sub    $0xc,%esp
8010463b:	68 20 5b 11 80       	push   $0x80115b20
80104640:	e8 7b 05 00 00       	call   80104bc0 <acquire>
    release(lk);
80104645:	89 34 24             	mov    %esi,(%esp)
80104648:	e8 33 06 00 00       	call   80104c80 <release>
  p->chan = chan;
8010464d:	89 7b 20             	mov    %edi,0x20(%ebx)
  p->state = SLEEPING;
80104650:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
80104657:	e8 64 fd ff ff       	call   801043c0 <sched>
  p->chan = 0;
8010465c:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
    release(&ptable.lock);
80104663:	c7 04 24 20 5b 11 80 	movl   $0x80115b20,(%esp)
8010466a:	e8 11 06 00 00       	call   80104c80 <release>
    acquire(lk);
8010466f:	89 75 08             	mov    %esi,0x8(%ebp)
80104672:	83 c4 10             	add    $0x10,%esp
}
80104675:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104678:	5b                   	pop    %ebx
80104679:	5e                   	pop    %esi
8010467a:	5f                   	pop    %edi
8010467b:	5d                   	pop    %ebp
    acquire(lk);
8010467c:	e9 3f 05 00 00       	jmp    80104bc0 <acquire>
80104681:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  p->chan = chan;
80104688:	89 7b 20             	mov    %edi,0x20(%ebx)
  p->state = SLEEPING;
8010468b:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
80104692:	e8 29 fd ff ff       	call   801043c0 <sched>
  p->chan = 0;
80104697:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
}
8010469e:	8d 65 f4             	lea    -0xc(%ebp),%esp
801046a1:	5b                   	pop    %ebx
801046a2:	5e                   	pop    %esi
801046a3:	5f                   	pop    %edi
801046a4:	5d                   	pop    %ebp
801046a5:	c3                   	ret    
    panic("sleep without lk");
801046a6:	83 ec 0c             	sub    $0xc,%esp
801046a9:	68 4f 7e 10 80       	push   $0x80107e4f
801046ae:	e8 dd bc ff ff       	call   80100390 <panic>
    panic("sleep");
801046b3:	83 ec 0c             	sub    $0xc,%esp
801046b6:	68 49 7e 10 80       	push   $0x80107e49
801046bb:	e8 d0 bc ff ff       	call   80100390 <panic>

801046c0 <wait>:
{
801046c0:	55                   	push   %ebp
801046c1:	89 e5                	mov    %esp,%ebp
801046c3:	56                   	push   %esi
801046c4:	53                   	push   %ebx
  pushcli();
801046c5:	e8 26 04 00 00       	call   80104af0 <pushcli>
  c = mycpu();
801046ca:	e8 f1 f8 ff ff       	call   80103fc0 <mycpu>
  p = c->proc;
801046cf:	8b b0 ac 00 00 00    	mov    0xac(%eax),%esi
  popcli();
801046d5:	e8 56 04 00 00       	call   80104b30 <popcli>
  acquire(&ptable.lock);
801046da:	83 ec 0c             	sub    $0xc,%esp
801046dd:	68 20 5b 11 80       	push   $0x80115b20
801046e2:	e8 d9 04 00 00       	call   80104bc0 <acquire>
801046e7:	83 c4 10             	add    $0x10,%esp
    havekids = 0;
801046ea:	31 c0                	xor    %eax,%eax
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801046ec:	bb 54 5b 11 80       	mov    $0x80115b54,%ebx
801046f1:	eb 10                	jmp    80104703 <wait+0x43>
801046f3:	90                   	nop
801046f4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
801046f8:	83 c3 7c             	add    $0x7c,%ebx
801046fb:	81 fb 54 7a 11 80    	cmp    $0x80117a54,%ebx
80104701:	73 1b                	jae    8010471e <wait+0x5e>
      if(p->parent != curproc)
80104703:	39 73 14             	cmp    %esi,0x14(%ebx)
80104706:	75 f0                	jne    801046f8 <wait+0x38>
      if(p->state == ZOMBIE){
80104708:	83 7b 0c 05          	cmpl   $0x5,0xc(%ebx)
8010470c:	74 32                	je     80104740 <wait+0x80>
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
8010470e:	83 c3 7c             	add    $0x7c,%ebx
      havekids = 1;
80104711:	b8 01 00 00 00       	mov    $0x1,%eax
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104716:	81 fb 54 7a 11 80    	cmp    $0x80117a54,%ebx
8010471c:	72 e5                	jb     80104703 <wait+0x43>
    if(!havekids || curproc->killed){
8010471e:	85 c0                	test   %eax,%eax
80104720:	74 74                	je     80104796 <wait+0xd6>
80104722:	8b 46 24             	mov    0x24(%esi),%eax
80104725:	85 c0                	test   %eax,%eax
80104727:	75 6d                	jne    80104796 <wait+0xd6>
    sleep(curproc, &ptable.lock);  //DOC: wait-sleep
80104729:	83 ec 08             	sub    $0x8,%esp
8010472c:	68 20 5b 11 80       	push   $0x80115b20
80104731:	56                   	push   %esi
80104732:	e8 c9 fe ff ff       	call   80104600 <sleep>
    havekids = 0;
80104737:	83 c4 10             	add    $0x10,%esp
8010473a:	eb ae                	jmp    801046ea <wait+0x2a>
8010473c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
        kfree(p->kstack);
80104740:	83 ec 0c             	sub    $0xc,%esp
80104743:	ff 73 08             	pushl  0x8(%ebx)
        pid = p->pid;
80104746:	8b 73 10             	mov    0x10(%ebx),%esi
        kfree(p->kstack);
80104749:	e8 42 e4 ff ff       	call   80102b90 <kfree>
        freevm(p->pgdir);
8010474e:	5a                   	pop    %edx
8010474f:	ff 73 04             	pushl  0x4(%ebx)
        p->kstack = 0;
80104752:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
        freevm(p->pgdir);
80104759:	e8 02 2d 00 00       	call   80107460 <freevm>
        release(&ptable.lock);
8010475e:	c7 04 24 20 5b 11 80 	movl   $0x80115b20,(%esp)
        p->pid = 0;
80104765:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%ebx)
        p->parent = 0;
8010476c:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%ebx)
        p->name[0] = 0;
80104773:	c6 43 6c 00          	movb   $0x0,0x6c(%ebx)
        p->killed = 0;
80104777:	c7 43 24 00 00 00 00 	movl   $0x0,0x24(%ebx)
        p->state = UNUSED;
8010477e:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
        release(&ptable.lock);
80104785:	e8 f6 04 00 00       	call   80104c80 <release>
        return pid;
8010478a:	83 c4 10             	add    $0x10,%esp
}
8010478d:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104790:	89 f0                	mov    %esi,%eax
80104792:	5b                   	pop    %ebx
80104793:	5e                   	pop    %esi
80104794:	5d                   	pop    %ebp
80104795:	c3                   	ret    
      release(&ptable.lock);
80104796:	83 ec 0c             	sub    $0xc,%esp
      return -1;
80104799:	be ff ff ff ff       	mov    $0xffffffff,%esi
      release(&ptable.lock);
8010479e:	68 20 5b 11 80       	push   $0x80115b20
801047a3:	e8 d8 04 00 00       	call   80104c80 <release>
      return -1;
801047a8:	83 c4 10             	add    $0x10,%esp
801047ab:	eb e0                	jmp    8010478d <wait+0xcd>
801047ad:	8d 76 00             	lea    0x0(%esi),%esi

801047b0 <wakeup>:
}

// Wake up all processes sleeping on chan.
void
wakeup(void *chan)
{
801047b0:	55                   	push   %ebp
801047b1:	89 e5                	mov    %esp,%ebp
801047b3:	53                   	push   %ebx
801047b4:	83 ec 10             	sub    $0x10,%esp
801047b7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&ptable.lock);
801047ba:	68 20 5b 11 80       	push   $0x80115b20
801047bf:	e8 fc 03 00 00       	call   80104bc0 <acquire>
801047c4:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801047c7:	b8 54 5b 11 80       	mov    $0x80115b54,%eax
801047cc:	eb 0c                	jmp    801047da <wakeup+0x2a>
801047ce:	66 90                	xchg   %ax,%ax
801047d0:	83 c0 7c             	add    $0x7c,%eax
801047d3:	3d 54 7a 11 80       	cmp    $0x80117a54,%eax
801047d8:	73 1c                	jae    801047f6 <wakeup+0x46>
    if(p->state == SLEEPING && p->chan == chan)
801047da:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
801047de:	75 f0                	jne    801047d0 <wakeup+0x20>
801047e0:	3b 58 20             	cmp    0x20(%eax),%ebx
801047e3:	75 eb                	jne    801047d0 <wakeup+0x20>
      p->state = RUNNABLE;
801047e5:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801047ec:	83 c0 7c             	add    $0x7c,%eax
801047ef:	3d 54 7a 11 80       	cmp    $0x80117a54,%eax
801047f4:	72 e4                	jb     801047da <wakeup+0x2a>
  wakeup1(chan);
  release(&ptable.lock);
801047f6:	c7 45 08 20 5b 11 80 	movl   $0x80115b20,0x8(%ebp)
}
801047fd:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104800:	c9                   	leave  
  release(&ptable.lock);
80104801:	e9 7a 04 00 00       	jmp    80104c80 <release>
80104806:	8d 76 00             	lea    0x0(%esi),%esi
80104809:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80104810 <kill>:
// Kill the process with the given pid.
// Process won't exit until it returns
// to user space (see trap in trap.c).
int
kill(int pid)
{
80104810:	55                   	push   %ebp
80104811:	89 e5                	mov    %esp,%ebp
80104813:	53                   	push   %ebx
80104814:	83 ec 10             	sub    $0x10,%esp
80104817:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *p;

  acquire(&ptable.lock);
8010481a:	68 20 5b 11 80       	push   $0x80115b20
8010481f:	e8 9c 03 00 00       	call   80104bc0 <acquire>
80104824:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104827:	b8 54 5b 11 80       	mov    $0x80115b54,%eax
8010482c:	eb 0c                	jmp    8010483a <kill+0x2a>
8010482e:	66 90                	xchg   %ax,%ax
80104830:	83 c0 7c             	add    $0x7c,%eax
80104833:	3d 54 7a 11 80       	cmp    $0x80117a54,%eax
80104838:	73 36                	jae    80104870 <kill+0x60>
    if(p->pid == pid){
8010483a:	39 58 10             	cmp    %ebx,0x10(%eax)
8010483d:	75 f1                	jne    80104830 <kill+0x20>
      p->killed = 1;
      // Wake process from sleep if necessary.
      if(p->state == SLEEPING)
8010483f:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
      p->killed = 1;
80104843:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
      if(p->state == SLEEPING)
8010484a:	75 07                	jne    80104853 <kill+0x43>
        p->state = RUNNABLE;
8010484c:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
      release(&ptable.lock);
80104853:	83 ec 0c             	sub    $0xc,%esp
80104856:	68 20 5b 11 80       	push   $0x80115b20
8010485b:	e8 20 04 00 00       	call   80104c80 <release>
      return 0;
80104860:	83 c4 10             	add    $0x10,%esp
80104863:	31 c0                	xor    %eax,%eax
    }
  }
  release(&ptable.lock);
  return -1;
}
80104865:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104868:	c9                   	leave  
80104869:	c3                   	ret    
8010486a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  release(&ptable.lock);
80104870:	83 ec 0c             	sub    $0xc,%esp
80104873:	68 20 5b 11 80       	push   $0x80115b20
80104878:	e8 03 04 00 00       	call   80104c80 <release>
  return -1;
8010487d:	83 c4 10             	add    $0x10,%esp
80104880:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80104885:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104888:	c9                   	leave  
80104889:	c3                   	ret    
8010488a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80104890 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
80104890:	55                   	push   %ebp
80104891:	89 e5                	mov    %esp,%ebp
80104893:	57                   	push   %edi
80104894:	56                   	push   %esi
80104895:	53                   	push   %ebx
80104896:	8d 75 e8             	lea    -0x18(%ebp),%esi
  int i;
  struct proc *p;
  char *state;
  uint pc[10];

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104899:	bb 54 5b 11 80       	mov    $0x80115b54,%ebx
{
8010489e:	83 ec 3c             	sub    $0x3c,%esp
801048a1:	eb 24                	jmp    801048c7 <procdump+0x37>
801048a3:	90                   	nop
801048a4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(p->state == SLEEPING){
      getcallerpcs((uint*)p->context->ebp+2, pc);
      for(i=0; i<10 && pc[i] != 0; i++)
        cprintf(" %p", pc[i]);
    }
    cprintf("\n");
801048a8:	83 ec 0c             	sub    $0xc,%esp
801048ab:	68 db 81 10 80       	push   $0x801081db
801048b0:	e8 ab bd ff ff       	call   80100660 <cprintf>
801048b5:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801048b8:	83 c3 7c             	add    $0x7c,%ebx
801048bb:	81 fb 54 7a 11 80    	cmp    $0x80117a54,%ebx
801048c1:	0f 83 81 00 00 00    	jae    80104948 <procdump+0xb8>
    if(p->state == UNUSED)
801048c7:	8b 43 0c             	mov    0xc(%ebx),%eax
801048ca:	85 c0                	test   %eax,%eax
801048cc:	74 ea                	je     801048b8 <procdump+0x28>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
801048ce:	83 f8 05             	cmp    $0x5,%eax
      state = "???";
801048d1:	ba 60 7e 10 80       	mov    $0x80107e60,%edx
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
801048d6:	77 11                	ja     801048e9 <procdump+0x59>
801048d8:	8b 14 85 c0 7e 10 80 	mov    -0x7fef8140(,%eax,4),%edx
      state = "???";
801048df:	b8 60 7e 10 80       	mov    $0x80107e60,%eax
801048e4:	85 d2                	test   %edx,%edx
801048e6:	0f 44 d0             	cmove  %eax,%edx
    cprintf("%d %s %s", p->pid, state, p->name);
801048e9:	8d 43 6c             	lea    0x6c(%ebx),%eax
801048ec:	50                   	push   %eax
801048ed:	52                   	push   %edx
801048ee:	ff 73 10             	pushl  0x10(%ebx)
801048f1:	68 64 7e 10 80       	push   $0x80107e64
801048f6:	e8 65 bd ff ff       	call   80100660 <cprintf>
    if(p->state == SLEEPING){
801048fb:	83 c4 10             	add    $0x10,%esp
801048fe:	83 7b 0c 02          	cmpl   $0x2,0xc(%ebx)
80104902:	75 a4                	jne    801048a8 <procdump+0x18>
      getcallerpcs((uint*)p->context->ebp+2, pc);
80104904:	8d 45 c0             	lea    -0x40(%ebp),%eax
80104907:	83 ec 08             	sub    $0x8,%esp
8010490a:	8d 7d c0             	lea    -0x40(%ebp),%edi
8010490d:	50                   	push   %eax
8010490e:	8b 43 1c             	mov    0x1c(%ebx),%eax
80104911:	8b 40 0c             	mov    0xc(%eax),%eax
80104914:	83 c0 08             	add    $0x8,%eax
80104917:	50                   	push   %eax
80104918:	e8 83 01 00 00       	call   80104aa0 <getcallerpcs>
8010491d:	83 c4 10             	add    $0x10,%esp
      for(i=0; i<10 && pc[i] != 0; i++)
80104920:	8b 17                	mov    (%edi),%edx
80104922:	85 d2                	test   %edx,%edx
80104924:	74 82                	je     801048a8 <procdump+0x18>
        cprintf(" %p", pc[i]);
80104926:	83 ec 08             	sub    $0x8,%esp
80104929:	83 c7 04             	add    $0x4,%edi
8010492c:	52                   	push   %edx
8010492d:	68 c1 77 10 80       	push   $0x801077c1
80104932:	e8 29 bd ff ff       	call   80100660 <cprintf>
      for(i=0; i<10 && pc[i] != 0; i++)
80104937:	83 c4 10             	add    $0x10,%esp
8010493a:	39 fe                	cmp    %edi,%esi
8010493c:	75 e2                	jne    80104920 <procdump+0x90>
8010493e:	e9 65 ff ff ff       	jmp    801048a8 <procdump+0x18>
80104943:	90                   	nop
80104944:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  }
}
80104948:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010494b:	5b                   	pop    %ebx
8010494c:	5e                   	pop    %esi
8010494d:	5f                   	pop    %edi
8010494e:	5d                   	pop    %ebp
8010494f:	c3                   	ret    

80104950 <initsleeplock>:
#include "spinlock.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
80104950:	55                   	push   %ebp
80104951:	89 e5                	mov    %esp,%ebp
80104953:	53                   	push   %ebx
80104954:	83 ec 0c             	sub    $0xc,%esp
80104957:	8b 5d 08             	mov    0x8(%ebp),%ebx
  initlock(&lk->lk, "sleep lock");
8010495a:	68 d8 7e 10 80       	push   $0x80107ed8
8010495f:	8d 43 04             	lea    0x4(%ebx),%eax
80104962:	50                   	push   %eax
80104963:	e8 18 01 00 00       	call   80104a80 <initlock>
  lk->name = name;
80104968:	8b 45 0c             	mov    0xc(%ebp),%eax
  lk->locked = 0;
8010496b:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  lk->pid = 0;
}
80104971:	83 c4 10             	add    $0x10,%esp
  lk->pid = 0;
80104974:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
  lk->name = name;
8010497b:	89 43 38             	mov    %eax,0x38(%ebx)
}
8010497e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104981:	c9                   	leave  
80104982:	c3                   	ret    
80104983:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104989:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80104990 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
80104990:	55                   	push   %ebp
80104991:	89 e5                	mov    %esp,%ebp
80104993:	56                   	push   %esi
80104994:	53                   	push   %ebx
80104995:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&lk->lk);
80104998:	83 ec 0c             	sub    $0xc,%esp
8010499b:	8d 73 04             	lea    0x4(%ebx),%esi
8010499e:	56                   	push   %esi
8010499f:	e8 1c 02 00 00       	call   80104bc0 <acquire>
  while (lk->locked) {
801049a4:	8b 13                	mov    (%ebx),%edx
801049a6:	83 c4 10             	add    $0x10,%esp
801049a9:	85 d2                	test   %edx,%edx
801049ab:	74 16                	je     801049c3 <acquiresleep+0x33>
801049ad:	8d 76 00             	lea    0x0(%esi),%esi
    sleep(lk, &lk->lk);
801049b0:	83 ec 08             	sub    $0x8,%esp
801049b3:	56                   	push   %esi
801049b4:	53                   	push   %ebx
801049b5:	e8 46 fc ff ff       	call   80104600 <sleep>
  while (lk->locked) {
801049ba:	8b 03                	mov    (%ebx),%eax
801049bc:	83 c4 10             	add    $0x10,%esp
801049bf:	85 c0                	test   %eax,%eax
801049c1:	75 ed                	jne    801049b0 <acquiresleep+0x20>
  }
  lk->locked = 1;
801049c3:	c7 03 01 00 00 00    	movl   $0x1,(%ebx)
  lk->pid = myproc()->pid;
801049c9:	e8 92 f6 ff ff       	call   80104060 <myproc>
801049ce:	8b 40 10             	mov    0x10(%eax),%eax
801049d1:	89 43 3c             	mov    %eax,0x3c(%ebx)
  release(&lk->lk);
801049d4:	89 75 08             	mov    %esi,0x8(%ebp)
}
801049d7:	8d 65 f8             	lea    -0x8(%ebp),%esp
801049da:	5b                   	pop    %ebx
801049db:	5e                   	pop    %esi
801049dc:	5d                   	pop    %ebp
  release(&lk->lk);
801049dd:	e9 9e 02 00 00       	jmp    80104c80 <release>
801049e2:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801049e9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

801049f0 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
801049f0:	55                   	push   %ebp
801049f1:	89 e5                	mov    %esp,%ebp
801049f3:	56                   	push   %esi
801049f4:	53                   	push   %ebx
801049f5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&lk->lk);
801049f8:	83 ec 0c             	sub    $0xc,%esp
801049fb:	8d 73 04             	lea    0x4(%ebx),%esi
801049fe:	56                   	push   %esi
801049ff:	e8 bc 01 00 00       	call   80104bc0 <acquire>
  lk->locked = 0;
80104a04:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  lk->pid = 0;
80104a0a:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
  wakeup(lk);
80104a11:	89 1c 24             	mov    %ebx,(%esp)
80104a14:	e8 97 fd ff ff       	call   801047b0 <wakeup>
  release(&lk->lk);
80104a19:	89 75 08             	mov    %esi,0x8(%ebp)
80104a1c:	83 c4 10             	add    $0x10,%esp
}
80104a1f:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104a22:	5b                   	pop    %ebx
80104a23:	5e                   	pop    %esi
80104a24:	5d                   	pop    %ebp
  release(&lk->lk);
80104a25:	e9 56 02 00 00       	jmp    80104c80 <release>
80104a2a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80104a30 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
80104a30:	55                   	push   %ebp
80104a31:	89 e5                	mov    %esp,%ebp
80104a33:	57                   	push   %edi
80104a34:	56                   	push   %esi
80104a35:	53                   	push   %ebx
80104a36:	31 ff                	xor    %edi,%edi
80104a38:	83 ec 18             	sub    $0x18,%esp
80104a3b:	8b 5d 08             	mov    0x8(%ebp),%ebx
  int r;
  
  acquire(&lk->lk);
80104a3e:	8d 73 04             	lea    0x4(%ebx),%esi
80104a41:	56                   	push   %esi
80104a42:	e8 79 01 00 00       	call   80104bc0 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
80104a47:	8b 03                	mov    (%ebx),%eax
80104a49:	83 c4 10             	add    $0x10,%esp
80104a4c:	85 c0                	test   %eax,%eax
80104a4e:	74 13                	je     80104a63 <holdingsleep+0x33>
80104a50:	8b 5b 3c             	mov    0x3c(%ebx),%ebx
80104a53:	e8 08 f6 ff ff       	call   80104060 <myproc>
80104a58:	39 58 10             	cmp    %ebx,0x10(%eax)
80104a5b:	0f 94 c0             	sete   %al
80104a5e:	0f b6 c0             	movzbl %al,%eax
80104a61:	89 c7                	mov    %eax,%edi
  release(&lk->lk);
80104a63:	83 ec 0c             	sub    $0xc,%esp
80104a66:	56                   	push   %esi
80104a67:	e8 14 02 00 00       	call   80104c80 <release>
  return r;
}
80104a6c:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104a6f:	89 f8                	mov    %edi,%eax
80104a71:	5b                   	pop    %ebx
80104a72:	5e                   	pop    %esi
80104a73:	5f                   	pop    %edi
80104a74:	5d                   	pop    %ebp
80104a75:	c3                   	ret    
80104a76:	66 90                	xchg   %ax,%ax
80104a78:	66 90                	xchg   %ax,%ax
80104a7a:	66 90                	xchg   %ax,%ax
80104a7c:	66 90                	xchg   %ax,%ax
80104a7e:	66 90                	xchg   %ax,%ax

80104a80 <initlock>:
#include "proc.h"
#include "spinlock.h"

void
initlock(struct spinlock *lk, char *name)
{
80104a80:	55                   	push   %ebp
80104a81:	89 e5                	mov    %esp,%ebp
80104a83:	8b 45 08             	mov    0x8(%ebp),%eax
  lk->name = name;
80104a86:	8b 55 0c             	mov    0xc(%ebp),%edx
  lk->locked = 0;
80104a89:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  lk->name = name;
80104a8f:	89 50 04             	mov    %edx,0x4(%eax)
  lk->cpu = 0;
80104a92:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%eax)
}
80104a99:	5d                   	pop    %ebp
80104a9a:	c3                   	ret    
80104a9b:	90                   	nop
80104a9c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80104aa0 <getcallerpcs>:
}

// Record the current call stack in pcs[] by following the %ebp chain.
void
getcallerpcs(void *v, uint pcs[])
{
80104aa0:	55                   	push   %ebp
  uint *ebp;
  int i;

  ebp = (uint*)v - 2;
  for(i = 0; i < 10; i++){
80104aa1:	31 d2                	xor    %edx,%edx
{
80104aa3:	89 e5                	mov    %esp,%ebp
80104aa5:	53                   	push   %ebx
  ebp = (uint*)v - 2;
80104aa6:	8b 45 08             	mov    0x8(%ebp),%eax
{
80104aa9:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  ebp = (uint*)v - 2;
80104aac:	83 e8 08             	sub    $0x8,%eax
80104aaf:	90                   	nop
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
80104ab0:	8d 98 00 00 00 80    	lea    -0x80000000(%eax),%ebx
80104ab6:	81 fb fe ff ff 7f    	cmp    $0x7ffffffe,%ebx
80104abc:	77 1a                	ja     80104ad8 <getcallerpcs+0x38>
      break;
    pcs[i] = ebp[1];     // saved %eip
80104abe:	8b 58 04             	mov    0x4(%eax),%ebx
80104ac1:	89 1c 91             	mov    %ebx,(%ecx,%edx,4)
  for(i = 0; i < 10; i++){
80104ac4:	83 c2 01             	add    $0x1,%edx
    ebp = (uint*)ebp[0]; // saved %ebp
80104ac7:	8b 00                	mov    (%eax),%eax
  for(i = 0; i < 10; i++){
80104ac9:	83 fa 0a             	cmp    $0xa,%edx
80104acc:	75 e2                	jne    80104ab0 <getcallerpcs+0x10>
  }
  for(; i < 10; i++)
    pcs[i] = 0;
}
80104ace:	5b                   	pop    %ebx
80104acf:	5d                   	pop    %ebp
80104ad0:	c3                   	ret    
80104ad1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80104ad8:	8d 04 91             	lea    (%ecx,%edx,4),%eax
80104adb:	83 c1 28             	add    $0x28,%ecx
80104ade:	66 90                	xchg   %ax,%ax
    pcs[i] = 0;
80104ae0:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
80104ae6:	83 c0 04             	add    $0x4,%eax
  for(; i < 10; i++)
80104ae9:	39 c1                	cmp    %eax,%ecx
80104aeb:	75 f3                	jne    80104ae0 <getcallerpcs+0x40>
}
80104aed:	5b                   	pop    %ebx
80104aee:	5d                   	pop    %ebp
80104aef:	c3                   	ret    

80104af0 <pushcli>:
// it takes two popcli to undo two pushcli.  Also, if interrupts
// are off, then pushcli, popcli leaves them off.

void
pushcli(void)
{
80104af0:	55                   	push   %ebp
80104af1:	89 e5                	mov    %esp,%ebp
80104af3:	53                   	push   %ebx
80104af4:	83 ec 04             	sub    $0x4,%esp
80104af7:	9c                   	pushf  
80104af8:	5b                   	pop    %ebx
  asm volatile("cli");
80104af9:	fa                   	cli    
  int eflags;

  eflags = readeflags();
  cli();
  if(mycpu()->ncli == 0)
80104afa:	e8 c1 f4 ff ff       	call   80103fc0 <mycpu>
80104aff:	8b 80 a4 00 00 00    	mov    0xa4(%eax),%eax
80104b05:	85 c0                	test   %eax,%eax
80104b07:	75 11                	jne    80104b1a <pushcli+0x2a>
    mycpu()->intena = eflags & FL_IF;
80104b09:	81 e3 00 02 00 00    	and    $0x200,%ebx
80104b0f:	e8 ac f4 ff ff       	call   80103fc0 <mycpu>
80104b14:	89 98 a8 00 00 00    	mov    %ebx,0xa8(%eax)
  mycpu()->ncli += 1;
80104b1a:	e8 a1 f4 ff ff       	call   80103fc0 <mycpu>
80104b1f:	83 80 a4 00 00 00 01 	addl   $0x1,0xa4(%eax)
}
80104b26:	83 c4 04             	add    $0x4,%esp
80104b29:	5b                   	pop    %ebx
80104b2a:	5d                   	pop    %ebp
80104b2b:	c3                   	ret    
80104b2c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80104b30 <popcli>:

void
popcli(void)
{
80104b30:	55                   	push   %ebp
80104b31:	89 e5                	mov    %esp,%ebp
80104b33:	83 ec 08             	sub    $0x8,%esp
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80104b36:	9c                   	pushf  
80104b37:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80104b38:	f6 c4 02             	test   $0x2,%ah
80104b3b:	75 35                	jne    80104b72 <popcli+0x42>
    panic("popcli - interruptible");
  if(--mycpu()->ncli < 0)
80104b3d:	e8 7e f4 ff ff       	call   80103fc0 <mycpu>
80104b42:	83 a8 a4 00 00 00 01 	subl   $0x1,0xa4(%eax)
80104b49:	78 34                	js     80104b7f <popcli+0x4f>
    panic("popcli");
  if(mycpu()->ncli == 0 && mycpu()->intena)
80104b4b:	e8 70 f4 ff ff       	call   80103fc0 <mycpu>
80104b50:	8b 90 a4 00 00 00    	mov    0xa4(%eax),%edx
80104b56:	85 d2                	test   %edx,%edx
80104b58:	74 06                	je     80104b60 <popcli+0x30>
    sti();
}
80104b5a:	c9                   	leave  
80104b5b:	c3                   	ret    
80104b5c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  if(mycpu()->ncli == 0 && mycpu()->intena)
80104b60:	e8 5b f4 ff ff       	call   80103fc0 <mycpu>
80104b65:	8b 80 a8 00 00 00    	mov    0xa8(%eax),%eax
80104b6b:	85 c0                	test   %eax,%eax
80104b6d:	74 eb                	je     80104b5a <popcli+0x2a>
  asm volatile("sti");
80104b6f:	fb                   	sti    
}
80104b70:	c9                   	leave  
80104b71:	c3                   	ret    
    panic("popcli - interruptible");
80104b72:	83 ec 0c             	sub    $0xc,%esp
80104b75:	68 e3 7e 10 80       	push   $0x80107ee3
80104b7a:	e8 11 b8 ff ff       	call   80100390 <panic>
    panic("popcli");
80104b7f:	83 ec 0c             	sub    $0xc,%esp
80104b82:	68 fa 7e 10 80       	push   $0x80107efa
80104b87:	e8 04 b8 ff ff       	call   80100390 <panic>
80104b8c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80104b90 <holding>:
{
80104b90:	55                   	push   %ebp
80104b91:	89 e5                	mov    %esp,%ebp
80104b93:	56                   	push   %esi
80104b94:	53                   	push   %ebx
80104b95:	8b 75 08             	mov    0x8(%ebp),%esi
80104b98:	31 db                	xor    %ebx,%ebx
  pushcli();
80104b9a:	e8 51 ff ff ff       	call   80104af0 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
80104b9f:	8b 06                	mov    (%esi),%eax
80104ba1:	85 c0                	test   %eax,%eax
80104ba3:	74 10                	je     80104bb5 <holding+0x25>
80104ba5:	8b 5e 08             	mov    0x8(%esi),%ebx
80104ba8:	e8 13 f4 ff ff       	call   80103fc0 <mycpu>
80104bad:	39 c3                	cmp    %eax,%ebx
80104baf:	0f 94 c3             	sete   %bl
80104bb2:	0f b6 db             	movzbl %bl,%ebx
  popcli();
80104bb5:	e8 76 ff ff ff       	call   80104b30 <popcli>
}
80104bba:	89 d8                	mov    %ebx,%eax
80104bbc:	5b                   	pop    %ebx
80104bbd:	5e                   	pop    %esi
80104bbe:	5d                   	pop    %ebp
80104bbf:	c3                   	ret    

80104bc0 <acquire>:
{
80104bc0:	55                   	push   %ebp
80104bc1:	89 e5                	mov    %esp,%ebp
80104bc3:	56                   	push   %esi
80104bc4:	53                   	push   %ebx
  pushcli(); // disable interrupts to avoid deadlock.
80104bc5:	e8 26 ff ff ff       	call   80104af0 <pushcli>
  if(holding(lk))
80104bca:	8b 5d 08             	mov    0x8(%ebp),%ebx
80104bcd:	83 ec 0c             	sub    $0xc,%esp
80104bd0:	53                   	push   %ebx
80104bd1:	e8 ba ff ff ff       	call   80104b90 <holding>
80104bd6:	83 c4 10             	add    $0x10,%esp
80104bd9:	85 c0                	test   %eax,%eax
80104bdb:	0f 85 83 00 00 00    	jne    80104c64 <acquire+0xa4>
80104be1:	89 c6                	mov    %eax,%esi
  asm volatile("lock; xchgl %0, %1" :
80104be3:	ba 01 00 00 00       	mov    $0x1,%edx
80104be8:	eb 09                	jmp    80104bf3 <acquire+0x33>
80104bea:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104bf0:	8b 5d 08             	mov    0x8(%ebp),%ebx
80104bf3:	89 d0                	mov    %edx,%eax
80104bf5:	f0 87 03             	lock xchg %eax,(%ebx)
  while(xchg(&lk->locked, 1) != 0)
80104bf8:	85 c0                	test   %eax,%eax
80104bfa:	75 f4                	jne    80104bf0 <acquire+0x30>
  __sync_synchronize();
80104bfc:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
  lk->cpu = mycpu();
80104c01:	8b 5d 08             	mov    0x8(%ebp),%ebx
80104c04:	e8 b7 f3 ff ff       	call   80103fc0 <mycpu>
  getcallerpcs(&lk, lk->pcs);
80104c09:	8d 53 0c             	lea    0xc(%ebx),%edx
  lk->cpu = mycpu();
80104c0c:	89 43 08             	mov    %eax,0x8(%ebx)
  ebp = (uint*)v - 2;
80104c0f:	89 e8                	mov    %ebp,%eax
80104c11:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
80104c18:	8d 88 00 00 00 80    	lea    -0x80000000(%eax),%ecx
80104c1e:	81 f9 fe ff ff 7f    	cmp    $0x7ffffffe,%ecx
80104c24:	77 1a                	ja     80104c40 <acquire+0x80>
    pcs[i] = ebp[1];     // saved %eip
80104c26:	8b 48 04             	mov    0x4(%eax),%ecx
80104c29:	89 0c b2             	mov    %ecx,(%edx,%esi,4)
  for(i = 0; i < 10; i++){
80104c2c:	83 c6 01             	add    $0x1,%esi
    ebp = (uint*)ebp[0]; // saved %ebp
80104c2f:	8b 00                	mov    (%eax),%eax
  for(i = 0; i < 10; i++){
80104c31:	83 fe 0a             	cmp    $0xa,%esi
80104c34:	75 e2                	jne    80104c18 <acquire+0x58>
}
80104c36:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104c39:	5b                   	pop    %ebx
80104c3a:	5e                   	pop    %esi
80104c3b:	5d                   	pop    %ebp
80104c3c:	c3                   	ret    
80104c3d:	8d 76 00             	lea    0x0(%esi),%esi
80104c40:	8d 04 b2             	lea    (%edx,%esi,4),%eax
80104c43:	83 c2 28             	add    $0x28,%edx
80104c46:	8d 76 00             	lea    0x0(%esi),%esi
80104c49:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    pcs[i] = 0;
80104c50:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
80104c56:	83 c0 04             	add    $0x4,%eax
  for(; i < 10; i++)
80104c59:	39 d0                	cmp    %edx,%eax
80104c5b:	75 f3                	jne    80104c50 <acquire+0x90>
}
80104c5d:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104c60:	5b                   	pop    %ebx
80104c61:	5e                   	pop    %esi
80104c62:	5d                   	pop    %ebp
80104c63:	c3                   	ret    
    panic("acquire");
80104c64:	83 ec 0c             	sub    $0xc,%esp
80104c67:	68 01 7f 10 80       	push   $0x80107f01
80104c6c:	e8 1f b7 ff ff       	call   80100390 <panic>
80104c71:	eb 0d                	jmp    80104c80 <release>
80104c73:	90                   	nop
80104c74:	90                   	nop
80104c75:	90                   	nop
80104c76:	90                   	nop
80104c77:	90                   	nop
80104c78:	90                   	nop
80104c79:	90                   	nop
80104c7a:	90                   	nop
80104c7b:	90                   	nop
80104c7c:	90                   	nop
80104c7d:	90                   	nop
80104c7e:	90                   	nop
80104c7f:	90                   	nop

80104c80 <release>:
{
80104c80:	55                   	push   %ebp
80104c81:	89 e5                	mov    %esp,%ebp
80104c83:	53                   	push   %ebx
80104c84:	83 ec 10             	sub    $0x10,%esp
80104c87:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holding(lk))
80104c8a:	53                   	push   %ebx
80104c8b:	e8 00 ff ff ff       	call   80104b90 <holding>
80104c90:	83 c4 10             	add    $0x10,%esp
80104c93:	85 c0                	test   %eax,%eax
80104c95:	74 22                	je     80104cb9 <release+0x39>
  lk->pcs[0] = 0;
80104c97:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
  lk->cpu = 0;
80104c9e:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
  __sync_synchronize();
80104ca5:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
  asm volatile("movl $0, %0" : "+m" (lk->locked) : );
80104caa:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
}
80104cb0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104cb3:	c9                   	leave  
  popcli();
80104cb4:	e9 77 fe ff ff       	jmp    80104b30 <popcli>
    panic("release");
80104cb9:	83 ec 0c             	sub    $0xc,%esp
80104cbc:	68 09 7f 10 80       	push   $0x80107f09
80104cc1:	e8 ca b6 ff ff       	call   80100390 <panic>
80104cc6:	66 90                	xchg   %ax,%ax
80104cc8:	66 90                	xchg   %ax,%ax
80104cca:	66 90                	xchg   %ax,%ax
80104ccc:	66 90                	xchg   %ax,%ax
80104cce:	66 90                	xchg   %ax,%ax

80104cd0 <memset>:
#include "types.h"
#include "x86.h"

void*
memset(void *dst, int c, uint n)
{
80104cd0:	55                   	push   %ebp
80104cd1:	89 e5                	mov    %esp,%ebp
80104cd3:	57                   	push   %edi
80104cd4:	53                   	push   %ebx
80104cd5:	8b 55 08             	mov    0x8(%ebp),%edx
80104cd8:	8b 4d 10             	mov    0x10(%ebp),%ecx
  if ((int)dst%4 == 0 && n%4 == 0){
80104cdb:	f6 c2 03             	test   $0x3,%dl
80104cde:	75 05                	jne    80104ce5 <memset+0x15>
80104ce0:	f6 c1 03             	test   $0x3,%cl
80104ce3:	74 13                	je     80104cf8 <memset+0x28>
  asm volatile("cld; rep stosb" :
80104ce5:	89 d7                	mov    %edx,%edi
80104ce7:	8b 45 0c             	mov    0xc(%ebp),%eax
80104cea:	fc                   	cld    
80104ceb:	f3 aa                	rep stos %al,%es:(%edi)
    c &= 0xFF;
    stosl(dst, (c<<24)|(c<<16)|(c<<8)|c, n/4);
  } else
    stosb(dst, c, n);
  return dst;
}
80104ced:	5b                   	pop    %ebx
80104cee:	89 d0                	mov    %edx,%eax
80104cf0:	5f                   	pop    %edi
80104cf1:	5d                   	pop    %ebp
80104cf2:	c3                   	ret    
80104cf3:	90                   	nop
80104cf4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    c &= 0xFF;
80104cf8:	0f b6 7d 0c          	movzbl 0xc(%ebp),%edi
    stosl(dst, (c<<24)|(c<<16)|(c<<8)|c, n/4);
80104cfc:	c1 e9 02             	shr    $0x2,%ecx
80104cff:	89 f8                	mov    %edi,%eax
80104d01:	89 fb                	mov    %edi,%ebx
80104d03:	c1 e0 18             	shl    $0x18,%eax
80104d06:	c1 e3 10             	shl    $0x10,%ebx
80104d09:	09 d8                	or     %ebx,%eax
80104d0b:	09 f8                	or     %edi,%eax
80104d0d:	c1 e7 08             	shl    $0x8,%edi
80104d10:	09 f8                	or     %edi,%eax
  asm volatile("cld; rep stosl" :
80104d12:	89 d7                	mov    %edx,%edi
80104d14:	fc                   	cld    
80104d15:	f3 ab                	rep stos %eax,%es:(%edi)
}
80104d17:	5b                   	pop    %ebx
80104d18:	89 d0                	mov    %edx,%eax
80104d1a:	5f                   	pop    %edi
80104d1b:	5d                   	pop    %ebp
80104d1c:	c3                   	ret    
80104d1d:	8d 76 00             	lea    0x0(%esi),%esi

80104d20 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
80104d20:	55                   	push   %ebp
80104d21:	89 e5                	mov    %esp,%ebp
80104d23:	57                   	push   %edi
80104d24:	56                   	push   %esi
80104d25:	53                   	push   %ebx
80104d26:	8b 5d 10             	mov    0x10(%ebp),%ebx
80104d29:	8b 75 08             	mov    0x8(%ebp),%esi
80104d2c:	8b 7d 0c             	mov    0xc(%ebp),%edi
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
80104d2f:	85 db                	test   %ebx,%ebx
80104d31:	74 29                	je     80104d5c <memcmp+0x3c>
    if(*s1 != *s2)
80104d33:	0f b6 16             	movzbl (%esi),%edx
80104d36:	0f b6 0f             	movzbl (%edi),%ecx
80104d39:	38 d1                	cmp    %dl,%cl
80104d3b:	75 2b                	jne    80104d68 <memcmp+0x48>
80104d3d:	b8 01 00 00 00       	mov    $0x1,%eax
80104d42:	eb 14                	jmp    80104d58 <memcmp+0x38>
80104d44:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80104d48:	0f b6 14 06          	movzbl (%esi,%eax,1),%edx
80104d4c:	83 c0 01             	add    $0x1,%eax
80104d4f:	0f b6 4c 07 ff       	movzbl -0x1(%edi,%eax,1),%ecx
80104d54:	38 ca                	cmp    %cl,%dl
80104d56:	75 10                	jne    80104d68 <memcmp+0x48>
  while(n-- > 0){
80104d58:	39 d8                	cmp    %ebx,%eax
80104d5a:	75 ec                	jne    80104d48 <memcmp+0x28>
      return *s1 - *s2;
    s1++, s2++;
  }

  return 0;
}
80104d5c:	5b                   	pop    %ebx
  return 0;
80104d5d:	31 c0                	xor    %eax,%eax
}
80104d5f:	5e                   	pop    %esi
80104d60:	5f                   	pop    %edi
80104d61:	5d                   	pop    %ebp
80104d62:	c3                   	ret    
80104d63:	90                   	nop
80104d64:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      return *s1 - *s2;
80104d68:	0f b6 c2             	movzbl %dl,%eax
}
80104d6b:	5b                   	pop    %ebx
      return *s1 - *s2;
80104d6c:	29 c8                	sub    %ecx,%eax
}
80104d6e:	5e                   	pop    %esi
80104d6f:	5f                   	pop    %edi
80104d70:	5d                   	pop    %ebp
80104d71:	c3                   	ret    
80104d72:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80104d79:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80104d80 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
80104d80:	55                   	push   %ebp
80104d81:	89 e5                	mov    %esp,%ebp
80104d83:	56                   	push   %esi
80104d84:	53                   	push   %ebx
80104d85:	8b 45 08             	mov    0x8(%ebp),%eax
80104d88:	8b 5d 0c             	mov    0xc(%ebp),%ebx
80104d8b:	8b 75 10             	mov    0x10(%ebp),%esi
  const char *s;
  char *d;

  s = src;
  d = dst;
  if(s < d && s + n > d){
80104d8e:	39 c3                	cmp    %eax,%ebx
80104d90:	73 26                	jae    80104db8 <memmove+0x38>
80104d92:	8d 0c 33             	lea    (%ebx,%esi,1),%ecx
80104d95:	39 c8                	cmp    %ecx,%eax
80104d97:	73 1f                	jae    80104db8 <memmove+0x38>
    s += n;
    d += n;
    while(n-- > 0)
80104d99:	85 f6                	test   %esi,%esi
80104d9b:	8d 56 ff             	lea    -0x1(%esi),%edx
80104d9e:	74 0f                	je     80104daf <memmove+0x2f>
      *--d = *--s;
80104da0:	0f b6 0c 13          	movzbl (%ebx,%edx,1),%ecx
80104da4:	88 0c 10             	mov    %cl,(%eax,%edx,1)
    while(n-- > 0)
80104da7:	83 ea 01             	sub    $0x1,%edx
80104daa:	83 fa ff             	cmp    $0xffffffff,%edx
80104dad:	75 f1                	jne    80104da0 <memmove+0x20>
  } else
    while(n-- > 0)
      *d++ = *s++;

  return dst;
}
80104daf:	5b                   	pop    %ebx
80104db0:	5e                   	pop    %esi
80104db1:	5d                   	pop    %ebp
80104db2:	c3                   	ret    
80104db3:	90                   	nop
80104db4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    while(n-- > 0)
80104db8:	31 d2                	xor    %edx,%edx
80104dba:	85 f6                	test   %esi,%esi
80104dbc:	74 f1                	je     80104daf <memmove+0x2f>
80104dbe:	66 90                	xchg   %ax,%ax
      *d++ = *s++;
80104dc0:	0f b6 0c 13          	movzbl (%ebx,%edx,1),%ecx
80104dc4:	88 0c 10             	mov    %cl,(%eax,%edx,1)
80104dc7:	83 c2 01             	add    $0x1,%edx
    while(n-- > 0)
80104dca:	39 d6                	cmp    %edx,%esi
80104dcc:	75 f2                	jne    80104dc0 <memmove+0x40>
}
80104dce:	5b                   	pop    %ebx
80104dcf:	5e                   	pop    %esi
80104dd0:	5d                   	pop    %ebp
80104dd1:	c3                   	ret    
80104dd2:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80104dd9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80104de0 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
80104de0:	55                   	push   %ebp
80104de1:	89 e5                	mov    %esp,%ebp
  return memmove(dst, src, n);
}
80104de3:	5d                   	pop    %ebp
  return memmove(dst, src, n);
80104de4:	eb 9a                	jmp    80104d80 <memmove>
80104de6:	8d 76 00             	lea    0x0(%esi),%esi
80104de9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80104df0 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
80104df0:	55                   	push   %ebp
80104df1:	89 e5                	mov    %esp,%ebp
80104df3:	57                   	push   %edi
80104df4:	56                   	push   %esi
80104df5:	8b 7d 10             	mov    0x10(%ebp),%edi
80104df8:	53                   	push   %ebx
80104df9:	8b 4d 08             	mov    0x8(%ebp),%ecx
80104dfc:	8b 75 0c             	mov    0xc(%ebp),%esi
  while(n > 0 && *p && *p == *q)
80104dff:	85 ff                	test   %edi,%edi
80104e01:	74 2f                	je     80104e32 <strncmp+0x42>
80104e03:	0f b6 01             	movzbl (%ecx),%eax
80104e06:	0f b6 1e             	movzbl (%esi),%ebx
80104e09:	84 c0                	test   %al,%al
80104e0b:	74 37                	je     80104e44 <strncmp+0x54>
80104e0d:	38 c3                	cmp    %al,%bl
80104e0f:	75 33                	jne    80104e44 <strncmp+0x54>
80104e11:	01 f7                	add    %esi,%edi
80104e13:	eb 13                	jmp    80104e28 <strncmp+0x38>
80104e15:	8d 76 00             	lea    0x0(%esi),%esi
80104e18:	0f b6 01             	movzbl (%ecx),%eax
80104e1b:	84 c0                	test   %al,%al
80104e1d:	74 21                	je     80104e40 <strncmp+0x50>
80104e1f:	0f b6 1a             	movzbl (%edx),%ebx
80104e22:	89 d6                	mov    %edx,%esi
80104e24:	38 d8                	cmp    %bl,%al
80104e26:	75 1c                	jne    80104e44 <strncmp+0x54>
    n--, p++, q++;
80104e28:	8d 56 01             	lea    0x1(%esi),%edx
80104e2b:	83 c1 01             	add    $0x1,%ecx
  while(n > 0 && *p && *p == *q)
80104e2e:	39 fa                	cmp    %edi,%edx
80104e30:	75 e6                	jne    80104e18 <strncmp+0x28>
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
}
80104e32:	5b                   	pop    %ebx
    return 0;
80104e33:	31 c0                	xor    %eax,%eax
}
80104e35:	5e                   	pop    %esi
80104e36:	5f                   	pop    %edi
80104e37:	5d                   	pop    %ebp
80104e38:	c3                   	ret    
80104e39:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80104e40:	0f b6 5e 01          	movzbl 0x1(%esi),%ebx
  return (uchar)*p - (uchar)*q;
80104e44:	29 d8                	sub    %ebx,%eax
}
80104e46:	5b                   	pop    %ebx
80104e47:	5e                   	pop    %esi
80104e48:	5f                   	pop    %edi
80104e49:	5d                   	pop    %ebp
80104e4a:	c3                   	ret    
80104e4b:	90                   	nop
80104e4c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80104e50 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
80104e50:	55                   	push   %ebp
80104e51:	89 e5                	mov    %esp,%ebp
80104e53:	56                   	push   %esi
80104e54:	53                   	push   %ebx
80104e55:	8b 45 08             	mov    0x8(%ebp),%eax
80104e58:	8b 5d 0c             	mov    0xc(%ebp),%ebx
80104e5b:	8b 4d 10             	mov    0x10(%ebp),%ecx
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
80104e5e:	89 c2                	mov    %eax,%edx
80104e60:	eb 19                	jmp    80104e7b <strncpy+0x2b>
80104e62:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104e68:	83 c3 01             	add    $0x1,%ebx
80104e6b:	0f b6 4b ff          	movzbl -0x1(%ebx),%ecx
80104e6f:	83 c2 01             	add    $0x1,%edx
80104e72:	84 c9                	test   %cl,%cl
80104e74:	88 4a ff             	mov    %cl,-0x1(%edx)
80104e77:	74 09                	je     80104e82 <strncpy+0x32>
80104e79:	89 f1                	mov    %esi,%ecx
80104e7b:	85 c9                	test   %ecx,%ecx
80104e7d:	8d 71 ff             	lea    -0x1(%ecx),%esi
80104e80:	7f e6                	jg     80104e68 <strncpy+0x18>
    ;
  while(n-- > 0)
80104e82:	31 c9                	xor    %ecx,%ecx
80104e84:	85 f6                	test   %esi,%esi
80104e86:	7e 17                	jle    80104e9f <strncpy+0x4f>
80104e88:	90                   	nop
80104e89:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    *s++ = 0;
80104e90:	c6 04 0a 00          	movb   $0x0,(%edx,%ecx,1)
80104e94:	89 f3                	mov    %esi,%ebx
80104e96:	83 c1 01             	add    $0x1,%ecx
80104e99:	29 cb                	sub    %ecx,%ebx
  while(n-- > 0)
80104e9b:	85 db                	test   %ebx,%ebx
80104e9d:	7f f1                	jg     80104e90 <strncpy+0x40>
  return os;
}
80104e9f:	5b                   	pop    %ebx
80104ea0:	5e                   	pop    %esi
80104ea1:	5d                   	pop    %ebp
80104ea2:	c3                   	ret    
80104ea3:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104ea9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80104eb0 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
80104eb0:	55                   	push   %ebp
80104eb1:	89 e5                	mov    %esp,%ebp
80104eb3:	56                   	push   %esi
80104eb4:	53                   	push   %ebx
80104eb5:	8b 4d 10             	mov    0x10(%ebp),%ecx
80104eb8:	8b 45 08             	mov    0x8(%ebp),%eax
80104ebb:	8b 55 0c             	mov    0xc(%ebp),%edx
  char *os;

  os = s;
  if(n <= 0)
80104ebe:	85 c9                	test   %ecx,%ecx
80104ec0:	7e 26                	jle    80104ee8 <safestrcpy+0x38>
80104ec2:	8d 74 0a ff          	lea    -0x1(%edx,%ecx,1),%esi
80104ec6:	89 c1                	mov    %eax,%ecx
80104ec8:	eb 17                	jmp    80104ee1 <safestrcpy+0x31>
80104eca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
80104ed0:	83 c2 01             	add    $0x1,%edx
80104ed3:	0f b6 5a ff          	movzbl -0x1(%edx),%ebx
80104ed7:	83 c1 01             	add    $0x1,%ecx
80104eda:	84 db                	test   %bl,%bl
80104edc:	88 59 ff             	mov    %bl,-0x1(%ecx)
80104edf:	74 04                	je     80104ee5 <safestrcpy+0x35>
80104ee1:	39 f2                	cmp    %esi,%edx
80104ee3:	75 eb                	jne    80104ed0 <safestrcpy+0x20>
    ;
  *s = 0;
80104ee5:	c6 01 00             	movb   $0x0,(%ecx)
  return os;
}
80104ee8:	5b                   	pop    %ebx
80104ee9:	5e                   	pop    %esi
80104eea:	5d                   	pop    %ebp
80104eeb:	c3                   	ret    
80104eec:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80104ef0 <strlen>:

int
strlen(const char *s)
{
80104ef0:	55                   	push   %ebp
  int n;

  for(n = 0; s[n]; n++)
80104ef1:	31 c0                	xor    %eax,%eax
{
80104ef3:	89 e5                	mov    %esp,%ebp
80104ef5:	8b 55 08             	mov    0x8(%ebp),%edx
  for(n = 0; s[n]; n++)
80104ef8:	80 3a 00             	cmpb   $0x0,(%edx)
80104efb:	74 0c                	je     80104f09 <strlen+0x19>
80104efd:	8d 76 00             	lea    0x0(%esi),%esi
80104f00:	83 c0 01             	add    $0x1,%eax
80104f03:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
80104f07:	75 f7                	jne    80104f00 <strlen+0x10>
    ;
  return n;
}
80104f09:	5d                   	pop    %ebp
80104f0a:	c3                   	ret    

80104f0b <swtch>:
# a struct context, and save its address in *old.
# Switch stacks to new and pop previously-saved registers.

.globl swtch
swtch:
  movl 4(%esp), %eax
80104f0b:	8b 44 24 04          	mov    0x4(%esp),%eax
  movl 8(%esp), %edx
80104f0f:	8b 54 24 08          	mov    0x8(%esp),%edx

  # Save old callee-saved registers
  pushl %ebp
80104f13:	55                   	push   %ebp
  pushl %ebx
80104f14:	53                   	push   %ebx
  pushl %esi
80104f15:	56                   	push   %esi
  pushl %edi
80104f16:	57                   	push   %edi

  # Switch stacks
  movl %esp, (%eax)
80104f17:	89 20                	mov    %esp,(%eax)
  movl %edx, %esp
80104f19:	89 d4                	mov    %edx,%esp

  # Load new callee-saved registers
  popl %edi
80104f1b:	5f                   	pop    %edi
  popl %esi
80104f1c:	5e                   	pop    %esi
  popl %ebx
80104f1d:	5b                   	pop    %ebx
  popl %ebp
80104f1e:	5d                   	pop    %ebp
  ret
80104f1f:	c3                   	ret    

80104f20 <fetchint>:
// to a saved program counter, and then the first argument.

// Fetch the int at addr from the current process.
int
fetchint(uint addr, int *ip)
{
80104f20:	55                   	push   %ebp
80104f21:	89 e5                	mov    %esp,%ebp
80104f23:	53                   	push   %ebx
80104f24:	83 ec 04             	sub    $0x4,%esp
80104f27:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *curproc = myproc();
80104f2a:	e8 31 f1 ff ff       	call   80104060 <myproc>

  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104f2f:	8b 00                	mov    (%eax),%eax
80104f31:	39 d8                	cmp    %ebx,%eax
80104f33:	76 1b                	jbe    80104f50 <fetchint+0x30>
80104f35:	8d 53 04             	lea    0x4(%ebx),%edx
80104f38:	39 d0                	cmp    %edx,%eax
80104f3a:	72 14                	jb     80104f50 <fetchint+0x30>
    return -1;
  *ip = *(int*)(addr);
80104f3c:	8b 45 0c             	mov    0xc(%ebp),%eax
80104f3f:	8b 13                	mov    (%ebx),%edx
80104f41:	89 10                	mov    %edx,(%eax)
  return 0;
80104f43:	31 c0                	xor    %eax,%eax
}
80104f45:	83 c4 04             	add    $0x4,%esp
80104f48:	5b                   	pop    %ebx
80104f49:	5d                   	pop    %ebp
80104f4a:	c3                   	ret    
80104f4b:	90                   	nop
80104f4c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80104f50:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104f55:	eb ee                	jmp    80104f45 <fetchint+0x25>
80104f57:	89 f6                	mov    %esi,%esi
80104f59:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80104f60 <fetchstr>:
// Fetch the nul-terminated string at addr from the current process.
// Doesn't actually copy the string - just sets *pp to point at it.
// Returns length of string, not including nul.
int
fetchstr(uint addr, char **pp)
{
80104f60:	55                   	push   %ebp
80104f61:	89 e5                	mov    %esp,%ebp
80104f63:	53                   	push   %ebx
80104f64:	83 ec 04             	sub    $0x4,%esp
80104f67:	8b 5d 08             	mov    0x8(%ebp),%ebx
  char *s, *ep;
  struct proc *curproc = myproc();
80104f6a:	e8 f1 f0 ff ff       	call   80104060 <myproc>

  if(addr >= curproc->sz)
80104f6f:	39 18                	cmp    %ebx,(%eax)
80104f71:	76 29                	jbe    80104f9c <fetchstr+0x3c>
    return -1;
  *pp = (char*)addr;
80104f73:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80104f76:	89 da                	mov    %ebx,%edx
80104f78:	89 19                	mov    %ebx,(%ecx)
  ep = (char*)curproc->sz;
80104f7a:	8b 00                	mov    (%eax),%eax
  for(s = *pp; s < ep; s++){
80104f7c:	39 c3                	cmp    %eax,%ebx
80104f7e:	73 1c                	jae    80104f9c <fetchstr+0x3c>
    if(*s == 0)
80104f80:	80 3b 00             	cmpb   $0x0,(%ebx)
80104f83:	75 10                	jne    80104f95 <fetchstr+0x35>
80104f85:	eb 39                	jmp    80104fc0 <fetchstr+0x60>
80104f87:	89 f6                	mov    %esi,%esi
80104f89:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
80104f90:	80 3a 00             	cmpb   $0x0,(%edx)
80104f93:	74 1b                	je     80104fb0 <fetchstr+0x50>
  for(s = *pp; s < ep; s++){
80104f95:	83 c2 01             	add    $0x1,%edx
80104f98:	39 d0                	cmp    %edx,%eax
80104f9a:	77 f4                	ja     80104f90 <fetchstr+0x30>
    return -1;
80104f9c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
      return s - *pp;
  }
  return -1;
}
80104fa1:	83 c4 04             	add    $0x4,%esp
80104fa4:	5b                   	pop    %ebx
80104fa5:	5d                   	pop    %ebp
80104fa6:	c3                   	ret    
80104fa7:	89 f6                	mov    %esi,%esi
80104fa9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
80104fb0:	83 c4 04             	add    $0x4,%esp
80104fb3:	89 d0                	mov    %edx,%eax
80104fb5:	29 d8                	sub    %ebx,%eax
80104fb7:	5b                   	pop    %ebx
80104fb8:	5d                   	pop    %ebp
80104fb9:	c3                   	ret    
80104fba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    if(*s == 0)
80104fc0:	31 c0                	xor    %eax,%eax
      return s - *pp;
80104fc2:	eb dd                	jmp    80104fa1 <fetchstr+0x41>
80104fc4:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104fca:	8d bf 00 00 00 00    	lea    0x0(%edi),%edi

80104fd0 <argint>:

// Fetch the nth 32-bit system call argument.
int
argint(int n, int *ip)
{
80104fd0:	55                   	push   %ebp
80104fd1:	89 e5                	mov    %esp,%ebp
80104fd3:	56                   	push   %esi
80104fd4:	53                   	push   %ebx
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104fd5:	e8 86 f0 ff ff       	call   80104060 <myproc>
80104fda:	8b 40 18             	mov    0x18(%eax),%eax
80104fdd:	8b 55 08             	mov    0x8(%ebp),%edx
80104fe0:	8b 40 44             	mov    0x44(%eax),%eax
80104fe3:	8d 1c 90             	lea    (%eax,%edx,4),%ebx
  struct proc *curproc = myproc();
80104fe6:	e8 75 f0 ff ff       	call   80104060 <myproc>
  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104feb:	8b 00                	mov    (%eax),%eax
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104fed:	8d 73 04             	lea    0x4(%ebx),%esi
  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104ff0:	39 c6                	cmp    %eax,%esi
80104ff2:	73 1c                	jae    80105010 <argint+0x40>
80104ff4:	8d 53 08             	lea    0x8(%ebx),%edx
80104ff7:	39 d0                	cmp    %edx,%eax
80104ff9:	72 15                	jb     80105010 <argint+0x40>
  *ip = *(int*)(addr);
80104ffb:	8b 45 0c             	mov    0xc(%ebp),%eax
80104ffe:	8b 53 04             	mov    0x4(%ebx),%edx
80105001:	89 10                	mov    %edx,(%eax)
  return 0;
80105003:	31 c0                	xor    %eax,%eax
}
80105005:	5b                   	pop    %ebx
80105006:	5e                   	pop    %esi
80105007:	5d                   	pop    %ebp
80105008:	c3                   	ret    
80105009:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80105010:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80105015:	eb ee                	jmp    80105005 <argint+0x35>
80105017:	89 f6                	mov    %esi,%esi
80105019:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80105020 <argptr>:
// Fetch the nth word-sized system call argument as a pointer
// to a block of memory of size bytes.  Check that the pointer
// lies within the process address space.
int
argptr(int n, char **pp, int size)
{
80105020:	55                   	push   %ebp
80105021:	89 e5                	mov    %esp,%ebp
80105023:	56                   	push   %esi
80105024:	53                   	push   %ebx
80105025:	83 ec 10             	sub    $0x10,%esp
80105028:	8b 5d 10             	mov    0x10(%ebp),%ebx
  int i;
  struct proc *curproc = myproc();
8010502b:	e8 30 f0 ff ff       	call   80104060 <myproc>
80105030:	89 c6                	mov    %eax,%esi
 
  if(argint(n, &i) < 0)
80105032:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105035:	83 ec 08             	sub    $0x8,%esp
80105038:	50                   	push   %eax
80105039:	ff 75 08             	pushl  0x8(%ebp)
8010503c:	e8 8f ff ff ff       	call   80104fd0 <argint>
    return -1;
  if(size < 0 || (uint)i >= curproc->sz || (uint)i+size > curproc->sz)
80105041:	83 c4 10             	add    $0x10,%esp
80105044:	85 c0                	test   %eax,%eax
80105046:	78 28                	js     80105070 <argptr+0x50>
80105048:	85 db                	test   %ebx,%ebx
8010504a:	78 24                	js     80105070 <argptr+0x50>
8010504c:	8b 16                	mov    (%esi),%edx
8010504e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105051:	39 c2                	cmp    %eax,%edx
80105053:	76 1b                	jbe    80105070 <argptr+0x50>
80105055:	01 c3                	add    %eax,%ebx
80105057:	39 da                	cmp    %ebx,%edx
80105059:	72 15                	jb     80105070 <argptr+0x50>
    return -1;
  *pp = (char*)i;
8010505b:	8b 55 0c             	mov    0xc(%ebp),%edx
8010505e:	89 02                	mov    %eax,(%edx)
  return 0;
80105060:	31 c0                	xor    %eax,%eax
}
80105062:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105065:	5b                   	pop    %ebx
80105066:	5e                   	pop    %esi
80105067:	5d                   	pop    %ebp
80105068:	c3                   	ret    
80105069:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80105070:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105075:	eb eb                	jmp    80105062 <argptr+0x42>
80105077:	89 f6                	mov    %esi,%esi
80105079:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80105080 <argstr>:
// Check that the pointer is valid and the string is nul-terminated.
// (There is no shared writable memory, so the string can't change
// between this check and being used by the kernel.)
int
argstr(int n, char **pp)
{
80105080:	55                   	push   %ebp
80105081:	89 e5                	mov    %esp,%ebp
80105083:	83 ec 20             	sub    $0x20,%esp
  int addr;
  if(argint(n, &addr) < 0)
80105086:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105089:	50                   	push   %eax
8010508a:	ff 75 08             	pushl  0x8(%ebp)
8010508d:	e8 3e ff ff ff       	call   80104fd0 <argint>
80105092:	83 c4 10             	add    $0x10,%esp
80105095:	85 c0                	test   %eax,%eax
80105097:	78 17                	js     801050b0 <argstr+0x30>
    return -1;
  return fetchstr(addr, pp);
80105099:	83 ec 08             	sub    $0x8,%esp
8010509c:	ff 75 0c             	pushl  0xc(%ebp)
8010509f:	ff 75 f4             	pushl  -0xc(%ebp)
801050a2:	e8 b9 fe ff ff       	call   80104f60 <fetchstr>
801050a7:	83 c4 10             	add    $0x10,%esp
}
801050aa:	c9                   	leave  
801050ab:	c3                   	ret    
801050ac:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    return -1;
801050b0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801050b5:	c9                   	leave  
801050b6:	c3                   	ret    
801050b7:	89 f6                	mov    %esi,%esi
801050b9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

801050c0 <syscall>:
[SYS_cpcow]   sys_cpcow,
};

void
syscall(void)
{
801050c0:	55                   	push   %ebp
801050c1:	89 e5                	mov    %esp,%ebp
801050c3:	53                   	push   %ebx
801050c4:	83 ec 04             	sub    $0x4,%esp
  int num;
  struct proc *curproc = myproc();
801050c7:	e8 94 ef ff ff       	call   80104060 <myproc>
801050cc:	89 c3                	mov    %eax,%ebx

  num = curproc->tf->eax;
801050ce:	8b 40 18             	mov    0x18(%eax),%eax
801050d1:	8b 40 1c             	mov    0x1c(%eax),%eax
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
801050d4:	8d 50 ff             	lea    -0x1(%eax),%edx
801050d7:	83 fa 15             	cmp    $0x15,%edx
801050da:	77 1c                	ja     801050f8 <syscall+0x38>
801050dc:	8b 14 85 40 7f 10 80 	mov    -0x7fef80c0(,%eax,4),%edx
801050e3:	85 d2                	test   %edx,%edx
801050e5:	74 11                	je     801050f8 <syscall+0x38>
    curproc->tf->eax = syscalls[num]();
801050e7:	ff d2                	call   *%edx
801050e9:	8b 53 18             	mov    0x18(%ebx),%edx
801050ec:	89 42 1c             	mov    %eax,0x1c(%edx)
  } else {
    cprintf("%d %s: unknown sys call %d\n",
            curproc->pid, curproc->name, num);
    curproc->tf->eax = -1;
  }
}
801050ef:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801050f2:	c9                   	leave  
801050f3:	c3                   	ret    
801050f4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    cprintf("%d %s: unknown sys call %d\n",
801050f8:	50                   	push   %eax
            curproc->pid, curproc->name, num);
801050f9:	8d 43 6c             	lea    0x6c(%ebx),%eax
    cprintf("%d %s: unknown sys call %d\n",
801050fc:	50                   	push   %eax
801050fd:	ff 73 10             	pushl  0x10(%ebx)
80105100:	68 11 7f 10 80       	push   $0x80107f11
80105105:	e8 56 b5 ff ff       	call   80100660 <cprintf>
    curproc->tf->eax = -1;
8010510a:	8b 43 18             	mov    0x18(%ebx),%eax
8010510d:	83 c4 10             	add    $0x10,%esp
80105110:	c7 40 1c ff ff ff ff 	movl   $0xffffffff,0x1c(%eax)
}
80105117:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010511a:	c9                   	leave  
8010511b:	c3                   	ret    
8010511c:	66 90                	xchg   %ax,%ax
8010511e:	66 90                	xchg   %ax,%ax

80105120 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
80105120:	55                   	push   %ebp
80105121:	89 e5                	mov    %esp,%ebp
80105123:	56                   	push   %esi
80105124:	53                   	push   %ebx
80105125:	89 d3                	mov    %edx,%ebx
  int fd;
  struct file *f;

  if(argint(n, &fd) < 0)
80105127:	8d 55 f4             	lea    -0xc(%ebp),%edx
{
8010512a:	89 ce                	mov    %ecx,%esi
8010512c:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
8010512f:	52                   	push   %edx
80105130:	50                   	push   %eax
80105131:	e8 9a fe ff ff       	call   80104fd0 <argint>
80105136:	83 c4 10             	add    $0x10,%esp
80105139:	85 c0                	test   %eax,%eax
8010513b:	78 2b                	js     80105168 <argfd+0x48>
    return -1;
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
8010513d:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
80105141:	77 25                	ja     80105168 <argfd+0x48>
80105143:	e8 18 ef ff ff       	call   80104060 <myproc>
80105148:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010514b:	8b 44 90 28          	mov    0x28(%eax,%edx,4),%eax
8010514f:	85 c0                	test   %eax,%eax
80105151:	74 15                	je     80105168 <argfd+0x48>
    return -1;
  if(pfd)
80105153:	85 db                	test   %ebx,%ebx
80105155:	74 02                	je     80105159 <argfd+0x39>
    *pfd = fd;
80105157:	89 13                	mov    %edx,(%ebx)
  if(pf)
    *pf = f;
80105159:	89 06                	mov    %eax,(%esi)
  return 0;
8010515b:	31 c0                	xor    %eax,%eax
}
8010515d:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105160:	5b                   	pop    %ebx
80105161:	5e                   	pop    %esi
80105162:	5d                   	pop    %ebp
80105163:	c3                   	ret    
80105164:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80105168:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010516d:	eb ee                	jmp    8010515d <argfd+0x3d>
8010516f:	90                   	nop

80105170 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
80105170:	55                   	push   %ebp
80105171:	89 e5                	mov    %esp,%ebp
80105173:	57                   	push   %edi
80105174:	56                   	push   %esi
80105175:	53                   	push   %ebx
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
80105176:	8d 75 da             	lea    -0x26(%ebp),%esi
{
80105179:	83 ec 34             	sub    $0x34,%esp
8010517c:	89 4d d0             	mov    %ecx,-0x30(%ebp)
8010517f:	8b 4d 08             	mov    0x8(%ebp),%ecx
  if((dp = nameiparent(path, name)) == 0)
80105182:	56                   	push   %esi
80105183:	50                   	push   %eax
{
80105184:	89 55 d4             	mov    %edx,-0x2c(%ebp)
80105187:	89 4d cc             	mov    %ecx,-0x34(%ebp)
  if((dp = nameiparent(path, name)) == 0)
8010518a:	e8 e1 d5 ff ff       	call   80102770 <nameiparent>
8010518f:	83 c4 10             	add    $0x10,%esp
80105192:	85 c0                	test   %eax,%eax
80105194:	0f 84 46 01 00 00    	je     801052e0 <create+0x170>
    return 0;
  ilock(dp);
8010519a:	83 ec 0c             	sub    $0xc,%esp
8010519d:	89 c3                	mov    %eax,%ebx
8010519f:	50                   	push   %eax
801051a0:	e8 bb c6 ff ff       	call   80101860 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
801051a5:	83 c4 0c             	add    $0xc,%esp
801051a8:	6a 00                	push   $0x0
801051aa:	56                   	push   %esi
801051ab:	53                   	push   %ebx
801051ac:	e8 6f d2 ff ff       	call   80102420 <dirlookup>
801051b1:	83 c4 10             	add    $0x10,%esp
801051b4:	85 c0                	test   %eax,%eax
801051b6:	89 c7                	mov    %eax,%edi
801051b8:	74 36                	je     801051f0 <create+0x80>
    iunlockput(dp);
801051ba:	83 ec 0c             	sub    $0xc,%esp
801051bd:	53                   	push   %ebx
801051be:	e8 ad cc ff ff       	call   80101e70 <iunlockput>
    ilock(ip);
801051c3:	89 3c 24             	mov    %edi,(%esp)
801051c6:	e8 95 c6 ff ff       	call   80101860 <ilock>
    if(type == T_FILE && ip->type == T_FILE)
801051cb:	83 c4 10             	add    $0x10,%esp
801051ce:	66 83 7d d4 02       	cmpw   $0x2,-0x2c(%ebp)
801051d3:	0f 85 97 00 00 00    	jne    80105270 <create+0x100>
801051d9:	66 83 7f 54 02       	cmpw   $0x2,0x54(%edi)
801051de:	0f 85 8c 00 00 00    	jne    80105270 <create+0x100>
    panic("create: dirlink");

  iunlockput(dp);

  return ip;
}
801051e4:	8d 65 f4             	lea    -0xc(%ebp),%esp
801051e7:	89 f8                	mov    %edi,%eax
801051e9:	5b                   	pop    %ebx
801051ea:	5e                   	pop    %esi
801051eb:	5f                   	pop    %edi
801051ec:	5d                   	pop    %ebp
801051ed:	c3                   	ret    
801051ee:	66 90                	xchg   %ax,%ax
  if((ip = ialloc(dp->dev, type)) == 0)
801051f0:	0f bf 45 d4          	movswl -0x2c(%ebp),%eax
801051f4:	83 ec 08             	sub    $0x8,%esp
801051f7:	50                   	push   %eax
801051f8:	ff 33                	pushl  (%ebx)
801051fa:	e8 f1 c4 ff ff       	call   801016f0 <ialloc>
801051ff:	83 c4 10             	add    $0x10,%esp
80105202:	85 c0                	test   %eax,%eax
80105204:	89 c7                	mov    %eax,%edi
80105206:	0f 84 e8 00 00 00    	je     801052f4 <create+0x184>
  ilock(ip);
8010520c:	83 ec 0c             	sub    $0xc,%esp
8010520f:	50                   	push   %eax
80105210:	e8 4b c6 ff ff       	call   80101860 <ilock>
  ip->major = major;
80105215:	0f b7 45 d0          	movzwl -0x30(%ebp),%eax
80105219:	66 89 47 56          	mov    %ax,0x56(%edi)
  ip->minor = minor;
8010521d:	0f b7 45 cc          	movzwl -0x34(%ebp),%eax
80105221:	66 89 47 58          	mov    %ax,0x58(%edi)
  ip->nlink = 1;
80105225:	b8 01 00 00 00       	mov    $0x1,%eax
8010522a:	66 89 47 5a          	mov    %ax,0x5a(%edi)
  iupdate(ip);
8010522e:	89 3c 24             	mov    %edi,(%esp)
80105231:	e8 7a c5 ff ff       	call   801017b0 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
80105236:	83 c4 10             	add    $0x10,%esp
80105239:	66 83 7d d4 01       	cmpw   $0x1,-0x2c(%ebp)
8010523e:	74 50                	je     80105290 <create+0x120>
  if(dirlink(dp, name, ip->inum) < 0)
80105240:	83 ec 04             	sub    $0x4,%esp
80105243:	ff 77 04             	pushl  0x4(%edi)
80105246:	56                   	push   %esi
80105247:	53                   	push   %ebx
80105248:	e8 43 d4 ff ff       	call   80102690 <dirlink>
8010524d:	83 c4 10             	add    $0x10,%esp
80105250:	85 c0                	test   %eax,%eax
80105252:	0f 88 8f 00 00 00    	js     801052e7 <create+0x177>
  iunlockput(dp);
80105258:	83 ec 0c             	sub    $0xc,%esp
8010525b:	53                   	push   %ebx
8010525c:	e8 0f cc ff ff       	call   80101e70 <iunlockput>
  return ip;
80105261:	83 c4 10             	add    $0x10,%esp
}
80105264:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105267:	89 f8                	mov    %edi,%eax
80105269:	5b                   	pop    %ebx
8010526a:	5e                   	pop    %esi
8010526b:	5f                   	pop    %edi
8010526c:	5d                   	pop    %ebp
8010526d:	c3                   	ret    
8010526e:	66 90                	xchg   %ax,%ax
    iunlockput(ip);
80105270:	83 ec 0c             	sub    $0xc,%esp
80105273:	57                   	push   %edi
    return 0;
80105274:	31 ff                	xor    %edi,%edi
    iunlockput(ip);
80105276:	e8 f5 cb ff ff       	call   80101e70 <iunlockput>
    return 0;
8010527b:	83 c4 10             	add    $0x10,%esp
}
8010527e:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105281:	89 f8                	mov    %edi,%eax
80105283:	5b                   	pop    %ebx
80105284:	5e                   	pop    %esi
80105285:	5f                   	pop    %edi
80105286:	5d                   	pop    %ebp
80105287:	c3                   	ret    
80105288:	90                   	nop
80105289:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    dp->nlink++;  // for ".."
80105290:	66 83 43 5a 01       	addw   $0x1,0x5a(%ebx)
    iupdate(dp);
80105295:	83 ec 0c             	sub    $0xc,%esp
80105298:	53                   	push   %ebx
80105299:	e8 12 c5 ff ff       	call   801017b0 <iupdate>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
8010529e:	83 c4 0c             	add    $0xc,%esp
801052a1:	ff 77 04             	pushl  0x4(%edi)
801052a4:	68 b8 7f 10 80       	push   $0x80107fb8
801052a9:	57                   	push   %edi
801052aa:	e8 e1 d3 ff ff       	call   80102690 <dirlink>
801052af:	83 c4 10             	add    $0x10,%esp
801052b2:	85 c0                	test   %eax,%eax
801052b4:	78 1c                	js     801052d2 <create+0x162>
801052b6:	83 ec 04             	sub    $0x4,%esp
801052b9:	ff 73 04             	pushl  0x4(%ebx)
801052bc:	68 b7 7f 10 80       	push   $0x80107fb7
801052c1:	57                   	push   %edi
801052c2:	e8 c9 d3 ff ff       	call   80102690 <dirlink>
801052c7:	83 c4 10             	add    $0x10,%esp
801052ca:	85 c0                	test   %eax,%eax
801052cc:	0f 89 6e ff ff ff    	jns    80105240 <create+0xd0>
      panic("create dots");
801052d2:	83 ec 0c             	sub    $0xc,%esp
801052d5:	68 ab 7f 10 80       	push   $0x80107fab
801052da:	e8 b1 b0 ff ff       	call   80100390 <panic>
801052df:	90                   	nop
    return 0;
801052e0:	31 ff                	xor    %edi,%edi
801052e2:	e9 fd fe ff ff       	jmp    801051e4 <create+0x74>
    panic("create: dirlink");
801052e7:	83 ec 0c             	sub    $0xc,%esp
801052ea:	68 ba 7f 10 80       	push   $0x80107fba
801052ef:	e8 9c b0 ff ff       	call   80100390 <panic>
    panic("create: ialloc");
801052f4:	83 ec 0c             	sub    $0xc,%esp
801052f7:	68 9c 7f 10 80       	push   $0x80107f9c
801052fc:	e8 8f b0 ff ff       	call   80100390 <panic>
80105301:	eb 0d                	jmp    80105310 <sys_dup>
80105303:	90                   	nop
80105304:	90                   	nop
80105305:	90                   	nop
80105306:	90                   	nop
80105307:	90                   	nop
80105308:	90                   	nop
80105309:	90                   	nop
8010530a:	90                   	nop
8010530b:	90                   	nop
8010530c:	90                   	nop
8010530d:	90                   	nop
8010530e:	90                   	nop
8010530f:	90                   	nop

80105310 <sys_dup>:
{
80105310:	55                   	push   %ebp
  if(argfd(0, 0, &f) < 0)
80105311:	31 d2                	xor    %edx,%edx
80105313:	31 c0                	xor    %eax,%eax
{
80105315:	89 e5                	mov    %esp,%ebp
80105317:	56                   	push   %esi
80105318:	53                   	push   %ebx
  if(argfd(0, 0, &f) < 0)
80105319:	8d 4d f4             	lea    -0xc(%ebp),%ecx
{
8010531c:	83 ec 10             	sub    $0x10,%esp
  if(argfd(0, 0, &f) < 0)
8010531f:	e8 fc fd ff ff       	call   80105120 <argfd>
80105324:	85 c0                	test   %eax,%eax
80105326:	78 40                	js     80105368 <sys_dup+0x58>
  if((fd=fdalloc(f)) < 0)
80105328:	8b 75 f4             	mov    -0xc(%ebp),%esi
  for(fd = 0; fd < NOFILE; fd++){
8010532b:	31 db                	xor    %ebx,%ebx
  struct proc *curproc = myproc();
8010532d:	e8 2e ed ff ff       	call   80104060 <myproc>
80105332:	eb 0c                	jmp    80105340 <sys_dup+0x30>
80105334:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  for(fd = 0; fd < NOFILE; fd++){
80105338:	83 c3 01             	add    $0x1,%ebx
8010533b:	83 fb 10             	cmp    $0x10,%ebx
8010533e:	74 28                	je     80105368 <sys_dup+0x58>
    if(curproc->ofile[fd] == 0){
80105340:	8b 54 98 28          	mov    0x28(%eax,%ebx,4),%edx
80105344:	85 d2                	test   %edx,%edx
80105346:	75 f0                	jne    80105338 <sys_dup+0x28>
      curproc->ofile[fd] = f;
80105348:	89 74 98 28          	mov    %esi,0x28(%eax,%ebx,4)
  filedup(f);
8010534c:	83 ec 0c             	sub    $0xc,%esp
8010534f:	ff 75 f4             	pushl  -0xc(%ebp)
80105352:	e8 99 ba ff ff       	call   80100df0 <filedup>
  return fd;
80105357:	83 c4 10             	add    $0x10,%esp
}
8010535a:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010535d:	89 d8                	mov    %ebx,%eax
8010535f:	5b                   	pop    %ebx
80105360:	5e                   	pop    %esi
80105361:	5d                   	pop    %ebp
80105362:	c3                   	ret    
80105363:	90                   	nop
80105364:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80105368:	8d 65 f8             	lea    -0x8(%ebp),%esp
    return -1;
8010536b:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
}
80105370:	89 d8                	mov    %ebx,%eax
80105372:	5b                   	pop    %ebx
80105373:	5e                   	pop    %esi
80105374:	5d                   	pop    %ebp
80105375:	c3                   	ret    
80105376:	8d 76 00             	lea    0x0(%esi),%esi
80105379:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80105380 <sys_read>:
{
80105380:	55                   	push   %ebp
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
80105381:	31 d2                	xor    %edx,%edx
80105383:	31 c0                	xor    %eax,%eax
{
80105385:	89 e5                	mov    %esp,%ebp
80105387:	83 ec 18             	sub    $0x18,%esp
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
8010538a:	8d 4d ec             	lea    -0x14(%ebp),%ecx
8010538d:	e8 8e fd ff ff       	call   80105120 <argfd>
80105392:	85 c0                	test   %eax,%eax
80105394:	78 4a                	js     801053e0 <sys_read+0x60>
80105396:	8d 45 f0             	lea    -0x10(%ebp),%eax
80105399:	83 ec 08             	sub    $0x8,%esp
8010539c:	50                   	push   %eax
8010539d:	6a 02                	push   $0x2
8010539f:	e8 2c fc ff ff       	call   80104fd0 <argint>
801053a4:	83 c4 10             	add    $0x10,%esp
801053a7:	85 c0                	test   %eax,%eax
801053a9:	78 35                	js     801053e0 <sys_read+0x60>
801053ab:	8d 45 f4             	lea    -0xc(%ebp),%eax
801053ae:	83 ec 04             	sub    $0x4,%esp
801053b1:	ff 75 f0             	pushl  -0x10(%ebp)
801053b4:	50                   	push   %eax
801053b5:	6a 01                	push   $0x1
801053b7:	e8 64 fc ff ff       	call   80105020 <argptr>
801053bc:	83 c4 10             	add    $0x10,%esp
801053bf:	85 c0                	test   %eax,%eax
801053c1:	78 1d                	js     801053e0 <sys_read+0x60>
  return fileread(f, p, n);
801053c3:	83 ec 04             	sub    $0x4,%esp
801053c6:	ff 75 f0             	pushl  -0x10(%ebp)
801053c9:	ff 75 f4             	pushl  -0xc(%ebp)
801053cc:	ff 75 ec             	pushl  -0x14(%ebp)
801053cf:	e8 8c bb ff ff       	call   80100f60 <fileread>
801053d4:	83 c4 10             	add    $0x10,%esp
}
801053d7:	c9                   	leave  
801053d8:	c3                   	ret    
801053d9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
801053e0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801053e5:	c9                   	leave  
801053e6:	c3                   	ret    
801053e7:	89 f6                	mov    %esi,%esi
801053e9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

801053f0 <sys_write>:
{
801053f0:	55                   	push   %ebp
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
801053f1:	31 d2                	xor    %edx,%edx
801053f3:	31 c0                	xor    %eax,%eax
{
801053f5:	89 e5                	mov    %esp,%ebp
801053f7:	83 ec 18             	sub    $0x18,%esp
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
801053fa:	8d 4d ec             	lea    -0x14(%ebp),%ecx
801053fd:	e8 1e fd ff ff       	call   80105120 <argfd>
80105402:	85 c0                	test   %eax,%eax
80105404:	78 4a                	js     80105450 <sys_write+0x60>
80105406:	8d 45 f0             	lea    -0x10(%ebp),%eax
80105409:	83 ec 08             	sub    $0x8,%esp
8010540c:	50                   	push   %eax
8010540d:	6a 02                	push   $0x2
8010540f:	e8 bc fb ff ff       	call   80104fd0 <argint>
80105414:	83 c4 10             	add    $0x10,%esp
80105417:	85 c0                	test   %eax,%eax
80105419:	78 35                	js     80105450 <sys_write+0x60>
8010541b:	8d 45 f4             	lea    -0xc(%ebp),%eax
8010541e:	83 ec 04             	sub    $0x4,%esp
80105421:	ff 75 f0             	pushl  -0x10(%ebp)
80105424:	50                   	push   %eax
80105425:	6a 01                	push   $0x1
80105427:	e8 f4 fb ff ff       	call   80105020 <argptr>
8010542c:	83 c4 10             	add    $0x10,%esp
8010542f:	85 c0                	test   %eax,%eax
80105431:	78 1d                	js     80105450 <sys_write+0x60>
  return filewrite(f, p, n);
80105433:	83 ec 04             	sub    $0x4,%esp
80105436:	ff 75 f0             	pushl  -0x10(%ebp)
80105439:	ff 75 f4             	pushl  -0xc(%ebp)
8010543c:	ff 75 ec             	pushl  -0x14(%ebp)
8010543f:	e8 ac bb ff ff       	call   80100ff0 <filewrite>
80105444:	83 c4 10             	add    $0x10,%esp
}
80105447:	c9                   	leave  
80105448:	c3                   	ret    
80105449:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80105450:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105455:	c9                   	leave  
80105456:	c3                   	ret    
80105457:	89 f6                	mov    %esi,%esi
80105459:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80105460 <sys_close>:
{
80105460:	55                   	push   %ebp
  if(argfd(0, &fd, &f) < 0)
80105461:	31 c0                	xor    %eax,%eax
{
80105463:	89 e5                	mov    %esp,%ebp
80105465:	83 ec 18             	sub    $0x18,%esp
  if(argfd(0, &fd, &f) < 0)
80105468:	8d 4d f4             	lea    -0xc(%ebp),%ecx
8010546b:	8d 55 f0             	lea    -0x10(%ebp),%edx
8010546e:	e8 ad fc ff ff       	call   80105120 <argfd>
80105473:	85 c0                	test   %eax,%eax
80105475:	78 29                	js     801054a0 <sys_close+0x40>
  myproc()->ofile[fd] = 0;
80105477:	e8 e4 eb ff ff       	call   80104060 <myproc>
8010547c:	8b 55 f0             	mov    -0x10(%ebp),%edx
  fileclose(f);
8010547f:	83 ec 0c             	sub    $0xc,%esp
  myproc()->ofile[fd] = 0;
80105482:	c7 44 90 28 00 00 00 	movl   $0x0,0x28(%eax,%edx,4)
80105489:	00 
  fileclose(f);
8010548a:	ff 75 f4             	pushl  -0xc(%ebp)
8010548d:	e8 ae b9 ff ff       	call   80100e40 <fileclose>
  return 0;
80105492:	83 c4 10             	add    $0x10,%esp
80105495:	31 c0                	xor    %eax,%eax
}
80105497:	c9                   	leave  
80105498:	c3                   	ret    
80105499:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
801054a0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801054a5:	c9                   	leave  
801054a6:	c3                   	ret    
801054a7:	89 f6                	mov    %esi,%esi
801054a9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

801054b0 <sys_fstat>:
{
801054b0:	55                   	push   %ebp
  if(argfd(0, 0, &f) < 0 || argptr(1, (void*)&st, sizeof(*st)) < 0)
801054b1:	31 d2                	xor    %edx,%edx
801054b3:	31 c0                	xor    %eax,%eax
{
801054b5:	89 e5                	mov    %esp,%ebp
801054b7:	83 ec 18             	sub    $0x18,%esp
  if(argfd(0, 0, &f) < 0 || argptr(1, (void*)&st, sizeof(*st)) < 0)
801054ba:	8d 4d f0             	lea    -0x10(%ebp),%ecx
801054bd:	e8 5e fc ff ff       	call   80105120 <argfd>
801054c2:	85 c0                	test   %eax,%eax
801054c4:	78 2a                	js     801054f0 <sys_fstat+0x40>
801054c6:	8d 45 f4             	lea    -0xc(%ebp),%eax
801054c9:	83 ec 04             	sub    $0x4,%esp
801054cc:	6a 14                	push   $0x14
801054ce:	50                   	push   %eax
801054cf:	6a 01                	push   $0x1
801054d1:	e8 4a fb ff ff       	call   80105020 <argptr>
801054d6:	83 c4 10             	add    $0x10,%esp
801054d9:	85 c0                	test   %eax,%eax
801054db:	78 13                	js     801054f0 <sys_fstat+0x40>
  return filestat(f, st);
801054dd:	83 ec 08             	sub    $0x8,%esp
801054e0:	ff 75 f4             	pushl  -0xc(%ebp)
801054e3:	ff 75 f0             	pushl  -0x10(%ebp)
801054e6:	e8 25 ba ff ff       	call   80100f10 <filestat>
801054eb:	83 c4 10             	add    $0x10,%esp
}
801054ee:	c9                   	leave  
801054ef:	c3                   	ret    
    return -1;
801054f0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801054f5:	c9                   	leave  
801054f6:	c3                   	ret    
801054f7:	89 f6                	mov    %esi,%esi
801054f9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80105500 <sys_link>:
{
80105500:	55                   	push   %ebp
80105501:	89 e5                	mov    %esp,%ebp
80105503:	57                   	push   %edi
80105504:	56                   	push   %esi
80105505:	53                   	push   %ebx
  if(argstr(0, &old) < 0 || argstr(1, &new) < 0)
80105506:	8d 45 d4             	lea    -0x2c(%ebp),%eax
{
80105509:	83 ec 34             	sub    $0x34,%esp
  if(argstr(0, &old) < 0 || argstr(1, &new) < 0)
8010550c:	50                   	push   %eax
8010550d:	6a 00                	push   $0x0
8010550f:	e8 6c fb ff ff       	call   80105080 <argstr>
80105514:	83 c4 10             	add    $0x10,%esp
80105517:	85 c0                	test   %eax,%eax
80105519:	0f 88 fb 00 00 00    	js     8010561a <sys_link+0x11a>
8010551f:	8d 45 d0             	lea    -0x30(%ebp),%eax
80105522:	83 ec 08             	sub    $0x8,%esp
80105525:	50                   	push   %eax
80105526:	6a 01                	push   $0x1
80105528:	e8 53 fb ff ff       	call   80105080 <argstr>
8010552d:	83 c4 10             	add    $0x10,%esp
80105530:	85 c0                	test   %eax,%eax
80105532:	0f 88 e2 00 00 00    	js     8010561a <sys_link+0x11a>
  begin_op();
80105538:	e8 e3 de ff ff       	call   80103420 <begin_op>
  if((ip = namei(old)) == 0){
8010553d:	83 ec 0c             	sub    $0xc,%esp
80105540:	ff 75 d4             	pushl  -0x2c(%ebp)
80105543:	e8 08 d2 ff ff       	call   80102750 <namei>
80105548:	83 c4 10             	add    $0x10,%esp
8010554b:	85 c0                	test   %eax,%eax
8010554d:	89 c3                	mov    %eax,%ebx
8010554f:	0f 84 ea 00 00 00    	je     8010563f <sys_link+0x13f>
  ilock(ip);
80105555:	83 ec 0c             	sub    $0xc,%esp
80105558:	50                   	push   %eax
80105559:	e8 02 c3 ff ff       	call   80101860 <ilock>
  if(ip->type == T_DIR){
8010555e:	83 c4 10             	add    $0x10,%esp
80105561:	66 83 7b 54 01       	cmpw   $0x1,0x54(%ebx)
80105566:	0f 84 bb 00 00 00    	je     80105627 <sys_link+0x127>
  ip->nlink++;
8010556c:	66 83 43 5a 01       	addw   $0x1,0x5a(%ebx)
  iupdate(ip);
80105571:	83 ec 0c             	sub    $0xc,%esp
  if((dp = nameiparent(new, name)) == 0)
80105574:	8d 7d da             	lea    -0x26(%ebp),%edi
  iupdate(ip);
80105577:	53                   	push   %ebx
80105578:	e8 33 c2 ff ff       	call   801017b0 <iupdate>
  iunlock(ip);
8010557d:	89 1c 24             	mov    %ebx,(%esp)
80105580:	e8 bb c3 ff ff       	call   80101940 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
80105585:	58                   	pop    %eax
80105586:	5a                   	pop    %edx
80105587:	57                   	push   %edi
80105588:	ff 75 d0             	pushl  -0x30(%ebp)
8010558b:	e8 e0 d1 ff ff       	call   80102770 <nameiparent>
80105590:	83 c4 10             	add    $0x10,%esp
80105593:	85 c0                	test   %eax,%eax
80105595:	89 c6                	mov    %eax,%esi
80105597:	74 5b                	je     801055f4 <sys_link+0xf4>
  ilock(dp);
80105599:	83 ec 0c             	sub    $0xc,%esp
8010559c:	50                   	push   %eax
8010559d:	e8 be c2 ff ff       	call   80101860 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
801055a2:	83 c4 10             	add    $0x10,%esp
801055a5:	8b 03                	mov    (%ebx),%eax
801055a7:	39 06                	cmp    %eax,(%esi)
801055a9:	75 3d                	jne    801055e8 <sys_link+0xe8>
801055ab:	83 ec 04             	sub    $0x4,%esp
801055ae:	ff 73 04             	pushl  0x4(%ebx)
801055b1:	57                   	push   %edi
801055b2:	56                   	push   %esi
801055b3:	e8 d8 d0 ff ff       	call   80102690 <dirlink>
801055b8:	83 c4 10             	add    $0x10,%esp
801055bb:	85 c0                	test   %eax,%eax
801055bd:	78 29                	js     801055e8 <sys_link+0xe8>
  iunlockput(dp);
801055bf:	83 ec 0c             	sub    $0xc,%esp
801055c2:	56                   	push   %esi
801055c3:	e8 a8 c8 ff ff       	call   80101e70 <iunlockput>
  iput(ip);
801055c8:	89 1c 24             	mov    %ebx,(%esp)
801055cb:	e8 c0 c5 ff ff       	call   80101b90 <iput>
  end_op();
801055d0:	e8 bb de ff ff       	call   80103490 <end_op>
  return 0;
801055d5:	83 c4 10             	add    $0x10,%esp
801055d8:	31 c0                	xor    %eax,%eax
}
801055da:	8d 65 f4             	lea    -0xc(%ebp),%esp
801055dd:	5b                   	pop    %ebx
801055de:	5e                   	pop    %esi
801055df:	5f                   	pop    %edi
801055e0:	5d                   	pop    %ebp
801055e1:	c3                   	ret    
801055e2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    iunlockput(dp);
801055e8:	83 ec 0c             	sub    $0xc,%esp
801055eb:	56                   	push   %esi
801055ec:	e8 7f c8 ff ff       	call   80101e70 <iunlockput>
    goto bad;
801055f1:	83 c4 10             	add    $0x10,%esp
  ilock(ip);
801055f4:	83 ec 0c             	sub    $0xc,%esp
801055f7:	53                   	push   %ebx
801055f8:	e8 63 c2 ff ff       	call   80101860 <ilock>
  ip->nlink--;
801055fd:	66 83 6b 5a 01       	subw   $0x1,0x5a(%ebx)
  iupdate(ip);
80105602:	89 1c 24             	mov    %ebx,(%esp)
80105605:	e8 a6 c1 ff ff       	call   801017b0 <iupdate>
  iunlockput(ip);
8010560a:	89 1c 24             	mov    %ebx,(%esp)
8010560d:	e8 5e c8 ff ff       	call   80101e70 <iunlockput>
  end_op();
80105612:	e8 79 de ff ff       	call   80103490 <end_op>
  return -1;
80105617:	83 c4 10             	add    $0x10,%esp
}
8010561a:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return -1;
8010561d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105622:	5b                   	pop    %ebx
80105623:	5e                   	pop    %esi
80105624:	5f                   	pop    %edi
80105625:	5d                   	pop    %ebp
80105626:	c3                   	ret    
    iunlockput(ip);
80105627:	83 ec 0c             	sub    $0xc,%esp
8010562a:	53                   	push   %ebx
8010562b:	e8 40 c8 ff ff       	call   80101e70 <iunlockput>
    end_op();
80105630:	e8 5b de ff ff       	call   80103490 <end_op>
    return -1;
80105635:	83 c4 10             	add    $0x10,%esp
80105638:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010563d:	eb 9b                	jmp    801055da <sys_link+0xda>
    end_op();
8010563f:	e8 4c de ff ff       	call   80103490 <end_op>
    return -1;
80105644:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105649:	eb 8f                	jmp    801055da <sys_link+0xda>
8010564b:	90                   	nop
8010564c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80105650 <sys_unlink>:
{
80105650:	55                   	push   %ebp
80105651:	89 e5                	mov    %esp,%ebp
80105653:	57                   	push   %edi
80105654:	56                   	push   %esi
80105655:	53                   	push   %ebx
  if(argstr(0, &path) < 0)
80105656:	8d 45 c0             	lea    -0x40(%ebp),%eax
{
80105659:	83 ec 44             	sub    $0x44,%esp
  if(argstr(0, &path) < 0)
8010565c:	50                   	push   %eax
8010565d:	6a 00                	push   $0x0
8010565f:	e8 1c fa ff ff       	call   80105080 <argstr>
80105664:	83 c4 10             	add    $0x10,%esp
80105667:	85 c0                	test   %eax,%eax
80105669:	0f 88 77 01 00 00    	js     801057e6 <sys_unlink+0x196>
  if((dp = nameiparent(path, name)) == 0){
8010566f:	8d 5d ca             	lea    -0x36(%ebp),%ebx
  begin_op();
80105672:	e8 a9 dd ff ff       	call   80103420 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
80105677:	83 ec 08             	sub    $0x8,%esp
8010567a:	53                   	push   %ebx
8010567b:	ff 75 c0             	pushl  -0x40(%ebp)
8010567e:	e8 ed d0 ff ff       	call   80102770 <nameiparent>
80105683:	83 c4 10             	add    $0x10,%esp
80105686:	85 c0                	test   %eax,%eax
80105688:	89 c6                	mov    %eax,%esi
8010568a:	0f 84 60 01 00 00    	je     801057f0 <sys_unlink+0x1a0>
  ilock(dp);
80105690:	83 ec 0c             	sub    $0xc,%esp
80105693:	50                   	push   %eax
80105694:	e8 c7 c1 ff ff       	call   80101860 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
80105699:	58                   	pop    %eax
8010569a:	5a                   	pop    %edx
8010569b:	68 b8 7f 10 80       	push   $0x80107fb8
801056a0:	53                   	push   %ebx
801056a1:	e8 5a cd ff ff       	call   80102400 <namecmp>
801056a6:	83 c4 10             	add    $0x10,%esp
801056a9:	85 c0                	test   %eax,%eax
801056ab:	0f 84 03 01 00 00    	je     801057b4 <sys_unlink+0x164>
801056b1:	83 ec 08             	sub    $0x8,%esp
801056b4:	68 b7 7f 10 80       	push   $0x80107fb7
801056b9:	53                   	push   %ebx
801056ba:	e8 41 cd ff ff       	call   80102400 <namecmp>
801056bf:	83 c4 10             	add    $0x10,%esp
801056c2:	85 c0                	test   %eax,%eax
801056c4:	0f 84 ea 00 00 00    	je     801057b4 <sys_unlink+0x164>
  if((ip = dirlookup(dp, name, &off)) == 0)
801056ca:	8d 45 c4             	lea    -0x3c(%ebp),%eax
801056cd:	83 ec 04             	sub    $0x4,%esp
801056d0:	50                   	push   %eax
801056d1:	53                   	push   %ebx
801056d2:	56                   	push   %esi
801056d3:	e8 48 cd ff ff       	call   80102420 <dirlookup>
801056d8:	83 c4 10             	add    $0x10,%esp
801056db:	85 c0                	test   %eax,%eax
801056dd:	89 c3                	mov    %eax,%ebx
801056df:	0f 84 cf 00 00 00    	je     801057b4 <sys_unlink+0x164>
  ilock(ip);
801056e5:	83 ec 0c             	sub    $0xc,%esp
801056e8:	50                   	push   %eax
801056e9:	e8 72 c1 ff ff       	call   80101860 <ilock>
  if(ip->nlink < 1)
801056ee:	83 c4 10             	add    $0x10,%esp
801056f1:	66 83 7b 5a 00       	cmpw   $0x0,0x5a(%ebx)
801056f6:	0f 8e 10 01 00 00    	jle    8010580c <sys_unlink+0x1bc>
  if(ip->type == T_DIR && !isdirempty(ip)){
801056fc:	66 83 7b 54 01       	cmpw   $0x1,0x54(%ebx)
80105701:	74 6d                	je     80105770 <sys_unlink+0x120>
  memset(&de, 0, sizeof(de));
80105703:	8d 45 d8             	lea    -0x28(%ebp),%eax
80105706:	83 ec 04             	sub    $0x4,%esp
80105709:	6a 10                	push   $0x10
8010570b:	6a 00                	push   $0x0
8010570d:	50                   	push   %eax
8010570e:	e8 bd f5 ff ff       	call   80104cd0 <memset>
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80105713:	8d 45 d8             	lea    -0x28(%ebp),%eax
80105716:	6a 10                	push   $0x10
80105718:	ff 75 c4             	pushl  -0x3c(%ebp)
8010571b:	50                   	push   %eax
8010571c:	56                   	push   %esi
8010571d:	e8 6e c7 ff ff       	call   80101e90 <writei>
80105722:	83 c4 20             	add    $0x20,%esp
80105725:	83 f8 10             	cmp    $0x10,%eax
80105728:	0f 85 eb 00 00 00    	jne    80105819 <sys_unlink+0x1c9>
  if(ip->type == T_DIR){
8010572e:	66 83 7b 54 01       	cmpw   $0x1,0x54(%ebx)
80105733:	0f 84 97 00 00 00    	je     801057d0 <sys_unlink+0x180>
  iunlockput(dp);
80105739:	83 ec 0c             	sub    $0xc,%esp
8010573c:	56                   	push   %esi
8010573d:	e8 2e c7 ff ff       	call   80101e70 <iunlockput>
  ip->nlink--;
80105742:	66 83 6b 5a 01       	subw   $0x1,0x5a(%ebx)
  iupdate(ip);
80105747:	89 1c 24             	mov    %ebx,(%esp)
8010574a:	e8 61 c0 ff ff       	call   801017b0 <iupdate>
  iunlockput(ip);
8010574f:	89 1c 24             	mov    %ebx,(%esp)
80105752:	e8 19 c7 ff ff       	call   80101e70 <iunlockput>
  end_op();
80105757:	e8 34 dd ff ff       	call   80103490 <end_op>
  return 0;
8010575c:	83 c4 10             	add    $0x10,%esp
8010575f:	31 c0                	xor    %eax,%eax
}
80105761:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105764:	5b                   	pop    %ebx
80105765:	5e                   	pop    %esi
80105766:	5f                   	pop    %edi
80105767:	5d                   	pop    %ebp
80105768:	c3                   	ret    
80105769:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
80105770:	83 7b 5c 20          	cmpl   $0x20,0x5c(%ebx)
80105774:	76 8d                	jbe    80105703 <sys_unlink+0xb3>
80105776:	bf 20 00 00 00       	mov    $0x20,%edi
8010577b:	eb 0f                	jmp    8010578c <sys_unlink+0x13c>
8010577d:	8d 76 00             	lea    0x0(%esi),%esi
80105780:	83 c7 10             	add    $0x10,%edi
80105783:	3b 7b 5c             	cmp    0x5c(%ebx),%edi
80105786:	0f 83 77 ff ff ff    	jae    80105703 <sys_unlink+0xb3>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
8010578c:	8d 45 d8             	lea    -0x28(%ebp),%eax
8010578f:	6a 10                	push   $0x10
80105791:	57                   	push   %edi
80105792:	50                   	push   %eax
80105793:	53                   	push   %ebx
80105794:	e8 27 c2 ff ff       	call   801019c0 <readi>
80105799:	83 c4 10             	add    $0x10,%esp
8010579c:	83 f8 10             	cmp    $0x10,%eax
8010579f:	75 5e                	jne    801057ff <sys_unlink+0x1af>
    if(de.inum != 0)
801057a1:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
801057a6:	74 d8                	je     80105780 <sys_unlink+0x130>
    iunlockput(ip);
801057a8:	83 ec 0c             	sub    $0xc,%esp
801057ab:	53                   	push   %ebx
801057ac:	e8 bf c6 ff ff       	call   80101e70 <iunlockput>
    goto bad;
801057b1:	83 c4 10             	add    $0x10,%esp
  iunlockput(dp);
801057b4:	83 ec 0c             	sub    $0xc,%esp
801057b7:	56                   	push   %esi
801057b8:	e8 b3 c6 ff ff       	call   80101e70 <iunlockput>
  end_op();
801057bd:	e8 ce dc ff ff       	call   80103490 <end_op>
  return -1;
801057c2:	83 c4 10             	add    $0x10,%esp
801057c5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801057ca:	eb 95                	jmp    80105761 <sys_unlink+0x111>
801057cc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    dp->nlink--;
801057d0:	66 83 6e 5a 01       	subw   $0x1,0x5a(%esi)
    iupdate(dp);
801057d5:	83 ec 0c             	sub    $0xc,%esp
801057d8:	56                   	push   %esi
801057d9:	e8 d2 bf ff ff       	call   801017b0 <iupdate>
801057de:	83 c4 10             	add    $0x10,%esp
801057e1:	e9 53 ff ff ff       	jmp    80105739 <sys_unlink+0xe9>
    return -1;
801057e6:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801057eb:	e9 71 ff ff ff       	jmp    80105761 <sys_unlink+0x111>
    end_op();
801057f0:	e8 9b dc ff ff       	call   80103490 <end_op>
    return -1;
801057f5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801057fa:	e9 62 ff ff ff       	jmp    80105761 <sys_unlink+0x111>
      panic("isdirempty: readi");
801057ff:	83 ec 0c             	sub    $0xc,%esp
80105802:	68 dc 7f 10 80       	push   $0x80107fdc
80105807:	e8 84 ab ff ff       	call   80100390 <panic>
    panic("unlink: nlink < 1");
8010580c:	83 ec 0c             	sub    $0xc,%esp
8010580f:	68 ca 7f 10 80       	push   $0x80107fca
80105814:	e8 77 ab ff ff       	call   80100390 <panic>
    panic("unlink: writei");
80105819:	83 ec 0c             	sub    $0xc,%esp
8010581c:	68 ee 7f 10 80       	push   $0x80107fee
80105821:	e8 6a ab ff ff       	call   80100390 <panic>
80105826:	8d 76 00             	lea    0x0(%esi),%esi
80105829:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80105830 <sys_open>:

int
sys_open(void)
{
80105830:	55                   	push   %ebp
80105831:	89 e5                	mov    %esp,%ebp
80105833:	57                   	push   %edi
80105834:	56                   	push   %esi
80105835:	53                   	push   %ebx
  char *path;
  int fd, omode;
  struct file *f;
  struct inode *ip;

  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)
80105836:	8d 45 e0             	lea    -0x20(%ebp),%eax
{
80105839:	83 ec 24             	sub    $0x24,%esp
  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)
8010583c:	50                   	push   %eax
8010583d:	6a 00                	push   $0x0
8010583f:	e8 3c f8 ff ff       	call   80105080 <argstr>
80105844:	83 c4 10             	add    $0x10,%esp
80105847:	85 c0                	test   %eax,%eax
80105849:	0f 88 1d 01 00 00    	js     8010596c <sys_open+0x13c>
8010584f:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80105852:	83 ec 08             	sub    $0x8,%esp
80105855:	50                   	push   %eax
80105856:	6a 01                	push   $0x1
80105858:	e8 73 f7 ff ff       	call   80104fd0 <argint>
8010585d:	83 c4 10             	add    $0x10,%esp
80105860:	85 c0                	test   %eax,%eax
80105862:	0f 88 04 01 00 00    	js     8010596c <sys_open+0x13c>
    return -1;

  begin_op();
80105868:	e8 b3 db ff ff       	call   80103420 <begin_op>

  if(omode & O_CREATE){
8010586d:	f6 45 e5 02          	testb  $0x2,-0x1b(%ebp)
80105871:	0f 85 a9 00 00 00    	jne    80105920 <sys_open+0xf0>
    if(ip == 0){
      end_op();
      return -1;
    }
  } else {
    if((ip = namei(path)) == 0){
80105877:	83 ec 0c             	sub    $0xc,%esp
8010587a:	ff 75 e0             	pushl  -0x20(%ebp)
8010587d:	e8 ce ce ff ff       	call   80102750 <namei>
80105882:	83 c4 10             	add    $0x10,%esp
80105885:	85 c0                	test   %eax,%eax
80105887:	89 c6                	mov    %eax,%esi
80105889:	0f 84 b2 00 00 00    	je     80105941 <sys_open+0x111>
      end_op();
      return -1;
    }
    ilock(ip);
8010588f:	83 ec 0c             	sub    $0xc,%esp
80105892:	50                   	push   %eax
80105893:	e8 c8 bf ff ff       	call   80101860 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
80105898:	83 c4 10             	add    $0x10,%esp
8010589b:	66 83 7e 54 01       	cmpw   $0x1,0x54(%esi)
801058a0:	0f 84 aa 00 00 00    	je     80105950 <sys_open+0x120>
      end_op();
      return -1;
    }
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
801058a6:	e8 d5 b4 ff ff       	call   80100d80 <filealloc>
801058ab:	85 c0                	test   %eax,%eax
801058ad:	89 c7                	mov    %eax,%edi
801058af:	0f 84 a6 00 00 00    	je     8010595b <sys_open+0x12b>
  struct proc *curproc = myproc();
801058b5:	e8 a6 e7 ff ff       	call   80104060 <myproc>
  for(fd = 0; fd < NOFILE; fd++){
801058ba:	31 db                	xor    %ebx,%ebx
801058bc:	eb 0e                	jmp    801058cc <sys_open+0x9c>
801058be:	66 90                	xchg   %ax,%ax
801058c0:	83 c3 01             	add    $0x1,%ebx
801058c3:	83 fb 10             	cmp    $0x10,%ebx
801058c6:	0f 84 ac 00 00 00    	je     80105978 <sys_open+0x148>
    if(curproc->ofile[fd] == 0){
801058cc:	8b 54 98 28          	mov    0x28(%eax,%ebx,4),%edx
801058d0:	85 d2                	test   %edx,%edx
801058d2:	75 ec                	jne    801058c0 <sys_open+0x90>
      fileclose(f);
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
801058d4:	83 ec 0c             	sub    $0xc,%esp
      curproc->ofile[fd] = f;
801058d7:	89 7c 98 28          	mov    %edi,0x28(%eax,%ebx,4)
  iunlock(ip);
801058db:	56                   	push   %esi
801058dc:	e8 5f c0 ff ff       	call   80101940 <iunlock>
  end_op();
801058e1:	e8 aa db ff ff       	call   80103490 <end_op>

  f->type = FD_INODE;
801058e6:	c7 07 02 00 00 00    	movl   $0x2,(%edi)
  f->ip = ip;
  f->off = 0;
  f->readable = !(omode & O_WRONLY);
801058ec:	8b 55 e4             	mov    -0x1c(%ebp),%edx
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
801058ef:	83 c4 10             	add    $0x10,%esp
  f->ip = ip;
801058f2:	89 77 10             	mov    %esi,0x10(%edi)
  f->off = 0;
801058f5:	c7 47 14 00 00 00 00 	movl   $0x0,0x14(%edi)
  f->readable = !(omode & O_WRONLY);
801058fc:	89 d0                	mov    %edx,%eax
801058fe:	f7 d0                	not    %eax
80105900:	83 e0 01             	and    $0x1,%eax
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
80105903:	83 e2 03             	and    $0x3,%edx
  f->readable = !(omode & O_WRONLY);
80105906:	88 47 08             	mov    %al,0x8(%edi)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
80105909:	0f 95 47 09          	setne  0x9(%edi)
  return fd;
}
8010590d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105910:	89 d8                	mov    %ebx,%eax
80105912:	5b                   	pop    %ebx
80105913:	5e                   	pop    %esi
80105914:	5f                   	pop    %edi
80105915:	5d                   	pop    %ebp
80105916:	c3                   	ret    
80105917:	89 f6                	mov    %esi,%esi
80105919:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    ip = create(path, T_FILE, 0, 0);
80105920:	83 ec 0c             	sub    $0xc,%esp
80105923:	8b 45 e0             	mov    -0x20(%ebp),%eax
80105926:	31 c9                	xor    %ecx,%ecx
80105928:	6a 00                	push   $0x0
8010592a:	ba 02 00 00 00       	mov    $0x2,%edx
8010592f:	e8 3c f8 ff ff       	call   80105170 <create>
    if(ip == 0){
80105934:	83 c4 10             	add    $0x10,%esp
80105937:	85 c0                	test   %eax,%eax
    ip = create(path, T_FILE, 0, 0);
80105939:	89 c6                	mov    %eax,%esi
    if(ip == 0){
8010593b:	0f 85 65 ff ff ff    	jne    801058a6 <sys_open+0x76>
      end_op();
80105941:	e8 4a db ff ff       	call   80103490 <end_op>
      return -1;
80105946:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
8010594b:	eb c0                	jmp    8010590d <sys_open+0xdd>
8010594d:	8d 76 00             	lea    0x0(%esi),%esi
    if(ip->type == T_DIR && omode != O_RDONLY){
80105950:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80105953:	85 c9                	test   %ecx,%ecx
80105955:	0f 84 4b ff ff ff    	je     801058a6 <sys_open+0x76>
    iunlockput(ip);
8010595b:	83 ec 0c             	sub    $0xc,%esp
8010595e:	56                   	push   %esi
8010595f:	e8 0c c5 ff ff       	call   80101e70 <iunlockput>
    end_op();
80105964:	e8 27 db ff ff       	call   80103490 <end_op>
    return -1;
80105969:	83 c4 10             	add    $0x10,%esp
8010596c:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80105971:	eb 9a                	jmp    8010590d <sys_open+0xdd>
80105973:	90                   	nop
80105974:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      fileclose(f);
80105978:	83 ec 0c             	sub    $0xc,%esp
8010597b:	57                   	push   %edi
8010597c:	e8 bf b4 ff ff       	call   80100e40 <fileclose>
80105981:	83 c4 10             	add    $0x10,%esp
80105984:	eb d5                	jmp    8010595b <sys_open+0x12b>
80105986:	8d 76 00             	lea    0x0(%esi),%esi
80105989:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80105990 <sys_mkdir>:

int
sys_mkdir(void)
{
80105990:	55                   	push   %ebp
80105991:	89 e5                	mov    %esp,%ebp
80105993:	83 ec 18             	sub    $0x18,%esp
  char *path;
  struct inode *ip;

  begin_op();
80105996:	e8 85 da ff ff       	call   80103420 <begin_op>
  if(argstr(0, &path) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
8010599b:	8d 45 f4             	lea    -0xc(%ebp),%eax
8010599e:	83 ec 08             	sub    $0x8,%esp
801059a1:	50                   	push   %eax
801059a2:	6a 00                	push   $0x0
801059a4:	e8 d7 f6 ff ff       	call   80105080 <argstr>
801059a9:	83 c4 10             	add    $0x10,%esp
801059ac:	85 c0                	test   %eax,%eax
801059ae:	78 30                	js     801059e0 <sys_mkdir+0x50>
801059b0:	83 ec 0c             	sub    $0xc,%esp
801059b3:	8b 45 f4             	mov    -0xc(%ebp),%eax
801059b6:	31 c9                	xor    %ecx,%ecx
801059b8:	6a 00                	push   $0x0
801059ba:	ba 01 00 00 00       	mov    $0x1,%edx
801059bf:	e8 ac f7 ff ff       	call   80105170 <create>
801059c4:	83 c4 10             	add    $0x10,%esp
801059c7:	85 c0                	test   %eax,%eax
801059c9:	74 15                	je     801059e0 <sys_mkdir+0x50>
    end_op();
    return -1;
  }
  iunlockput(ip);
801059cb:	83 ec 0c             	sub    $0xc,%esp
801059ce:	50                   	push   %eax
801059cf:	e8 9c c4 ff ff       	call   80101e70 <iunlockput>
  end_op();
801059d4:	e8 b7 da ff ff       	call   80103490 <end_op>
  return 0;
801059d9:	83 c4 10             	add    $0x10,%esp
801059dc:	31 c0                	xor    %eax,%eax
}
801059de:	c9                   	leave  
801059df:	c3                   	ret    
    end_op();
801059e0:	e8 ab da ff ff       	call   80103490 <end_op>
    return -1;
801059e5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801059ea:	c9                   	leave  
801059eb:	c3                   	ret    
801059ec:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

801059f0 <sys_mknod>:

int
sys_mknod(void)
{
801059f0:	55                   	push   %ebp
801059f1:	89 e5                	mov    %esp,%ebp
801059f3:	83 ec 18             	sub    $0x18,%esp
  struct inode *ip;
  char *path;
  int major, minor;

  begin_op();
801059f6:	e8 25 da ff ff       	call   80103420 <begin_op>
  if((argstr(0, &path)) < 0 ||
801059fb:	8d 45 ec             	lea    -0x14(%ebp),%eax
801059fe:	83 ec 08             	sub    $0x8,%esp
80105a01:	50                   	push   %eax
80105a02:	6a 00                	push   $0x0
80105a04:	e8 77 f6 ff ff       	call   80105080 <argstr>
80105a09:	83 c4 10             	add    $0x10,%esp
80105a0c:	85 c0                	test   %eax,%eax
80105a0e:	78 60                	js     80105a70 <sys_mknod+0x80>
     argint(1, &major) < 0 ||
80105a10:	8d 45 f0             	lea    -0x10(%ebp),%eax
80105a13:	83 ec 08             	sub    $0x8,%esp
80105a16:	50                   	push   %eax
80105a17:	6a 01                	push   $0x1
80105a19:	e8 b2 f5 ff ff       	call   80104fd0 <argint>
  if((argstr(0, &path)) < 0 ||
80105a1e:	83 c4 10             	add    $0x10,%esp
80105a21:	85 c0                	test   %eax,%eax
80105a23:	78 4b                	js     80105a70 <sys_mknod+0x80>
     argint(2, &minor) < 0 ||
80105a25:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105a28:	83 ec 08             	sub    $0x8,%esp
80105a2b:	50                   	push   %eax
80105a2c:	6a 02                	push   $0x2
80105a2e:	e8 9d f5 ff ff       	call   80104fd0 <argint>
     argint(1, &major) < 0 ||
80105a33:	83 c4 10             	add    $0x10,%esp
80105a36:	85 c0                	test   %eax,%eax
80105a38:	78 36                	js     80105a70 <sys_mknod+0x80>
     (ip = create(path, T_DEV, major, minor)) == 0){
80105a3a:	0f bf 45 f4          	movswl -0xc(%ebp),%eax
     argint(2, &minor) < 0 ||
80105a3e:	83 ec 0c             	sub    $0xc,%esp
     (ip = create(path, T_DEV, major, minor)) == 0){
80105a41:	0f bf 4d f0          	movswl -0x10(%ebp),%ecx
     argint(2, &minor) < 0 ||
80105a45:	ba 03 00 00 00       	mov    $0x3,%edx
80105a4a:	50                   	push   %eax
80105a4b:	8b 45 ec             	mov    -0x14(%ebp),%eax
80105a4e:	e8 1d f7 ff ff       	call   80105170 <create>
80105a53:	83 c4 10             	add    $0x10,%esp
80105a56:	85 c0                	test   %eax,%eax
80105a58:	74 16                	je     80105a70 <sys_mknod+0x80>
    end_op();
    return -1;
  }
  iunlockput(ip);
80105a5a:	83 ec 0c             	sub    $0xc,%esp
80105a5d:	50                   	push   %eax
80105a5e:	e8 0d c4 ff ff       	call   80101e70 <iunlockput>
  end_op();
80105a63:	e8 28 da ff ff       	call   80103490 <end_op>
  return 0;
80105a68:	83 c4 10             	add    $0x10,%esp
80105a6b:	31 c0                	xor    %eax,%eax
}
80105a6d:	c9                   	leave  
80105a6e:	c3                   	ret    
80105a6f:	90                   	nop
    end_op();
80105a70:	e8 1b da ff ff       	call   80103490 <end_op>
    return -1;
80105a75:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105a7a:	c9                   	leave  
80105a7b:	c3                   	ret    
80105a7c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80105a80 <sys_chdir>:

int
sys_chdir(void)
{
80105a80:	55                   	push   %ebp
80105a81:	89 e5                	mov    %esp,%ebp
80105a83:	56                   	push   %esi
80105a84:	53                   	push   %ebx
80105a85:	83 ec 10             	sub    $0x10,%esp
  char *path;
  struct inode *ip;
  struct proc *curproc = myproc();
80105a88:	e8 d3 e5 ff ff       	call   80104060 <myproc>
80105a8d:	89 c6                	mov    %eax,%esi
  
  begin_op();
80105a8f:	e8 8c d9 ff ff       	call   80103420 <begin_op>
  if(argstr(0, &path) < 0 || (ip = namei(path)) == 0){
80105a94:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105a97:	83 ec 08             	sub    $0x8,%esp
80105a9a:	50                   	push   %eax
80105a9b:	6a 00                	push   $0x0
80105a9d:	e8 de f5 ff ff       	call   80105080 <argstr>
80105aa2:	83 c4 10             	add    $0x10,%esp
80105aa5:	85 c0                	test   %eax,%eax
80105aa7:	78 77                	js     80105b20 <sys_chdir+0xa0>
80105aa9:	83 ec 0c             	sub    $0xc,%esp
80105aac:	ff 75 f4             	pushl  -0xc(%ebp)
80105aaf:	e8 9c cc ff ff       	call   80102750 <namei>
80105ab4:	83 c4 10             	add    $0x10,%esp
80105ab7:	85 c0                	test   %eax,%eax
80105ab9:	89 c3                	mov    %eax,%ebx
80105abb:	74 63                	je     80105b20 <sys_chdir+0xa0>
    end_op();
    return -1;
  }
  ilock(ip);
80105abd:	83 ec 0c             	sub    $0xc,%esp
80105ac0:	50                   	push   %eax
80105ac1:	e8 9a bd ff ff       	call   80101860 <ilock>
  if(ip->type != T_DIR){
80105ac6:	83 c4 10             	add    $0x10,%esp
80105ac9:	66 83 7b 54 01       	cmpw   $0x1,0x54(%ebx)
80105ace:	75 30                	jne    80105b00 <sys_chdir+0x80>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
80105ad0:	83 ec 0c             	sub    $0xc,%esp
80105ad3:	53                   	push   %ebx
80105ad4:	e8 67 be ff ff       	call   80101940 <iunlock>
  iput(curproc->cwd);
80105ad9:	58                   	pop    %eax
80105ada:	ff 76 68             	pushl  0x68(%esi)
80105add:	e8 ae c0 ff ff       	call   80101b90 <iput>
  end_op();
80105ae2:	e8 a9 d9 ff ff       	call   80103490 <end_op>
  curproc->cwd = ip;
80105ae7:	89 5e 68             	mov    %ebx,0x68(%esi)
  return 0;
80105aea:	83 c4 10             	add    $0x10,%esp
80105aed:	31 c0                	xor    %eax,%eax
}
80105aef:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105af2:	5b                   	pop    %ebx
80105af3:	5e                   	pop    %esi
80105af4:	5d                   	pop    %ebp
80105af5:	c3                   	ret    
80105af6:	8d 76 00             	lea    0x0(%esi),%esi
80105af9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    iunlockput(ip);
80105b00:	83 ec 0c             	sub    $0xc,%esp
80105b03:	53                   	push   %ebx
80105b04:	e8 67 c3 ff ff       	call   80101e70 <iunlockput>
    end_op();
80105b09:	e8 82 d9 ff ff       	call   80103490 <end_op>
    return -1;
80105b0e:	83 c4 10             	add    $0x10,%esp
80105b11:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105b16:	eb d7                	jmp    80105aef <sys_chdir+0x6f>
80105b18:	90                   	nop
80105b19:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    end_op();
80105b20:	e8 6b d9 ff ff       	call   80103490 <end_op>
    return -1;
80105b25:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105b2a:	eb c3                	jmp    80105aef <sys_chdir+0x6f>
80105b2c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80105b30 <sys_exec>:

int
sys_exec(void)
{
80105b30:	55                   	push   %ebp
80105b31:	89 e5                	mov    %esp,%ebp
80105b33:	57                   	push   %edi
80105b34:	56                   	push   %esi
80105b35:	53                   	push   %ebx
  char *path, *argv[MAXARG];
  int i;
  uint uargv, uarg;

  if(argstr(0, &path) < 0 || argint(1, (int*)&uargv) < 0){
80105b36:	8d 85 5c ff ff ff    	lea    -0xa4(%ebp),%eax
{
80105b3c:	81 ec a4 00 00 00    	sub    $0xa4,%esp
  if(argstr(0, &path) < 0 || argint(1, (int*)&uargv) < 0){
80105b42:	50                   	push   %eax
80105b43:	6a 00                	push   $0x0
80105b45:	e8 36 f5 ff ff       	call   80105080 <argstr>
80105b4a:	83 c4 10             	add    $0x10,%esp
80105b4d:	85 c0                	test   %eax,%eax
80105b4f:	0f 88 87 00 00 00    	js     80105bdc <sys_exec+0xac>
80105b55:	8d 85 60 ff ff ff    	lea    -0xa0(%ebp),%eax
80105b5b:	83 ec 08             	sub    $0x8,%esp
80105b5e:	50                   	push   %eax
80105b5f:	6a 01                	push   $0x1
80105b61:	e8 6a f4 ff ff       	call   80104fd0 <argint>
80105b66:	83 c4 10             	add    $0x10,%esp
80105b69:	85 c0                	test   %eax,%eax
80105b6b:	78 6f                	js     80105bdc <sys_exec+0xac>
    return -1;
  }
  memset(argv, 0, sizeof(argv));
80105b6d:	8d 85 68 ff ff ff    	lea    -0x98(%ebp),%eax
80105b73:	83 ec 04             	sub    $0x4,%esp
  for(i=0;; i++){
80105b76:	31 db                	xor    %ebx,%ebx
  memset(argv, 0, sizeof(argv));
80105b78:	68 80 00 00 00       	push   $0x80
80105b7d:	6a 00                	push   $0x0
80105b7f:	8d bd 64 ff ff ff    	lea    -0x9c(%ebp),%edi
80105b85:	50                   	push   %eax
80105b86:	e8 45 f1 ff ff       	call   80104cd0 <memset>
80105b8b:	83 c4 10             	add    $0x10,%esp
80105b8e:	eb 2c                	jmp    80105bbc <sys_exec+0x8c>
    if(i >= NELEM(argv))
      return -1;
    if(fetchint(uargv+4*i, (int*)&uarg) < 0)
      return -1;
    if(uarg == 0){
80105b90:	8b 85 64 ff ff ff    	mov    -0x9c(%ebp),%eax
80105b96:	85 c0                	test   %eax,%eax
80105b98:	74 56                	je     80105bf0 <sys_exec+0xc0>
      argv[i] = 0;
      break;
    }
    if(fetchstr(uarg, &argv[i]) < 0)
80105b9a:	8d 8d 68 ff ff ff    	lea    -0x98(%ebp),%ecx
80105ba0:	83 ec 08             	sub    $0x8,%esp
80105ba3:	8d 14 31             	lea    (%ecx,%esi,1),%edx
80105ba6:	52                   	push   %edx
80105ba7:	50                   	push   %eax
80105ba8:	e8 b3 f3 ff ff       	call   80104f60 <fetchstr>
80105bad:	83 c4 10             	add    $0x10,%esp
80105bb0:	85 c0                	test   %eax,%eax
80105bb2:	78 28                	js     80105bdc <sys_exec+0xac>
  for(i=0;; i++){
80105bb4:	83 c3 01             	add    $0x1,%ebx
    if(i >= NELEM(argv))
80105bb7:	83 fb 20             	cmp    $0x20,%ebx
80105bba:	74 20                	je     80105bdc <sys_exec+0xac>
    if(fetchint(uargv+4*i, (int*)&uarg) < 0)
80105bbc:	8b 85 60 ff ff ff    	mov    -0xa0(%ebp),%eax
80105bc2:	8d 34 9d 00 00 00 00 	lea    0x0(,%ebx,4),%esi
80105bc9:	83 ec 08             	sub    $0x8,%esp
80105bcc:	57                   	push   %edi
80105bcd:	01 f0                	add    %esi,%eax
80105bcf:	50                   	push   %eax
80105bd0:	e8 4b f3 ff ff       	call   80104f20 <fetchint>
80105bd5:	83 c4 10             	add    $0x10,%esp
80105bd8:	85 c0                	test   %eax,%eax
80105bda:	79 b4                	jns    80105b90 <sys_exec+0x60>
      return -1;
  }
  return exec(path, argv);
}
80105bdc:	8d 65 f4             	lea    -0xc(%ebp),%esp
    return -1;
80105bdf:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105be4:	5b                   	pop    %ebx
80105be5:	5e                   	pop    %esi
80105be6:	5f                   	pop    %edi
80105be7:	5d                   	pop    %ebp
80105be8:	c3                   	ret    
80105be9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return exec(path, argv);
80105bf0:	8d 85 68 ff ff ff    	lea    -0x98(%ebp),%eax
80105bf6:	83 ec 08             	sub    $0x8,%esp
      argv[i] = 0;
80105bf9:	c7 84 9d 68 ff ff ff 	movl   $0x0,-0x98(%ebp,%ebx,4)
80105c00:	00 00 00 00 
  return exec(path, argv);
80105c04:	50                   	push   %eax
80105c05:	ff b5 5c ff ff ff    	pushl  -0xa4(%ebp)
80105c0b:	e8 00 ae ff ff       	call   80100a10 <exec>
80105c10:	83 c4 10             	add    $0x10,%esp
}
80105c13:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105c16:	5b                   	pop    %ebx
80105c17:	5e                   	pop    %esi
80105c18:	5f                   	pop    %edi
80105c19:	5d                   	pop    %ebp
80105c1a:	c3                   	ret    
80105c1b:	90                   	nop
80105c1c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80105c20 <sys_pipe>:

int
sys_pipe(void)
{
80105c20:	55                   	push   %ebp
80105c21:	89 e5                	mov    %esp,%ebp
80105c23:	57                   	push   %edi
80105c24:	56                   	push   %esi
80105c25:	53                   	push   %ebx
  int *fd;
  struct file *rf, *wf;
  int fd0, fd1;

  if(argptr(0, (void*)&fd, 2*sizeof(fd[0])) < 0)
80105c26:	8d 45 dc             	lea    -0x24(%ebp),%eax
{
80105c29:	83 ec 20             	sub    $0x20,%esp
  if(argptr(0, (void*)&fd, 2*sizeof(fd[0])) < 0)
80105c2c:	6a 08                	push   $0x8
80105c2e:	50                   	push   %eax
80105c2f:	6a 00                	push   $0x0
80105c31:	e8 ea f3 ff ff       	call   80105020 <argptr>
80105c36:	83 c4 10             	add    $0x10,%esp
80105c39:	85 c0                	test   %eax,%eax
80105c3b:	0f 88 ae 00 00 00    	js     80105cef <sys_pipe+0xcf>
    return -1;
  if(pipealloc(&rf, &wf) < 0)
80105c41:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80105c44:	83 ec 08             	sub    $0x8,%esp
80105c47:	50                   	push   %eax
80105c48:	8d 45 e0             	lea    -0x20(%ebp),%eax
80105c4b:	50                   	push   %eax
80105c4c:	e8 6f de ff ff       	call   80103ac0 <pipealloc>
80105c51:	83 c4 10             	add    $0x10,%esp
80105c54:	85 c0                	test   %eax,%eax
80105c56:	0f 88 93 00 00 00    	js     80105cef <sys_pipe+0xcf>
    return -1;
  fd0 = -1;
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
80105c5c:	8b 7d e0             	mov    -0x20(%ebp),%edi
  for(fd = 0; fd < NOFILE; fd++){
80105c5f:	31 db                	xor    %ebx,%ebx
  struct proc *curproc = myproc();
80105c61:	e8 fa e3 ff ff       	call   80104060 <myproc>
80105c66:	eb 10                	jmp    80105c78 <sys_pipe+0x58>
80105c68:	90                   	nop
80105c69:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  for(fd = 0; fd < NOFILE; fd++){
80105c70:	83 c3 01             	add    $0x1,%ebx
80105c73:	83 fb 10             	cmp    $0x10,%ebx
80105c76:	74 60                	je     80105cd8 <sys_pipe+0xb8>
    if(curproc->ofile[fd] == 0){
80105c78:	8b 74 98 28          	mov    0x28(%eax,%ebx,4),%esi
80105c7c:	85 f6                	test   %esi,%esi
80105c7e:	75 f0                	jne    80105c70 <sys_pipe+0x50>
      curproc->ofile[fd] = f;
80105c80:	8d 73 08             	lea    0x8(%ebx),%esi
80105c83:	89 7c b0 08          	mov    %edi,0x8(%eax,%esi,4)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
80105c87:	8b 7d e4             	mov    -0x1c(%ebp),%edi
  struct proc *curproc = myproc();
80105c8a:	e8 d1 e3 ff ff       	call   80104060 <myproc>
  for(fd = 0; fd < NOFILE; fd++){
80105c8f:	31 d2                	xor    %edx,%edx
80105c91:	eb 0d                	jmp    80105ca0 <sys_pipe+0x80>
80105c93:	90                   	nop
80105c94:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80105c98:	83 c2 01             	add    $0x1,%edx
80105c9b:	83 fa 10             	cmp    $0x10,%edx
80105c9e:	74 28                	je     80105cc8 <sys_pipe+0xa8>
    if(curproc->ofile[fd] == 0){
80105ca0:	8b 4c 90 28          	mov    0x28(%eax,%edx,4),%ecx
80105ca4:	85 c9                	test   %ecx,%ecx
80105ca6:	75 f0                	jne    80105c98 <sys_pipe+0x78>
      curproc->ofile[fd] = f;
80105ca8:	89 7c 90 28          	mov    %edi,0x28(%eax,%edx,4)
      myproc()->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  fd[0] = fd0;
80105cac:	8b 45 dc             	mov    -0x24(%ebp),%eax
80105caf:	89 18                	mov    %ebx,(%eax)
  fd[1] = fd1;
80105cb1:	8b 45 dc             	mov    -0x24(%ebp),%eax
80105cb4:	89 50 04             	mov    %edx,0x4(%eax)
  return 0;
80105cb7:	31 c0                	xor    %eax,%eax
}
80105cb9:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105cbc:	5b                   	pop    %ebx
80105cbd:	5e                   	pop    %esi
80105cbe:	5f                   	pop    %edi
80105cbf:	5d                   	pop    %ebp
80105cc0:	c3                   	ret    
80105cc1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      myproc()->ofile[fd0] = 0;
80105cc8:	e8 93 e3 ff ff       	call   80104060 <myproc>
80105ccd:	c7 44 b0 08 00 00 00 	movl   $0x0,0x8(%eax,%esi,4)
80105cd4:	00 
80105cd5:	8d 76 00             	lea    0x0(%esi),%esi
    fileclose(rf);
80105cd8:	83 ec 0c             	sub    $0xc,%esp
80105cdb:	ff 75 e0             	pushl  -0x20(%ebp)
80105cde:	e8 5d b1 ff ff       	call   80100e40 <fileclose>
    fileclose(wf);
80105ce3:	58                   	pop    %eax
80105ce4:	ff 75 e4             	pushl  -0x1c(%ebp)
80105ce7:	e8 54 b1 ff ff       	call   80100e40 <fileclose>
    return -1;
80105cec:	83 c4 10             	add    $0x10,%esp
80105cef:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105cf4:	eb c3                	jmp    80105cb9 <sys_pipe+0x99>
80105cf6:	8d 76 00             	lea    0x0(%esi),%esi
80105cf9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80105d00 <sys_cpcow>:

// SJ
int
sys_cpcow(void)
{
80105d00:	55                   	push   %ebp
  struct file *fds, *fdd;

  if((argfd(0, 0, &fds) < 0) || argfd(1, 0, &fdd) < 0)
80105d01:	31 d2                	xor    %edx,%edx
80105d03:	31 c0                	xor    %eax,%eax
{
80105d05:	89 e5                	mov    %esp,%ebp
80105d07:	83 ec 18             	sub    $0x18,%esp
  if((argfd(0, 0, &fds) < 0) || argfd(1, 0, &fdd) < 0)
80105d0a:	8d 4d f0             	lea    -0x10(%ebp),%ecx
80105d0d:	e8 0e f4 ff ff       	call   80105120 <argfd>
80105d12:	85 c0                	test   %eax,%eax
80105d14:	78 2a                	js     80105d40 <sys_cpcow+0x40>
80105d16:	8d 4d f4             	lea    -0xc(%ebp),%ecx
80105d19:	31 d2                	xor    %edx,%edx
80105d1b:	b8 01 00 00 00       	mov    $0x1,%eax
80105d20:	e8 fb f3 ff ff       	call   80105120 <argfd>
80105d25:	85 c0                	test   %eax,%eax
80105d27:	78 17                	js     80105d40 <sys_cpcow+0x40>
    return -1;
  int n = filecopy(fds, fdd);
80105d29:	83 ec 08             	sub    $0x8,%esp
80105d2c:	ff 75 f4             	pushl  -0xc(%ebp)
80105d2f:	ff 75 f0             	pushl  -0x10(%ebp)
80105d32:	e8 d9 b3 ff ff       	call   80101110 <filecopy>
  return n;
80105d37:	83 c4 10             	add    $0x10,%esp
80105d3a:	c9                   	leave  
80105d3b:	c3                   	ret    
80105d3c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80105d40:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105d45:	c9                   	leave  
80105d46:	c3                   	ret    
80105d47:	66 90                	xchg   %ax,%ax
80105d49:	66 90                	xchg   %ax,%ax
80105d4b:	66 90                	xchg   %ax,%ax
80105d4d:	66 90                	xchg   %ax,%ax
80105d4f:	90                   	nop

80105d50 <sys_fork>:
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
80105d50:	55                   	push   %ebp
80105d51:	89 e5                	mov    %esp,%ebp
  return fork();
}
80105d53:	5d                   	pop    %ebp
  return fork();
80105d54:	e9 a7 e4 ff ff       	jmp    80104200 <fork>
80105d59:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80105d60 <sys_exit>:

int
sys_exit(void)
{
80105d60:	55                   	push   %ebp
80105d61:	89 e5                	mov    %esp,%ebp
80105d63:	83 ec 08             	sub    $0x8,%esp
  exit();
80105d66:	e8 15 e7 ff ff       	call   80104480 <exit>
  return 0;  // not reached
}
80105d6b:	31 c0                	xor    %eax,%eax
80105d6d:	c9                   	leave  
80105d6e:	c3                   	ret    
80105d6f:	90                   	nop

80105d70 <sys_wait>:

int
sys_wait(void)
{
80105d70:	55                   	push   %ebp
80105d71:	89 e5                	mov    %esp,%ebp
  return wait();
}
80105d73:	5d                   	pop    %ebp
  return wait();
80105d74:	e9 47 e9 ff ff       	jmp    801046c0 <wait>
80105d79:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80105d80 <sys_kill>:

int
sys_kill(void)
{
80105d80:	55                   	push   %ebp
80105d81:	89 e5                	mov    %esp,%ebp
80105d83:	83 ec 20             	sub    $0x20,%esp
  int pid;

  if(argint(0, &pid) < 0)
80105d86:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105d89:	50                   	push   %eax
80105d8a:	6a 00                	push   $0x0
80105d8c:	e8 3f f2 ff ff       	call   80104fd0 <argint>
80105d91:	83 c4 10             	add    $0x10,%esp
80105d94:	85 c0                	test   %eax,%eax
80105d96:	78 18                	js     80105db0 <sys_kill+0x30>
    return -1;
  return kill(pid);
80105d98:	83 ec 0c             	sub    $0xc,%esp
80105d9b:	ff 75 f4             	pushl  -0xc(%ebp)
80105d9e:	e8 6d ea ff ff       	call   80104810 <kill>
80105da3:	83 c4 10             	add    $0x10,%esp
}
80105da6:	c9                   	leave  
80105da7:	c3                   	ret    
80105da8:	90                   	nop
80105da9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80105db0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105db5:	c9                   	leave  
80105db6:	c3                   	ret    
80105db7:	89 f6                	mov    %esi,%esi
80105db9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80105dc0 <sys_getpid>:

int
sys_getpid(void)
{
80105dc0:	55                   	push   %ebp
80105dc1:	89 e5                	mov    %esp,%ebp
80105dc3:	83 ec 08             	sub    $0x8,%esp
  return myproc()->pid;
80105dc6:	e8 95 e2 ff ff       	call   80104060 <myproc>
80105dcb:	8b 40 10             	mov    0x10(%eax),%eax
}
80105dce:	c9                   	leave  
80105dcf:	c3                   	ret    

80105dd0 <sys_sbrk>:

int
sys_sbrk(void)
{
80105dd0:	55                   	push   %ebp
80105dd1:	89 e5                	mov    %esp,%ebp
80105dd3:	53                   	push   %ebx
  int addr;
  int n;

  if(argint(0, &n) < 0)
80105dd4:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
80105dd7:	83 ec 1c             	sub    $0x1c,%esp
  if(argint(0, &n) < 0)
80105dda:	50                   	push   %eax
80105ddb:	6a 00                	push   $0x0
80105ddd:	e8 ee f1 ff ff       	call   80104fd0 <argint>
80105de2:	83 c4 10             	add    $0x10,%esp
80105de5:	85 c0                	test   %eax,%eax
80105de7:	78 27                	js     80105e10 <sys_sbrk+0x40>
    return -1;
  addr = myproc()->sz;
80105de9:	e8 72 e2 ff ff       	call   80104060 <myproc>
  if(growproc(n) < 0)
80105dee:	83 ec 0c             	sub    $0xc,%esp
  addr = myproc()->sz;
80105df1:	8b 18                	mov    (%eax),%ebx
  if(growproc(n) < 0)
80105df3:	ff 75 f4             	pushl  -0xc(%ebp)
80105df6:	e8 85 e3 ff ff       	call   80104180 <growproc>
80105dfb:	83 c4 10             	add    $0x10,%esp
80105dfe:	85 c0                	test   %eax,%eax
80105e00:	78 0e                	js     80105e10 <sys_sbrk+0x40>
    return -1;
  return addr;
}
80105e02:	89 d8                	mov    %ebx,%eax
80105e04:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105e07:	c9                   	leave  
80105e08:	c3                   	ret    
80105e09:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80105e10:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80105e15:	eb eb                	jmp    80105e02 <sys_sbrk+0x32>
80105e17:	89 f6                	mov    %esi,%esi
80105e19:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80105e20 <sys_sleep>:

int
sys_sleep(void)
{
80105e20:	55                   	push   %ebp
80105e21:	89 e5                	mov    %esp,%ebp
80105e23:	53                   	push   %ebx
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
80105e24:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
80105e27:	83 ec 1c             	sub    $0x1c,%esp
  if(argint(0, &n) < 0)
80105e2a:	50                   	push   %eax
80105e2b:	6a 00                	push   $0x0
80105e2d:	e8 9e f1 ff ff       	call   80104fd0 <argint>
80105e32:	83 c4 10             	add    $0x10,%esp
80105e35:	85 c0                	test   %eax,%eax
80105e37:	0f 88 8a 00 00 00    	js     80105ec7 <sys_sleep+0xa7>
    return -1;
  acquire(&tickslock);
80105e3d:	83 ec 0c             	sub    $0xc,%esp
80105e40:	68 60 7a 11 80       	push   $0x80117a60
80105e45:	e8 76 ed ff ff       	call   80104bc0 <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
80105e4a:	8b 55 f4             	mov    -0xc(%ebp),%edx
80105e4d:	83 c4 10             	add    $0x10,%esp
  ticks0 = ticks;
80105e50:	8b 1d a0 82 11 80    	mov    0x801182a0,%ebx
  while(ticks - ticks0 < n){
80105e56:	85 d2                	test   %edx,%edx
80105e58:	75 27                	jne    80105e81 <sys_sleep+0x61>
80105e5a:	eb 54                	jmp    80105eb0 <sys_sleep+0x90>
80105e5c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
80105e60:	83 ec 08             	sub    $0x8,%esp
80105e63:	68 60 7a 11 80       	push   $0x80117a60
80105e68:	68 a0 82 11 80       	push   $0x801182a0
80105e6d:	e8 8e e7 ff ff       	call   80104600 <sleep>
  while(ticks - ticks0 < n){
80105e72:	a1 a0 82 11 80       	mov    0x801182a0,%eax
80105e77:	83 c4 10             	add    $0x10,%esp
80105e7a:	29 d8                	sub    %ebx,%eax
80105e7c:	3b 45 f4             	cmp    -0xc(%ebp),%eax
80105e7f:	73 2f                	jae    80105eb0 <sys_sleep+0x90>
    if(myproc()->killed){
80105e81:	e8 da e1 ff ff       	call   80104060 <myproc>
80105e86:	8b 40 24             	mov    0x24(%eax),%eax
80105e89:	85 c0                	test   %eax,%eax
80105e8b:	74 d3                	je     80105e60 <sys_sleep+0x40>
      release(&tickslock);
80105e8d:	83 ec 0c             	sub    $0xc,%esp
80105e90:	68 60 7a 11 80       	push   $0x80117a60
80105e95:	e8 e6 ed ff ff       	call   80104c80 <release>
      return -1;
80105e9a:	83 c4 10             	add    $0x10,%esp
80105e9d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  }
  release(&tickslock);
  return 0;
}
80105ea2:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105ea5:	c9                   	leave  
80105ea6:	c3                   	ret    
80105ea7:	89 f6                	mov    %esi,%esi
80105ea9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
  release(&tickslock);
80105eb0:	83 ec 0c             	sub    $0xc,%esp
80105eb3:	68 60 7a 11 80       	push   $0x80117a60
80105eb8:	e8 c3 ed ff ff       	call   80104c80 <release>
  return 0;
80105ebd:	83 c4 10             	add    $0x10,%esp
80105ec0:	31 c0                	xor    %eax,%eax
}
80105ec2:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105ec5:	c9                   	leave  
80105ec6:	c3                   	ret    
    return -1;
80105ec7:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105ecc:	eb f4                	jmp    80105ec2 <sys_sleep+0xa2>
80105ece:	66 90                	xchg   %ax,%ax

80105ed0 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
80105ed0:	55                   	push   %ebp
80105ed1:	89 e5                	mov    %esp,%ebp
80105ed3:	53                   	push   %ebx
80105ed4:	83 ec 10             	sub    $0x10,%esp
  uint xticks;

  acquire(&tickslock);
80105ed7:	68 60 7a 11 80       	push   $0x80117a60
80105edc:	e8 df ec ff ff       	call   80104bc0 <acquire>
  xticks = ticks;
80105ee1:	8b 1d a0 82 11 80    	mov    0x801182a0,%ebx
  release(&tickslock);
80105ee7:	c7 04 24 60 7a 11 80 	movl   $0x80117a60,(%esp)
80105eee:	e8 8d ed ff ff       	call   80104c80 <release>
  return xticks;
}
80105ef3:	89 d8                	mov    %ebx,%eax
80105ef5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105ef8:	c9                   	leave  
80105ef9:	c3                   	ret    

80105efa <alltraps>:

  # vectors.S sends all traps here.
.globl alltraps
alltraps:
  # Build trap frame.
  pushl %ds
80105efa:	1e                   	push   %ds
  pushl %es
80105efb:	06                   	push   %es
  pushl %fs
80105efc:	0f a0                	push   %fs
  pushl %gs
80105efe:	0f a8                	push   %gs
  pushal
80105f00:	60                   	pusha  
  
  # Set up data segments.
  movw $(SEG_KDATA<<3), %ax
80105f01:	66 b8 10 00          	mov    $0x10,%ax
  movw %ax, %ds
80105f05:	8e d8                	mov    %eax,%ds
  movw %ax, %es
80105f07:	8e c0                	mov    %eax,%es

  # Call trap(tf), where tf=%esp
  pushl %esp
80105f09:	54                   	push   %esp
  call trap
80105f0a:	e8 c1 00 00 00       	call   80105fd0 <trap>
  addl $4, %esp
80105f0f:	83 c4 04             	add    $0x4,%esp

80105f12 <trapret>:

  # Return falls through to trapret...
.globl trapret
trapret:
  popal
80105f12:	61                   	popa   
  popl %gs
80105f13:	0f a9                	pop    %gs
  popl %fs
80105f15:	0f a1                	pop    %fs
  popl %es
80105f17:	07                   	pop    %es
  popl %ds
80105f18:	1f                   	pop    %ds
  addl $0x8, %esp  # trapno and errcode
80105f19:	83 c4 08             	add    $0x8,%esp
  iret
80105f1c:	cf                   	iret   
80105f1d:	66 90                	xchg   %ax,%ax
80105f1f:	90                   	nop

80105f20 <tvinit>:
struct spinlock tickslock;
uint ticks;

void
tvinit(void)
{
80105f20:	55                   	push   %ebp
  int i;

  for(i = 0; i < 256; i++)
80105f21:	31 c0                	xor    %eax,%eax
{
80105f23:	89 e5                	mov    %esp,%ebp
80105f25:	83 ec 08             	sub    $0x8,%esp
80105f28:	90                   	nop
80105f29:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
80105f30:	8b 14 85 08 b0 10 80 	mov    -0x7fef4ff8(,%eax,4),%edx
80105f37:	c7 04 c5 a2 7a 11 80 	movl   $0x8e000008,-0x7fee855e(,%eax,8)
80105f3e:	08 00 00 8e 
80105f42:	66 89 14 c5 a0 7a 11 	mov    %dx,-0x7fee8560(,%eax,8)
80105f49:	80 
80105f4a:	c1 ea 10             	shr    $0x10,%edx
80105f4d:	66 89 14 c5 a6 7a 11 	mov    %dx,-0x7fee855a(,%eax,8)
80105f54:	80 
  for(i = 0; i < 256; i++)
80105f55:	83 c0 01             	add    $0x1,%eax
80105f58:	3d 00 01 00 00       	cmp    $0x100,%eax
80105f5d:	75 d1                	jne    80105f30 <tvinit+0x10>
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
80105f5f:	a1 08 b1 10 80       	mov    0x8010b108,%eax

  initlock(&tickslock, "time");
80105f64:	83 ec 08             	sub    $0x8,%esp
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
80105f67:	c7 05 a2 7c 11 80 08 	movl   $0xef000008,0x80117ca2
80105f6e:	00 00 ef 
  initlock(&tickslock, "time");
80105f71:	68 fd 7f 10 80       	push   $0x80107ffd
80105f76:	68 60 7a 11 80       	push   $0x80117a60
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
80105f7b:	66 a3 a0 7c 11 80    	mov    %ax,0x80117ca0
80105f81:	c1 e8 10             	shr    $0x10,%eax
80105f84:	66 a3 a6 7c 11 80    	mov    %ax,0x80117ca6
  initlock(&tickslock, "time");
80105f8a:	e8 f1 ea ff ff       	call   80104a80 <initlock>
}
80105f8f:	83 c4 10             	add    $0x10,%esp
80105f92:	c9                   	leave  
80105f93:	c3                   	ret    
80105f94:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80105f9a:	8d bf 00 00 00 00    	lea    0x0(%edi),%edi

80105fa0 <idtinit>:

void
idtinit(void)
{
80105fa0:	55                   	push   %ebp
  pd[0] = size-1;
80105fa1:	b8 ff 07 00 00       	mov    $0x7ff,%eax
80105fa6:	89 e5                	mov    %esp,%ebp
80105fa8:	83 ec 10             	sub    $0x10,%esp
80105fab:	66 89 45 fa          	mov    %ax,-0x6(%ebp)
  pd[1] = (uint)p;
80105faf:	b8 a0 7a 11 80       	mov    $0x80117aa0,%eax
80105fb4:	66 89 45 fc          	mov    %ax,-0x4(%ebp)
  pd[2] = (uint)p >> 16;
80105fb8:	c1 e8 10             	shr    $0x10,%eax
80105fbb:	66 89 45 fe          	mov    %ax,-0x2(%ebp)
  asm volatile("lidt (%0)" : : "r" (pd));
80105fbf:	8d 45 fa             	lea    -0x6(%ebp),%eax
80105fc2:	0f 01 18             	lidtl  (%eax)
  lidt(idt, sizeof(idt));
}
80105fc5:	c9                   	leave  
80105fc6:	c3                   	ret    
80105fc7:	89 f6                	mov    %esi,%esi
80105fc9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80105fd0 <trap>:

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{
80105fd0:	55                   	push   %ebp
80105fd1:	89 e5                	mov    %esp,%ebp
80105fd3:	57                   	push   %edi
80105fd4:	56                   	push   %esi
80105fd5:	53                   	push   %ebx
80105fd6:	83 ec 1c             	sub    $0x1c,%esp
80105fd9:	8b 7d 08             	mov    0x8(%ebp),%edi
  if(tf->trapno == T_SYSCALL){
80105fdc:	8b 47 30             	mov    0x30(%edi),%eax
80105fdf:	83 f8 40             	cmp    $0x40,%eax
80105fe2:	0f 84 f0 00 00 00    	je     801060d8 <trap+0x108>
    if(myproc()->killed)
      exit();
    return;
  }

  switch(tf->trapno){
80105fe8:	83 e8 20             	sub    $0x20,%eax
80105feb:	83 f8 1f             	cmp    $0x1f,%eax
80105fee:	77 10                	ja     80106000 <trap+0x30>
80105ff0:	ff 24 85 a4 80 10 80 	jmp    *-0x7fef7f5c(,%eax,4)
80105ff7:	89 f6                	mov    %esi,%esi
80105ff9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    lapiceoi();
    break;

  //PAGEBREAK: 13
  default:
    if(myproc() == 0 || (tf->cs&3) == 0){
80106000:	e8 5b e0 ff ff       	call   80104060 <myproc>
80106005:	85 c0                	test   %eax,%eax
80106007:	8b 5f 38             	mov    0x38(%edi),%ebx
8010600a:	0f 84 14 02 00 00    	je     80106224 <trap+0x254>
80106010:	f6 47 3c 03          	testb  $0x3,0x3c(%edi)
80106014:	0f 84 0a 02 00 00    	je     80106224 <trap+0x254>

static inline uint
rcr2(void)
{
  uint val;
  asm volatile("movl %%cr2,%0" : "=r" (val));
8010601a:	0f 20 d1             	mov    %cr2,%ecx
8010601d:	89 4d d8             	mov    %ecx,-0x28(%ebp)
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
              tf->trapno, cpuid(), tf->eip, rcr2());
      panic("trap");
    }
    // In user space, assume process misbehaved.
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80106020:	e8 1b e0 ff ff       	call   80104040 <cpuid>
80106025:	89 45 dc             	mov    %eax,-0x24(%ebp)
80106028:	8b 47 34             	mov    0x34(%edi),%eax
8010602b:	8b 77 30             	mov    0x30(%edi),%esi
8010602e:	89 45 e4             	mov    %eax,-0x1c(%ebp)
            "eip 0x%x addr 0x%x--kill proc\n",
            myproc()->pid, myproc()->name, tf->trapno,
80106031:	e8 2a e0 ff ff       	call   80104060 <myproc>
80106036:	89 45 e0             	mov    %eax,-0x20(%ebp)
80106039:	e8 22 e0 ff ff       	call   80104060 <myproc>
    cprintf("pid %d %s: trap %d err %d on cpu %d "
8010603e:	8b 4d d8             	mov    -0x28(%ebp),%ecx
80106041:	8b 55 dc             	mov    -0x24(%ebp),%edx
80106044:	51                   	push   %ecx
80106045:	53                   	push   %ebx
80106046:	52                   	push   %edx
            myproc()->pid, myproc()->name, tf->trapno,
80106047:	8b 55 e0             	mov    -0x20(%ebp),%edx
    cprintf("pid %d %s: trap %d err %d on cpu %d "
8010604a:	ff 75 e4             	pushl  -0x1c(%ebp)
8010604d:	56                   	push   %esi
            myproc()->pid, myproc()->name, tf->trapno,
8010604e:	83 c2 6c             	add    $0x6c,%edx
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80106051:	52                   	push   %edx
80106052:	ff 70 10             	pushl  0x10(%eax)
80106055:	68 60 80 10 80       	push   $0x80108060
8010605a:	e8 01 a6 ff ff       	call   80100660 <cprintf>
            tf->err, cpuid(), tf->eip, rcr2());
    myproc()->killed = 1;
8010605f:	83 c4 20             	add    $0x20,%esp
80106062:	e8 f9 df ff ff       	call   80104060 <myproc>
80106067:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
8010606e:	e8 ed df ff ff       	call   80104060 <myproc>
80106073:	85 c0                	test   %eax,%eax
80106075:	74 1d                	je     80106094 <trap+0xc4>
80106077:	e8 e4 df ff ff       	call   80104060 <myproc>
8010607c:	8b 50 24             	mov    0x24(%eax),%edx
8010607f:	85 d2                	test   %edx,%edx
80106081:	74 11                	je     80106094 <trap+0xc4>
80106083:	0f b7 47 3c          	movzwl 0x3c(%edi),%eax
80106087:	83 e0 03             	and    $0x3,%eax
8010608a:	66 83 f8 03          	cmp    $0x3,%ax
8010608e:	0f 84 4c 01 00 00    	je     801061e0 <trap+0x210>
    exit();

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  if(myproc() && myproc()->state == RUNNING &&
80106094:	e8 c7 df ff ff       	call   80104060 <myproc>
80106099:	85 c0                	test   %eax,%eax
8010609b:	74 0b                	je     801060a8 <trap+0xd8>
8010609d:	e8 be df ff ff       	call   80104060 <myproc>
801060a2:	83 78 0c 04          	cmpl   $0x4,0xc(%eax)
801060a6:	74 68                	je     80106110 <trap+0x140>
     tf->trapno == T_IRQ0+IRQ_TIMER)
    yield();

  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
801060a8:	e8 b3 df ff ff       	call   80104060 <myproc>
801060ad:	85 c0                	test   %eax,%eax
801060af:	74 19                	je     801060ca <trap+0xfa>
801060b1:	e8 aa df ff ff       	call   80104060 <myproc>
801060b6:	8b 40 24             	mov    0x24(%eax),%eax
801060b9:	85 c0                	test   %eax,%eax
801060bb:	74 0d                	je     801060ca <trap+0xfa>
801060bd:	0f b7 47 3c          	movzwl 0x3c(%edi),%eax
801060c1:	83 e0 03             	and    $0x3,%eax
801060c4:	66 83 f8 03          	cmp    $0x3,%ax
801060c8:	74 37                	je     80106101 <trap+0x131>
    exit();
}
801060ca:	8d 65 f4             	lea    -0xc(%ebp),%esp
801060cd:	5b                   	pop    %ebx
801060ce:	5e                   	pop    %esi
801060cf:	5f                   	pop    %edi
801060d0:	5d                   	pop    %ebp
801060d1:	c3                   	ret    
801060d2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    if(myproc()->killed)
801060d8:	e8 83 df ff ff       	call   80104060 <myproc>
801060dd:	8b 58 24             	mov    0x24(%eax),%ebx
801060e0:	85 db                	test   %ebx,%ebx
801060e2:	0f 85 e8 00 00 00    	jne    801061d0 <trap+0x200>
    myproc()->tf = tf;
801060e8:	e8 73 df ff ff       	call   80104060 <myproc>
801060ed:	89 78 18             	mov    %edi,0x18(%eax)
    syscall();
801060f0:	e8 cb ef ff ff       	call   801050c0 <syscall>
    if(myproc()->killed)
801060f5:	e8 66 df ff ff       	call   80104060 <myproc>
801060fa:	8b 48 24             	mov    0x24(%eax),%ecx
801060fd:	85 c9                	test   %ecx,%ecx
801060ff:	74 c9                	je     801060ca <trap+0xfa>
}
80106101:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106104:	5b                   	pop    %ebx
80106105:	5e                   	pop    %esi
80106106:	5f                   	pop    %edi
80106107:	5d                   	pop    %ebp
      exit();
80106108:	e9 73 e3 ff ff       	jmp    80104480 <exit>
8010610d:	8d 76 00             	lea    0x0(%esi),%esi
  if(myproc() && myproc()->state == RUNNING &&
80106110:	83 7f 30 20          	cmpl   $0x20,0x30(%edi)
80106114:	75 92                	jne    801060a8 <trap+0xd8>
    yield();
80106116:	e8 95 e4 ff ff       	call   801045b0 <yield>
8010611b:	eb 8b                	jmp    801060a8 <trap+0xd8>
8010611d:	8d 76 00             	lea    0x0(%esi),%esi
    if(cpuid() == 0){
80106120:	e8 1b df ff ff       	call   80104040 <cpuid>
80106125:	85 c0                	test   %eax,%eax
80106127:	0f 84 c3 00 00 00    	je     801061f0 <trap+0x220>
    lapiceoi();
8010612d:	e8 9e ce ff ff       	call   80102fd0 <lapiceoi>
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80106132:	e8 29 df ff ff       	call   80104060 <myproc>
80106137:	85 c0                	test   %eax,%eax
80106139:	0f 85 38 ff ff ff    	jne    80106077 <trap+0xa7>
8010613f:	e9 50 ff ff ff       	jmp    80106094 <trap+0xc4>
80106144:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    kbdintr();
80106148:	e8 43 cd ff ff       	call   80102e90 <kbdintr>
    lapiceoi();
8010614d:	e8 7e ce ff ff       	call   80102fd0 <lapiceoi>
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80106152:	e8 09 df ff ff       	call   80104060 <myproc>
80106157:	85 c0                	test   %eax,%eax
80106159:	0f 85 18 ff ff ff    	jne    80106077 <trap+0xa7>
8010615f:	e9 30 ff ff ff       	jmp    80106094 <trap+0xc4>
80106164:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    uartintr();
80106168:	e8 53 02 00 00       	call   801063c0 <uartintr>
    lapiceoi();
8010616d:	e8 5e ce ff ff       	call   80102fd0 <lapiceoi>
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80106172:	e8 e9 de ff ff       	call   80104060 <myproc>
80106177:	85 c0                	test   %eax,%eax
80106179:	0f 85 f8 fe ff ff    	jne    80106077 <trap+0xa7>
8010617f:	e9 10 ff ff ff       	jmp    80106094 <trap+0xc4>
80106184:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
80106188:	0f b7 5f 3c          	movzwl 0x3c(%edi),%ebx
8010618c:	8b 77 38             	mov    0x38(%edi),%esi
8010618f:	e8 ac de ff ff       	call   80104040 <cpuid>
80106194:	56                   	push   %esi
80106195:	53                   	push   %ebx
80106196:	50                   	push   %eax
80106197:	68 08 80 10 80       	push   $0x80108008
8010619c:	e8 bf a4 ff ff       	call   80100660 <cprintf>
    lapiceoi();
801061a1:	e8 2a ce ff ff       	call   80102fd0 <lapiceoi>
    break;
801061a6:	83 c4 10             	add    $0x10,%esp
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
801061a9:	e8 b2 de ff ff       	call   80104060 <myproc>
801061ae:	85 c0                	test   %eax,%eax
801061b0:	0f 85 c1 fe ff ff    	jne    80106077 <trap+0xa7>
801061b6:	e9 d9 fe ff ff       	jmp    80106094 <trap+0xc4>
801061bb:	90                   	nop
801061bc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    ideintr();
801061c0:	e8 3b c7 ff ff       	call   80102900 <ideintr>
801061c5:	e9 63 ff ff ff       	jmp    8010612d <trap+0x15d>
801061ca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      exit();
801061d0:	e8 ab e2 ff ff       	call   80104480 <exit>
801061d5:	e9 0e ff ff ff       	jmp    801060e8 <trap+0x118>
801061da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    exit();
801061e0:	e8 9b e2 ff ff       	call   80104480 <exit>
801061e5:	e9 aa fe ff ff       	jmp    80106094 <trap+0xc4>
801061ea:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      acquire(&tickslock);
801061f0:	83 ec 0c             	sub    $0xc,%esp
801061f3:	68 60 7a 11 80       	push   $0x80117a60
801061f8:	e8 c3 e9 ff ff       	call   80104bc0 <acquire>
      wakeup(&ticks);
801061fd:	c7 04 24 a0 82 11 80 	movl   $0x801182a0,(%esp)
      ticks++;
80106204:	83 05 a0 82 11 80 01 	addl   $0x1,0x801182a0
      wakeup(&ticks);
8010620b:	e8 a0 e5 ff ff       	call   801047b0 <wakeup>
      release(&tickslock);
80106210:	c7 04 24 60 7a 11 80 	movl   $0x80117a60,(%esp)
80106217:	e8 64 ea ff ff       	call   80104c80 <release>
8010621c:	83 c4 10             	add    $0x10,%esp
8010621f:	e9 09 ff ff ff       	jmp    8010612d <trap+0x15d>
80106224:	0f 20 d6             	mov    %cr2,%esi
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
80106227:	e8 14 de ff ff       	call   80104040 <cpuid>
8010622c:	83 ec 0c             	sub    $0xc,%esp
8010622f:	56                   	push   %esi
80106230:	53                   	push   %ebx
80106231:	50                   	push   %eax
80106232:	ff 77 30             	pushl  0x30(%edi)
80106235:	68 2c 80 10 80       	push   $0x8010802c
8010623a:	e8 21 a4 ff ff       	call   80100660 <cprintf>
      panic("trap");
8010623f:	83 c4 14             	add    $0x14,%esp
80106242:	68 02 80 10 80       	push   $0x80108002
80106247:	e8 44 a1 ff ff       	call   80100390 <panic>
8010624c:	66 90                	xchg   %ax,%ax
8010624e:	66 90                	xchg   %ax,%ax

80106250 <uartgetc>:
}

static int
uartgetc(void)
{
  if(!uart)
80106250:	a1 bc b5 10 80       	mov    0x8010b5bc,%eax
{
80106255:	55                   	push   %ebp
80106256:	89 e5                	mov    %esp,%ebp
  if(!uart)
80106258:	85 c0                	test   %eax,%eax
8010625a:	74 1c                	je     80106278 <uartgetc+0x28>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010625c:	ba fd 03 00 00       	mov    $0x3fd,%edx
80106261:	ec                   	in     (%dx),%al
    return -1;
  if(!(inb(COM1+5) & 0x01))
80106262:	a8 01                	test   $0x1,%al
80106264:	74 12                	je     80106278 <uartgetc+0x28>
80106266:	ba f8 03 00 00       	mov    $0x3f8,%edx
8010626b:	ec                   	in     (%dx),%al
    return -1;
  return inb(COM1+0);
8010626c:	0f b6 c0             	movzbl %al,%eax
}
8010626f:	5d                   	pop    %ebp
80106270:	c3                   	ret    
80106271:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80106278:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010627d:	5d                   	pop    %ebp
8010627e:	c3                   	ret    
8010627f:	90                   	nop

80106280 <uartputc.part.0>:
uartputc(int c)
80106280:	55                   	push   %ebp
80106281:	89 e5                	mov    %esp,%ebp
80106283:	57                   	push   %edi
80106284:	56                   	push   %esi
80106285:	53                   	push   %ebx
80106286:	89 c7                	mov    %eax,%edi
80106288:	bb 80 00 00 00       	mov    $0x80,%ebx
8010628d:	be fd 03 00 00       	mov    $0x3fd,%esi
80106292:	83 ec 0c             	sub    $0xc,%esp
80106295:	eb 1b                	jmp    801062b2 <uartputc.part.0+0x32>
80106297:	89 f6                	mov    %esi,%esi
80106299:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    microdelay(10);
801062a0:	83 ec 0c             	sub    $0xc,%esp
801062a3:	6a 0a                	push   $0xa
801062a5:	e8 46 cd ff ff       	call   80102ff0 <microdelay>
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
801062aa:	83 c4 10             	add    $0x10,%esp
801062ad:	83 eb 01             	sub    $0x1,%ebx
801062b0:	74 07                	je     801062b9 <uartputc.part.0+0x39>
801062b2:	89 f2                	mov    %esi,%edx
801062b4:	ec                   	in     (%dx),%al
801062b5:	a8 20                	test   $0x20,%al
801062b7:	74 e7                	je     801062a0 <uartputc.part.0+0x20>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801062b9:	ba f8 03 00 00       	mov    $0x3f8,%edx
801062be:	89 f8                	mov    %edi,%eax
801062c0:	ee                   	out    %al,(%dx)
}
801062c1:	8d 65 f4             	lea    -0xc(%ebp),%esp
801062c4:	5b                   	pop    %ebx
801062c5:	5e                   	pop    %esi
801062c6:	5f                   	pop    %edi
801062c7:	5d                   	pop    %ebp
801062c8:	c3                   	ret    
801062c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

801062d0 <uartinit>:
{
801062d0:	55                   	push   %ebp
801062d1:	31 c9                	xor    %ecx,%ecx
801062d3:	89 c8                	mov    %ecx,%eax
801062d5:	89 e5                	mov    %esp,%ebp
801062d7:	57                   	push   %edi
801062d8:	56                   	push   %esi
801062d9:	53                   	push   %ebx
801062da:	bb fa 03 00 00       	mov    $0x3fa,%ebx
801062df:	89 da                	mov    %ebx,%edx
801062e1:	83 ec 0c             	sub    $0xc,%esp
801062e4:	ee                   	out    %al,(%dx)
801062e5:	bf fb 03 00 00       	mov    $0x3fb,%edi
801062ea:	b8 80 ff ff ff       	mov    $0xffffff80,%eax
801062ef:	89 fa                	mov    %edi,%edx
801062f1:	ee                   	out    %al,(%dx)
801062f2:	b8 0c 00 00 00       	mov    $0xc,%eax
801062f7:	ba f8 03 00 00       	mov    $0x3f8,%edx
801062fc:	ee                   	out    %al,(%dx)
801062fd:	be f9 03 00 00       	mov    $0x3f9,%esi
80106302:	89 c8                	mov    %ecx,%eax
80106304:	89 f2                	mov    %esi,%edx
80106306:	ee                   	out    %al,(%dx)
80106307:	b8 03 00 00 00       	mov    $0x3,%eax
8010630c:	89 fa                	mov    %edi,%edx
8010630e:	ee                   	out    %al,(%dx)
8010630f:	ba fc 03 00 00       	mov    $0x3fc,%edx
80106314:	89 c8                	mov    %ecx,%eax
80106316:	ee                   	out    %al,(%dx)
80106317:	b8 01 00 00 00       	mov    $0x1,%eax
8010631c:	89 f2                	mov    %esi,%edx
8010631e:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010631f:	ba fd 03 00 00       	mov    $0x3fd,%edx
80106324:	ec                   	in     (%dx),%al
  if(inb(COM1+5) == 0xFF)
80106325:	3c ff                	cmp    $0xff,%al
80106327:	74 5a                	je     80106383 <uartinit+0xb3>
  uart = 1;
80106329:	c7 05 bc b5 10 80 01 	movl   $0x1,0x8010b5bc
80106330:	00 00 00 
80106333:	89 da                	mov    %ebx,%edx
80106335:	ec                   	in     (%dx),%al
80106336:	ba f8 03 00 00       	mov    $0x3f8,%edx
8010633b:	ec                   	in     (%dx),%al
  ioapicenable(IRQ_COM1, 0);
8010633c:	83 ec 08             	sub    $0x8,%esp
  for(p="xv6...\n"; *p; p++)
8010633f:	bb 24 81 10 80       	mov    $0x80108124,%ebx
  ioapicenable(IRQ_COM1, 0);
80106344:	6a 00                	push   $0x0
80106346:	6a 04                	push   $0x4
80106348:	e8 03 c8 ff ff       	call   80102b50 <ioapicenable>
8010634d:	83 c4 10             	add    $0x10,%esp
  for(p="xv6...\n"; *p; p++)
80106350:	b8 78 00 00 00       	mov    $0x78,%eax
80106355:	eb 13                	jmp    8010636a <uartinit+0x9a>
80106357:	89 f6                	mov    %esi,%esi
80106359:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
80106360:	83 c3 01             	add    $0x1,%ebx
80106363:	0f be 03             	movsbl (%ebx),%eax
80106366:	84 c0                	test   %al,%al
80106368:	74 19                	je     80106383 <uartinit+0xb3>
  if(!uart)
8010636a:	8b 15 bc b5 10 80    	mov    0x8010b5bc,%edx
80106370:	85 d2                	test   %edx,%edx
80106372:	74 ec                	je     80106360 <uartinit+0x90>
  for(p="xv6...\n"; *p; p++)
80106374:	83 c3 01             	add    $0x1,%ebx
80106377:	e8 04 ff ff ff       	call   80106280 <uartputc.part.0>
8010637c:	0f be 03             	movsbl (%ebx),%eax
8010637f:	84 c0                	test   %al,%al
80106381:	75 e7                	jne    8010636a <uartinit+0x9a>
}
80106383:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106386:	5b                   	pop    %ebx
80106387:	5e                   	pop    %esi
80106388:	5f                   	pop    %edi
80106389:	5d                   	pop    %ebp
8010638a:	c3                   	ret    
8010638b:	90                   	nop
8010638c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80106390 <uartputc>:
  if(!uart)
80106390:	8b 15 bc b5 10 80    	mov    0x8010b5bc,%edx
{
80106396:	55                   	push   %ebp
80106397:	89 e5                	mov    %esp,%ebp
  if(!uart)
80106399:	85 d2                	test   %edx,%edx
{
8010639b:	8b 45 08             	mov    0x8(%ebp),%eax
  if(!uart)
8010639e:	74 10                	je     801063b0 <uartputc+0x20>
}
801063a0:	5d                   	pop    %ebp
801063a1:	e9 da fe ff ff       	jmp    80106280 <uartputc.part.0>
801063a6:	8d 76 00             	lea    0x0(%esi),%esi
801063a9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
801063b0:	5d                   	pop    %ebp
801063b1:	c3                   	ret    
801063b2:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801063b9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

801063c0 <uartintr>:

void
uartintr(void)
{
801063c0:	55                   	push   %ebp
801063c1:	89 e5                	mov    %esp,%ebp
801063c3:	83 ec 14             	sub    $0x14,%esp
  consoleintr(uartgetc);
801063c6:	68 50 62 10 80       	push   $0x80106250
801063cb:	e8 40 a4 ff ff       	call   80100810 <consoleintr>
}
801063d0:	83 c4 10             	add    $0x10,%esp
801063d3:	c9                   	leave  
801063d4:	c3                   	ret    

801063d5 <vector0>:
# generated by vectors.pl - do not edit
# handlers
.globl alltraps
.globl vector0
vector0:
  pushl $0
801063d5:	6a 00                	push   $0x0
  pushl $0
801063d7:	6a 00                	push   $0x0
  jmp alltraps
801063d9:	e9 1c fb ff ff       	jmp    80105efa <alltraps>

801063de <vector1>:
.globl vector1
vector1:
  pushl $0
801063de:	6a 00                	push   $0x0
  pushl $1
801063e0:	6a 01                	push   $0x1
  jmp alltraps
801063e2:	e9 13 fb ff ff       	jmp    80105efa <alltraps>

801063e7 <vector2>:
.globl vector2
vector2:
  pushl $0
801063e7:	6a 00                	push   $0x0
  pushl $2
801063e9:	6a 02                	push   $0x2
  jmp alltraps
801063eb:	e9 0a fb ff ff       	jmp    80105efa <alltraps>

801063f0 <vector3>:
.globl vector3
vector3:
  pushl $0
801063f0:	6a 00                	push   $0x0
  pushl $3
801063f2:	6a 03                	push   $0x3
  jmp alltraps
801063f4:	e9 01 fb ff ff       	jmp    80105efa <alltraps>

801063f9 <vector4>:
.globl vector4
vector4:
  pushl $0
801063f9:	6a 00                	push   $0x0
  pushl $4
801063fb:	6a 04                	push   $0x4
  jmp alltraps
801063fd:	e9 f8 fa ff ff       	jmp    80105efa <alltraps>

80106402 <vector5>:
.globl vector5
vector5:
  pushl $0
80106402:	6a 00                	push   $0x0
  pushl $5
80106404:	6a 05                	push   $0x5
  jmp alltraps
80106406:	e9 ef fa ff ff       	jmp    80105efa <alltraps>

8010640b <vector6>:
.globl vector6
vector6:
  pushl $0
8010640b:	6a 00                	push   $0x0
  pushl $6
8010640d:	6a 06                	push   $0x6
  jmp alltraps
8010640f:	e9 e6 fa ff ff       	jmp    80105efa <alltraps>

80106414 <vector7>:
.globl vector7
vector7:
  pushl $0
80106414:	6a 00                	push   $0x0
  pushl $7
80106416:	6a 07                	push   $0x7
  jmp alltraps
80106418:	e9 dd fa ff ff       	jmp    80105efa <alltraps>

8010641d <vector8>:
.globl vector8
vector8:
  pushl $8
8010641d:	6a 08                	push   $0x8
  jmp alltraps
8010641f:	e9 d6 fa ff ff       	jmp    80105efa <alltraps>

80106424 <vector9>:
.globl vector9
vector9:
  pushl $0
80106424:	6a 00                	push   $0x0
  pushl $9
80106426:	6a 09                	push   $0x9
  jmp alltraps
80106428:	e9 cd fa ff ff       	jmp    80105efa <alltraps>

8010642d <vector10>:
.globl vector10
vector10:
  pushl $10
8010642d:	6a 0a                	push   $0xa
  jmp alltraps
8010642f:	e9 c6 fa ff ff       	jmp    80105efa <alltraps>

80106434 <vector11>:
.globl vector11
vector11:
  pushl $11
80106434:	6a 0b                	push   $0xb
  jmp alltraps
80106436:	e9 bf fa ff ff       	jmp    80105efa <alltraps>

8010643b <vector12>:
.globl vector12
vector12:
  pushl $12
8010643b:	6a 0c                	push   $0xc
  jmp alltraps
8010643d:	e9 b8 fa ff ff       	jmp    80105efa <alltraps>

80106442 <vector13>:
.globl vector13
vector13:
  pushl $13
80106442:	6a 0d                	push   $0xd
  jmp alltraps
80106444:	e9 b1 fa ff ff       	jmp    80105efa <alltraps>

80106449 <vector14>:
.globl vector14
vector14:
  pushl $14
80106449:	6a 0e                	push   $0xe
  jmp alltraps
8010644b:	e9 aa fa ff ff       	jmp    80105efa <alltraps>

80106450 <vector15>:
.globl vector15
vector15:
  pushl $0
80106450:	6a 00                	push   $0x0
  pushl $15
80106452:	6a 0f                	push   $0xf
  jmp alltraps
80106454:	e9 a1 fa ff ff       	jmp    80105efa <alltraps>

80106459 <vector16>:
.globl vector16
vector16:
  pushl $0
80106459:	6a 00                	push   $0x0
  pushl $16
8010645b:	6a 10                	push   $0x10
  jmp alltraps
8010645d:	e9 98 fa ff ff       	jmp    80105efa <alltraps>

80106462 <vector17>:
.globl vector17
vector17:
  pushl $17
80106462:	6a 11                	push   $0x11
  jmp alltraps
80106464:	e9 91 fa ff ff       	jmp    80105efa <alltraps>

80106469 <vector18>:
.globl vector18
vector18:
  pushl $0
80106469:	6a 00                	push   $0x0
  pushl $18
8010646b:	6a 12                	push   $0x12
  jmp alltraps
8010646d:	e9 88 fa ff ff       	jmp    80105efa <alltraps>

80106472 <vector19>:
.globl vector19
vector19:
  pushl $0
80106472:	6a 00                	push   $0x0
  pushl $19
80106474:	6a 13                	push   $0x13
  jmp alltraps
80106476:	e9 7f fa ff ff       	jmp    80105efa <alltraps>

8010647b <vector20>:
.globl vector20
vector20:
  pushl $0
8010647b:	6a 00                	push   $0x0
  pushl $20
8010647d:	6a 14                	push   $0x14
  jmp alltraps
8010647f:	e9 76 fa ff ff       	jmp    80105efa <alltraps>

80106484 <vector21>:
.globl vector21
vector21:
  pushl $0
80106484:	6a 00                	push   $0x0
  pushl $21
80106486:	6a 15                	push   $0x15
  jmp alltraps
80106488:	e9 6d fa ff ff       	jmp    80105efa <alltraps>

8010648d <vector22>:
.globl vector22
vector22:
  pushl $0
8010648d:	6a 00                	push   $0x0
  pushl $22
8010648f:	6a 16                	push   $0x16
  jmp alltraps
80106491:	e9 64 fa ff ff       	jmp    80105efa <alltraps>

80106496 <vector23>:
.globl vector23
vector23:
  pushl $0
80106496:	6a 00                	push   $0x0
  pushl $23
80106498:	6a 17                	push   $0x17
  jmp alltraps
8010649a:	e9 5b fa ff ff       	jmp    80105efa <alltraps>

8010649f <vector24>:
.globl vector24
vector24:
  pushl $0
8010649f:	6a 00                	push   $0x0
  pushl $24
801064a1:	6a 18                	push   $0x18
  jmp alltraps
801064a3:	e9 52 fa ff ff       	jmp    80105efa <alltraps>

801064a8 <vector25>:
.globl vector25
vector25:
  pushl $0
801064a8:	6a 00                	push   $0x0
  pushl $25
801064aa:	6a 19                	push   $0x19
  jmp alltraps
801064ac:	e9 49 fa ff ff       	jmp    80105efa <alltraps>

801064b1 <vector26>:
.globl vector26
vector26:
  pushl $0
801064b1:	6a 00                	push   $0x0
  pushl $26
801064b3:	6a 1a                	push   $0x1a
  jmp alltraps
801064b5:	e9 40 fa ff ff       	jmp    80105efa <alltraps>

801064ba <vector27>:
.globl vector27
vector27:
  pushl $0
801064ba:	6a 00                	push   $0x0
  pushl $27
801064bc:	6a 1b                	push   $0x1b
  jmp alltraps
801064be:	e9 37 fa ff ff       	jmp    80105efa <alltraps>

801064c3 <vector28>:
.globl vector28
vector28:
  pushl $0
801064c3:	6a 00                	push   $0x0
  pushl $28
801064c5:	6a 1c                	push   $0x1c
  jmp alltraps
801064c7:	e9 2e fa ff ff       	jmp    80105efa <alltraps>

801064cc <vector29>:
.globl vector29
vector29:
  pushl $0
801064cc:	6a 00                	push   $0x0
  pushl $29
801064ce:	6a 1d                	push   $0x1d
  jmp alltraps
801064d0:	e9 25 fa ff ff       	jmp    80105efa <alltraps>

801064d5 <vector30>:
.globl vector30
vector30:
  pushl $0
801064d5:	6a 00                	push   $0x0
  pushl $30
801064d7:	6a 1e                	push   $0x1e
  jmp alltraps
801064d9:	e9 1c fa ff ff       	jmp    80105efa <alltraps>

801064de <vector31>:
.globl vector31
vector31:
  pushl $0
801064de:	6a 00                	push   $0x0
  pushl $31
801064e0:	6a 1f                	push   $0x1f
  jmp alltraps
801064e2:	e9 13 fa ff ff       	jmp    80105efa <alltraps>

801064e7 <vector32>:
.globl vector32
vector32:
  pushl $0
801064e7:	6a 00                	push   $0x0
  pushl $32
801064e9:	6a 20                	push   $0x20
  jmp alltraps
801064eb:	e9 0a fa ff ff       	jmp    80105efa <alltraps>

801064f0 <vector33>:
.globl vector33
vector33:
  pushl $0
801064f0:	6a 00                	push   $0x0
  pushl $33
801064f2:	6a 21                	push   $0x21
  jmp alltraps
801064f4:	e9 01 fa ff ff       	jmp    80105efa <alltraps>

801064f9 <vector34>:
.globl vector34
vector34:
  pushl $0
801064f9:	6a 00                	push   $0x0
  pushl $34
801064fb:	6a 22                	push   $0x22
  jmp alltraps
801064fd:	e9 f8 f9 ff ff       	jmp    80105efa <alltraps>

80106502 <vector35>:
.globl vector35
vector35:
  pushl $0
80106502:	6a 00                	push   $0x0
  pushl $35
80106504:	6a 23                	push   $0x23
  jmp alltraps
80106506:	e9 ef f9 ff ff       	jmp    80105efa <alltraps>

8010650b <vector36>:
.globl vector36
vector36:
  pushl $0
8010650b:	6a 00                	push   $0x0
  pushl $36
8010650d:	6a 24                	push   $0x24
  jmp alltraps
8010650f:	e9 e6 f9 ff ff       	jmp    80105efa <alltraps>

80106514 <vector37>:
.globl vector37
vector37:
  pushl $0
80106514:	6a 00                	push   $0x0
  pushl $37
80106516:	6a 25                	push   $0x25
  jmp alltraps
80106518:	e9 dd f9 ff ff       	jmp    80105efa <alltraps>

8010651d <vector38>:
.globl vector38
vector38:
  pushl $0
8010651d:	6a 00                	push   $0x0
  pushl $38
8010651f:	6a 26                	push   $0x26
  jmp alltraps
80106521:	e9 d4 f9 ff ff       	jmp    80105efa <alltraps>

80106526 <vector39>:
.globl vector39
vector39:
  pushl $0
80106526:	6a 00                	push   $0x0
  pushl $39
80106528:	6a 27                	push   $0x27
  jmp alltraps
8010652a:	e9 cb f9 ff ff       	jmp    80105efa <alltraps>

8010652f <vector40>:
.globl vector40
vector40:
  pushl $0
8010652f:	6a 00                	push   $0x0
  pushl $40
80106531:	6a 28                	push   $0x28
  jmp alltraps
80106533:	e9 c2 f9 ff ff       	jmp    80105efa <alltraps>

80106538 <vector41>:
.globl vector41
vector41:
  pushl $0
80106538:	6a 00                	push   $0x0
  pushl $41
8010653a:	6a 29                	push   $0x29
  jmp alltraps
8010653c:	e9 b9 f9 ff ff       	jmp    80105efa <alltraps>

80106541 <vector42>:
.globl vector42
vector42:
  pushl $0
80106541:	6a 00                	push   $0x0
  pushl $42
80106543:	6a 2a                	push   $0x2a
  jmp alltraps
80106545:	e9 b0 f9 ff ff       	jmp    80105efa <alltraps>

8010654a <vector43>:
.globl vector43
vector43:
  pushl $0
8010654a:	6a 00                	push   $0x0
  pushl $43
8010654c:	6a 2b                	push   $0x2b
  jmp alltraps
8010654e:	e9 a7 f9 ff ff       	jmp    80105efa <alltraps>

80106553 <vector44>:
.globl vector44
vector44:
  pushl $0
80106553:	6a 00                	push   $0x0
  pushl $44
80106555:	6a 2c                	push   $0x2c
  jmp alltraps
80106557:	e9 9e f9 ff ff       	jmp    80105efa <alltraps>

8010655c <vector45>:
.globl vector45
vector45:
  pushl $0
8010655c:	6a 00                	push   $0x0
  pushl $45
8010655e:	6a 2d                	push   $0x2d
  jmp alltraps
80106560:	e9 95 f9 ff ff       	jmp    80105efa <alltraps>

80106565 <vector46>:
.globl vector46
vector46:
  pushl $0
80106565:	6a 00                	push   $0x0
  pushl $46
80106567:	6a 2e                	push   $0x2e
  jmp alltraps
80106569:	e9 8c f9 ff ff       	jmp    80105efa <alltraps>

8010656e <vector47>:
.globl vector47
vector47:
  pushl $0
8010656e:	6a 00                	push   $0x0
  pushl $47
80106570:	6a 2f                	push   $0x2f
  jmp alltraps
80106572:	e9 83 f9 ff ff       	jmp    80105efa <alltraps>

80106577 <vector48>:
.globl vector48
vector48:
  pushl $0
80106577:	6a 00                	push   $0x0
  pushl $48
80106579:	6a 30                	push   $0x30
  jmp alltraps
8010657b:	e9 7a f9 ff ff       	jmp    80105efa <alltraps>

80106580 <vector49>:
.globl vector49
vector49:
  pushl $0
80106580:	6a 00                	push   $0x0
  pushl $49
80106582:	6a 31                	push   $0x31
  jmp alltraps
80106584:	e9 71 f9 ff ff       	jmp    80105efa <alltraps>

80106589 <vector50>:
.globl vector50
vector50:
  pushl $0
80106589:	6a 00                	push   $0x0
  pushl $50
8010658b:	6a 32                	push   $0x32
  jmp alltraps
8010658d:	e9 68 f9 ff ff       	jmp    80105efa <alltraps>

80106592 <vector51>:
.globl vector51
vector51:
  pushl $0
80106592:	6a 00                	push   $0x0
  pushl $51
80106594:	6a 33                	push   $0x33
  jmp alltraps
80106596:	e9 5f f9 ff ff       	jmp    80105efa <alltraps>

8010659b <vector52>:
.globl vector52
vector52:
  pushl $0
8010659b:	6a 00                	push   $0x0
  pushl $52
8010659d:	6a 34                	push   $0x34
  jmp alltraps
8010659f:	e9 56 f9 ff ff       	jmp    80105efa <alltraps>

801065a4 <vector53>:
.globl vector53
vector53:
  pushl $0
801065a4:	6a 00                	push   $0x0
  pushl $53
801065a6:	6a 35                	push   $0x35
  jmp alltraps
801065a8:	e9 4d f9 ff ff       	jmp    80105efa <alltraps>

801065ad <vector54>:
.globl vector54
vector54:
  pushl $0
801065ad:	6a 00                	push   $0x0
  pushl $54
801065af:	6a 36                	push   $0x36
  jmp alltraps
801065b1:	e9 44 f9 ff ff       	jmp    80105efa <alltraps>

801065b6 <vector55>:
.globl vector55
vector55:
  pushl $0
801065b6:	6a 00                	push   $0x0
  pushl $55
801065b8:	6a 37                	push   $0x37
  jmp alltraps
801065ba:	e9 3b f9 ff ff       	jmp    80105efa <alltraps>

801065bf <vector56>:
.globl vector56
vector56:
  pushl $0
801065bf:	6a 00                	push   $0x0
  pushl $56
801065c1:	6a 38                	push   $0x38
  jmp alltraps
801065c3:	e9 32 f9 ff ff       	jmp    80105efa <alltraps>

801065c8 <vector57>:
.globl vector57
vector57:
  pushl $0
801065c8:	6a 00                	push   $0x0
  pushl $57
801065ca:	6a 39                	push   $0x39
  jmp alltraps
801065cc:	e9 29 f9 ff ff       	jmp    80105efa <alltraps>

801065d1 <vector58>:
.globl vector58
vector58:
  pushl $0
801065d1:	6a 00                	push   $0x0
  pushl $58
801065d3:	6a 3a                	push   $0x3a
  jmp alltraps
801065d5:	e9 20 f9 ff ff       	jmp    80105efa <alltraps>

801065da <vector59>:
.globl vector59
vector59:
  pushl $0
801065da:	6a 00                	push   $0x0
  pushl $59
801065dc:	6a 3b                	push   $0x3b
  jmp alltraps
801065de:	e9 17 f9 ff ff       	jmp    80105efa <alltraps>

801065e3 <vector60>:
.globl vector60
vector60:
  pushl $0
801065e3:	6a 00                	push   $0x0
  pushl $60
801065e5:	6a 3c                	push   $0x3c
  jmp alltraps
801065e7:	e9 0e f9 ff ff       	jmp    80105efa <alltraps>

801065ec <vector61>:
.globl vector61
vector61:
  pushl $0
801065ec:	6a 00                	push   $0x0
  pushl $61
801065ee:	6a 3d                	push   $0x3d
  jmp alltraps
801065f0:	e9 05 f9 ff ff       	jmp    80105efa <alltraps>

801065f5 <vector62>:
.globl vector62
vector62:
  pushl $0
801065f5:	6a 00                	push   $0x0
  pushl $62
801065f7:	6a 3e                	push   $0x3e
  jmp alltraps
801065f9:	e9 fc f8 ff ff       	jmp    80105efa <alltraps>

801065fe <vector63>:
.globl vector63
vector63:
  pushl $0
801065fe:	6a 00                	push   $0x0
  pushl $63
80106600:	6a 3f                	push   $0x3f
  jmp alltraps
80106602:	e9 f3 f8 ff ff       	jmp    80105efa <alltraps>

80106607 <vector64>:
.globl vector64
vector64:
  pushl $0
80106607:	6a 00                	push   $0x0
  pushl $64
80106609:	6a 40                	push   $0x40
  jmp alltraps
8010660b:	e9 ea f8 ff ff       	jmp    80105efa <alltraps>

80106610 <vector65>:
.globl vector65
vector65:
  pushl $0
80106610:	6a 00                	push   $0x0
  pushl $65
80106612:	6a 41                	push   $0x41
  jmp alltraps
80106614:	e9 e1 f8 ff ff       	jmp    80105efa <alltraps>

80106619 <vector66>:
.globl vector66
vector66:
  pushl $0
80106619:	6a 00                	push   $0x0
  pushl $66
8010661b:	6a 42                	push   $0x42
  jmp alltraps
8010661d:	e9 d8 f8 ff ff       	jmp    80105efa <alltraps>

80106622 <vector67>:
.globl vector67
vector67:
  pushl $0
80106622:	6a 00                	push   $0x0
  pushl $67
80106624:	6a 43                	push   $0x43
  jmp alltraps
80106626:	e9 cf f8 ff ff       	jmp    80105efa <alltraps>

8010662b <vector68>:
.globl vector68
vector68:
  pushl $0
8010662b:	6a 00                	push   $0x0
  pushl $68
8010662d:	6a 44                	push   $0x44
  jmp alltraps
8010662f:	e9 c6 f8 ff ff       	jmp    80105efa <alltraps>

80106634 <vector69>:
.globl vector69
vector69:
  pushl $0
80106634:	6a 00                	push   $0x0
  pushl $69
80106636:	6a 45                	push   $0x45
  jmp alltraps
80106638:	e9 bd f8 ff ff       	jmp    80105efa <alltraps>

8010663d <vector70>:
.globl vector70
vector70:
  pushl $0
8010663d:	6a 00                	push   $0x0
  pushl $70
8010663f:	6a 46                	push   $0x46
  jmp alltraps
80106641:	e9 b4 f8 ff ff       	jmp    80105efa <alltraps>

80106646 <vector71>:
.globl vector71
vector71:
  pushl $0
80106646:	6a 00                	push   $0x0
  pushl $71
80106648:	6a 47                	push   $0x47
  jmp alltraps
8010664a:	e9 ab f8 ff ff       	jmp    80105efa <alltraps>

8010664f <vector72>:
.globl vector72
vector72:
  pushl $0
8010664f:	6a 00                	push   $0x0
  pushl $72
80106651:	6a 48                	push   $0x48
  jmp alltraps
80106653:	e9 a2 f8 ff ff       	jmp    80105efa <alltraps>

80106658 <vector73>:
.globl vector73
vector73:
  pushl $0
80106658:	6a 00                	push   $0x0
  pushl $73
8010665a:	6a 49                	push   $0x49
  jmp alltraps
8010665c:	e9 99 f8 ff ff       	jmp    80105efa <alltraps>

80106661 <vector74>:
.globl vector74
vector74:
  pushl $0
80106661:	6a 00                	push   $0x0
  pushl $74
80106663:	6a 4a                	push   $0x4a
  jmp alltraps
80106665:	e9 90 f8 ff ff       	jmp    80105efa <alltraps>

8010666a <vector75>:
.globl vector75
vector75:
  pushl $0
8010666a:	6a 00                	push   $0x0
  pushl $75
8010666c:	6a 4b                	push   $0x4b
  jmp alltraps
8010666e:	e9 87 f8 ff ff       	jmp    80105efa <alltraps>

80106673 <vector76>:
.globl vector76
vector76:
  pushl $0
80106673:	6a 00                	push   $0x0
  pushl $76
80106675:	6a 4c                	push   $0x4c
  jmp alltraps
80106677:	e9 7e f8 ff ff       	jmp    80105efa <alltraps>

8010667c <vector77>:
.globl vector77
vector77:
  pushl $0
8010667c:	6a 00                	push   $0x0
  pushl $77
8010667e:	6a 4d                	push   $0x4d
  jmp alltraps
80106680:	e9 75 f8 ff ff       	jmp    80105efa <alltraps>

80106685 <vector78>:
.globl vector78
vector78:
  pushl $0
80106685:	6a 00                	push   $0x0
  pushl $78
80106687:	6a 4e                	push   $0x4e
  jmp alltraps
80106689:	e9 6c f8 ff ff       	jmp    80105efa <alltraps>

8010668e <vector79>:
.globl vector79
vector79:
  pushl $0
8010668e:	6a 00                	push   $0x0
  pushl $79
80106690:	6a 4f                	push   $0x4f
  jmp alltraps
80106692:	e9 63 f8 ff ff       	jmp    80105efa <alltraps>

80106697 <vector80>:
.globl vector80
vector80:
  pushl $0
80106697:	6a 00                	push   $0x0
  pushl $80
80106699:	6a 50                	push   $0x50
  jmp alltraps
8010669b:	e9 5a f8 ff ff       	jmp    80105efa <alltraps>

801066a0 <vector81>:
.globl vector81
vector81:
  pushl $0
801066a0:	6a 00                	push   $0x0
  pushl $81
801066a2:	6a 51                	push   $0x51
  jmp alltraps
801066a4:	e9 51 f8 ff ff       	jmp    80105efa <alltraps>

801066a9 <vector82>:
.globl vector82
vector82:
  pushl $0
801066a9:	6a 00                	push   $0x0
  pushl $82
801066ab:	6a 52                	push   $0x52
  jmp alltraps
801066ad:	e9 48 f8 ff ff       	jmp    80105efa <alltraps>

801066b2 <vector83>:
.globl vector83
vector83:
  pushl $0
801066b2:	6a 00                	push   $0x0
  pushl $83
801066b4:	6a 53                	push   $0x53
  jmp alltraps
801066b6:	e9 3f f8 ff ff       	jmp    80105efa <alltraps>

801066bb <vector84>:
.globl vector84
vector84:
  pushl $0
801066bb:	6a 00                	push   $0x0
  pushl $84
801066bd:	6a 54                	push   $0x54
  jmp alltraps
801066bf:	e9 36 f8 ff ff       	jmp    80105efa <alltraps>

801066c4 <vector85>:
.globl vector85
vector85:
  pushl $0
801066c4:	6a 00                	push   $0x0
  pushl $85
801066c6:	6a 55                	push   $0x55
  jmp alltraps
801066c8:	e9 2d f8 ff ff       	jmp    80105efa <alltraps>

801066cd <vector86>:
.globl vector86
vector86:
  pushl $0
801066cd:	6a 00                	push   $0x0
  pushl $86
801066cf:	6a 56                	push   $0x56
  jmp alltraps
801066d1:	e9 24 f8 ff ff       	jmp    80105efa <alltraps>

801066d6 <vector87>:
.globl vector87
vector87:
  pushl $0
801066d6:	6a 00                	push   $0x0
  pushl $87
801066d8:	6a 57                	push   $0x57
  jmp alltraps
801066da:	e9 1b f8 ff ff       	jmp    80105efa <alltraps>

801066df <vector88>:
.globl vector88
vector88:
  pushl $0
801066df:	6a 00                	push   $0x0
  pushl $88
801066e1:	6a 58                	push   $0x58
  jmp alltraps
801066e3:	e9 12 f8 ff ff       	jmp    80105efa <alltraps>

801066e8 <vector89>:
.globl vector89
vector89:
  pushl $0
801066e8:	6a 00                	push   $0x0
  pushl $89
801066ea:	6a 59                	push   $0x59
  jmp alltraps
801066ec:	e9 09 f8 ff ff       	jmp    80105efa <alltraps>

801066f1 <vector90>:
.globl vector90
vector90:
  pushl $0
801066f1:	6a 00                	push   $0x0
  pushl $90
801066f3:	6a 5a                	push   $0x5a
  jmp alltraps
801066f5:	e9 00 f8 ff ff       	jmp    80105efa <alltraps>

801066fa <vector91>:
.globl vector91
vector91:
  pushl $0
801066fa:	6a 00                	push   $0x0
  pushl $91
801066fc:	6a 5b                	push   $0x5b
  jmp alltraps
801066fe:	e9 f7 f7 ff ff       	jmp    80105efa <alltraps>

80106703 <vector92>:
.globl vector92
vector92:
  pushl $0
80106703:	6a 00                	push   $0x0
  pushl $92
80106705:	6a 5c                	push   $0x5c
  jmp alltraps
80106707:	e9 ee f7 ff ff       	jmp    80105efa <alltraps>

8010670c <vector93>:
.globl vector93
vector93:
  pushl $0
8010670c:	6a 00                	push   $0x0
  pushl $93
8010670e:	6a 5d                	push   $0x5d
  jmp alltraps
80106710:	e9 e5 f7 ff ff       	jmp    80105efa <alltraps>

80106715 <vector94>:
.globl vector94
vector94:
  pushl $0
80106715:	6a 00                	push   $0x0
  pushl $94
80106717:	6a 5e                	push   $0x5e
  jmp alltraps
80106719:	e9 dc f7 ff ff       	jmp    80105efa <alltraps>

8010671e <vector95>:
.globl vector95
vector95:
  pushl $0
8010671e:	6a 00                	push   $0x0
  pushl $95
80106720:	6a 5f                	push   $0x5f
  jmp alltraps
80106722:	e9 d3 f7 ff ff       	jmp    80105efa <alltraps>

80106727 <vector96>:
.globl vector96
vector96:
  pushl $0
80106727:	6a 00                	push   $0x0
  pushl $96
80106729:	6a 60                	push   $0x60
  jmp alltraps
8010672b:	e9 ca f7 ff ff       	jmp    80105efa <alltraps>

80106730 <vector97>:
.globl vector97
vector97:
  pushl $0
80106730:	6a 00                	push   $0x0
  pushl $97
80106732:	6a 61                	push   $0x61
  jmp alltraps
80106734:	e9 c1 f7 ff ff       	jmp    80105efa <alltraps>

80106739 <vector98>:
.globl vector98
vector98:
  pushl $0
80106739:	6a 00                	push   $0x0
  pushl $98
8010673b:	6a 62                	push   $0x62
  jmp alltraps
8010673d:	e9 b8 f7 ff ff       	jmp    80105efa <alltraps>

80106742 <vector99>:
.globl vector99
vector99:
  pushl $0
80106742:	6a 00                	push   $0x0
  pushl $99
80106744:	6a 63                	push   $0x63
  jmp alltraps
80106746:	e9 af f7 ff ff       	jmp    80105efa <alltraps>

8010674b <vector100>:
.globl vector100
vector100:
  pushl $0
8010674b:	6a 00                	push   $0x0
  pushl $100
8010674d:	6a 64                	push   $0x64
  jmp alltraps
8010674f:	e9 a6 f7 ff ff       	jmp    80105efa <alltraps>

80106754 <vector101>:
.globl vector101
vector101:
  pushl $0
80106754:	6a 00                	push   $0x0
  pushl $101
80106756:	6a 65                	push   $0x65
  jmp alltraps
80106758:	e9 9d f7 ff ff       	jmp    80105efa <alltraps>

8010675d <vector102>:
.globl vector102
vector102:
  pushl $0
8010675d:	6a 00                	push   $0x0
  pushl $102
8010675f:	6a 66                	push   $0x66
  jmp alltraps
80106761:	e9 94 f7 ff ff       	jmp    80105efa <alltraps>

80106766 <vector103>:
.globl vector103
vector103:
  pushl $0
80106766:	6a 00                	push   $0x0
  pushl $103
80106768:	6a 67                	push   $0x67
  jmp alltraps
8010676a:	e9 8b f7 ff ff       	jmp    80105efa <alltraps>

8010676f <vector104>:
.globl vector104
vector104:
  pushl $0
8010676f:	6a 00                	push   $0x0
  pushl $104
80106771:	6a 68                	push   $0x68
  jmp alltraps
80106773:	e9 82 f7 ff ff       	jmp    80105efa <alltraps>

80106778 <vector105>:
.globl vector105
vector105:
  pushl $0
80106778:	6a 00                	push   $0x0
  pushl $105
8010677a:	6a 69                	push   $0x69
  jmp alltraps
8010677c:	e9 79 f7 ff ff       	jmp    80105efa <alltraps>

80106781 <vector106>:
.globl vector106
vector106:
  pushl $0
80106781:	6a 00                	push   $0x0
  pushl $106
80106783:	6a 6a                	push   $0x6a
  jmp alltraps
80106785:	e9 70 f7 ff ff       	jmp    80105efa <alltraps>

8010678a <vector107>:
.globl vector107
vector107:
  pushl $0
8010678a:	6a 00                	push   $0x0
  pushl $107
8010678c:	6a 6b                	push   $0x6b
  jmp alltraps
8010678e:	e9 67 f7 ff ff       	jmp    80105efa <alltraps>

80106793 <vector108>:
.globl vector108
vector108:
  pushl $0
80106793:	6a 00                	push   $0x0
  pushl $108
80106795:	6a 6c                	push   $0x6c
  jmp alltraps
80106797:	e9 5e f7 ff ff       	jmp    80105efa <alltraps>

8010679c <vector109>:
.globl vector109
vector109:
  pushl $0
8010679c:	6a 00                	push   $0x0
  pushl $109
8010679e:	6a 6d                	push   $0x6d
  jmp alltraps
801067a0:	e9 55 f7 ff ff       	jmp    80105efa <alltraps>

801067a5 <vector110>:
.globl vector110
vector110:
  pushl $0
801067a5:	6a 00                	push   $0x0
  pushl $110
801067a7:	6a 6e                	push   $0x6e
  jmp alltraps
801067a9:	e9 4c f7 ff ff       	jmp    80105efa <alltraps>

801067ae <vector111>:
.globl vector111
vector111:
  pushl $0
801067ae:	6a 00                	push   $0x0
  pushl $111
801067b0:	6a 6f                	push   $0x6f
  jmp alltraps
801067b2:	e9 43 f7 ff ff       	jmp    80105efa <alltraps>

801067b7 <vector112>:
.globl vector112
vector112:
  pushl $0
801067b7:	6a 00                	push   $0x0
  pushl $112
801067b9:	6a 70                	push   $0x70
  jmp alltraps
801067bb:	e9 3a f7 ff ff       	jmp    80105efa <alltraps>

801067c0 <vector113>:
.globl vector113
vector113:
  pushl $0
801067c0:	6a 00                	push   $0x0
  pushl $113
801067c2:	6a 71                	push   $0x71
  jmp alltraps
801067c4:	e9 31 f7 ff ff       	jmp    80105efa <alltraps>

801067c9 <vector114>:
.globl vector114
vector114:
  pushl $0
801067c9:	6a 00                	push   $0x0
  pushl $114
801067cb:	6a 72                	push   $0x72
  jmp alltraps
801067cd:	e9 28 f7 ff ff       	jmp    80105efa <alltraps>

801067d2 <vector115>:
.globl vector115
vector115:
  pushl $0
801067d2:	6a 00                	push   $0x0
  pushl $115
801067d4:	6a 73                	push   $0x73
  jmp alltraps
801067d6:	e9 1f f7 ff ff       	jmp    80105efa <alltraps>

801067db <vector116>:
.globl vector116
vector116:
  pushl $0
801067db:	6a 00                	push   $0x0
  pushl $116
801067dd:	6a 74                	push   $0x74
  jmp alltraps
801067df:	e9 16 f7 ff ff       	jmp    80105efa <alltraps>

801067e4 <vector117>:
.globl vector117
vector117:
  pushl $0
801067e4:	6a 00                	push   $0x0
  pushl $117
801067e6:	6a 75                	push   $0x75
  jmp alltraps
801067e8:	e9 0d f7 ff ff       	jmp    80105efa <alltraps>

801067ed <vector118>:
.globl vector118
vector118:
  pushl $0
801067ed:	6a 00                	push   $0x0
  pushl $118
801067ef:	6a 76                	push   $0x76
  jmp alltraps
801067f1:	e9 04 f7 ff ff       	jmp    80105efa <alltraps>

801067f6 <vector119>:
.globl vector119
vector119:
  pushl $0
801067f6:	6a 00                	push   $0x0
  pushl $119
801067f8:	6a 77                	push   $0x77
  jmp alltraps
801067fa:	e9 fb f6 ff ff       	jmp    80105efa <alltraps>

801067ff <vector120>:
.globl vector120
vector120:
  pushl $0
801067ff:	6a 00                	push   $0x0
  pushl $120
80106801:	6a 78                	push   $0x78
  jmp alltraps
80106803:	e9 f2 f6 ff ff       	jmp    80105efa <alltraps>

80106808 <vector121>:
.globl vector121
vector121:
  pushl $0
80106808:	6a 00                	push   $0x0
  pushl $121
8010680a:	6a 79                	push   $0x79
  jmp alltraps
8010680c:	e9 e9 f6 ff ff       	jmp    80105efa <alltraps>

80106811 <vector122>:
.globl vector122
vector122:
  pushl $0
80106811:	6a 00                	push   $0x0
  pushl $122
80106813:	6a 7a                	push   $0x7a
  jmp alltraps
80106815:	e9 e0 f6 ff ff       	jmp    80105efa <alltraps>

8010681a <vector123>:
.globl vector123
vector123:
  pushl $0
8010681a:	6a 00                	push   $0x0
  pushl $123
8010681c:	6a 7b                	push   $0x7b
  jmp alltraps
8010681e:	e9 d7 f6 ff ff       	jmp    80105efa <alltraps>

80106823 <vector124>:
.globl vector124
vector124:
  pushl $0
80106823:	6a 00                	push   $0x0
  pushl $124
80106825:	6a 7c                	push   $0x7c
  jmp alltraps
80106827:	e9 ce f6 ff ff       	jmp    80105efa <alltraps>

8010682c <vector125>:
.globl vector125
vector125:
  pushl $0
8010682c:	6a 00                	push   $0x0
  pushl $125
8010682e:	6a 7d                	push   $0x7d
  jmp alltraps
80106830:	e9 c5 f6 ff ff       	jmp    80105efa <alltraps>

80106835 <vector126>:
.globl vector126
vector126:
  pushl $0
80106835:	6a 00                	push   $0x0
  pushl $126
80106837:	6a 7e                	push   $0x7e
  jmp alltraps
80106839:	e9 bc f6 ff ff       	jmp    80105efa <alltraps>

8010683e <vector127>:
.globl vector127
vector127:
  pushl $0
8010683e:	6a 00                	push   $0x0
  pushl $127
80106840:	6a 7f                	push   $0x7f
  jmp alltraps
80106842:	e9 b3 f6 ff ff       	jmp    80105efa <alltraps>

80106847 <vector128>:
.globl vector128
vector128:
  pushl $0
80106847:	6a 00                	push   $0x0
  pushl $128
80106849:	68 80 00 00 00       	push   $0x80
  jmp alltraps
8010684e:	e9 a7 f6 ff ff       	jmp    80105efa <alltraps>

80106853 <vector129>:
.globl vector129
vector129:
  pushl $0
80106853:	6a 00                	push   $0x0
  pushl $129
80106855:	68 81 00 00 00       	push   $0x81
  jmp alltraps
8010685a:	e9 9b f6 ff ff       	jmp    80105efa <alltraps>

8010685f <vector130>:
.globl vector130
vector130:
  pushl $0
8010685f:	6a 00                	push   $0x0
  pushl $130
80106861:	68 82 00 00 00       	push   $0x82
  jmp alltraps
80106866:	e9 8f f6 ff ff       	jmp    80105efa <alltraps>

8010686b <vector131>:
.globl vector131
vector131:
  pushl $0
8010686b:	6a 00                	push   $0x0
  pushl $131
8010686d:	68 83 00 00 00       	push   $0x83
  jmp alltraps
80106872:	e9 83 f6 ff ff       	jmp    80105efa <alltraps>

80106877 <vector132>:
.globl vector132
vector132:
  pushl $0
80106877:	6a 00                	push   $0x0
  pushl $132
80106879:	68 84 00 00 00       	push   $0x84
  jmp alltraps
8010687e:	e9 77 f6 ff ff       	jmp    80105efa <alltraps>

80106883 <vector133>:
.globl vector133
vector133:
  pushl $0
80106883:	6a 00                	push   $0x0
  pushl $133
80106885:	68 85 00 00 00       	push   $0x85
  jmp alltraps
8010688a:	e9 6b f6 ff ff       	jmp    80105efa <alltraps>

8010688f <vector134>:
.globl vector134
vector134:
  pushl $0
8010688f:	6a 00                	push   $0x0
  pushl $134
80106891:	68 86 00 00 00       	push   $0x86
  jmp alltraps
80106896:	e9 5f f6 ff ff       	jmp    80105efa <alltraps>

8010689b <vector135>:
.globl vector135
vector135:
  pushl $0
8010689b:	6a 00                	push   $0x0
  pushl $135
8010689d:	68 87 00 00 00       	push   $0x87
  jmp alltraps
801068a2:	e9 53 f6 ff ff       	jmp    80105efa <alltraps>

801068a7 <vector136>:
.globl vector136
vector136:
  pushl $0
801068a7:	6a 00                	push   $0x0
  pushl $136
801068a9:	68 88 00 00 00       	push   $0x88
  jmp alltraps
801068ae:	e9 47 f6 ff ff       	jmp    80105efa <alltraps>

801068b3 <vector137>:
.globl vector137
vector137:
  pushl $0
801068b3:	6a 00                	push   $0x0
  pushl $137
801068b5:	68 89 00 00 00       	push   $0x89
  jmp alltraps
801068ba:	e9 3b f6 ff ff       	jmp    80105efa <alltraps>

801068bf <vector138>:
.globl vector138
vector138:
  pushl $0
801068bf:	6a 00                	push   $0x0
  pushl $138
801068c1:	68 8a 00 00 00       	push   $0x8a
  jmp alltraps
801068c6:	e9 2f f6 ff ff       	jmp    80105efa <alltraps>

801068cb <vector139>:
.globl vector139
vector139:
  pushl $0
801068cb:	6a 00                	push   $0x0
  pushl $139
801068cd:	68 8b 00 00 00       	push   $0x8b
  jmp alltraps
801068d2:	e9 23 f6 ff ff       	jmp    80105efa <alltraps>

801068d7 <vector140>:
.globl vector140
vector140:
  pushl $0
801068d7:	6a 00                	push   $0x0
  pushl $140
801068d9:	68 8c 00 00 00       	push   $0x8c
  jmp alltraps
801068de:	e9 17 f6 ff ff       	jmp    80105efa <alltraps>

801068e3 <vector141>:
.globl vector141
vector141:
  pushl $0
801068e3:	6a 00                	push   $0x0
  pushl $141
801068e5:	68 8d 00 00 00       	push   $0x8d
  jmp alltraps
801068ea:	e9 0b f6 ff ff       	jmp    80105efa <alltraps>

801068ef <vector142>:
.globl vector142
vector142:
  pushl $0
801068ef:	6a 00                	push   $0x0
  pushl $142
801068f1:	68 8e 00 00 00       	push   $0x8e
  jmp alltraps
801068f6:	e9 ff f5 ff ff       	jmp    80105efa <alltraps>

801068fb <vector143>:
.globl vector143
vector143:
  pushl $0
801068fb:	6a 00                	push   $0x0
  pushl $143
801068fd:	68 8f 00 00 00       	push   $0x8f
  jmp alltraps
80106902:	e9 f3 f5 ff ff       	jmp    80105efa <alltraps>

80106907 <vector144>:
.globl vector144
vector144:
  pushl $0
80106907:	6a 00                	push   $0x0
  pushl $144
80106909:	68 90 00 00 00       	push   $0x90
  jmp alltraps
8010690e:	e9 e7 f5 ff ff       	jmp    80105efa <alltraps>

80106913 <vector145>:
.globl vector145
vector145:
  pushl $0
80106913:	6a 00                	push   $0x0
  pushl $145
80106915:	68 91 00 00 00       	push   $0x91
  jmp alltraps
8010691a:	e9 db f5 ff ff       	jmp    80105efa <alltraps>

8010691f <vector146>:
.globl vector146
vector146:
  pushl $0
8010691f:	6a 00                	push   $0x0
  pushl $146
80106921:	68 92 00 00 00       	push   $0x92
  jmp alltraps
80106926:	e9 cf f5 ff ff       	jmp    80105efa <alltraps>

8010692b <vector147>:
.globl vector147
vector147:
  pushl $0
8010692b:	6a 00                	push   $0x0
  pushl $147
8010692d:	68 93 00 00 00       	push   $0x93
  jmp alltraps
80106932:	e9 c3 f5 ff ff       	jmp    80105efa <alltraps>

80106937 <vector148>:
.globl vector148
vector148:
  pushl $0
80106937:	6a 00                	push   $0x0
  pushl $148
80106939:	68 94 00 00 00       	push   $0x94
  jmp alltraps
8010693e:	e9 b7 f5 ff ff       	jmp    80105efa <alltraps>

80106943 <vector149>:
.globl vector149
vector149:
  pushl $0
80106943:	6a 00                	push   $0x0
  pushl $149
80106945:	68 95 00 00 00       	push   $0x95
  jmp alltraps
8010694a:	e9 ab f5 ff ff       	jmp    80105efa <alltraps>

8010694f <vector150>:
.globl vector150
vector150:
  pushl $0
8010694f:	6a 00                	push   $0x0
  pushl $150
80106951:	68 96 00 00 00       	push   $0x96
  jmp alltraps
80106956:	e9 9f f5 ff ff       	jmp    80105efa <alltraps>

8010695b <vector151>:
.globl vector151
vector151:
  pushl $0
8010695b:	6a 00                	push   $0x0
  pushl $151
8010695d:	68 97 00 00 00       	push   $0x97
  jmp alltraps
80106962:	e9 93 f5 ff ff       	jmp    80105efa <alltraps>

80106967 <vector152>:
.globl vector152
vector152:
  pushl $0
80106967:	6a 00                	push   $0x0
  pushl $152
80106969:	68 98 00 00 00       	push   $0x98
  jmp alltraps
8010696e:	e9 87 f5 ff ff       	jmp    80105efa <alltraps>

80106973 <vector153>:
.globl vector153
vector153:
  pushl $0
80106973:	6a 00                	push   $0x0
  pushl $153
80106975:	68 99 00 00 00       	push   $0x99
  jmp alltraps
8010697a:	e9 7b f5 ff ff       	jmp    80105efa <alltraps>

8010697f <vector154>:
.globl vector154
vector154:
  pushl $0
8010697f:	6a 00                	push   $0x0
  pushl $154
80106981:	68 9a 00 00 00       	push   $0x9a
  jmp alltraps
80106986:	e9 6f f5 ff ff       	jmp    80105efa <alltraps>

8010698b <vector155>:
.globl vector155
vector155:
  pushl $0
8010698b:	6a 00                	push   $0x0
  pushl $155
8010698d:	68 9b 00 00 00       	push   $0x9b
  jmp alltraps
80106992:	e9 63 f5 ff ff       	jmp    80105efa <alltraps>

80106997 <vector156>:
.globl vector156
vector156:
  pushl $0
80106997:	6a 00                	push   $0x0
  pushl $156
80106999:	68 9c 00 00 00       	push   $0x9c
  jmp alltraps
8010699e:	e9 57 f5 ff ff       	jmp    80105efa <alltraps>

801069a3 <vector157>:
.globl vector157
vector157:
  pushl $0
801069a3:	6a 00                	push   $0x0
  pushl $157
801069a5:	68 9d 00 00 00       	push   $0x9d
  jmp alltraps
801069aa:	e9 4b f5 ff ff       	jmp    80105efa <alltraps>

801069af <vector158>:
.globl vector158
vector158:
  pushl $0
801069af:	6a 00                	push   $0x0
  pushl $158
801069b1:	68 9e 00 00 00       	push   $0x9e
  jmp alltraps
801069b6:	e9 3f f5 ff ff       	jmp    80105efa <alltraps>

801069bb <vector159>:
.globl vector159
vector159:
  pushl $0
801069bb:	6a 00                	push   $0x0
  pushl $159
801069bd:	68 9f 00 00 00       	push   $0x9f
  jmp alltraps
801069c2:	e9 33 f5 ff ff       	jmp    80105efa <alltraps>

801069c7 <vector160>:
.globl vector160
vector160:
  pushl $0
801069c7:	6a 00                	push   $0x0
  pushl $160
801069c9:	68 a0 00 00 00       	push   $0xa0
  jmp alltraps
801069ce:	e9 27 f5 ff ff       	jmp    80105efa <alltraps>

801069d3 <vector161>:
.globl vector161
vector161:
  pushl $0
801069d3:	6a 00                	push   $0x0
  pushl $161
801069d5:	68 a1 00 00 00       	push   $0xa1
  jmp alltraps
801069da:	e9 1b f5 ff ff       	jmp    80105efa <alltraps>

801069df <vector162>:
.globl vector162
vector162:
  pushl $0
801069df:	6a 00                	push   $0x0
  pushl $162
801069e1:	68 a2 00 00 00       	push   $0xa2
  jmp alltraps
801069e6:	e9 0f f5 ff ff       	jmp    80105efa <alltraps>

801069eb <vector163>:
.globl vector163
vector163:
  pushl $0
801069eb:	6a 00                	push   $0x0
  pushl $163
801069ed:	68 a3 00 00 00       	push   $0xa3
  jmp alltraps
801069f2:	e9 03 f5 ff ff       	jmp    80105efa <alltraps>

801069f7 <vector164>:
.globl vector164
vector164:
  pushl $0
801069f7:	6a 00                	push   $0x0
  pushl $164
801069f9:	68 a4 00 00 00       	push   $0xa4
  jmp alltraps
801069fe:	e9 f7 f4 ff ff       	jmp    80105efa <alltraps>

80106a03 <vector165>:
.globl vector165
vector165:
  pushl $0
80106a03:	6a 00                	push   $0x0
  pushl $165
80106a05:	68 a5 00 00 00       	push   $0xa5
  jmp alltraps
80106a0a:	e9 eb f4 ff ff       	jmp    80105efa <alltraps>

80106a0f <vector166>:
.globl vector166
vector166:
  pushl $0
80106a0f:	6a 00                	push   $0x0
  pushl $166
80106a11:	68 a6 00 00 00       	push   $0xa6
  jmp alltraps
80106a16:	e9 df f4 ff ff       	jmp    80105efa <alltraps>

80106a1b <vector167>:
.globl vector167
vector167:
  pushl $0
80106a1b:	6a 00                	push   $0x0
  pushl $167
80106a1d:	68 a7 00 00 00       	push   $0xa7
  jmp alltraps
80106a22:	e9 d3 f4 ff ff       	jmp    80105efa <alltraps>

80106a27 <vector168>:
.globl vector168
vector168:
  pushl $0
80106a27:	6a 00                	push   $0x0
  pushl $168
80106a29:	68 a8 00 00 00       	push   $0xa8
  jmp alltraps
80106a2e:	e9 c7 f4 ff ff       	jmp    80105efa <alltraps>

80106a33 <vector169>:
.globl vector169
vector169:
  pushl $0
80106a33:	6a 00                	push   $0x0
  pushl $169
80106a35:	68 a9 00 00 00       	push   $0xa9
  jmp alltraps
80106a3a:	e9 bb f4 ff ff       	jmp    80105efa <alltraps>

80106a3f <vector170>:
.globl vector170
vector170:
  pushl $0
80106a3f:	6a 00                	push   $0x0
  pushl $170
80106a41:	68 aa 00 00 00       	push   $0xaa
  jmp alltraps
80106a46:	e9 af f4 ff ff       	jmp    80105efa <alltraps>

80106a4b <vector171>:
.globl vector171
vector171:
  pushl $0
80106a4b:	6a 00                	push   $0x0
  pushl $171
80106a4d:	68 ab 00 00 00       	push   $0xab
  jmp alltraps
80106a52:	e9 a3 f4 ff ff       	jmp    80105efa <alltraps>

80106a57 <vector172>:
.globl vector172
vector172:
  pushl $0
80106a57:	6a 00                	push   $0x0
  pushl $172
80106a59:	68 ac 00 00 00       	push   $0xac
  jmp alltraps
80106a5e:	e9 97 f4 ff ff       	jmp    80105efa <alltraps>

80106a63 <vector173>:
.globl vector173
vector173:
  pushl $0
80106a63:	6a 00                	push   $0x0
  pushl $173
80106a65:	68 ad 00 00 00       	push   $0xad
  jmp alltraps
80106a6a:	e9 8b f4 ff ff       	jmp    80105efa <alltraps>

80106a6f <vector174>:
.globl vector174
vector174:
  pushl $0
80106a6f:	6a 00                	push   $0x0
  pushl $174
80106a71:	68 ae 00 00 00       	push   $0xae
  jmp alltraps
80106a76:	e9 7f f4 ff ff       	jmp    80105efa <alltraps>

80106a7b <vector175>:
.globl vector175
vector175:
  pushl $0
80106a7b:	6a 00                	push   $0x0
  pushl $175
80106a7d:	68 af 00 00 00       	push   $0xaf
  jmp alltraps
80106a82:	e9 73 f4 ff ff       	jmp    80105efa <alltraps>

80106a87 <vector176>:
.globl vector176
vector176:
  pushl $0
80106a87:	6a 00                	push   $0x0
  pushl $176
80106a89:	68 b0 00 00 00       	push   $0xb0
  jmp alltraps
80106a8e:	e9 67 f4 ff ff       	jmp    80105efa <alltraps>

80106a93 <vector177>:
.globl vector177
vector177:
  pushl $0
80106a93:	6a 00                	push   $0x0
  pushl $177
80106a95:	68 b1 00 00 00       	push   $0xb1
  jmp alltraps
80106a9a:	e9 5b f4 ff ff       	jmp    80105efa <alltraps>

80106a9f <vector178>:
.globl vector178
vector178:
  pushl $0
80106a9f:	6a 00                	push   $0x0
  pushl $178
80106aa1:	68 b2 00 00 00       	push   $0xb2
  jmp alltraps
80106aa6:	e9 4f f4 ff ff       	jmp    80105efa <alltraps>

80106aab <vector179>:
.globl vector179
vector179:
  pushl $0
80106aab:	6a 00                	push   $0x0
  pushl $179
80106aad:	68 b3 00 00 00       	push   $0xb3
  jmp alltraps
80106ab2:	e9 43 f4 ff ff       	jmp    80105efa <alltraps>

80106ab7 <vector180>:
.globl vector180
vector180:
  pushl $0
80106ab7:	6a 00                	push   $0x0
  pushl $180
80106ab9:	68 b4 00 00 00       	push   $0xb4
  jmp alltraps
80106abe:	e9 37 f4 ff ff       	jmp    80105efa <alltraps>

80106ac3 <vector181>:
.globl vector181
vector181:
  pushl $0
80106ac3:	6a 00                	push   $0x0
  pushl $181
80106ac5:	68 b5 00 00 00       	push   $0xb5
  jmp alltraps
80106aca:	e9 2b f4 ff ff       	jmp    80105efa <alltraps>

80106acf <vector182>:
.globl vector182
vector182:
  pushl $0
80106acf:	6a 00                	push   $0x0
  pushl $182
80106ad1:	68 b6 00 00 00       	push   $0xb6
  jmp alltraps
80106ad6:	e9 1f f4 ff ff       	jmp    80105efa <alltraps>

80106adb <vector183>:
.globl vector183
vector183:
  pushl $0
80106adb:	6a 00                	push   $0x0
  pushl $183
80106add:	68 b7 00 00 00       	push   $0xb7
  jmp alltraps
80106ae2:	e9 13 f4 ff ff       	jmp    80105efa <alltraps>

80106ae7 <vector184>:
.globl vector184
vector184:
  pushl $0
80106ae7:	6a 00                	push   $0x0
  pushl $184
80106ae9:	68 b8 00 00 00       	push   $0xb8
  jmp alltraps
80106aee:	e9 07 f4 ff ff       	jmp    80105efa <alltraps>

80106af3 <vector185>:
.globl vector185
vector185:
  pushl $0
80106af3:	6a 00                	push   $0x0
  pushl $185
80106af5:	68 b9 00 00 00       	push   $0xb9
  jmp alltraps
80106afa:	e9 fb f3 ff ff       	jmp    80105efa <alltraps>

80106aff <vector186>:
.globl vector186
vector186:
  pushl $0
80106aff:	6a 00                	push   $0x0
  pushl $186
80106b01:	68 ba 00 00 00       	push   $0xba
  jmp alltraps
80106b06:	e9 ef f3 ff ff       	jmp    80105efa <alltraps>

80106b0b <vector187>:
.globl vector187
vector187:
  pushl $0
80106b0b:	6a 00                	push   $0x0
  pushl $187
80106b0d:	68 bb 00 00 00       	push   $0xbb
  jmp alltraps
80106b12:	e9 e3 f3 ff ff       	jmp    80105efa <alltraps>

80106b17 <vector188>:
.globl vector188
vector188:
  pushl $0
80106b17:	6a 00                	push   $0x0
  pushl $188
80106b19:	68 bc 00 00 00       	push   $0xbc
  jmp alltraps
80106b1e:	e9 d7 f3 ff ff       	jmp    80105efa <alltraps>

80106b23 <vector189>:
.globl vector189
vector189:
  pushl $0
80106b23:	6a 00                	push   $0x0
  pushl $189
80106b25:	68 bd 00 00 00       	push   $0xbd
  jmp alltraps
80106b2a:	e9 cb f3 ff ff       	jmp    80105efa <alltraps>

80106b2f <vector190>:
.globl vector190
vector190:
  pushl $0
80106b2f:	6a 00                	push   $0x0
  pushl $190
80106b31:	68 be 00 00 00       	push   $0xbe
  jmp alltraps
80106b36:	e9 bf f3 ff ff       	jmp    80105efa <alltraps>

80106b3b <vector191>:
.globl vector191
vector191:
  pushl $0
80106b3b:	6a 00                	push   $0x0
  pushl $191
80106b3d:	68 bf 00 00 00       	push   $0xbf
  jmp alltraps
80106b42:	e9 b3 f3 ff ff       	jmp    80105efa <alltraps>

80106b47 <vector192>:
.globl vector192
vector192:
  pushl $0
80106b47:	6a 00                	push   $0x0
  pushl $192
80106b49:	68 c0 00 00 00       	push   $0xc0
  jmp alltraps
80106b4e:	e9 a7 f3 ff ff       	jmp    80105efa <alltraps>

80106b53 <vector193>:
.globl vector193
vector193:
  pushl $0
80106b53:	6a 00                	push   $0x0
  pushl $193
80106b55:	68 c1 00 00 00       	push   $0xc1
  jmp alltraps
80106b5a:	e9 9b f3 ff ff       	jmp    80105efa <alltraps>

80106b5f <vector194>:
.globl vector194
vector194:
  pushl $0
80106b5f:	6a 00                	push   $0x0
  pushl $194
80106b61:	68 c2 00 00 00       	push   $0xc2
  jmp alltraps
80106b66:	e9 8f f3 ff ff       	jmp    80105efa <alltraps>

80106b6b <vector195>:
.globl vector195
vector195:
  pushl $0
80106b6b:	6a 00                	push   $0x0
  pushl $195
80106b6d:	68 c3 00 00 00       	push   $0xc3
  jmp alltraps
80106b72:	e9 83 f3 ff ff       	jmp    80105efa <alltraps>

80106b77 <vector196>:
.globl vector196
vector196:
  pushl $0
80106b77:	6a 00                	push   $0x0
  pushl $196
80106b79:	68 c4 00 00 00       	push   $0xc4
  jmp alltraps
80106b7e:	e9 77 f3 ff ff       	jmp    80105efa <alltraps>

80106b83 <vector197>:
.globl vector197
vector197:
  pushl $0
80106b83:	6a 00                	push   $0x0
  pushl $197
80106b85:	68 c5 00 00 00       	push   $0xc5
  jmp alltraps
80106b8a:	e9 6b f3 ff ff       	jmp    80105efa <alltraps>

80106b8f <vector198>:
.globl vector198
vector198:
  pushl $0
80106b8f:	6a 00                	push   $0x0
  pushl $198
80106b91:	68 c6 00 00 00       	push   $0xc6
  jmp alltraps
80106b96:	e9 5f f3 ff ff       	jmp    80105efa <alltraps>

80106b9b <vector199>:
.globl vector199
vector199:
  pushl $0
80106b9b:	6a 00                	push   $0x0
  pushl $199
80106b9d:	68 c7 00 00 00       	push   $0xc7
  jmp alltraps
80106ba2:	e9 53 f3 ff ff       	jmp    80105efa <alltraps>

80106ba7 <vector200>:
.globl vector200
vector200:
  pushl $0
80106ba7:	6a 00                	push   $0x0
  pushl $200
80106ba9:	68 c8 00 00 00       	push   $0xc8
  jmp alltraps
80106bae:	e9 47 f3 ff ff       	jmp    80105efa <alltraps>

80106bb3 <vector201>:
.globl vector201
vector201:
  pushl $0
80106bb3:	6a 00                	push   $0x0
  pushl $201
80106bb5:	68 c9 00 00 00       	push   $0xc9
  jmp alltraps
80106bba:	e9 3b f3 ff ff       	jmp    80105efa <alltraps>

80106bbf <vector202>:
.globl vector202
vector202:
  pushl $0
80106bbf:	6a 00                	push   $0x0
  pushl $202
80106bc1:	68 ca 00 00 00       	push   $0xca
  jmp alltraps
80106bc6:	e9 2f f3 ff ff       	jmp    80105efa <alltraps>

80106bcb <vector203>:
.globl vector203
vector203:
  pushl $0
80106bcb:	6a 00                	push   $0x0
  pushl $203
80106bcd:	68 cb 00 00 00       	push   $0xcb
  jmp alltraps
80106bd2:	e9 23 f3 ff ff       	jmp    80105efa <alltraps>

80106bd7 <vector204>:
.globl vector204
vector204:
  pushl $0
80106bd7:	6a 00                	push   $0x0
  pushl $204
80106bd9:	68 cc 00 00 00       	push   $0xcc
  jmp alltraps
80106bde:	e9 17 f3 ff ff       	jmp    80105efa <alltraps>

80106be3 <vector205>:
.globl vector205
vector205:
  pushl $0
80106be3:	6a 00                	push   $0x0
  pushl $205
80106be5:	68 cd 00 00 00       	push   $0xcd
  jmp alltraps
80106bea:	e9 0b f3 ff ff       	jmp    80105efa <alltraps>

80106bef <vector206>:
.globl vector206
vector206:
  pushl $0
80106bef:	6a 00                	push   $0x0
  pushl $206
80106bf1:	68 ce 00 00 00       	push   $0xce
  jmp alltraps
80106bf6:	e9 ff f2 ff ff       	jmp    80105efa <alltraps>

80106bfb <vector207>:
.globl vector207
vector207:
  pushl $0
80106bfb:	6a 00                	push   $0x0
  pushl $207
80106bfd:	68 cf 00 00 00       	push   $0xcf
  jmp alltraps
80106c02:	e9 f3 f2 ff ff       	jmp    80105efa <alltraps>

80106c07 <vector208>:
.globl vector208
vector208:
  pushl $0
80106c07:	6a 00                	push   $0x0
  pushl $208
80106c09:	68 d0 00 00 00       	push   $0xd0
  jmp alltraps
80106c0e:	e9 e7 f2 ff ff       	jmp    80105efa <alltraps>

80106c13 <vector209>:
.globl vector209
vector209:
  pushl $0
80106c13:	6a 00                	push   $0x0
  pushl $209
80106c15:	68 d1 00 00 00       	push   $0xd1
  jmp alltraps
80106c1a:	e9 db f2 ff ff       	jmp    80105efa <alltraps>

80106c1f <vector210>:
.globl vector210
vector210:
  pushl $0
80106c1f:	6a 00                	push   $0x0
  pushl $210
80106c21:	68 d2 00 00 00       	push   $0xd2
  jmp alltraps
80106c26:	e9 cf f2 ff ff       	jmp    80105efa <alltraps>

80106c2b <vector211>:
.globl vector211
vector211:
  pushl $0
80106c2b:	6a 00                	push   $0x0
  pushl $211
80106c2d:	68 d3 00 00 00       	push   $0xd3
  jmp alltraps
80106c32:	e9 c3 f2 ff ff       	jmp    80105efa <alltraps>

80106c37 <vector212>:
.globl vector212
vector212:
  pushl $0
80106c37:	6a 00                	push   $0x0
  pushl $212
80106c39:	68 d4 00 00 00       	push   $0xd4
  jmp alltraps
80106c3e:	e9 b7 f2 ff ff       	jmp    80105efa <alltraps>

80106c43 <vector213>:
.globl vector213
vector213:
  pushl $0
80106c43:	6a 00                	push   $0x0
  pushl $213
80106c45:	68 d5 00 00 00       	push   $0xd5
  jmp alltraps
80106c4a:	e9 ab f2 ff ff       	jmp    80105efa <alltraps>

80106c4f <vector214>:
.globl vector214
vector214:
  pushl $0
80106c4f:	6a 00                	push   $0x0
  pushl $214
80106c51:	68 d6 00 00 00       	push   $0xd6
  jmp alltraps
80106c56:	e9 9f f2 ff ff       	jmp    80105efa <alltraps>

80106c5b <vector215>:
.globl vector215
vector215:
  pushl $0
80106c5b:	6a 00                	push   $0x0
  pushl $215
80106c5d:	68 d7 00 00 00       	push   $0xd7
  jmp alltraps
80106c62:	e9 93 f2 ff ff       	jmp    80105efa <alltraps>

80106c67 <vector216>:
.globl vector216
vector216:
  pushl $0
80106c67:	6a 00                	push   $0x0
  pushl $216
80106c69:	68 d8 00 00 00       	push   $0xd8
  jmp alltraps
80106c6e:	e9 87 f2 ff ff       	jmp    80105efa <alltraps>

80106c73 <vector217>:
.globl vector217
vector217:
  pushl $0
80106c73:	6a 00                	push   $0x0
  pushl $217
80106c75:	68 d9 00 00 00       	push   $0xd9
  jmp alltraps
80106c7a:	e9 7b f2 ff ff       	jmp    80105efa <alltraps>

80106c7f <vector218>:
.globl vector218
vector218:
  pushl $0
80106c7f:	6a 00                	push   $0x0
  pushl $218
80106c81:	68 da 00 00 00       	push   $0xda
  jmp alltraps
80106c86:	e9 6f f2 ff ff       	jmp    80105efa <alltraps>

80106c8b <vector219>:
.globl vector219
vector219:
  pushl $0
80106c8b:	6a 00                	push   $0x0
  pushl $219
80106c8d:	68 db 00 00 00       	push   $0xdb
  jmp alltraps
80106c92:	e9 63 f2 ff ff       	jmp    80105efa <alltraps>

80106c97 <vector220>:
.globl vector220
vector220:
  pushl $0
80106c97:	6a 00                	push   $0x0
  pushl $220
80106c99:	68 dc 00 00 00       	push   $0xdc
  jmp alltraps
80106c9e:	e9 57 f2 ff ff       	jmp    80105efa <alltraps>

80106ca3 <vector221>:
.globl vector221
vector221:
  pushl $0
80106ca3:	6a 00                	push   $0x0
  pushl $221
80106ca5:	68 dd 00 00 00       	push   $0xdd
  jmp alltraps
80106caa:	e9 4b f2 ff ff       	jmp    80105efa <alltraps>

80106caf <vector222>:
.globl vector222
vector222:
  pushl $0
80106caf:	6a 00                	push   $0x0
  pushl $222
80106cb1:	68 de 00 00 00       	push   $0xde
  jmp alltraps
80106cb6:	e9 3f f2 ff ff       	jmp    80105efa <alltraps>

80106cbb <vector223>:
.globl vector223
vector223:
  pushl $0
80106cbb:	6a 00                	push   $0x0
  pushl $223
80106cbd:	68 df 00 00 00       	push   $0xdf
  jmp alltraps
80106cc2:	e9 33 f2 ff ff       	jmp    80105efa <alltraps>

80106cc7 <vector224>:
.globl vector224
vector224:
  pushl $0
80106cc7:	6a 00                	push   $0x0
  pushl $224
80106cc9:	68 e0 00 00 00       	push   $0xe0
  jmp alltraps
80106cce:	e9 27 f2 ff ff       	jmp    80105efa <alltraps>

80106cd3 <vector225>:
.globl vector225
vector225:
  pushl $0
80106cd3:	6a 00                	push   $0x0
  pushl $225
80106cd5:	68 e1 00 00 00       	push   $0xe1
  jmp alltraps
80106cda:	e9 1b f2 ff ff       	jmp    80105efa <alltraps>

80106cdf <vector226>:
.globl vector226
vector226:
  pushl $0
80106cdf:	6a 00                	push   $0x0
  pushl $226
80106ce1:	68 e2 00 00 00       	push   $0xe2
  jmp alltraps
80106ce6:	e9 0f f2 ff ff       	jmp    80105efa <alltraps>

80106ceb <vector227>:
.globl vector227
vector227:
  pushl $0
80106ceb:	6a 00                	push   $0x0
  pushl $227
80106ced:	68 e3 00 00 00       	push   $0xe3
  jmp alltraps
80106cf2:	e9 03 f2 ff ff       	jmp    80105efa <alltraps>

80106cf7 <vector228>:
.globl vector228
vector228:
  pushl $0
80106cf7:	6a 00                	push   $0x0
  pushl $228
80106cf9:	68 e4 00 00 00       	push   $0xe4
  jmp alltraps
80106cfe:	e9 f7 f1 ff ff       	jmp    80105efa <alltraps>

80106d03 <vector229>:
.globl vector229
vector229:
  pushl $0
80106d03:	6a 00                	push   $0x0
  pushl $229
80106d05:	68 e5 00 00 00       	push   $0xe5
  jmp alltraps
80106d0a:	e9 eb f1 ff ff       	jmp    80105efa <alltraps>

80106d0f <vector230>:
.globl vector230
vector230:
  pushl $0
80106d0f:	6a 00                	push   $0x0
  pushl $230
80106d11:	68 e6 00 00 00       	push   $0xe6
  jmp alltraps
80106d16:	e9 df f1 ff ff       	jmp    80105efa <alltraps>

80106d1b <vector231>:
.globl vector231
vector231:
  pushl $0
80106d1b:	6a 00                	push   $0x0
  pushl $231
80106d1d:	68 e7 00 00 00       	push   $0xe7
  jmp alltraps
80106d22:	e9 d3 f1 ff ff       	jmp    80105efa <alltraps>

80106d27 <vector232>:
.globl vector232
vector232:
  pushl $0
80106d27:	6a 00                	push   $0x0
  pushl $232
80106d29:	68 e8 00 00 00       	push   $0xe8
  jmp alltraps
80106d2e:	e9 c7 f1 ff ff       	jmp    80105efa <alltraps>

80106d33 <vector233>:
.globl vector233
vector233:
  pushl $0
80106d33:	6a 00                	push   $0x0
  pushl $233
80106d35:	68 e9 00 00 00       	push   $0xe9
  jmp alltraps
80106d3a:	e9 bb f1 ff ff       	jmp    80105efa <alltraps>

80106d3f <vector234>:
.globl vector234
vector234:
  pushl $0
80106d3f:	6a 00                	push   $0x0
  pushl $234
80106d41:	68 ea 00 00 00       	push   $0xea
  jmp alltraps
80106d46:	e9 af f1 ff ff       	jmp    80105efa <alltraps>

80106d4b <vector235>:
.globl vector235
vector235:
  pushl $0
80106d4b:	6a 00                	push   $0x0
  pushl $235
80106d4d:	68 eb 00 00 00       	push   $0xeb
  jmp alltraps
80106d52:	e9 a3 f1 ff ff       	jmp    80105efa <alltraps>

80106d57 <vector236>:
.globl vector236
vector236:
  pushl $0
80106d57:	6a 00                	push   $0x0
  pushl $236
80106d59:	68 ec 00 00 00       	push   $0xec
  jmp alltraps
80106d5e:	e9 97 f1 ff ff       	jmp    80105efa <alltraps>

80106d63 <vector237>:
.globl vector237
vector237:
  pushl $0
80106d63:	6a 00                	push   $0x0
  pushl $237
80106d65:	68 ed 00 00 00       	push   $0xed
  jmp alltraps
80106d6a:	e9 8b f1 ff ff       	jmp    80105efa <alltraps>

80106d6f <vector238>:
.globl vector238
vector238:
  pushl $0
80106d6f:	6a 00                	push   $0x0
  pushl $238
80106d71:	68 ee 00 00 00       	push   $0xee
  jmp alltraps
80106d76:	e9 7f f1 ff ff       	jmp    80105efa <alltraps>

80106d7b <vector239>:
.globl vector239
vector239:
  pushl $0
80106d7b:	6a 00                	push   $0x0
  pushl $239
80106d7d:	68 ef 00 00 00       	push   $0xef
  jmp alltraps
80106d82:	e9 73 f1 ff ff       	jmp    80105efa <alltraps>

80106d87 <vector240>:
.globl vector240
vector240:
  pushl $0
80106d87:	6a 00                	push   $0x0
  pushl $240
80106d89:	68 f0 00 00 00       	push   $0xf0
  jmp alltraps
80106d8e:	e9 67 f1 ff ff       	jmp    80105efa <alltraps>

80106d93 <vector241>:
.globl vector241
vector241:
  pushl $0
80106d93:	6a 00                	push   $0x0
  pushl $241
80106d95:	68 f1 00 00 00       	push   $0xf1
  jmp alltraps
80106d9a:	e9 5b f1 ff ff       	jmp    80105efa <alltraps>

80106d9f <vector242>:
.globl vector242
vector242:
  pushl $0
80106d9f:	6a 00                	push   $0x0
  pushl $242
80106da1:	68 f2 00 00 00       	push   $0xf2
  jmp alltraps
80106da6:	e9 4f f1 ff ff       	jmp    80105efa <alltraps>

80106dab <vector243>:
.globl vector243
vector243:
  pushl $0
80106dab:	6a 00                	push   $0x0
  pushl $243
80106dad:	68 f3 00 00 00       	push   $0xf3
  jmp alltraps
80106db2:	e9 43 f1 ff ff       	jmp    80105efa <alltraps>

80106db7 <vector244>:
.globl vector244
vector244:
  pushl $0
80106db7:	6a 00                	push   $0x0
  pushl $244
80106db9:	68 f4 00 00 00       	push   $0xf4
  jmp alltraps
80106dbe:	e9 37 f1 ff ff       	jmp    80105efa <alltraps>

80106dc3 <vector245>:
.globl vector245
vector245:
  pushl $0
80106dc3:	6a 00                	push   $0x0
  pushl $245
80106dc5:	68 f5 00 00 00       	push   $0xf5
  jmp alltraps
80106dca:	e9 2b f1 ff ff       	jmp    80105efa <alltraps>

80106dcf <vector246>:
.globl vector246
vector246:
  pushl $0
80106dcf:	6a 00                	push   $0x0
  pushl $246
80106dd1:	68 f6 00 00 00       	push   $0xf6
  jmp alltraps
80106dd6:	e9 1f f1 ff ff       	jmp    80105efa <alltraps>

80106ddb <vector247>:
.globl vector247
vector247:
  pushl $0
80106ddb:	6a 00                	push   $0x0
  pushl $247
80106ddd:	68 f7 00 00 00       	push   $0xf7
  jmp alltraps
80106de2:	e9 13 f1 ff ff       	jmp    80105efa <alltraps>

80106de7 <vector248>:
.globl vector248
vector248:
  pushl $0
80106de7:	6a 00                	push   $0x0
  pushl $248
80106de9:	68 f8 00 00 00       	push   $0xf8
  jmp alltraps
80106dee:	e9 07 f1 ff ff       	jmp    80105efa <alltraps>

80106df3 <vector249>:
.globl vector249
vector249:
  pushl $0
80106df3:	6a 00                	push   $0x0
  pushl $249
80106df5:	68 f9 00 00 00       	push   $0xf9
  jmp alltraps
80106dfa:	e9 fb f0 ff ff       	jmp    80105efa <alltraps>

80106dff <vector250>:
.globl vector250
vector250:
  pushl $0
80106dff:	6a 00                	push   $0x0
  pushl $250
80106e01:	68 fa 00 00 00       	push   $0xfa
  jmp alltraps
80106e06:	e9 ef f0 ff ff       	jmp    80105efa <alltraps>

80106e0b <vector251>:
.globl vector251
vector251:
  pushl $0
80106e0b:	6a 00                	push   $0x0
  pushl $251
80106e0d:	68 fb 00 00 00       	push   $0xfb
  jmp alltraps
80106e12:	e9 e3 f0 ff ff       	jmp    80105efa <alltraps>

80106e17 <vector252>:
.globl vector252
vector252:
  pushl $0
80106e17:	6a 00                	push   $0x0
  pushl $252
80106e19:	68 fc 00 00 00       	push   $0xfc
  jmp alltraps
80106e1e:	e9 d7 f0 ff ff       	jmp    80105efa <alltraps>

80106e23 <vector253>:
.globl vector253
vector253:
  pushl $0
80106e23:	6a 00                	push   $0x0
  pushl $253
80106e25:	68 fd 00 00 00       	push   $0xfd
  jmp alltraps
80106e2a:	e9 cb f0 ff ff       	jmp    80105efa <alltraps>

80106e2f <vector254>:
.globl vector254
vector254:
  pushl $0
80106e2f:	6a 00                	push   $0x0
  pushl $254
80106e31:	68 fe 00 00 00       	push   $0xfe
  jmp alltraps
80106e36:	e9 bf f0 ff ff       	jmp    80105efa <alltraps>

80106e3b <vector255>:
.globl vector255
vector255:
  pushl $0
80106e3b:	6a 00                	push   $0x0
  pushl $255
80106e3d:	68 ff 00 00 00       	push   $0xff
  jmp alltraps
80106e42:	e9 b3 f0 ff ff       	jmp    80105efa <alltraps>
80106e47:	66 90                	xchg   %ax,%ax
80106e49:	66 90                	xchg   %ax,%ax
80106e4b:	66 90                	xchg   %ax,%ax
80106e4d:	66 90                	xchg   %ax,%ax
80106e4f:	90                   	nop

80106e50 <walkpgdir>:
// Return the address of the PTE in page table pgdir
// that corresponds to virtual address va.  If alloc!=0,
// create any required page table pages.
static pte_t *
walkpgdir(pde_t *pgdir, const void *va, int alloc)
{
80106e50:	55                   	push   %ebp
80106e51:	89 e5                	mov    %esp,%ebp
80106e53:	57                   	push   %edi
80106e54:	56                   	push   %esi
80106e55:	53                   	push   %ebx
  pde_t *pde;
  pte_t *pgtab;

  pde = &pgdir[PDX(va)];
80106e56:	89 d3                	mov    %edx,%ebx
{
80106e58:	89 d7                	mov    %edx,%edi
  pde = &pgdir[PDX(va)];
80106e5a:	c1 eb 16             	shr    $0x16,%ebx
80106e5d:	8d 34 98             	lea    (%eax,%ebx,4),%esi
{
80106e60:	83 ec 0c             	sub    $0xc,%esp
  if(*pde & PTE_P){
80106e63:	8b 06                	mov    (%esi),%eax
80106e65:	a8 01                	test   $0x1,%al
80106e67:	74 27                	je     80106e90 <walkpgdir+0x40>
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80106e69:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106e6e:	8d 98 00 00 00 80    	lea    -0x80000000(%eax),%ebx
    // The permissions here are overly generous, but they can
    // be further restricted by the permissions in the page table
    // entries, if necessary.
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
  }
  return &pgtab[PTX(va)];
80106e74:	c1 ef 0a             	shr    $0xa,%edi
}
80106e77:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return &pgtab[PTX(va)];
80106e7a:	89 fa                	mov    %edi,%edx
80106e7c:	81 e2 fc 0f 00 00    	and    $0xffc,%edx
80106e82:	8d 04 13             	lea    (%ebx,%edx,1),%eax
}
80106e85:	5b                   	pop    %ebx
80106e86:	5e                   	pop    %esi
80106e87:	5f                   	pop    %edi
80106e88:	5d                   	pop    %ebp
80106e89:	c3                   	ret    
80106e8a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    if(!alloc || (pgtab = (pte_t*)kalloc()) == 0)
80106e90:	85 c9                	test   %ecx,%ecx
80106e92:	74 2c                	je     80106ec0 <walkpgdir+0x70>
80106e94:	e8 a7 be ff ff       	call   80102d40 <kalloc>
80106e99:	85 c0                	test   %eax,%eax
80106e9b:	89 c3                	mov    %eax,%ebx
80106e9d:	74 21                	je     80106ec0 <walkpgdir+0x70>
    memset(pgtab, 0, PGSIZE);
80106e9f:	83 ec 04             	sub    $0x4,%esp
80106ea2:	68 00 10 00 00       	push   $0x1000
80106ea7:	6a 00                	push   $0x0
80106ea9:	50                   	push   %eax
80106eaa:	e8 21 de ff ff       	call   80104cd0 <memset>
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
80106eaf:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
80106eb5:	83 c4 10             	add    $0x10,%esp
80106eb8:	83 c8 07             	or     $0x7,%eax
80106ebb:	89 06                	mov    %eax,(%esi)
80106ebd:	eb b5                	jmp    80106e74 <walkpgdir+0x24>
80106ebf:	90                   	nop
}
80106ec0:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return 0;
80106ec3:	31 c0                	xor    %eax,%eax
}
80106ec5:	5b                   	pop    %ebx
80106ec6:	5e                   	pop    %esi
80106ec7:	5f                   	pop    %edi
80106ec8:	5d                   	pop    %ebp
80106ec9:	c3                   	ret    
80106eca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80106ed0 <mappages>:
// Create PTEs for virtual addresses starting at va that refer to
// physical addresses starting at pa. va and size might not
// be page-aligned.
static int
mappages(pde_t *pgdir, void *va, uint size, uint pa, int perm)
{
80106ed0:	55                   	push   %ebp
80106ed1:	89 e5                	mov    %esp,%ebp
80106ed3:	57                   	push   %edi
80106ed4:	56                   	push   %esi
80106ed5:	53                   	push   %ebx
  char *a, *last;
  pte_t *pte;

  a = (char*)PGROUNDDOWN((uint)va);
80106ed6:	89 d3                	mov    %edx,%ebx
80106ed8:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
{
80106ede:	83 ec 1c             	sub    $0x1c,%esp
80106ee1:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  last = (char*)PGROUNDDOWN(((uint)va) + size - 1);
80106ee4:	8d 44 0a ff          	lea    -0x1(%edx,%ecx,1),%eax
80106ee8:	8b 7d 08             	mov    0x8(%ebp),%edi
80106eeb:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106ef0:	89 45 e0             	mov    %eax,-0x20(%ebp)
  for(;;){
    if((pte = walkpgdir(pgdir, a, 1)) == 0)
      return -1;
    if(*pte & PTE_P)
      panic("remap");
    *pte = pa | perm | PTE_P;
80106ef3:	8b 45 0c             	mov    0xc(%ebp),%eax
80106ef6:	29 df                	sub    %ebx,%edi
80106ef8:	83 c8 01             	or     $0x1,%eax
80106efb:	89 45 dc             	mov    %eax,-0x24(%ebp)
80106efe:	eb 15                	jmp    80106f15 <mappages+0x45>
    if(*pte & PTE_P)
80106f00:	f6 00 01             	testb  $0x1,(%eax)
80106f03:	75 45                	jne    80106f4a <mappages+0x7a>
    *pte = pa | perm | PTE_P;
80106f05:	0b 75 dc             	or     -0x24(%ebp),%esi
    if(a == last)
80106f08:	3b 5d e0             	cmp    -0x20(%ebp),%ebx
    *pte = pa | perm | PTE_P;
80106f0b:	89 30                	mov    %esi,(%eax)
    if(a == last)
80106f0d:	74 31                	je     80106f40 <mappages+0x70>
      break;
    a += PGSIZE;
80106f0f:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    if((pte = walkpgdir(pgdir, a, 1)) == 0)
80106f15:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80106f18:	b9 01 00 00 00       	mov    $0x1,%ecx
80106f1d:	89 da                	mov    %ebx,%edx
80106f1f:	8d 34 3b             	lea    (%ebx,%edi,1),%esi
80106f22:	e8 29 ff ff ff       	call   80106e50 <walkpgdir>
80106f27:	85 c0                	test   %eax,%eax
80106f29:	75 d5                	jne    80106f00 <mappages+0x30>
    pa += PGSIZE;
  }
  return 0;
}
80106f2b:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return -1;
80106f2e:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80106f33:	5b                   	pop    %ebx
80106f34:	5e                   	pop    %esi
80106f35:	5f                   	pop    %edi
80106f36:	5d                   	pop    %ebp
80106f37:	c3                   	ret    
80106f38:	90                   	nop
80106f39:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80106f40:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
80106f43:	31 c0                	xor    %eax,%eax
}
80106f45:	5b                   	pop    %ebx
80106f46:	5e                   	pop    %esi
80106f47:	5f                   	pop    %edi
80106f48:	5d                   	pop    %ebp
80106f49:	c3                   	ret    
      panic("remap");
80106f4a:	83 ec 0c             	sub    $0xc,%esp
80106f4d:	68 2c 81 10 80       	push   $0x8010812c
80106f52:	e8 39 94 ff ff       	call   80100390 <panic>
80106f57:	89 f6                	mov    %esi,%esi
80106f59:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80106f60 <deallocuvm.part.0>:
// Deallocate user pages to bring the process size from oldsz to
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
int
deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
80106f60:	55                   	push   %ebp
80106f61:	89 e5                	mov    %esp,%ebp
80106f63:	57                   	push   %edi
80106f64:	56                   	push   %esi
80106f65:	53                   	push   %ebx
  uint a, pa;

  if(newsz >= oldsz)
    return oldsz;

  a = PGROUNDUP(newsz);
80106f66:	8d 99 ff 0f 00 00    	lea    0xfff(%ecx),%ebx
deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
80106f6c:	89 c7                	mov    %eax,%edi
  a = PGROUNDUP(newsz);
80106f6e:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
80106f74:	83 ec 1c             	sub    $0x1c,%esp
80106f77:	89 4d e0             	mov    %ecx,-0x20(%ebp)
  for(; a  < oldsz; a += PGSIZE){
80106f7a:	39 d3                	cmp    %edx,%ebx
80106f7c:	73 66                	jae    80106fe4 <deallocuvm.part.0+0x84>
80106f7e:	89 d6                	mov    %edx,%esi
80106f80:	eb 3d                	jmp    80106fbf <deallocuvm.part.0+0x5f>
80106f82:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    pte = walkpgdir(pgdir, (char*)a, 0);
    if(!pte)
      a = PGADDR(PDX(a) + 1, 0, 0) - PGSIZE;
    else if((*pte & PTE_P) != 0){
80106f88:	8b 10                	mov    (%eax),%edx
80106f8a:	f6 c2 01             	test   $0x1,%dl
80106f8d:	74 26                	je     80106fb5 <deallocuvm.part.0+0x55>
      pa = PTE_ADDR(*pte);
      if(pa == 0)
80106f8f:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
80106f95:	74 58                	je     80106fef <deallocuvm.part.0+0x8f>
        panic("kfree");
      char *v = P2V(pa);
      kfree(v);
80106f97:	83 ec 0c             	sub    $0xc,%esp
      char *v = P2V(pa);
80106f9a:	81 c2 00 00 00 80    	add    $0x80000000,%edx
80106fa0:	89 45 e4             	mov    %eax,-0x1c(%ebp)
      kfree(v);
80106fa3:	52                   	push   %edx
80106fa4:	e8 e7 bb ff ff       	call   80102b90 <kfree>
      *pte = 0;
80106fa9:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80106fac:	83 c4 10             	add    $0x10,%esp
80106faf:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; a  < oldsz; a += PGSIZE){
80106fb5:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80106fbb:	39 f3                	cmp    %esi,%ebx
80106fbd:	73 25                	jae    80106fe4 <deallocuvm.part.0+0x84>
    pte = walkpgdir(pgdir, (char*)a, 0);
80106fbf:	31 c9                	xor    %ecx,%ecx
80106fc1:	89 da                	mov    %ebx,%edx
80106fc3:	89 f8                	mov    %edi,%eax
80106fc5:	e8 86 fe ff ff       	call   80106e50 <walkpgdir>
    if(!pte)
80106fca:	85 c0                	test   %eax,%eax
80106fcc:	75 ba                	jne    80106f88 <deallocuvm.part.0+0x28>
      a = PGADDR(PDX(a) + 1, 0, 0) - PGSIZE;
80106fce:	81 e3 00 00 c0 ff    	and    $0xffc00000,%ebx
80106fd4:	81 c3 00 f0 3f 00    	add    $0x3ff000,%ebx
  for(; a  < oldsz; a += PGSIZE){
80106fda:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80106fe0:	39 f3                	cmp    %esi,%ebx
80106fe2:	72 db                	jb     80106fbf <deallocuvm.part.0+0x5f>
    }
  }
  return newsz;
}
80106fe4:	8b 45 e0             	mov    -0x20(%ebp),%eax
80106fe7:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106fea:	5b                   	pop    %ebx
80106feb:	5e                   	pop    %esi
80106fec:	5f                   	pop    %edi
80106fed:	5d                   	pop    %ebp
80106fee:	c3                   	ret    
        panic("kfree");
80106fef:	83 ec 0c             	sub    $0xc,%esp
80106ff2:	68 b6 7a 10 80       	push   $0x80107ab6
80106ff7:	e8 94 93 ff ff       	call   80100390 <panic>
80106ffc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80107000 <seginit>:
{
80107000:	55                   	push   %ebp
80107001:	89 e5                	mov    %esp,%ebp
80107003:	83 ec 18             	sub    $0x18,%esp
  c = &cpus[cpuid()];
80107006:	e8 35 d0 ff ff       	call   80104040 <cpuid>
8010700b:	69 c0 b0 00 00 00    	imul   $0xb0,%eax,%eax
  pd[0] = size-1;
80107011:	ba 2f 00 00 00       	mov    $0x2f,%edx
80107016:	66 89 55 f2          	mov    %dx,-0xe(%ebp)
  c->gdt[SEG_KCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, 0);
8010701a:	c7 80 f8 55 11 80 ff 	movl   $0xffff,-0x7feeaa08(%eax)
80107021:	ff 00 00 
80107024:	c7 80 fc 55 11 80 00 	movl   $0xcf9a00,-0x7feeaa04(%eax)
8010702b:	9a cf 00 
  c->gdt[SEG_KDATA] = SEG(STA_W, 0, 0xffffffff, 0);
8010702e:	c7 80 00 56 11 80 ff 	movl   $0xffff,-0x7feeaa00(%eax)
80107035:	ff 00 00 
80107038:	c7 80 04 56 11 80 00 	movl   $0xcf9200,-0x7feea9fc(%eax)
8010703f:	92 cf 00 
  c->gdt[SEG_UCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, DPL_USER);
80107042:	c7 80 08 56 11 80 ff 	movl   $0xffff,-0x7feea9f8(%eax)
80107049:	ff 00 00 
8010704c:	c7 80 0c 56 11 80 00 	movl   $0xcffa00,-0x7feea9f4(%eax)
80107053:	fa cf 00 
  c->gdt[SEG_UDATA] = SEG(STA_W, 0, 0xffffffff, DPL_USER);
80107056:	c7 80 10 56 11 80 ff 	movl   $0xffff,-0x7feea9f0(%eax)
8010705d:	ff 00 00 
80107060:	c7 80 14 56 11 80 00 	movl   $0xcff200,-0x7feea9ec(%eax)
80107067:	f2 cf 00 
  lgdt(c->gdt, sizeof(c->gdt));
8010706a:	05 f0 55 11 80       	add    $0x801155f0,%eax
  pd[1] = (uint)p;
8010706f:	66 89 45 f4          	mov    %ax,-0xc(%ebp)
  pd[2] = (uint)p >> 16;
80107073:	c1 e8 10             	shr    $0x10,%eax
80107076:	66 89 45 f6          	mov    %ax,-0xa(%ebp)
  asm volatile("lgdt (%0)" : : "r" (pd));
8010707a:	8d 45 f2             	lea    -0xe(%ebp),%eax
8010707d:	0f 01 10             	lgdtl  (%eax)
}
80107080:	c9                   	leave  
80107081:	c3                   	ret    
80107082:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80107089:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80107090 <switchkvm>:
  lcr3(V2P(kpgdir));   // switch to the kernel page table
80107090:	a1 a4 82 11 80       	mov    0x801182a4,%eax
{
80107095:	55                   	push   %ebp
80107096:	89 e5                	mov    %esp,%ebp
  lcr3(V2P(kpgdir));   // switch to the kernel page table
80107098:	05 00 00 00 80       	add    $0x80000000,%eax
}

static inline void
lcr3(uint val)
{
  asm volatile("movl %0,%%cr3" : : "r" (val));
8010709d:	0f 22 d8             	mov    %eax,%cr3
}
801070a0:	5d                   	pop    %ebp
801070a1:	c3                   	ret    
801070a2:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801070a9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

801070b0 <switchuvm>:
{
801070b0:	55                   	push   %ebp
801070b1:	89 e5                	mov    %esp,%ebp
801070b3:	57                   	push   %edi
801070b4:	56                   	push   %esi
801070b5:	53                   	push   %ebx
801070b6:	83 ec 1c             	sub    $0x1c,%esp
801070b9:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(p == 0)
801070bc:	85 db                	test   %ebx,%ebx
801070be:	0f 84 cb 00 00 00    	je     8010718f <switchuvm+0xdf>
  if(p->kstack == 0)
801070c4:	8b 43 08             	mov    0x8(%ebx),%eax
801070c7:	85 c0                	test   %eax,%eax
801070c9:	0f 84 da 00 00 00    	je     801071a9 <switchuvm+0xf9>
  if(p->pgdir == 0)
801070cf:	8b 43 04             	mov    0x4(%ebx),%eax
801070d2:	85 c0                	test   %eax,%eax
801070d4:	0f 84 c2 00 00 00    	je     8010719c <switchuvm+0xec>
  pushcli();
801070da:	e8 11 da ff ff       	call   80104af0 <pushcli>
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
801070df:	e8 dc ce ff ff       	call   80103fc0 <mycpu>
801070e4:	89 c6                	mov    %eax,%esi
801070e6:	e8 d5 ce ff ff       	call   80103fc0 <mycpu>
801070eb:	89 c7                	mov    %eax,%edi
801070ed:	e8 ce ce ff ff       	call   80103fc0 <mycpu>
801070f2:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801070f5:	83 c7 08             	add    $0x8,%edi
801070f8:	e8 c3 ce ff ff       	call   80103fc0 <mycpu>
801070fd:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80107100:	83 c0 08             	add    $0x8,%eax
80107103:	ba 67 00 00 00       	mov    $0x67,%edx
80107108:	c1 e8 18             	shr    $0x18,%eax
8010710b:	66 89 96 98 00 00 00 	mov    %dx,0x98(%esi)
80107112:	66 89 be 9a 00 00 00 	mov    %di,0x9a(%esi)
80107119:	88 86 9f 00 00 00    	mov    %al,0x9f(%esi)
  mycpu()->ts.iomb = (ushort) 0xFFFF;
8010711f:	bf ff ff ff ff       	mov    $0xffffffff,%edi
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
80107124:	83 c1 08             	add    $0x8,%ecx
80107127:	c1 e9 10             	shr    $0x10,%ecx
8010712a:	88 8e 9c 00 00 00    	mov    %cl,0x9c(%esi)
80107130:	b9 99 40 00 00       	mov    $0x4099,%ecx
80107135:	66 89 8e 9d 00 00 00 	mov    %cx,0x9d(%esi)
  mycpu()->ts.ss0 = SEG_KDATA << 3;
8010713c:	be 10 00 00 00       	mov    $0x10,%esi
  mycpu()->gdt[SEG_TSS].s = 0;
80107141:	e8 7a ce ff ff       	call   80103fc0 <mycpu>
80107146:	80 a0 9d 00 00 00 ef 	andb   $0xef,0x9d(%eax)
  mycpu()->ts.ss0 = SEG_KDATA << 3;
8010714d:	e8 6e ce ff ff       	call   80103fc0 <mycpu>
80107152:	66 89 70 10          	mov    %si,0x10(%eax)
  mycpu()->ts.esp0 = (uint)p->kstack + KSTACKSIZE;
80107156:	8b 73 08             	mov    0x8(%ebx),%esi
80107159:	e8 62 ce ff ff       	call   80103fc0 <mycpu>
8010715e:	81 c6 00 10 00 00    	add    $0x1000,%esi
80107164:	89 70 0c             	mov    %esi,0xc(%eax)
  mycpu()->ts.iomb = (ushort) 0xFFFF;
80107167:	e8 54 ce ff ff       	call   80103fc0 <mycpu>
8010716c:	66 89 78 6e          	mov    %di,0x6e(%eax)
  asm volatile("ltr %0" : : "r" (sel));
80107170:	b8 28 00 00 00       	mov    $0x28,%eax
80107175:	0f 00 d8             	ltr    %ax
  lcr3(V2P(p->pgdir));  // switch to process's address space
80107178:	8b 43 04             	mov    0x4(%ebx),%eax
8010717b:	05 00 00 00 80       	add    $0x80000000,%eax
  asm volatile("movl %0,%%cr3" : : "r" (val));
80107180:	0f 22 d8             	mov    %eax,%cr3
}
80107183:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107186:	5b                   	pop    %ebx
80107187:	5e                   	pop    %esi
80107188:	5f                   	pop    %edi
80107189:	5d                   	pop    %ebp
  popcli();
8010718a:	e9 a1 d9 ff ff       	jmp    80104b30 <popcli>
    panic("switchuvm: no process");
8010718f:	83 ec 0c             	sub    $0xc,%esp
80107192:	68 32 81 10 80       	push   $0x80108132
80107197:	e8 f4 91 ff ff       	call   80100390 <panic>
    panic("switchuvm: no pgdir");
8010719c:	83 ec 0c             	sub    $0xc,%esp
8010719f:	68 5d 81 10 80       	push   $0x8010815d
801071a4:	e8 e7 91 ff ff       	call   80100390 <panic>
    panic("switchuvm: no kstack");
801071a9:	83 ec 0c             	sub    $0xc,%esp
801071ac:	68 48 81 10 80       	push   $0x80108148
801071b1:	e8 da 91 ff ff       	call   80100390 <panic>
801071b6:	8d 76 00             	lea    0x0(%esi),%esi
801071b9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

801071c0 <inituvm>:
{
801071c0:	55                   	push   %ebp
801071c1:	89 e5                	mov    %esp,%ebp
801071c3:	57                   	push   %edi
801071c4:	56                   	push   %esi
801071c5:	53                   	push   %ebx
801071c6:	83 ec 1c             	sub    $0x1c,%esp
801071c9:	8b 75 10             	mov    0x10(%ebp),%esi
801071cc:	8b 45 08             	mov    0x8(%ebp),%eax
801071cf:	8b 7d 0c             	mov    0xc(%ebp),%edi
  if(sz >= PGSIZE)
801071d2:	81 fe ff 0f 00 00    	cmp    $0xfff,%esi
{
801071d8:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(sz >= PGSIZE)
801071db:	77 49                	ja     80107226 <inituvm+0x66>
  mem = kalloc();
801071dd:	e8 5e bb ff ff       	call   80102d40 <kalloc>
  memset(mem, 0, PGSIZE);
801071e2:	83 ec 04             	sub    $0x4,%esp
  mem = kalloc();
801071e5:	89 c3                	mov    %eax,%ebx
  memset(mem, 0, PGSIZE);
801071e7:	68 00 10 00 00       	push   $0x1000
801071ec:	6a 00                	push   $0x0
801071ee:	50                   	push   %eax
801071ef:	e8 dc da ff ff       	call   80104cd0 <memset>
  mappages(pgdir, 0, PGSIZE, V2P(mem), PTE_W|PTE_U);
801071f4:	58                   	pop    %eax
801071f5:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
801071fb:	b9 00 10 00 00       	mov    $0x1000,%ecx
80107200:	5a                   	pop    %edx
80107201:	6a 06                	push   $0x6
80107203:	50                   	push   %eax
80107204:	31 d2                	xor    %edx,%edx
80107206:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80107209:	e8 c2 fc ff ff       	call   80106ed0 <mappages>
  memmove(mem, init, sz);
8010720e:	89 75 10             	mov    %esi,0x10(%ebp)
80107211:	89 7d 0c             	mov    %edi,0xc(%ebp)
80107214:	83 c4 10             	add    $0x10,%esp
80107217:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
8010721a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010721d:	5b                   	pop    %ebx
8010721e:	5e                   	pop    %esi
8010721f:	5f                   	pop    %edi
80107220:	5d                   	pop    %ebp
  memmove(mem, init, sz);
80107221:	e9 5a db ff ff       	jmp    80104d80 <memmove>
    panic("inituvm: more than a page");
80107226:	83 ec 0c             	sub    $0xc,%esp
80107229:	68 71 81 10 80       	push   $0x80108171
8010722e:	e8 5d 91 ff ff       	call   80100390 <panic>
80107233:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80107239:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80107240 <loaduvm>:
{
80107240:	55                   	push   %ebp
80107241:	89 e5                	mov    %esp,%ebp
80107243:	57                   	push   %edi
80107244:	56                   	push   %esi
80107245:	53                   	push   %ebx
80107246:	83 ec 0c             	sub    $0xc,%esp
  if((uint) addr % PGSIZE != 0)
80107249:	f7 45 0c ff 0f 00 00 	testl  $0xfff,0xc(%ebp)
80107250:	0f 85 91 00 00 00    	jne    801072e7 <loaduvm+0xa7>
  for(i = 0; i < sz; i += PGSIZE){
80107256:	8b 75 18             	mov    0x18(%ebp),%esi
80107259:	31 db                	xor    %ebx,%ebx
8010725b:	85 f6                	test   %esi,%esi
8010725d:	75 1a                	jne    80107279 <loaduvm+0x39>
8010725f:	eb 6f                	jmp    801072d0 <loaduvm+0x90>
80107261:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80107268:	81 c3 00 10 00 00    	add    $0x1000,%ebx
8010726e:	81 ee 00 10 00 00    	sub    $0x1000,%esi
80107274:	39 5d 18             	cmp    %ebx,0x18(%ebp)
80107277:	76 57                	jbe    801072d0 <loaduvm+0x90>
    if((pte = walkpgdir(pgdir, addr+i, 0)) == 0)
80107279:	8b 55 0c             	mov    0xc(%ebp),%edx
8010727c:	8b 45 08             	mov    0x8(%ebp),%eax
8010727f:	31 c9                	xor    %ecx,%ecx
80107281:	01 da                	add    %ebx,%edx
80107283:	e8 c8 fb ff ff       	call   80106e50 <walkpgdir>
80107288:	85 c0                	test   %eax,%eax
8010728a:	74 4e                	je     801072da <loaduvm+0x9a>
    pa = PTE_ADDR(*pte);
8010728c:	8b 00                	mov    (%eax),%eax
    if(readi(ip, P2V(pa), offset+i, n) != n)
8010728e:	8b 4d 14             	mov    0x14(%ebp),%ecx
    if(sz - i < PGSIZE)
80107291:	bf 00 10 00 00       	mov    $0x1000,%edi
    pa = PTE_ADDR(*pte);
80107296:	25 00 f0 ff ff       	and    $0xfffff000,%eax
    if(sz - i < PGSIZE)
8010729b:	81 fe ff 0f 00 00    	cmp    $0xfff,%esi
801072a1:	0f 46 fe             	cmovbe %esi,%edi
    if(readi(ip, P2V(pa), offset+i, n) != n)
801072a4:	01 d9                	add    %ebx,%ecx
801072a6:	05 00 00 00 80       	add    $0x80000000,%eax
801072ab:	57                   	push   %edi
801072ac:	51                   	push   %ecx
801072ad:	50                   	push   %eax
801072ae:	ff 75 10             	pushl  0x10(%ebp)
801072b1:	e8 0a a7 ff ff       	call   801019c0 <readi>
801072b6:	83 c4 10             	add    $0x10,%esp
801072b9:	39 f8                	cmp    %edi,%eax
801072bb:	74 ab                	je     80107268 <loaduvm+0x28>
}
801072bd:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return -1;
801072c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801072c5:	5b                   	pop    %ebx
801072c6:	5e                   	pop    %esi
801072c7:	5f                   	pop    %edi
801072c8:	5d                   	pop    %ebp
801072c9:	c3                   	ret    
801072ca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801072d0:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
801072d3:	31 c0                	xor    %eax,%eax
}
801072d5:	5b                   	pop    %ebx
801072d6:	5e                   	pop    %esi
801072d7:	5f                   	pop    %edi
801072d8:	5d                   	pop    %ebp
801072d9:	c3                   	ret    
      panic("loaduvm: address should exist");
801072da:	83 ec 0c             	sub    $0xc,%esp
801072dd:	68 8b 81 10 80       	push   $0x8010818b
801072e2:	e8 a9 90 ff ff       	call   80100390 <panic>
    panic("loaduvm: addr must be page aligned");
801072e7:	83 ec 0c             	sub    $0xc,%esp
801072ea:	68 2c 82 10 80       	push   $0x8010822c
801072ef:	e8 9c 90 ff ff       	call   80100390 <panic>
801072f4:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801072fa:	8d bf 00 00 00 00    	lea    0x0(%edi),%edi

80107300 <allocuvm>:
{
80107300:	55                   	push   %ebp
80107301:	89 e5                	mov    %esp,%ebp
80107303:	57                   	push   %edi
80107304:	56                   	push   %esi
80107305:	53                   	push   %ebx
80107306:	83 ec 1c             	sub    $0x1c,%esp
  if(newsz >= KERNBASE)
80107309:	8b 7d 10             	mov    0x10(%ebp),%edi
8010730c:	85 ff                	test   %edi,%edi
8010730e:	0f 88 8e 00 00 00    	js     801073a2 <allocuvm+0xa2>
  if(newsz < oldsz)
80107314:	3b 7d 0c             	cmp    0xc(%ebp),%edi
80107317:	0f 82 93 00 00 00    	jb     801073b0 <allocuvm+0xb0>
  a = PGROUNDUP(oldsz);
8010731d:	8b 45 0c             	mov    0xc(%ebp),%eax
80107320:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
80107326:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; a < newsz; a += PGSIZE){
8010732c:	39 5d 10             	cmp    %ebx,0x10(%ebp)
8010732f:	0f 86 7e 00 00 00    	jbe    801073b3 <allocuvm+0xb3>
80107335:	89 7d e4             	mov    %edi,-0x1c(%ebp)
80107338:	8b 7d 08             	mov    0x8(%ebp),%edi
8010733b:	eb 42                	jmp    8010737f <allocuvm+0x7f>
8010733d:	8d 76 00             	lea    0x0(%esi),%esi
    memset(mem, 0, PGSIZE);
80107340:	83 ec 04             	sub    $0x4,%esp
80107343:	68 00 10 00 00       	push   $0x1000
80107348:	6a 00                	push   $0x0
8010734a:	50                   	push   %eax
8010734b:	e8 80 d9 ff ff       	call   80104cd0 <memset>
    if(mappages(pgdir, (char*)a, PGSIZE, V2P(mem), PTE_W|PTE_U) < 0){
80107350:	58                   	pop    %eax
80107351:	8d 86 00 00 00 80    	lea    -0x80000000(%esi),%eax
80107357:	b9 00 10 00 00       	mov    $0x1000,%ecx
8010735c:	5a                   	pop    %edx
8010735d:	6a 06                	push   $0x6
8010735f:	50                   	push   %eax
80107360:	89 da                	mov    %ebx,%edx
80107362:	89 f8                	mov    %edi,%eax
80107364:	e8 67 fb ff ff       	call   80106ed0 <mappages>
80107369:	83 c4 10             	add    $0x10,%esp
8010736c:	85 c0                	test   %eax,%eax
8010736e:	78 50                	js     801073c0 <allocuvm+0xc0>
  for(; a < newsz; a += PGSIZE){
80107370:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80107376:	39 5d 10             	cmp    %ebx,0x10(%ebp)
80107379:	0f 86 81 00 00 00    	jbe    80107400 <allocuvm+0x100>
    mem = kalloc();
8010737f:	e8 bc b9 ff ff       	call   80102d40 <kalloc>
    if(mem == 0){
80107384:	85 c0                	test   %eax,%eax
    mem = kalloc();
80107386:	89 c6                	mov    %eax,%esi
    if(mem == 0){
80107388:	75 b6                	jne    80107340 <allocuvm+0x40>
      cprintf("allocuvm out of memory\n");
8010738a:	83 ec 0c             	sub    $0xc,%esp
8010738d:	68 a9 81 10 80       	push   $0x801081a9
80107392:	e8 c9 92 ff ff       	call   80100660 <cprintf>
  if(newsz >= oldsz)
80107397:	83 c4 10             	add    $0x10,%esp
8010739a:	8b 45 0c             	mov    0xc(%ebp),%eax
8010739d:	39 45 10             	cmp    %eax,0x10(%ebp)
801073a0:	77 6e                	ja     80107410 <allocuvm+0x110>
}
801073a2:	8d 65 f4             	lea    -0xc(%ebp),%esp
    return 0;
801073a5:	31 ff                	xor    %edi,%edi
}
801073a7:	89 f8                	mov    %edi,%eax
801073a9:	5b                   	pop    %ebx
801073aa:	5e                   	pop    %esi
801073ab:	5f                   	pop    %edi
801073ac:	5d                   	pop    %ebp
801073ad:	c3                   	ret    
801073ae:	66 90                	xchg   %ax,%ax
    return oldsz;
801073b0:	8b 7d 0c             	mov    0xc(%ebp),%edi
}
801073b3:	8d 65 f4             	lea    -0xc(%ebp),%esp
801073b6:	89 f8                	mov    %edi,%eax
801073b8:	5b                   	pop    %ebx
801073b9:	5e                   	pop    %esi
801073ba:	5f                   	pop    %edi
801073bb:	5d                   	pop    %ebp
801073bc:	c3                   	ret    
801073bd:	8d 76 00             	lea    0x0(%esi),%esi
      cprintf("allocuvm out of memory (2)\n");
801073c0:	83 ec 0c             	sub    $0xc,%esp
801073c3:	68 c1 81 10 80       	push   $0x801081c1
801073c8:	e8 93 92 ff ff       	call   80100660 <cprintf>
  if(newsz >= oldsz)
801073cd:	83 c4 10             	add    $0x10,%esp
801073d0:	8b 45 0c             	mov    0xc(%ebp),%eax
801073d3:	39 45 10             	cmp    %eax,0x10(%ebp)
801073d6:	76 0d                	jbe    801073e5 <allocuvm+0xe5>
801073d8:	89 c1                	mov    %eax,%ecx
801073da:	8b 55 10             	mov    0x10(%ebp),%edx
801073dd:	8b 45 08             	mov    0x8(%ebp),%eax
801073e0:	e8 7b fb ff ff       	call   80106f60 <deallocuvm.part.0>
      kfree(mem);
801073e5:	83 ec 0c             	sub    $0xc,%esp
      return 0;
801073e8:	31 ff                	xor    %edi,%edi
      kfree(mem);
801073ea:	56                   	push   %esi
801073eb:	e8 a0 b7 ff ff       	call   80102b90 <kfree>
      return 0;
801073f0:	83 c4 10             	add    $0x10,%esp
}
801073f3:	8d 65 f4             	lea    -0xc(%ebp),%esp
801073f6:	89 f8                	mov    %edi,%eax
801073f8:	5b                   	pop    %ebx
801073f9:	5e                   	pop    %esi
801073fa:	5f                   	pop    %edi
801073fb:	5d                   	pop    %ebp
801073fc:	c3                   	ret    
801073fd:	8d 76 00             	lea    0x0(%esi),%esi
80107400:	8b 7d e4             	mov    -0x1c(%ebp),%edi
80107403:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107406:	5b                   	pop    %ebx
80107407:	89 f8                	mov    %edi,%eax
80107409:	5e                   	pop    %esi
8010740a:	5f                   	pop    %edi
8010740b:	5d                   	pop    %ebp
8010740c:	c3                   	ret    
8010740d:	8d 76 00             	lea    0x0(%esi),%esi
80107410:	89 c1                	mov    %eax,%ecx
80107412:	8b 55 10             	mov    0x10(%ebp),%edx
80107415:	8b 45 08             	mov    0x8(%ebp),%eax
      return 0;
80107418:	31 ff                	xor    %edi,%edi
8010741a:	e8 41 fb ff ff       	call   80106f60 <deallocuvm.part.0>
8010741f:	eb 92                	jmp    801073b3 <allocuvm+0xb3>
80107421:	eb 0d                	jmp    80107430 <deallocuvm>
80107423:	90                   	nop
80107424:	90                   	nop
80107425:	90                   	nop
80107426:	90                   	nop
80107427:	90                   	nop
80107428:	90                   	nop
80107429:	90                   	nop
8010742a:	90                   	nop
8010742b:	90                   	nop
8010742c:	90                   	nop
8010742d:	90                   	nop
8010742e:	90                   	nop
8010742f:	90                   	nop

80107430 <deallocuvm>:
{
80107430:	55                   	push   %ebp
80107431:	89 e5                	mov    %esp,%ebp
80107433:	8b 55 0c             	mov    0xc(%ebp),%edx
80107436:	8b 4d 10             	mov    0x10(%ebp),%ecx
80107439:	8b 45 08             	mov    0x8(%ebp),%eax
  if(newsz >= oldsz)
8010743c:	39 d1                	cmp    %edx,%ecx
8010743e:	73 10                	jae    80107450 <deallocuvm+0x20>
}
80107440:	5d                   	pop    %ebp
80107441:	e9 1a fb ff ff       	jmp    80106f60 <deallocuvm.part.0>
80107446:	8d 76 00             	lea    0x0(%esi),%esi
80107449:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
80107450:	89 d0                	mov    %edx,%eax
80107452:	5d                   	pop    %ebp
80107453:	c3                   	ret    
80107454:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
8010745a:	8d bf 00 00 00 00    	lea    0x0(%edi),%edi

80107460 <freevm>:

// Free a page table and all the physical memory pages
// in the user part.
void
freevm(pde_t *pgdir)
{
80107460:	55                   	push   %ebp
80107461:	89 e5                	mov    %esp,%ebp
80107463:	57                   	push   %edi
80107464:	56                   	push   %esi
80107465:	53                   	push   %ebx
80107466:	83 ec 0c             	sub    $0xc,%esp
80107469:	8b 75 08             	mov    0x8(%ebp),%esi
  uint i;

  if(pgdir == 0)
8010746c:	85 f6                	test   %esi,%esi
8010746e:	74 59                	je     801074c9 <freevm+0x69>
80107470:	31 c9                	xor    %ecx,%ecx
80107472:	ba 00 00 00 80       	mov    $0x80000000,%edx
80107477:	89 f0                	mov    %esi,%eax
80107479:	e8 e2 fa ff ff       	call   80106f60 <deallocuvm.part.0>
8010747e:	89 f3                	mov    %esi,%ebx
80107480:	8d be 00 10 00 00    	lea    0x1000(%esi),%edi
80107486:	eb 0f                	jmp    80107497 <freevm+0x37>
80107488:	90                   	nop
80107489:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80107490:	83 c3 04             	add    $0x4,%ebx
    panic("freevm: no pgdir");
  deallocuvm(pgdir, KERNBASE, 0);
  for(i = 0; i < NPDENTRIES; i++){
80107493:	39 fb                	cmp    %edi,%ebx
80107495:	74 23                	je     801074ba <freevm+0x5a>
    if(pgdir[i] & PTE_P){
80107497:	8b 03                	mov    (%ebx),%eax
80107499:	a8 01                	test   $0x1,%al
8010749b:	74 f3                	je     80107490 <freevm+0x30>
      char * v = P2V(PTE_ADDR(pgdir[i]));
8010749d:	25 00 f0 ff ff       	and    $0xfffff000,%eax
      kfree(v);
801074a2:	83 ec 0c             	sub    $0xc,%esp
801074a5:	83 c3 04             	add    $0x4,%ebx
      char * v = P2V(PTE_ADDR(pgdir[i]));
801074a8:	05 00 00 00 80       	add    $0x80000000,%eax
      kfree(v);
801074ad:	50                   	push   %eax
801074ae:	e8 dd b6 ff ff       	call   80102b90 <kfree>
801074b3:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < NPDENTRIES; i++){
801074b6:	39 fb                	cmp    %edi,%ebx
801074b8:	75 dd                	jne    80107497 <freevm+0x37>
    }
  }
  kfree((char*)pgdir);
801074ba:	89 75 08             	mov    %esi,0x8(%ebp)
}
801074bd:	8d 65 f4             	lea    -0xc(%ebp),%esp
801074c0:	5b                   	pop    %ebx
801074c1:	5e                   	pop    %esi
801074c2:	5f                   	pop    %edi
801074c3:	5d                   	pop    %ebp
  kfree((char*)pgdir);
801074c4:	e9 c7 b6 ff ff       	jmp    80102b90 <kfree>
    panic("freevm: no pgdir");
801074c9:	83 ec 0c             	sub    $0xc,%esp
801074cc:	68 dd 81 10 80       	push   $0x801081dd
801074d1:	e8 ba 8e ff ff       	call   80100390 <panic>
801074d6:	8d 76 00             	lea    0x0(%esi),%esi
801074d9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

801074e0 <setupkvm>:
{
801074e0:	55                   	push   %ebp
801074e1:	89 e5                	mov    %esp,%ebp
801074e3:	56                   	push   %esi
801074e4:	53                   	push   %ebx
  if((pgdir = (pde_t*)kalloc()) == 0)
801074e5:	e8 56 b8 ff ff       	call   80102d40 <kalloc>
801074ea:	85 c0                	test   %eax,%eax
801074ec:	89 c6                	mov    %eax,%esi
801074ee:	74 42                	je     80107532 <setupkvm+0x52>
  memset(pgdir, 0, PGSIZE);
801074f0:	83 ec 04             	sub    $0x4,%esp
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
801074f3:	bb 20 b4 10 80       	mov    $0x8010b420,%ebx
  memset(pgdir, 0, PGSIZE);
801074f8:	68 00 10 00 00       	push   $0x1000
801074fd:	6a 00                	push   $0x0
801074ff:	50                   	push   %eax
80107500:	e8 cb d7 ff ff       	call   80104cd0 <memset>
80107505:	83 c4 10             	add    $0x10,%esp
                (uint)k->phys_start, k->perm) < 0) {
80107508:	8b 43 04             	mov    0x4(%ebx),%eax
    if(mappages(pgdir, k->virt, k->phys_end - k->phys_start,
8010750b:	8b 4b 08             	mov    0x8(%ebx),%ecx
8010750e:	83 ec 08             	sub    $0x8,%esp
80107511:	8b 13                	mov    (%ebx),%edx
80107513:	ff 73 0c             	pushl  0xc(%ebx)
80107516:	50                   	push   %eax
80107517:	29 c1                	sub    %eax,%ecx
80107519:	89 f0                	mov    %esi,%eax
8010751b:	e8 b0 f9 ff ff       	call   80106ed0 <mappages>
80107520:	83 c4 10             	add    $0x10,%esp
80107523:	85 c0                	test   %eax,%eax
80107525:	78 19                	js     80107540 <setupkvm+0x60>
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
80107527:	83 c3 10             	add    $0x10,%ebx
8010752a:	81 fb 60 b4 10 80    	cmp    $0x8010b460,%ebx
80107530:	75 d6                	jne    80107508 <setupkvm+0x28>
}
80107532:	8d 65 f8             	lea    -0x8(%ebp),%esp
80107535:	89 f0                	mov    %esi,%eax
80107537:	5b                   	pop    %ebx
80107538:	5e                   	pop    %esi
80107539:	5d                   	pop    %ebp
8010753a:	c3                   	ret    
8010753b:	90                   	nop
8010753c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      freevm(pgdir);
80107540:	83 ec 0c             	sub    $0xc,%esp
80107543:	56                   	push   %esi
      return 0;
80107544:	31 f6                	xor    %esi,%esi
      freevm(pgdir);
80107546:	e8 15 ff ff ff       	call   80107460 <freevm>
      return 0;
8010754b:	83 c4 10             	add    $0x10,%esp
}
8010754e:	8d 65 f8             	lea    -0x8(%ebp),%esp
80107551:	89 f0                	mov    %esi,%eax
80107553:	5b                   	pop    %ebx
80107554:	5e                   	pop    %esi
80107555:	5d                   	pop    %ebp
80107556:	c3                   	ret    
80107557:	89 f6                	mov    %esi,%esi
80107559:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

80107560 <kvmalloc>:
{
80107560:	55                   	push   %ebp
80107561:	89 e5                	mov    %esp,%ebp
80107563:	83 ec 08             	sub    $0x8,%esp
  kpgdir = setupkvm();
80107566:	e8 75 ff ff ff       	call   801074e0 <setupkvm>
8010756b:	a3 a4 82 11 80       	mov    %eax,0x801182a4
  lcr3(V2P(kpgdir));   // switch to the kernel page table
80107570:	05 00 00 00 80       	add    $0x80000000,%eax
80107575:	0f 22 d8             	mov    %eax,%cr3
}
80107578:	c9                   	leave  
80107579:	c3                   	ret    
8010757a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80107580 <clearpteu>:

// Clear PTE_U on a page. Used to create an inaccessible
// page beneath the user stack.
void
clearpteu(pde_t *pgdir, char *uva)
{
80107580:	55                   	push   %ebp
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
80107581:	31 c9                	xor    %ecx,%ecx
{
80107583:	89 e5                	mov    %esp,%ebp
80107585:	83 ec 08             	sub    $0x8,%esp
  pte = walkpgdir(pgdir, uva, 0);
80107588:	8b 55 0c             	mov    0xc(%ebp),%edx
8010758b:	8b 45 08             	mov    0x8(%ebp),%eax
8010758e:	e8 bd f8 ff ff       	call   80106e50 <walkpgdir>
  if(pte == 0)
80107593:	85 c0                	test   %eax,%eax
80107595:	74 05                	je     8010759c <clearpteu+0x1c>
    panic("clearpteu");
  *pte &= ~PTE_U;
80107597:	83 20 fb             	andl   $0xfffffffb,(%eax)
}
8010759a:	c9                   	leave  
8010759b:	c3                   	ret    
    panic("clearpteu");
8010759c:	83 ec 0c             	sub    $0xc,%esp
8010759f:	68 ee 81 10 80       	push   $0x801081ee
801075a4:	e8 e7 8d ff ff       	call   80100390 <panic>
801075a9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

801075b0 <copyuvm>:

// Given a parent process's page table, create a copy
// of it for a child.
pde_t*
copyuvm(pde_t *pgdir, uint sz)
{
801075b0:	55                   	push   %ebp
801075b1:	89 e5                	mov    %esp,%ebp
801075b3:	57                   	push   %edi
801075b4:	56                   	push   %esi
801075b5:	53                   	push   %ebx
801075b6:	83 ec 1c             	sub    $0x1c,%esp
  pde_t *d;
  pte_t *pte;
  uint pa, i, flags;
  char *mem;

  if((d = setupkvm()) == 0)
801075b9:	e8 22 ff ff ff       	call   801074e0 <setupkvm>
801075be:	85 c0                	test   %eax,%eax
801075c0:	89 45 e0             	mov    %eax,-0x20(%ebp)
801075c3:	0f 84 9f 00 00 00    	je     80107668 <copyuvm+0xb8>
    return 0;
  for(i = 0; i < sz; i += PGSIZE){
801075c9:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801075cc:	85 c9                	test   %ecx,%ecx
801075ce:	0f 84 94 00 00 00    	je     80107668 <copyuvm+0xb8>
801075d4:	31 ff                	xor    %edi,%edi
801075d6:	eb 4a                	jmp    80107622 <copyuvm+0x72>
801075d8:	90                   	nop
801075d9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      panic("copyuvm: page not present");
    pa = PTE_ADDR(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto bad;
    memmove(mem, (char*)P2V(pa), PGSIZE);
801075e0:	83 ec 04             	sub    $0x4,%esp
801075e3:	81 c3 00 00 00 80    	add    $0x80000000,%ebx
801075e9:	68 00 10 00 00       	push   $0x1000
801075ee:	53                   	push   %ebx
801075ef:	50                   	push   %eax
801075f0:	e8 8b d7 ff ff       	call   80104d80 <memmove>
    if(mappages(d, (void*)i, PGSIZE, V2P(mem), flags) < 0) {
801075f5:	58                   	pop    %eax
801075f6:	8d 86 00 00 00 80    	lea    -0x80000000(%esi),%eax
801075fc:	b9 00 10 00 00       	mov    $0x1000,%ecx
80107601:	5a                   	pop    %edx
80107602:	ff 75 e4             	pushl  -0x1c(%ebp)
80107605:	50                   	push   %eax
80107606:	89 fa                	mov    %edi,%edx
80107608:	8b 45 e0             	mov    -0x20(%ebp),%eax
8010760b:	e8 c0 f8 ff ff       	call   80106ed0 <mappages>
80107610:	83 c4 10             	add    $0x10,%esp
80107613:	85 c0                	test   %eax,%eax
80107615:	78 61                	js     80107678 <copyuvm+0xc8>
  for(i = 0; i < sz; i += PGSIZE){
80107617:	81 c7 00 10 00 00    	add    $0x1000,%edi
8010761d:	39 7d 0c             	cmp    %edi,0xc(%ebp)
80107620:	76 46                	jbe    80107668 <copyuvm+0xb8>
    if((pte = walkpgdir(pgdir, (void *) i, 0)) == 0)
80107622:	8b 45 08             	mov    0x8(%ebp),%eax
80107625:	31 c9                	xor    %ecx,%ecx
80107627:	89 fa                	mov    %edi,%edx
80107629:	e8 22 f8 ff ff       	call   80106e50 <walkpgdir>
8010762e:	85 c0                	test   %eax,%eax
80107630:	74 61                	je     80107693 <copyuvm+0xe3>
    if(!(*pte & PTE_P))
80107632:	8b 00                	mov    (%eax),%eax
80107634:	a8 01                	test   $0x1,%al
80107636:	74 4e                	je     80107686 <copyuvm+0xd6>
    pa = PTE_ADDR(*pte);
80107638:	89 c3                	mov    %eax,%ebx
    flags = PTE_FLAGS(*pte);
8010763a:	25 ff 0f 00 00       	and    $0xfff,%eax
    pa = PTE_ADDR(*pte);
8010763f:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
    flags = PTE_FLAGS(*pte);
80107645:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    if((mem = kalloc()) == 0)
80107648:	e8 f3 b6 ff ff       	call   80102d40 <kalloc>
8010764d:	85 c0                	test   %eax,%eax
8010764f:	89 c6                	mov    %eax,%esi
80107651:	75 8d                	jne    801075e0 <copyuvm+0x30>
    }
  }
  return d;

bad:
  freevm(d);
80107653:	83 ec 0c             	sub    $0xc,%esp
80107656:	ff 75 e0             	pushl  -0x20(%ebp)
80107659:	e8 02 fe ff ff       	call   80107460 <freevm>
  return 0;
8010765e:	83 c4 10             	add    $0x10,%esp
80107661:	c7 45 e0 00 00 00 00 	movl   $0x0,-0x20(%ebp)
}
80107668:	8b 45 e0             	mov    -0x20(%ebp),%eax
8010766b:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010766e:	5b                   	pop    %ebx
8010766f:	5e                   	pop    %esi
80107670:	5f                   	pop    %edi
80107671:	5d                   	pop    %ebp
80107672:	c3                   	ret    
80107673:	90                   	nop
80107674:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      kfree(mem);
80107678:	83 ec 0c             	sub    $0xc,%esp
8010767b:	56                   	push   %esi
8010767c:	e8 0f b5 ff ff       	call   80102b90 <kfree>
      goto bad;
80107681:	83 c4 10             	add    $0x10,%esp
80107684:	eb cd                	jmp    80107653 <copyuvm+0xa3>
      panic("copyuvm: page not present");
80107686:	83 ec 0c             	sub    $0xc,%esp
80107689:	68 12 82 10 80       	push   $0x80108212
8010768e:	e8 fd 8c ff ff       	call   80100390 <panic>
      panic("copyuvm: pte should exist");
80107693:	83 ec 0c             	sub    $0xc,%esp
80107696:	68 f8 81 10 80       	push   $0x801081f8
8010769b:	e8 f0 8c ff ff       	call   80100390 <panic>

801076a0 <uva2ka>:

//PAGEBREAK!
// Map user virtual address to kernel address.
char*
uva2ka(pde_t *pgdir, char *uva)
{
801076a0:	55                   	push   %ebp
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
801076a1:	31 c9                	xor    %ecx,%ecx
{
801076a3:	89 e5                	mov    %esp,%ebp
801076a5:	83 ec 08             	sub    $0x8,%esp
  pte = walkpgdir(pgdir, uva, 0);
801076a8:	8b 55 0c             	mov    0xc(%ebp),%edx
801076ab:	8b 45 08             	mov    0x8(%ebp),%eax
801076ae:	e8 9d f7 ff ff       	call   80106e50 <walkpgdir>
  if((*pte & PTE_P) == 0)
801076b3:	8b 00                	mov    (%eax),%eax
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  return (char*)P2V(PTE_ADDR(*pte));
}
801076b5:	c9                   	leave  
  if((*pte & PTE_U) == 0)
801076b6:	89 c2                	mov    %eax,%edx
  return (char*)P2V(PTE_ADDR(*pte));
801076b8:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  if((*pte & PTE_U) == 0)
801076bd:	83 e2 05             	and    $0x5,%edx
  return (char*)P2V(PTE_ADDR(*pte));
801076c0:	05 00 00 00 80       	add    $0x80000000,%eax
801076c5:	83 fa 05             	cmp    $0x5,%edx
801076c8:	ba 00 00 00 00       	mov    $0x0,%edx
801076cd:	0f 45 c2             	cmovne %edx,%eax
}
801076d0:	c3                   	ret    
801076d1:	eb 0d                	jmp    801076e0 <copyout>
801076d3:	90                   	nop
801076d4:	90                   	nop
801076d5:	90                   	nop
801076d6:	90                   	nop
801076d7:	90                   	nop
801076d8:	90                   	nop
801076d9:	90                   	nop
801076da:	90                   	nop
801076db:	90                   	nop
801076dc:	90                   	nop
801076dd:	90                   	nop
801076de:	90                   	nop
801076df:	90                   	nop

801076e0 <copyout>:
// Copy len bytes from p to user address va in page table pgdir.
// Most useful when pgdir is not the current page table.
// uva2ka ensures this only works for PTE_U pages.
int
copyout(pde_t *pgdir, uint va, void *p, uint len)
{
801076e0:	55                   	push   %ebp
801076e1:	89 e5                	mov    %esp,%ebp
801076e3:	57                   	push   %edi
801076e4:	56                   	push   %esi
801076e5:	53                   	push   %ebx
801076e6:	83 ec 1c             	sub    $0x1c,%esp
801076e9:	8b 5d 14             	mov    0x14(%ebp),%ebx
801076ec:	8b 55 0c             	mov    0xc(%ebp),%edx
801076ef:	8b 7d 10             	mov    0x10(%ebp),%edi
  char *buf, *pa0;
  uint n, va0;

  buf = (char*)p;
  while(len > 0){
801076f2:	85 db                	test   %ebx,%ebx
801076f4:	75 40                	jne    80107736 <copyout+0x56>
801076f6:	eb 70                	jmp    80107768 <copyout+0x88>
801076f8:	90                   	nop
801076f9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    va0 = (uint)PGROUNDDOWN(va);
    pa0 = uva2ka(pgdir, (char*)va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (va - va0);
80107700:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80107703:	89 f1                	mov    %esi,%ecx
80107705:	29 d1                	sub    %edx,%ecx
80107707:	81 c1 00 10 00 00    	add    $0x1000,%ecx
8010770d:	39 d9                	cmp    %ebx,%ecx
8010770f:	0f 47 cb             	cmova  %ebx,%ecx
    if(n > len)
      n = len;
    memmove(pa0 + (va - va0), buf, n);
80107712:	29 f2                	sub    %esi,%edx
80107714:	83 ec 04             	sub    $0x4,%esp
80107717:	01 d0                	add    %edx,%eax
80107719:	51                   	push   %ecx
8010771a:	57                   	push   %edi
8010771b:	50                   	push   %eax
8010771c:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
8010771f:	e8 5c d6 ff ff       	call   80104d80 <memmove>
    len -= n;
    buf += n;
80107724:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
  while(len > 0){
80107727:	83 c4 10             	add    $0x10,%esp
    va = va0 + PGSIZE;
8010772a:	8d 96 00 10 00 00    	lea    0x1000(%esi),%edx
    buf += n;
80107730:	01 cf                	add    %ecx,%edi
  while(len > 0){
80107732:	29 cb                	sub    %ecx,%ebx
80107734:	74 32                	je     80107768 <copyout+0x88>
    va0 = (uint)PGROUNDDOWN(va);
80107736:	89 d6                	mov    %edx,%esi
    pa0 = uva2ka(pgdir, (char*)va0);
80107738:	83 ec 08             	sub    $0x8,%esp
    va0 = (uint)PGROUNDDOWN(va);
8010773b:	89 55 e4             	mov    %edx,-0x1c(%ebp)
8010773e:	81 e6 00 f0 ff ff    	and    $0xfffff000,%esi
    pa0 = uva2ka(pgdir, (char*)va0);
80107744:	56                   	push   %esi
80107745:	ff 75 08             	pushl  0x8(%ebp)
80107748:	e8 53 ff ff ff       	call   801076a0 <uva2ka>
    if(pa0 == 0)
8010774d:	83 c4 10             	add    $0x10,%esp
80107750:	85 c0                	test   %eax,%eax
80107752:	75 ac                	jne    80107700 <copyout+0x20>
  }
  return 0;
}
80107754:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return -1;
80107757:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010775c:	5b                   	pop    %ebx
8010775d:	5e                   	pop    %esi
8010775e:	5f                   	pop    %edi
8010775f:	5d                   	pop    %ebp
80107760:	c3                   	ret    
80107761:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80107768:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
8010776b:	31 c0                	xor    %eax,%eax
}
8010776d:	5b                   	pop    %ebx
8010776e:	5e                   	pop    %esi
8010776f:	5f                   	pop    %edi
80107770:	5d                   	pop    %ebp
80107771:	c3                   	ret    
