user/cowfstest.o: user/cowfstest.c /usr/include/stdc-predef.h types.h \
 stat.h user.h fcntl.h
