#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int compare_files(const char *file1, const char *file2);
int compare_buffers(char *buf1, char *buf2, int size);
void cat(int fd);
char buf[512];

int
main()
{
  int fds,sectors;
  int fd1,fd2;

  char *f1 = "original.file";
  char *f2 = "copy.file";
  /////////////////////////////////////////////////////////
  fds = open("original.file", O_CREATE | O_WRONLY);
  if(fds < 0){ 
    printf(2, "original: cannot open original.file\n");
    exit();
  }

  sectors = 0;
  while(1){
    *(int*)buf = 'Q';
    int cc = write(fds, buf, sizeof(buf));
    if(cc <= 0)
      break;
    sectors++;
  	if (sectors % 10 == 0)
    	printf(2, ".");
  }
  close(fds);

  printf(1, "\nwrote %d sectors in original file\n", sectors);

  if((fds = open("original.file", 0)) < 0){
    printf(1, "cannot open original.file\n");
    exit();
  }
  
  //////////////////////////////////////////////
  if((fd1 = open("copy.file", O_CREATE | O_WRONLY)) < 0){ 
    printf(1, "copy: cannot copy.file\n");
    close(fds); // if fdd can't open file, fds need to closed
    exit();
  }

  if(cpcow(fds, fd1) <= 0){
    printf(1, "Can't copy all block in file\n");
    close(fds);
    close(fd1);
    exit();
  }

  printf(1, "original copy in copy.file\n");
  
  // close(fds); // DO NOT activate
  // close(fdd); // DO NOT activate

  if(compare_files(f1, f2) == 1) printf(1, "OK\n"); 
  else printf(1, "WRONG\n");

  close(fds);
  close(fd1);

   if((fds = open("original.file", 0)) < 0){
    printf(1, "cannot open original.file\n");
    exit();
  }
  
  //////////////////////////////////////////////
  if((fd2 = open("update.file", O_CREATE | O_WRONLY)) < 0){ 
    printf(1, "copy: cannot copy.file\n");
    close(fds); // if fdd can't open file, fds need to closed
    exit();
  }

  if(cpcow(fds, fd2) <= 0){
    printf(1, "Can't copy all block in file\n");
    close(fds);
    close(fd2);
    exit();
  }
  char *f3 = "update.file";
  if(compare_files(f1, f3) == 1) printf(1, "OK\n"); 
  else printf(1, "WRONG\n");

  close(fds);
  close(fd2);


  //////////////////////////////////////////////
  fd2 = open("update.file", O_RDWR);
  if(fd1 < 0){ 
    printf(2, "original: cannot open original.file\n");
    exit();
  }

  sectors = 0;
  while(1){
    *(int*)buf = 'W';
    int cc = write(fd2, buf, sizeof(buf));
    if(cc <= 0)
      break;
    sectors++;
  	if (sectors % 10 == 0)
    	printf(2, ".");
  }
  close(fd2);
  
  //////////////////////////////////////////////
  fds = open("original.file", O_RDWR);
  if(fds < 0){ 
    printf(2, "original: cannot open original.file\n");
    exit();
  }
  printf(1,"\n");
  cat(fds);
  close(fds);

  fd1 = open("copy.file", O_RDWR);
  if(fd1 < 0){ 
    printf(2, "original: cannot open original.file\n");
    exit();
  }
  printf(1,"\n");
  cat(fd1);
  close(fd1);

  fd2 = open("update.file", O_RDWR);
  if(fd2 < 0){ 
    printf(2, "original: cannot open original.file\n");
    exit();
  }
  printf(1,"\n");
  cat(fd2);
  close(fd2);
  printf(1,"\nUNLINK F1 START\n");
  unlink(f1);
  printf(1,"UNLINK F2 START\n");
  unlink(f2);
  printf(1,"UNLINK F3 START\n");
  unlink(f3);
  // A - B - C ==>  A-B   // C 


  //////////////////////////////////////////////
  // unlink test 2
  // A -B -C














  

  /////////////////////////////////////////////
  // NEXT STEP (SUCCESS)
  // printf(1,"\nNEXT STEP\n");
  // if((fds = open("original.file", 0)) < 0){
  //   printf(1, "cannot open original.file\n");
  //   exit();
  // }
  // if((fd2 = open("AAA.file", O_CREATE | O_WRONLY)) < 0){ 
  //   printf(1, "copy: cannot copy.file\n");
  //   close(fds); // if fdd can't open file, fds need to closed
  //   exit();
  // }

  // if(cpcow(fds, fd2) <= 0){
  //   printf(1, "Can't copy all block in file\n");
  //   close(fds);
  //   close(fd2);
  //   exit();
  // }
  // char *ffs1 = "original.file";
  // char *ffd2 = "AAA.file";
  // if(compare_files(ffs1, ffd2) == 1) printf(1, "OK\n"); 
  // else printf(1, "WRONG\n");

  // close(fds);
  // close(fd2);
  // if((fds = open("original.file", 0)) < 0){
  //   printf(1, "cannot open original.file\n");
  //   exit();
  // }
  // if((fd3 = open("BBB.file", O_CREATE | O_WRONLY)) < 0){ 
  //   printf(1, "copy: cannot copy.file\n");
  //   close(fds); // if fdd can't open file, fds need to closed
  //   exit();
  // }
  // if(cpcow(fds, fd3) <= 0){
  //   printf(1, "Can't copy all block in file\n");
  //   close(fds);
  //   close(fd3);
  //   exit();
  // }
  // char *ffd3 = "BBB.file";
  // if(compare_files(ffs1, ffd3) == 1) printf(1, "OK\n"); 
  // else printf(1, "WRONG\n");

  // close(fds);
  // close(fd3);
  // printf(1, "CPCOW END\n");
  // fd3 = open("BBB.file", O_RDWR);
  // if(fd3 < 0){ 
  //   printf(2, "original: cannot open original.file\n");
  //   exit();
  // }

  // sectors = 0;
  // while(1){
  //   *(int*)buf = 'E';
  //   int cc = write(fd3, buf, sizeof(buf));
  //   if(cc <= 0)
  //     break;
  //   sectors++;
  // 	if (sectors % 10 == 0)
  //   	printf(2, ".");
  // }
  // close(fd3);
  // printf(1,"\nFILE UPDATE END\n");


  // fds = open("original.file", O_RDWR);
  // if(fds < 0){ 
  //   printf(2, "original: cannot open original.file\n");
  //   exit();
  // }
  // printf(1,"\n");
  // cat(fds);
  // close(fds);
  // fd2= open("AAA.file", O_RDWR);
  // if(fd2 < 0){ 
  //   printf(2, "original: cannot open original.file\n");
  //   exit();
  // }
  // printf(1,"\n");
  // cat(fd2);
  // close(fd2);
  // fd3 = open("BBB.file", O_RDWR);
  // if(fd3 < 0){ 
  //   printf(2, "original: cannot open original.file\n");
  //   exit();
  // }
  // printf(1,"\n");
  // cat(fd3);
  // close(fd3);
  
  exit();
}


////////////////////////////////////////////////////////////////////////////////////
int compare_buffers(char *buf1, char *buf2, int size) {
    for (int i = 0; i < size; i++) {
        if (buf1[i] != buf2[i]) {
            return 0;
        }
    }
    return 1;
}

int compare_files(const char *file1, const char *file2) {
    int fd1, fd2;
    int n1, n2;
    char buf1[140], buf2[140];

    fd1 = open(file1, O_RDONLY);
    if (fd1 < 0) {
      printf(1, "cannot open %s\n", file1);
      return -1;
    }

    fd2 = open(file2, O_RDONLY);
    if (fd2 < 0) {
      printf(1, "cannot open %s\n", file2);
      close(fd1);
      return -1;
    }

    while (1) {
      n1 = read(fd1, buf1, sizeof(buf1));
      n2 = read(fd2, buf2, sizeof(buf2));

      if (n1 < 0 || n2 < 0) {
        printf(1, "error reading files\n");
        close(fd1);
        close(fd2);
        printf(1, "can't read\n");
        return -1;
      }
      int tmp = compare_buffers(buf1, buf2, n1);
      if (n1 != n2 || tmp == 0) {
        close(fd1);
        close(fd2);
        printf(1, "not equal\n");
        return 0;
      }

      if (n1 == 0 && n2 == 0) {
        break;
      }
    }

    // printf(1, "File1 = File2\n");
    // close(fd1); // DO NOT activate
    // close(fd2); // DO NOT activate
    return 1;
}

void
cat(int fd)
{
  int n;

  while((n = read(fd, buf, sizeof(buf))) > 0) {
    if (write(1, buf, n) != n) {
      printf(1, "cat: write error\n");
      exit();
    }
  }
  if(n < 0){
    printf(1, "cat: read error\n");
    exit();
  }
}