user/kill.o: user/kill.c /usr/include/stdc-predef.h types.h stat.h user.h
