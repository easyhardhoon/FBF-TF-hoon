
user/_cowfstest:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
void cat(int fd);
char buf[512];

int
main()
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  if(fds < 0){ 
    printf(2, "original: cannot open original.file\n");
    exit();
  }

  sectors = 0;
  11:	31 ff                	xor    %edi,%edi
    *(int*)buf = 'Q';
    int cc = write(fds, buf, sizeof(buf));
    if(cc <= 0)
      break;
    sectors++;
  	if (sectors % 10 == 0)
  13:	be cd cc cc cc       	mov    $0xcccccccd,%esi
{
  18:	83 ec 10             	sub    $0x10,%esp
  fds = open("original.file", O_CREATE | O_WRONLY);
  1b:	68 01 02 00 00       	push   $0x201
  20:	68 87 0d 00 00       	push   $0xd87
  25:	e8 98 08 00 00       	call   8c2 <open>
  if(fds < 0){ 
  2a:	83 c4 10             	add    $0x10,%esp
  2d:	85 c0                	test   %eax,%eax
  fds = open("original.file", O_CREATE | O_WRONLY);
  2f:	89 c3                	mov    %eax,%ebx
  if(fds < 0){ 
  31:	0f 88 25 02 00 00    	js     25c <main+0x25c>
  37:	89 f6                	mov    %esi,%esi
  39:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    int cc = write(fds, buf, sizeof(buf));
  40:	83 ec 04             	sub    $0x4,%esp
    *(int*)buf = 'Q';
  43:	c7 05 40 12 00 00 51 	movl   $0x51,0x1240
  4a:	00 00 00 
    int cc = write(fds, buf, sizeof(buf));
  4d:	68 00 02 00 00       	push   $0x200
  52:	68 40 12 00 00       	push   $0x1240
  57:	53                   	push   %ebx
  58:	e8 45 08 00 00       	call   8a2 <write>
    if(cc <= 0)
  5d:	83 c4 10             	add    $0x10,%esp
  60:	85 c0                	test   %eax,%eax
  62:	7e 2c                	jle    90 <main+0x90>
    sectors++;
  64:	83 c7 01             	add    $0x1,%edi
  	if (sectors % 10 == 0)
  67:	89 f8                	mov    %edi,%eax
  69:	f7 e6                	mul    %esi
  6b:	c1 ea 03             	shr    $0x3,%edx
  6e:	8d 04 92             	lea    (%edx,%edx,4),%eax
  71:	01 c0                	add    %eax,%eax
  73:	39 c7                	cmp    %eax,%edi
  75:	75 c9                	jne    40 <main+0x40>
    	printf(2, ".");
  77:	83 ec 08             	sub    $0x8,%esp
  7a:	68 95 0d 00 00       	push   $0xd95
  7f:	6a 02                	push   $0x2
  81:	e8 4a 09 00 00       	call   9d0 <printf>
  86:	83 c4 10             	add    $0x10,%esp
  89:	eb b5                	jmp    40 <main+0x40>
  8b:	90                   	nop
  8c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  }
  close(fds);
  90:	83 ec 0c             	sub    $0xc,%esp
  93:	53                   	push   %ebx
  94:	e8 11 08 00 00       	call   8aa <close>

  printf(1, "\nwrote %d sectors in original file\n", sectors);
  99:	83 c4 0c             	add    $0xc,%esp
  9c:	57                   	push   %edi
  9d:	68 84 0e 00 00       	push   $0xe84
  a2:	6a 01                	push   $0x1
  a4:	e8 27 09 00 00       	call   9d0 <printf>

  if((fds = open("original.file", 0)) < 0){
  a9:	58                   	pop    %eax
  aa:	5a                   	pop    %edx
  ab:	6a 00                	push   $0x0
  ad:	68 87 0d 00 00       	push   $0xd87
  b2:	e8 0b 08 00 00       	call   8c2 <open>
  b7:	83 c4 10             	add    $0x10,%esp
  ba:	85 c0                	test   %eax,%eax
  bc:	89 c3                	mov    %eax,%ebx
  be:	0f 88 85 01 00 00    	js     249 <main+0x249>
    printf(1, "cannot open original.file\n");
    exit();
  }
  
  //////////////////////////////////////////////
  if((fd1 = open("copy.file", O_CREATE | O_WRONLY)) < 0){ 
  c4:	56                   	push   %esi
  c5:	56                   	push   %esi
  c6:	68 01 02 00 00       	push   $0x201
  cb:	68 b2 0d 00 00       	push   $0xdb2
  d0:	e8 ed 07 00 00       	call   8c2 <open>
  d5:	83 c4 10             	add    $0x10,%esp
  d8:	85 c0                	test   %eax,%eax
  da:	89 c6                	mov    %eax,%esi
  dc:	0f 88 4c 01 00 00    	js     22e <main+0x22e>
    printf(1, "copy: cannot copy.file\n");
    close(fds); // if fdd can't open file, fds need to closed
    exit();
  }

  if(cpcow(fds, fd1) <= 0){
  e2:	51                   	push   %ecx
  e3:	51                   	push   %ecx
  e4:	50                   	push   %eax
  e5:	53                   	push   %ebx
  e6:	e8 37 08 00 00       	call   922 <cpcow>
  eb:	83 c4 10             	add    $0x10,%esp
  ee:	85 c0                	test   %eax,%eax
  f0:	0f 8e 8f 01 00 00    	jle    285 <main+0x285>
    close(fds);
    close(fd1);
    exit();
  }

  printf(1, "original copy in copy.file\n");
  f6:	50                   	push   %eax
  f7:	50                   	push   %eax
  f8:	68 f2 0d 00 00       	push   $0xdf2
  fd:	6a 01                	push   $0x1
  ff:	e8 cc 08 00 00       	call   9d0 <printf>
  
  // close(fds); // DO NOT activate
  // close(fdd); // DO NOT activate

  if(compare_files(f1, f2) == 1) printf(1, "OK\n"); 
 104:	58                   	pop    %eax
 105:	5a                   	pop    %edx
 106:	68 b2 0d 00 00       	push   $0xdb2
 10b:	68 87 0d 00 00       	push   $0xd87
 110:	e8 0b 03 00 00       	call   420 <compare_files>
 115:	83 c4 10             	add    $0x10,%esp
 118:	83 e8 01             	sub    $0x1,%eax
 11b:	0f 84 4e 01 00 00    	je     26f <main+0x26f>
  else printf(1, "WRONG\n");
 121:	51                   	push   %ecx
 122:	51                   	push   %ecx
 123:	68 12 0e 00 00       	push   $0xe12
 128:	6a 01                	push   $0x1
 12a:	e8 a1 08 00 00       	call   9d0 <printf>
 12f:	83 c4 10             	add    $0x10,%esp

  close(fds);
 132:	83 ec 0c             	sub    $0xc,%esp
 135:	53                   	push   %ebx
 136:	e8 6f 07 00 00       	call   8aa <close>
  close(fd1);
 13b:	89 34 24             	mov    %esi,(%esp)
 13e:	e8 67 07 00 00       	call   8aa <close>

   if((fds = open("original.file", 0)) < 0){
 143:	58                   	pop    %eax
 144:	5a                   	pop    %edx
 145:	6a 00                	push   $0x0
 147:	68 87 0d 00 00       	push   $0xd87
 14c:	e8 71 07 00 00       	call   8c2 <open>
 151:	83 c4 10             	add    $0x10,%esp
 154:	85 c0                	test   %eax,%eax
 156:	89 c3                	mov    %eax,%ebx
 158:	0f 88 eb 00 00 00    	js     249 <main+0x249>
    printf(1, "cannot open original.file\n");
    exit();
  }
  
  //////////////////////////////////////////////
  if((fd2 = open("update.file", O_CREATE | O_WRONLY)) < 0){ 
 15e:	50                   	push   %eax
 15f:	50                   	push   %eax
 160:	68 01 02 00 00       	push   $0x201
 165:	68 19 0e 00 00       	push   $0xe19
 16a:	e8 53 07 00 00       	call   8c2 <open>
 16f:	83 c4 10             	add    $0x10,%esp
 172:	85 c0                	test   %eax,%eax
 174:	89 c6                	mov    %eax,%esi
 176:	0f 88 b2 00 00 00    	js     22e <main+0x22e>
    printf(1, "copy: cannot copy.file\n");
    close(fds); // if fdd can't open file, fds need to closed
    exit();
  }

  if(cpcow(fds, fd2) <= 0){
 17c:	50                   	push   %eax
 17d:	50                   	push   %eax
 17e:	56                   	push   %esi
 17f:	53                   	push   %ebx
 180:	e8 9d 07 00 00       	call   922 <cpcow>
 185:	83 c4 10             	add    $0x10,%esp
 188:	85 c0                	test   %eax,%eax
 18a:	0f 8e f5 00 00 00    	jle    285 <main+0x285>
    close(fds);
    close(fd2);
    exit();
  }
  char *f3 = "update.file";
  if(compare_files(f1, f3) == 1) printf(1, "OK\n"); 
 190:	50                   	push   %eax
 191:	50                   	push   %eax
 192:	68 19 0e 00 00       	push   $0xe19
 197:	68 87 0d 00 00       	push   $0xd87
 19c:	e8 7f 02 00 00       	call   420 <compare_files>
 1a1:	83 c4 10             	add    $0x10,%esp
 1a4:	83 e8 01             	sub    $0x1,%eax
 1a7:	0f 84 fb 00 00 00    	je     2a8 <main+0x2a8>
  else printf(1, "WRONG\n");
 1ad:	51                   	push   %ecx
 1ae:	51                   	push   %ecx
 1af:	68 12 0e 00 00       	push   $0xe12
 1b4:	6a 01                	push   $0x1
 1b6:	e8 15 08 00 00       	call   9d0 <printf>
 1bb:	83 c4 10             	add    $0x10,%esp

  close(fds);
 1be:	83 ec 0c             	sub    $0xc,%esp
 1c1:	53                   	push   %ebx
  if(fd1 < 0){ 
    printf(2, "original: cannot open original.file\n");
    exit();
  }

  sectors = 0;
 1c2:	31 db                	xor    %ebx,%ebx
  close(fds);
 1c4:	e8 e1 06 00 00       	call   8aa <close>
  close(fd2);
 1c9:	89 34 24             	mov    %esi,(%esp)
    *(int*)buf = 'W';
    int cc = write(fd2, buf, sizeof(buf));
    if(cc <= 0)
      break;
    sectors++;
  	if (sectors % 10 == 0)
 1cc:	be 0a 00 00 00       	mov    $0xa,%esi
  close(fd2);
 1d1:	e8 d4 06 00 00       	call   8aa <close>
  fd2 = open("update.file", O_RDWR);
 1d6:	58                   	pop    %eax
 1d7:	5a                   	pop    %edx
 1d8:	6a 02                	push   $0x2
 1da:	68 19 0e 00 00       	push   $0xe19
 1df:	e8 de 06 00 00       	call   8c2 <open>
 1e4:	83 c4 10             	add    $0x10,%esp
 1e7:	89 c7                	mov    %eax,%edi
    int cc = write(fd2, buf, sizeof(buf));
 1e9:	50                   	push   %eax
 1ea:	68 00 02 00 00       	push   $0x200
 1ef:	68 40 12 00 00       	push   $0x1240
 1f4:	57                   	push   %edi
    *(int*)buf = 'W';
 1f5:	c7 05 40 12 00 00 57 	movl   $0x57,0x1240
 1fc:	00 00 00 
    int cc = write(fd2, buf, sizeof(buf));
 1ff:	e8 9e 06 00 00       	call   8a2 <write>
    if(cc <= 0)
 204:	83 c4 10             	add    $0x10,%esp
 207:	85 c0                	test   %eax,%eax
 209:	0f 8e af 00 00 00    	jle    2be <main+0x2be>
    sectors++;
 20f:	83 c3 01             	add    $0x1,%ebx
  	if (sectors % 10 == 0)
 212:	89 d8                	mov    %ebx,%eax
 214:	99                   	cltd   
 215:	f7 fe                	idiv   %esi
 217:	85 d2                	test   %edx,%edx
 219:	75 ce                	jne    1e9 <main+0x1e9>
    	printf(2, ".");
 21b:	50                   	push   %eax
 21c:	50                   	push   %eax
 21d:	68 95 0d 00 00       	push   $0xd95
 222:	6a 02                	push   $0x2
 224:	e8 a7 07 00 00       	call   9d0 <printf>
 229:	83 c4 10             	add    $0x10,%esp
 22c:	eb bb                	jmp    1e9 <main+0x1e9>
    printf(1, "copy: cannot copy.file\n");
 22e:	50                   	push   %eax
 22f:	50                   	push   %eax
 230:	68 bc 0d 00 00       	push   $0xdbc
 235:	6a 01                	push   $0x1
 237:	e8 94 07 00 00       	call   9d0 <printf>
    close(fds); // if fdd can't open file, fds need to closed
 23c:	89 1c 24             	mov    %ebx,(%esp)
 23f:	e8 66 06 00 00       	call   8aa <close>
    exit();
 244:	e8 39 06 00 00       	call   882 <exit>
    printf(1, "cannot open original.file\n");
 249:	57                   	push   %edi
 24a:	57                   	push   %edi
 24b:	68 97 0d 00 00       	push   $0xd97
 250:	6a 01                	push   $0x1
 252:	e8 79 07 00 00       	call   9d0 <printf>
    exit();
 257:	e8 26 06 00 00       	call   882 <exit>
    printf(2, "original: cannot open original.file\n");
 25c:	51                   	push   %ecx
 25d:	51                   	push   %ecx
 25e:	68 5c 0e 00 00       	push   $0xe5c
 263:	6a 02                	push   $0x2
 265:	e8 66 07 00 00       	call   9d0 <printf>
    exit();
 26a:	e8 13 06 00 00       	call   882 <exit>
  if(compare_files(f1, f2) == 1) printf(1, "OK\n"); 
 26f:	57                   	push   %edi
 270:	57                   	push   %edi
 271:	68 0e 0e 00 00       	push   $0xe0e
 276:	6a 01                	push   $0x1
 278:	e8 53 07 00 00       	call   9d0 <printf>
 27d:	83 c4 10             	add    $0x10,%esp
 280:	e9 ad fe ff ff       	jmp    132 <main+0x132>
    printf(1, "Can't copy all block in file\n");
 285:	50                   	push   %eax
 286:	50                   	push   %eax
 287:	68 d4 0d 00 00       	push   $0xdd4
 28c:	6a 01                	push   $0x1
 28e:	e8 3d 07 00 00       	call   9d0 <printf>
    close(fds);
 293:	89 1c 24             	mov    %ebx,(%esp)
 296:	e8 0f 06 00 00       	call   8aa <close>
    close(fd2);
 29b:	89 34 24             	mov    %esi,(%esp)
 29e:	e8 07 06 00 00       	call   8aa <close>
    exit();
 2a3:	e8 da 05 00 00       	call   882 <exit>
  if(compare_files(f1, f3) == 1) printf(1, "OK\n"); 
 2a8:	57                   	push   %edi
 2a9:	57                   	push   %edi
 2aa:	68 0e 0e 00 00       	push   $0xe0e
 2af:	6a 01                	push   $0x1
 2b1:	e8 1a 07 00 00       	call   9d0 <printf>
 2b6:	83 c4 10             	add    $0x10,%esp
 2b9:	e9 00 ff ff ff       	jmp    1be <main+0x1be>
  }
  close(fd2);
 2be:	83 ec 0c             	sub    $0xc,%esp
 2c1:	57                   	push   %edi
 2c2:	e8 e3 05 00 00       	call   8aa <close>
  
  //////////////////////////////////////////////
  fds = open("original.file", O_RDWR);
 2c7:	5f                   	pop    %edi
 2c8:	58                   	pop    %eax
 2c9:	6a 02                	push   $0x2
 2cb:	68 87 0d 00 00       	push   $0xd87
 2d0:	e8 ed 05 00 00       	call   8c2 <open>
  if(fds < 0){ 
 2d5:	83 c4 10             	add    $0x10,%esp
 2d8:	85 c0                	test   %eax,%eax
  fds = open("original.file", O_RDWR);
 2da:	89 c3                	mov    %eax,%ebx
  if(fds < 0){ 
 2dc:	0f 88 7a ff ff ff    	js     25c <main+0x25c>
    printf(2, "original: cannot open original.file\n");
    exit();
  }
  printf(1,"\n");
 2e2:	51                   	push   %ecx
 2e3:	51                   	push   %ecx
 2e4:	68 17 0e 00 00       	push   $0xe17
 2e9:	6a 01                	push   $0x1
 2eb:	e8 e0 06 00 00       	call   9d0 <printf>
  cat(fds);
 2f0:	89 1c 24             	mov    %ebx,(%esp)
 2f3:	e8 b8 02 00 00       	call   5b0 <cat>
  close(fds);
 2f8:	89 1c 24             	mov    %ebx,(%esp)
 2fb:	e8 aa 05 00 00       	call   8aa <close>

  fd1 = open("copy.file", O_RDWR);
 300:	5b                   	pop    %ebx
 301:	5e                   	pop    %esi
 302:	6a 02                	push   $0x2
 304:	68 b2 0d 00 00       	push   $0xdb2
 309:	e8 b4 05 00 00       	call   8c2 <open>
  if(fd1 < 0){ 
 30e:	83 c4 10             	add    $0x10,%esp
 311:	85 c0                	test   %eax,%eax
  fd1 = open("copy.file", O_RDWR);
 313:	89 c3                	mov    %eax,%ebx
  if(fd1 < 0){ 
 315:	0f 88 41 ff ff ff    	js     25c <main+0x25c>
    printf(2, "original: cannot open original.file\n");
    exit();
  }
  printf(1,"\n");
 31b:	50                   	push   %eax
 31c:	50                   	push   %eax
 31d:	68 17 0e 00 00       	push   $0xe17
 322:	6a 01                	push   $0x1
 324:	e8 a7 06 00 00       	call   9d0 <printf>
  cat(fd1);
 329:	89 1c 24             	mov    %ebx,(%esp)
 32c:	e8 7f 02 00 00       	call   5b0 <cat>
  close(fd1);
 331:	89 1c 24             	mov    %ebx,(%esp)
 334:	e8 71 05 00 00       	call   8aa <close>

  fd2 = open("update.file", O_RDWR);
 339:	58                   	pop    %eax
 33a:	5a                   	pop    %edx
 33b:	6a 02                	push   $0x2
 33d:	68 19 0e 00 00       	push   $0xe19
 342:	e8 7b 05 00 00       	call   8c2 <open>
  if(fd2 < 0){ 
 347:	83 c4 10             	add    $0x10,%esp
 34a:	85 c0                	test   %eax,%eax
  fd2 = open("update.file", O_RDWR);
 34c:	89 c3                	mov    %eax,%ebx
  if(fd2 < 0){ 
 34e:	0f 88 08 ff ff ff    	js     25c <main+0x25c>
    printf(2, "original: cannot open original.file\n");
    exit();
  }
  printf(1,"\n");
 354:	50                   	push   %eax
 355:	50                   	push   %eax
 356:	68 17 0e 00 00       	push   $0xe17
 35b:	6a 01                	push   $0x1
 35d:	e8 6e 06 00 00       	call   9d0 <printf>
  cat(fd2);
 362:	89 1c 24             	mov    %ebx,(%esp)
 365:	e8 46 02 00 00       	call   5b0 <cat>
  close(fd2);
 36a:	89 1c 24             	mov    %ebx,(%esp)
 36d:	e8 38 05 00 00       	call   8aa <close>
  printf(1,"\nUNLINK F1 START\n");
 372:	5a                   	pop    %edx
 373:	59                   	pop    %ecx
 374:	68 25 0e 00 00       	push   $0xe25
 379:	6a 01                	push   $0x1
 37b:	e8 50 06 00 00       	call   9d0 <printf>
  unlink(f1);
 380:	c7 04 24 87 0d 00 00 	movl   $0xd87,(%esp)
 387:	e8 46 05 00 00       	call   8d2 <unlink>
  printf(1,"UNLINK F2 START\n");
 38c:	5b                   	pop    %ebx
 38d:	5e                   	pop    %esi
 38e:	68 37 0e 00 00       	push   $0xe37
 393:	6a 01                	push   $0x1
 395:	e8 36 06 00 00       	call   9d0 <printf>
  unlink(f2);
 39a:	c7 04 24 b2 0d 00 00 	movl   $0xdb2,(%esp)
 3a1:	e8 2c 05 00 00       	call   8d2 <unlink>
  printf(1,"UNLINK F3 START\n");
 3a6:	5f                   	pop    %edi
 3a7:	58                   	pop    %eax
 3a8:	68 48 0e 00 00       	push   $0xe48
 3ad:	6a 01                	push   $0x1
 3af:	e8 1c 06 00 00       	call   9d0 <printf>
  unlink(f3);
 3b4:	c7 04 24 19 0e 00 00 	movl   $0xe19,(%esp)
 3bb:	e8 12 05 00 00       	call   8d2 <unlink>
  // }
  // printf(1,"\n");
  // cat(fd3);
  // close(fd3);
  
  exit();
 3c0:	e8 bd 04 00 00       	call   882 <exit>
 3c5:	66 90                	xchg   %ax,%ax
 3c7:	66 90                	xchg   %ax,%ax
 3c9:	66 90                	xchg   %ax,%ax
 3cb:	66 90                	xchg   %ax,%ax
 3cd:	66 90                	xchg   %ax,%ax
 3cf:	90                   	nop

000003d0 <compare_buffers>:
}


////////////////////////////////////////////////////////////////////////////////////
int compare_buffers(char *buf1, char *buf2, int size) {
 3d0:	55                   	push   %ebp
 3d1:	89 e5                	mov    %esp,%ebp
 3d3:	56                   	push   %esi
 3d4:	53                   	push   %ebx
 3d5:	8b 75 10             	mov    0x10(%ebp),%esi
 3d8:	8b 4d 08             	mov    0x8(%ebp),%ecx
 3db:	8b 5d 0c             	mov    0xc(%ebp),%ebx
    for (int i = 0; i < size; i++) {
 3de:	85 f6                	test   %esi,%esi
 3e0:	7e 1e                	jle    400 <compare_buffers+0x30>
        if (buf1[i] != buf2[i]) {
 3e2:	0f b6 03             	movzbl (%ebx),%eax
 3e5:	38 01                	cmp    %al,(%ecx)
            return 0;
 3e7:	b8 00 00 00 00       	mov    $0x0,%eax
        if (buf1[i] != buf2[i]) {
 3ec:	74 0b                	je     3f9 <compare_buffers+0x29>
 3ee:	eb 15                	jmp    405 <compare_buffers+0x35>
 3f0:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
 3f4:	38 14 01             	cmp    %dl,(%ecx,%eax,1)
 3f7:	75 17                	jne    410 <compare_buffers+0x40>
    for (int i = 0; i < size; i++) {
 3f9:	83 c0 01             	add    $0x1,%eax
 3fc:	39 c6                	cmp    %eax,%esi
 3fe:	75 f0                	jne    3f0 <compare_buffers+0x20>
        }
    }
    return 1;
 400:	b8 01 00 00 00       	mov    $0x1,%eax
}
 405:	5b                   	pop    %ebx
 406:	5e                   	pop    %esi
 407:	5d                   	pop    %ebp
 408:	c3                   	ret    
 409:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 410:	5b                   	pop    %ebx
            return 0;
 411:	31 c0                	xor    %eax,%eax
}
 413:	5e                   	pop    %esi
 414:	5d                   	pop    %ebp
 415:	c3                   	ret    
 416:	8d 76 00             	lea    0x0(%esi),%esi
 419:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

00000420 <compare_files>:

int compare_files(const char *file1, const char *file2) {
 420:	55                   	push   %ebp
 421:	89 e5                	mov    %esp,%ebp
 423:	57                   	push   %edi
 424:	56                   	push   %esi
 425:	53                   	push   %ebx
 426:	81 ec 44 01 00 00    	sub    $0x144,%esp
 42c:	8b 7d 08             	mov    0x8(%ebp),%edi
 42f:	8b 5d 0c             	mov    0xc(%ebp),%ebx
    int fd1, fd2;
    int n1, n2;
    char buf1[140], buf2[140];

    fd1 = open(file1, O_RDONLY);
 432:	6a 00                	push   $0x0
 434:	57                   	push   %edi
 435:	e8 88 04 00 00       	call   8c2 <open>
    if (fd1 < 0) {
 43a:	83 c4 10             	add    $0x10,%esp
 43d:	85 c0                	test   %eax,%eax
    fd1 = open(file1, O_RDONLY);
 43f:	89 85 c4 fe ff ff    	mov    %eax,-0x13c(%ebp)
    if (fd1 < 0) {
 445:	0f 88 1b 01 00 00    	js     566 <compare_files+0x146>
      printf(1, "cannot open %s\n", file1);
      return -1;
    }

    fd2 = open(file2, O_RDONLY);
 44b:	83 ec 08             	sub    $0x8,%esp
 44e:	6a 00                	push   $0x0
 450:	53                   	push   %ebx
 451:	e8 6c 04 00 00       	call   8c2 <open>
    if (fd2 < 0) {
 456:	83 c4 10             	add    $0x10,%esp
 459:	85 c0                	test   %eax,%eax
    fd2 = open(file2, O_RDONLY);
 45b:	89 85 c0 fe ff ff    	mov    %eax,-0x140(%ebp)
    if (fd2 < 0) {
 461:	0f 88 19 01 00 00    	js     580 <compare_files+0x160>
 467:	8d b5 d0 fe ff ff    	lea    -0x130(%ebp),%esi
 46d:	8d bd 5c ff ff ff    	lea    -0xa4(%ebp),%edi
      close(fd1);
      return -1;
    }

    while (1) {
      n1 = read(fd1, buf1, sizeof(buf1));
 473:	83 ec 04             	sub    $0x4,%esp
 476:	68 8c 00 00 00       	push   $0x8c
 47b:	56                   	push   %esi
 47c:	ff b5 c4 fe ff ff    	pushl  -0x13c(%ebp)
 482:	e8 13 04 00 00       	call   89a <read>
      n2 = read(fd2, buf2, sizeof(buf2));
 487:	83 c4 0c             	add    $0xc,%esp
      n1 = read(fd1, buf1, sizeof(buf1));
 48a:	89 c3                	mov    %eax,%ebx
      n2 = read(fd2, buf2, sizeof(buf2));
 48c:	68 8c 00 00 00       	push   $0x8c
 491:	57                   	push   %edi
 492:	ff b5 c0 fe ff ff    	pushl  -0x140(%ebp)
 498:	e8 fd 03 00 00       	call   89a <read>

      if (n1 < 0 || n2 < 0) {
 49d:	83 c4 10             	add    $0x10,%esp
 4a0:	85 db                	test   %ebx,%ebx
 4a2:	78 7d                	js     521 <compare_files+0x101>
 4a4:	85 c0                	test   %eax,%eax
 4a6:	78 79                	js     521 <compare_files+0x101>
    for (int i = 0; i < size; i++) {
 4a8:	85 db                	test   %ebx,%ebx
 4aa:	74 64                	je     510 <compare_files+0xf0>
        if (buf1[i] != buf2[i]) {
 4ac:	0f b6 8d 5c ff ff ff 	movzbl -0xa4(%ebp),%ecx
 4b3:	38 8d d0 fe ff ff    	cmp    %cl,-0x130(%ebp)
 4b9:	75 19                	jne    4d4 <compare_files+0xb4>
    for (int i = 0; i < size; i++) {
 4bb:	31 d2                	xor    %edx,%edx
 4bd:	eb 0a                	jmp    4c9 <compare_files+0xa9>
 4bf:	90                   	nop
        if (buf1[i] != buf2[i]) {
 4c0:	0f b6 0c 17          	movzbl (%edi,%edx,1),%ecx
 4c4:	38 0c 16             	cmp    %cl,(%esi,%edx,1)
 4c7:	75 0b                	jne    4d4 <compare_files+0xb4>
    for (int i = 0; i < size; i++) {
 4c9:	83 c2 01             	add    $0x1,%edx
 4cc:	39 d3                	cmp    %edx,%ebx
 4ce:	75 f0                	jne    4c0 <compare_files+0xa0>
        close(fd2);
        printf(1, "can't read\n");
        return -1;
      }
      int tmp = compare_buffers(buf1, buf2, n1);
      if (n1 != n2 || tmp == 0) {
 4d0:	39 d8                	cmp    %ebx,%eax
 4d2:	74 9f                	je     473 <compare_files+0x53>
        close(fd1);
 4d4:	83 ec 0c             	sub    $0xc,%esp
 4d7:	ff b5 c4 fe ff ff    	pushl  -0x13c(%ebp)
 4dd:	e8 c8 03 00 00       	call   8aa <close>
        close(fd2);
 4e2:	58                   	pop    %eax
 4e3:	ff b5 c0 fe ff ff    	pushl  -0x140(%ebp)
 4e9:	e8 bc 03 00 00       	call   8aa <close>
        printf(1, "not equal\n");
 4ee:	5a                   	pop    %edx
 4ef:	59                   	pop    %ecx
 4f0:	68 59 0d 00 00       	push   $0xd59
 4f5:	6a 01                	push   $0x1
 4f7:	e8 d4 04 00 00       	call   9d0 <printf>
        return 0;
 4fc:	83 c4 10             	add    $0x10,%esp

    // printf(1, "File1 = File2\n");
    // close(fd1); // DO NOT activate
    // close(fd2); // DO NOT activate
    return 1;
}
 4ff:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return 0;
 502:	31 c0                	xor    %eax,%eax
}
 504:	5b                   	pop    %ebx
 505:	5e                   	pop    %esi
 506:	5f                   	pop    %edi
 507:	5d                   	pop    %ebp
 508:	c3                   	ret    
 509:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      if (n1 != n2 || tmp == 0) {
 510:	85 c0                	test   %eax,%eax
 512:	75 c0                	jne    4d4 <compare_files+0xb4>
    return 1;
 514:	b8 01 00 00 00       	mov    $0x1,%eax
}
 519:	8d 65 f4             	lea    -0xc(%ebp),%esp
 51c:	5b                   	pop    %ebx
 51d:	5e                   	pop    %esi
 51e:	5f                   	pop    %edi
 51f:	5d                   	pop    %ebp
 520:	c3                   	ret    
        printf(1, "error reading files\n");
 521:	83 ec 08             	sub    $0x8,%esp
 524:	68 38 0d 00 00       	push   $0xd38
 529:	6a 01                	push   $0x1
 52b:	e8 a0 04 00 00       	call   9d0 <printf>
        close(fd1);
 530:	5b                   	pop    %ebx
 531:	ff b5 c4 fe ff ff    	pushl  -0x13c(%ebp)
 537:	e8 6e 03 00 00       	call   8aa <close>
        close(fd2);
 53c:	5e                   	pop    %esi
 53d:	ff b5 c0 fe ff ff    	pushl  -0x140(%ebp)
 543:	e8 62 03 00 00       	call   8aa <close>
        printf(1, "can't read\n");
 548:	5f                   	pop    %edi
 549:	58                   	pop    %eax
 54a:	68 4d 0d 00 00       	push   $0xd4d
 54f:	6a 01                	push   $0x1
 551:	e8 7a 04 00 00       	call   9d0 <printf>
        return -1;
 556:	83 c4 10             	add    $0x10,%esp
}
 559:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return -1;
 55c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
 561:	5b                   	pop    %ebx
 562:	5e                   	pop    %esi
 563:	5f                   	pop    %edi
 564:	5d                   	pop    %ebp
 565:	c3                   	ret    
      printf(1, "cannot open %s\n", file1);
 566:	83 ec 04             	sub    $0x4,%esp
 569:	57                   	push   %edi
 56a:	68 28 0d 00 00       	push   $0xd28
 56f:	6a 01                	push   $0x1
 571:	e8 5a 04 00 00       	call   9d0 <printf>
      return -1;
 576:	83 c4 10             	add    $0x10,%esp
 579:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
 57e:	eb 99                	jmp    519 <compare_files+0xf9>
      printf(1, "cannot open %s\n", file2);
 580:	83 ec 04             	sub    $0x4,%esp
 583:	53                   	push   %ebx
 584:	68 28 0d 00 00       	push   $0xd28
 589:	6a 01                	push   $0x1
 58b:	e8 40 04 00 00       	call   9d0 <printf>
      close(fd1);
 590:	58                   	pop    %eax
 591:	ff b5 c4 fe ff ff    	pushl  -0x13c(%ebp)
 597:	e8 0e 03 00 00       	call   8aa <close>
      return -1;
 59c:	83 c4 10             	add    $0x10,%esp
 59f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
 5a4:	e9 70 ff ff ff       	jmp    519 <compare_files+0xf9>
 5a9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

000005b0 <cat>:

void
cat(int fd)
{
 5b0:	55                   	push   %ebp
 5b1:	89 e5                	mov    %esp,%ebp
 5b3:	56                   	push   %esi
 5b4:	53                   	push   %ebx
 5b5:	8b 75 08             	mov    0x8(%ebp),%esi
  int n;

  while((n = read(fd, buf, sizeof(buf))) > 0) {
 5b8:	eb 1d                	jmp    5d7 <cat+0x27>
 5ba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    if (write(1, buf, n) != n) {
 5c0:	83 ec 04             	sub    $0x4,%esp
 5c3:	53                   	push   %ebx
 5c4:	68 40 12 00 00       	push   $0x1240
 5c9:	6a 01                	push   $0x1
 5cb:	e8 d2 02 00 00       	call   8a2 <write>
 5d0:	83 c4 10             	add    $0x10,%esp
 5d3:	39 d8                	cmp    %ebx,%eax
 5d5:	75 26                	jne    5fd <cat+0x4d>
  while((n = read(fd, buf, sizeof(buf))) > 0) {
 5d7:	83 ec 04             	sub    $0x4,%esp
 5da:	68 00 02 00 00       	push   $0x200
 5df:	68 40 12 00 00       	push   $0x1240
 5e4:	56                   	push   %esi
 5e5:	e8 b0 02 00 00       	call   89a <read>
 5ea:	83 c4 10             	add    $0x10,%esp
 5ed:	83 f8 00             	cmp    $0x0,%eax
 5f0:	89 c3                	mov    %eax,%ebx
 5f2:	7f cc                	jg     5c0 <cat+0x10>
      printf(1, "cat: write error\n");
      exit();
    }
  }
  if(n < 0){
 5f4:	75 1b                	jne    611 <cat+0x61>
    printf(1, "cat: read error\n");
    exit();
  }
 5f6:	8d 65 f8             	lea    -0x8(%ebp),%esp
 5f9:	5b                   	pop    %ebx
 5fa:	5e                   	pop    %esi
 5fb:	5d                   	pop    %ebp
 5fc:	c3                   	ret    
      printf(1, "cat: write error\n");
 5fd:	83 ec 08             	sub    $0x8,%esp
 600:	68 64 0d 00 00       	push   $0xd64
 605:	6a 01                	push   $0x1
 607:	e8 c4 03 00 00       	call   9d0 <printf>
      exit();
 60c:	e8 71 02 00 00       	call   882 <exit>
    printf(1, "cat: read error\n");
 611:	50                   	push   %eax
 612:	50                   	push   %eax
 613:	68 76 0d 00 00       	push   $0xd76
 618:	6a 01                	push   $0x1
 61a:	e8 b1 03 00 00       	call   9d0 <printf>
    exit();
 61f:	e8 5e 02 00 00       	call   882 <exit>
 624:	66 90                	xchg   %ax,%ax
 626:	66 90                	xchg   %ax,%ax
 628:	66 90                	xchg   %ax,%ax
 62a:	66 90                	xchg   %ax,%ax
 62c:	66 90                	xchg   %ax,%ax
 62e:	66 90                	xchg   %ax,%ax

00000630 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 630:	55                   	push   %ebp
 631:	89 e5                	mov    %esp,%ebp
 633:	53                   	push   %ebx
 634:	8b 45 08             	mov    0x8(%ebp),%eax
 637:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 63a:	89 c2                	mov    %eax,%edx
 63c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 640:	83 c1 01             	add    $0x1,%ecx
 643:	0f b6 59 ff          	movzbl -0x1(%ecx),%ebx
 647:	83 c2 01             	add    $0x1,%edx
 64a:	84 db                	test   %bl,%bl
 64c:	88 5a ff             	mov    %bl,-0x1(%edx)
 64f:	75 ef                	jne    640 <strcpy+0x10>
    ;
  return os;
}
 651:	5b                   	pop    %ebx
 652:	5d                   	pop    %ebp
 653:	c3                   	ret    
 654:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
 65a:	8d bf 00 00 00 00    	lea    0x0(%edi),%edi

00000660 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 660:	55                   	push   %ebp
 661:	89 e5                	mov    %esp,%ebp
 663:	53                   	push   %ebx
 664:	8b 55 08             	mov    0x8(%ebp),%edx
 667:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
 66a:	0f b6 02             	movzbl (%edx),%eax
 66d:	0f b6 19             	movzbl (%ecx),%ebx
 670:	84 c0                	test   %al,%al
 672:	75 1c                	jne    690 <strcmp+0x30>
 674:	eb 2a                	jmp    6a0 <strcmp+0x40>
 676:	8d 76 00             	lea    0x0(%esi),%esi
 679:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    p++, q++;
 680:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
 683:	0f b6 02             	movzbl (%edx),%eax
    p++, q++;
 686:	83 c1 01             	add    $0x1,%ecx
 689:	0f b6 19             	movzbl (%ecx),%ebx
  while(*p && *p == *q)
 68c:	84 c0                	test   %al,%al
 68e:	74 10                	je     6a0 <strcmp+0x40>
 690:	38 d8                	cmp    %bl,%al
 692:	74 ec                	je     680 <strcmp+0x20>
  return (uchar)*p - (uchar)*q;
 694:	29 d8                	sub    %ebx,%eax
}
 696:	5b                   	pop    %ebx
 697:	5d                   	pop    %ebp
 698:	c3                   	ret    
 699:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 6a0:	31 c0                	xor    %eax,%eax
  return (uchar)*p - (uchar)*q;
 6a2:	29 d8                	sub    %ebx,%eax
}
 6a4:	5b                   	pop    %ebx
 6a5:	5d                   	pop    %ebp
 6a6:	c3                   	ret    
 6a7:	89 f6                	mov    %esi,%esi
 6a9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

000006b0 <strlen>:

uint
strlen(const char *s)
{
 6b0:	55                   	push   %ebp
 6b1:	89 e5                	mov    %esp,%ebp
 6b3:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
 6b6:	80 39 00             	cmpb   $0x0,(%ecx)
 6b9:	74 15                	je     6d0 <strlen+0x20>
 6bb:	31 d2                	xor    %edx,%edx
 6bd:	8d 76 00             	lea    0x0(%esi),%esi
 6c0:	83 c2 01             	add    $0x1,%edx
 6c3:	80 3c 11 00          	cmpb   $0x0,(%ecx,%edx,1)
 6c7:	89 d0                	mov    %edx,%eax
 6c9:	75 f5                	jne    6c0 <strlen+0x10>
    ;
  return n;
}
 6cb:	5d                   	pop    %ebp
 6cc:	c3                   	ret    
 6cd:	8d 76 00             	lea    0x0(%esi),%esi
  for(n = 0; s[n]; n++)
 6d0:	31 c0                	xor    %eax,%eax
}
 6d2:	5d                   	pop    %ebp
 6d3:	c3                   	ret    
 6d4:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
 6da:	8d bf 00 00 00 00    	lea    0x0(%edi),%edi

000006e0 <memset>:

void*
memset(void *dst, int c, uint n)
{
 6e0:	55                   	push   %ebp
 6e1:	89 e5                	mov    %esp,%ebp
 6e3:	57                   	push   %edi
 6e4:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 6e7:	8b 4d 10             	mov    0x10(%ebp),%ecx
 6ea:	8b 45 0c             	mov    0xc(%ebp),%eax
 6ed:	89 d7                	mov    %edx,%edi
 6ef:	fc                   	cld    
 6f0:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 6f2:	89 d0                	mov    %edx,%eax
 6f4:	5f                   	pop    %edi
 6f5:	5d                   	pop    %ebp
 6f6:	c3                   	ret    
 6f7:	89 f6                	mov    %esi,%esi
 6f9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

00000700 <strchr>:

char*
strchr(const char *s, char c)
{
 700:	55                   	push   %ebp
 701:	89 e5                	mov    %esp,%ebp
 703:	53                   	push   %ebx
 704:	8b 45 08             	mov    0x8(%ebp),%eax
 707:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  for(; *s; s++)
 70a:	0f b6 10             	movzbl (%eax),%edx
 70d:	84 d2                	test   %dl,%dl
 70f:	74 1d                	je     72e <strchr+0x2e>
    if(*s == c)
 711:	38 d3                	cmp    %dl,%bl
 713:	89 d9                	mov    %ebx,%ecx
 715:	75 0d                	jne    724 <strchr+0x24>
 717:	eb 17                	jmp    730 <strchr+0x30>
 719:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 720:	38 ca                	cmp    %cl,%dl
 722:	74 0c                	je     730 <strchr+0x30>
  for(; *s; s++)
 724:	83 c0 01             	add    $0x1,%eax
 727:	0f b6 10             	movzbl (%eax),%edx
 72a:	84 d2                	test   %dl,%dl
 72c:	75 f2                	jne    720 <strchr+0x20>
      return (char*)s;
  return 0;
 72e:	31 c0                	xor    %eax,%eax
}
 730:	5b                   	pop    %ebx
 731:	5d                   	pop    %ebp
 732:	c3                   	ret    
 733:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
 739:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

00000740 <gets>:

char*
gets(char *buf, int max)
{
 740:	55                   	push   %ebp
 741:	89 e5                	mov    %esp,%ebp
 743:	57                   	push   %edi
 744:	56                   	push   %esi
 745:	53                   	push   %ebx
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 746:	31 f6                	xor    %esi,%esi
 748:	89 f3                	mov    %esi,%ebx
{
 74a:	83 ec 1c             	sub    $0x1c,%esp
 74d:	8b 7d 08             	mov    0x8(%ebp),%edi
  for(i=0; i+1 < max; ){
 750:	eb 2f                	jmp    781 <gets+0x41>
 752:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    cc = read(0, &c, 1);
 758:	8d 45 e7             	lea    -0x19(%ebp),%eax
 75b:	83 ec 04             	sub    $0x4,%esp
 75e:	6a 01                	push   $0x1
 760:	50                   	push   %eax
 761:	6a 00                	push   $0x0
 763:	e8 32 01 00 00       	call   89a <read>
    if(cc < 1)
 768:	83 c4 10             	add    $0x10,%esp
 76b:	85 c0                	test   %eax,%eax
 76d:	7e 1c                	jle    78b <gets+0x4b>
      break;
    buf[i++] = c;
 76f:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 773:	83 c7 01             	add    $0x1,%edi
 776:	88 47 ff             	mov    %al,-0x1(%edi)
    if(c == '\n' || c == '\r')
 779:	3c 0a                	cmp    $0xa,%al
 77b:	74 23                	je     7a0 <gets+0x60>
 77d:	3c 0d                	cmp    $0xd,%al
 77f:	74 1f                	je     7a0 <gets+0x60>
  for(i=0; i+1 < max; ){
 781:	83 c3 01             	add    $0x1,%ebx
 784:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 787:	89 fe                	mov    %edi,%esi
 789:	7c cd                	jl     758 <gets+0x18>
 78b:	89 f3                	mov    %esi,%ebx
      break;
  }
  buf[i] = '\0';
  return buf;
}
 78d:	8b 45 08             	mov    0x8(%ebp),%eax
  buf[i] = '\0';
 790:	c6 03 00             	movb   $0x0,(%ebx)
}
 793:	8d 65 f4             	lea    -0xc(%ebp),%esp
 796:	5b                   	pop    %ebx
 797:	5e                   	pop    %esi
 798:	5f                   	pop    %edi
 799:	5d                   	pop    %ebp
 79a:	c3                   	ret    
 79b:	90                   	nop
 79c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 7a0:	8b 75 08             	mov    0x8(%ebp),%esi
 7a3:	8b 45 08             	mov    0x8(%ebp),%eax
 7a6:	01 de                	add    %ebx,%esi
 7a8:	89 f3                	mov    %esi,%ebx
  buf[i] = '\0';
 7aa:	c6 03 00             	movb   $0x0,(%ebx)
}
 7ad:	8d 65 f4             	lea    -0xc(%ebp),%esp
 7b0:	5b                   	pop    %ebx
 7b1:	5e                   	pop    %esi
 7b2:	5f                   	pop    %edi
 7b3:	5d                   	pop    %ebp
 7b4:	c3                   	ret    
 7b5:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 7b9:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

000007c0 <stat>:

int
stat(const char *n, struct stat *st)
{
 7c0:	55                   	push   %ebp
 7c1:	89 e5                	mov    %esp,%ebp
 7c3:	56                   	push   %esi
 7c4:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 7c5:	83 ec 08             	sub    $0x8,%esp
 7c8:	6a 00                	push   $0x0
 7ca:	ff 75 08             	pushl  0x8(%ebp)
 7cd:	e8 f0 00 00 00       	call   8c2 <open>
  if(fd < 0)
 7d2:	83 c4 10             	add    $0x10,%esp
 7d5:	85 c0                	test   %eax,%eax
 7d7:	78 27                	js     800 <stat+0x40>
    return -1;
  r = fstat(fd, st);
 7d9:	83 ec 08             	sub    $0x8,%esp
 7dc:	ff 75 0c             	pushl  0xc(%ebp)
 7df:	89 c3                	mov    %eax,%ebx
 7e1:	50                   	push   %eax
 7e2:	e8 f3 00 00 00       	call   8da <fstat>
  close(fd);
 7e7:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
 7ea:	89 c6                	mov    %eax,%esi
  close(fd);
 7ec:	e8 b9 00 00 00       	call   8aa <close>
  return r;
 7f1:	83 c4 10             	add    $0x10,%esp
}
 7f4:	8d 65 f8             	lea    -0x8(%ebp),%esp
 7f7:	89 f0                	mov    %esi,%eax
 7f9:	5b                   	pop    %ebx
 7fa:	5e                   	pop    %esi
 7fb:	5d                   	pop    %ebp
 7fc:	c3                   	ret    
 7fd:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
 800:	be ff ff ff ff       	mov    $0xffffffff,%esi
 805:	eb ed                	jmp    7f4 <stat+0x34>
 807:	89 f6                	mov    %esi,%esi
 809:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi

00000810 <atoi>:

int
atoi(const char *s)
{
 810:	55                   	push   %ebp
 811:	89 e5                	mov    %esp,%ebp
 813:	53                   	push   %ebx
 814:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 817:	0f be 11             	movsbl (%ecx),%edx
 81a:	8d 42 d0             	lea    -0x30(%edx),%eax
 81d:	3c 09                	cmp    $0x9,%al
  n = 0;
 81f:	b8 00 00 00 00       	mov    $0x0,%eax
  while('0' <= *s && *s <= '9')
 824:	77 1f                	ja     845 <atoi+0x35>
 826:	8d 76 00             	lea    0x0(%esi),%esi
 829:	8d bc 27 00 00 00 00 	lea    0x0(%edi,%eiz,1),%edi
    n = n*10 + *s++ - '0';
 830:	8d 04 80             	lea    (%eax,%eax,4),%eax
 833:	83 c1 01             	add    $0x1,%ecx
 836:	8d 44 42 d0          	lea    -0x30(%edx,%eax,2),%eax
  while('0' <= *s && *s <= '9')
 83a:	0f be 11             	movsbl (%ecx),%edx
 83d:	8d 5a d0             	lea    -0x30(%edx),%ebx
 840:	80 fb 09             	cmp    $0x9,%bl
 843:	76 eb                	jbe    830 <atoi+0x20>
  return n;
}
 845:	5b                   	pop    %ebx
 846:	5d                   	pop    %ebp
 847:	c3                   	ret    
 848:	90                   	nop
 849:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

00000850 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 850:	55                   	push   %ebp
 851:	89 e5                	mov    %esp,%ebp
 853:	56                   	push   %esi
 854:	53                   	push   %ebx
 855:	8b 5d 10             	mov    0x10(%ebp),%ebx
 858:	8b 45 08             	mov    0x8(%ebp),%eax
 85b:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 85e:	85 db                	test   %ebx,%ebx
 860:	7e 14                	jle    876 <memmove+0x26>
 862:	31 d2                	xor    %edx,%edx
 864:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    *dst++ = *src++;
 868:	0f b6 0c 16          	movzbl (%esi,%edx,1),%ecx
 86c:	88 0c 10             	mov    %cl,(%eax,%edx,1)
 86f:	83 c2 01             	add    $0x1,%edx
  while(n-- > 0)
 872:	39 d3                	cmp    %edx,%ebx
 874:	75 f2                	jne    868 <memmove+0x18>
  return vdst;
}
 876:	5b                   	pop    %ebx
 877:	5e                   	pop    %esi
 878:	5d                   	pop    %ebp
 879:	c3                   	ret    

0000087a <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 87a:	b8 01 00 00 00       	mov    $0x1,%eax
 87f:	cd 40                	int    $0x40
 881:	c3                   	ret    

00000882 <exit>:
SYSCALL(exit)
 882:	b8 02 00 00 00       	mov    $0x2,%eax
 887:	cd 40                	int    $0x40
 889:	c3                   	ret    

0000088a <wait>:
SYSCALL(wait)
 88a:	b8 03 00 00 00       	mov    $0x3,%eax
 88f:	cd 40                	int    $0x40
 891:	c3                   	ret    

00000892 <pipe>:
SYSCALL(pipe)
 892:	b8 04 00 00 00       	mov    $0x4,%eax
 897:	cd 40                	int    $0x40
 899:	c3                   	ret    

0000089a <read>:
SYSCALL(read)
 89a:	b8 05 00 00 00       	mov    $0x5,%eax
 89f:	cd 40                	int    $0x40
 8a1:	c3                   	ret    

000008a2 <write>:
SYSCALL(write)
 8a2:	b8 10 00 00 00       	mov    $0x10,%eax
 8a7:	cd 40                	int    $0x40
 8a9:	c3                   	ret    

000008aa <close>:
SYSCALL(close)
 8aa:	b8 15 00 00 00       	mov    $0x15,%eax
 8af:	cd 40                	int    $0x40
 8b1:	c3                   	ret    

000008b2 <kill>:
SYSCALL(kill)
 8b2:	b8 06 00 00 00       	mov    $0x6,%eax
 8b7:	cd 40                	int    $0x40
 8b9:	c3                   	ret    

000008ba <exec>:
SYSCALL(exec)
 8ba:	b8 07 00 00 00       	mov    $0x7,%eax
 8bf:	cd 40                	int    $0x40
 8c1:	c3                   	ret    

000008c2 <open>:
SYSCALL(open)
 8c2:	b8 0f 00 00 00       	mov    $0xf,%eax
 8c7:	cd 40                	int    $0x40
 8c9:	c3                   	ret    

000008ca <mknod>:
SYSCALL(mknod)
 8ca:	b8 11 00 00 00       	mov    $0x11,%eax
 8cf:	cd 40                	int    $0x40
 8d1:	c3                   	ret    

000008d2 <unlink>:
SYSCALL(unlink)
 8d2:	b8 12 00 00 00       	mov    $0x12,%eax
 8d7:	cd 40                	int    $0x40
 8d9:	c3                   	ret    

000008da <fstat>:
SYSCALL(fstat)
 8da:	b8 08 00 00 00       	mov    $0x8,%eax
 8df:	cd 40                	int    $0x40
 8e1:	c3                   	ret    

000008e2 <link>:
SYSCALL(link)
 8e2:	b8 13 00 00 00       	mov    $0x13,%eax
 8e7:	cd 40                	int    $0x40
 8e9:	c3                   	ret    

000008ea <mkdir>:
SYSCALL(mkdir)
 8ea:	b8 14 00 00 00       	mov    $0x14,%eax
 8ef:	cd 40                	int    $0x40
 8f1:	c3                   	ret    

000008f2 <chdir>:
SYSCALL(chdir)
 8f2:	b8 09 00 00 00       	mov    $0x9,%eax
 8f7:	cd 40                	int    $0x40
 8f9:	c3                   	ret    

000008fa <dup>:
SYSCALL(dup)
 8fa:	b8 0a 00 00 00       	mov    $0xa,%eax
 8ff:	cd 40                	int    $0x40
 901:	c3                   	ret    

00000902 <getpid>:
SYSCALL(getpid)
 902:	b8 0b 00 00 00       	mov    $0xb,%eax
 907:	cd 40                	int    $0x40
 909:	c3                   	ret    

0000090a <sbrk>:
SYSCALL(sbrk)
 90a:	b8 0c 00 00 00       	mov    $0xc,%eax
 90f:	cd 40                	int    $0x40
 911:	c3                   	ret    

00000912 <sleep>:
SYSCALL(sleep)
 912:	b8 0d 00 00 00       	mov    $0xd,%eax
 917:	cd 40                	int    $0x40
 919:	c3                   	ret    

0000091a <uptime>:
SYSCALL(uptime)
 91a:	b8 0e 00 00 00       	mov    $0xe,%eax
 91f:	cd 40                	int    $0x40
 921:	c3                   	ret    

00000922 <cpcow>:
 922:	b8 16 00 00 00       	mov    $0x16,%eax
 927:	cd 40                	int    $0x40
 929:	c3                   	ret    
 92a:	66 90                	xchg   %ax,%ax
 92c:	66 90                	xchg   %ax,%ax
 92e:	66 90                	xchg   %ax,%ax

00000930 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 930:	55                   	push   %ebp
 931:	89 e5                	mov    %esp,%ebp
 933:	57                   	push   %edi
 934:	56                   	push   %esi
 935:	53                   	push   %ebx
 936:	83 ec 3c             	sub    $0x3c,%esp
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 939:	85 d2                	test   %edx,%edx
{
 93b:	89 45 c0             	mov    %eax,-0x40(%ebp)
    neg = 1;
    x = -xx;
 93e:	89 d0                	mov    %edx,%eax
  if(sgn && xx < 0){
 940:	79 76                	jns    9b8 <printint+0x88>
 942:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
 946:	74 70                	je     9b8 <printint+0x88>
    x = -xx;
 948:	f7 d8                	neg    %eax
    neg = 1;
 94a:	c7 45 c4 01 00 00 00 	movl   $0x1,-0x3c(%ebp)
  } else {
    x = xx;
  }

  i = 0;
 951:	31 f6                	xor    %esi,%esi
 953:	8d 5d d7             	lea    -0x29(%ebp),%ebx
 956:	eb 0a                	jmp    962 <printint+0x32>
 958:	90                   	nop
 959:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  do{
    buf[i++] = digits[x % base];
 960:	89 fe                	mov    %edi,%esi
 962:	31 d2                	xor    %edx,%edx
 964:	8d 7e 01             	lea    0x1(%esi),%edi
 967:	f7 f1                	div    %ecx
 969:	0f b6 92 b0 0e 00 00 	movzbl 0xeb0(%edx),%edx
  }while((x /= base) != 0);
 970:	85 c0                	test   %eax,%eax
    buf[i++] = digits[x % base];
 972:	88 14 3b             	mov    %dl,(%ebx,%edi,1)
  }while((x /= base) != 0);
 975:	75 e9                	jne    960 <printint+0x30>
  if(neg)
 977:	8b 45 c4             	mov    -0x3c(%ebp),%eax
 97a:	85 c0                	test   %eax,%eax
 97c:	74 08                	je     986 <printint+0x56>
    buf[i++] = '-';
 97e:	c6 44 3d d8 2d       	movb   $0x2d,-0x28(%ebp,%edi,1)
 983:	8d 7e 02             	lea    0x2(%esi),%edi
 986:	8d 74 3d d7          	lea    -0x29(%ebp,%edi,1),%esi
 98a:	8b 7d c0             	mov    -0x40(%ebp),%edi
 98d:	8d 76 00             	lea    0x0(%esi),%esi
 990:	0f b6 06             	movzbl (%esi),%eax
  write(fd, &c, 1);
 993:	83 ec 04             	sub    $0x4,%esp
 996:	83 ee 01             	sub    $0x1,%esi
 999:	6a 01                	push   $0x1
 99b:	53                   	push   %ebx
 99c:	57                   	push   %edi
 99d:	88 45 d7             	mov    %al,-0x29(%ebp)
 9a0:	e8 fd fe ff ff       	call   8a2 <write>

  while(--i >= 0)
 9a5:	83 c4 10             	add    $0x10,%esp
 9a8:	39 de                	cmp    %ebx,%esi
 9aa:	75 e4                	jne    990 <printint+0x60>
    putc(fd, buf[i]);
}
 9ac:	8d 65 f4             	lea    -0xc(%ebp),%esp
 9af:	5b                   	pop    %ebx
 9b0:	5e                   	pop    %esi
 9b1:	5f                   	pop    %edi
 9b2:	5d                   	pop    %ebp
 9b3:	c3                   	ret    
 9b4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  neg = 0;
 9b8:	c7 45 c4 00 00 00 00 	movl   $0x0,-0x3c(%ebp)
 9bf:	eb 90                	jmp    951 <printint+0x21>
 9c1:	eb 0d                	jmp    9d0 <printf>
 9c3:	90                   	nop
 9c4:	90                   	nop
 9c5:	90                   	nop
 9c6:	90                   	nop
 9c7:	90                   	nop
 9c8:	90                   	nop
 9c9:	90                   	nop
 9ca:	90                   	nop
 9cb:	90                   	nop
 9cc:	90                   	nop
 9cd:	90                   	nop
 9ce:	90                   	nop
 9cf:	90                   	nop

000009d0 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 9d0:	55                   	push   %ebp
 9d1:	89 e5                	mov    %esp,%ebp
 9d3:	57                   	push   %edi
 9d4:	56                   	push   %esi
 9d5:	53                   	push   %ebx
 9d6:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 9d9:	8b 75 0c             	mov    0xc(%ebp),%esi
 9dc:	0f b6 1e             	movzbl (%esi),%ebx
 9df:	84 db                	test   %bl,%bl
 9e1:	0f 84 b3 00 00 00    	je     a9a <printf+0xca>
  ap = (uint*)(void*)&fmt + 1;
 9e7:	8d 45 10             	lea    0x10(%ebp),%eax
 9ea:	83 c6 01             	add    $0x1,%esi
  state = 0;
 9ed:	31 ff                	xor    %edi,%edi
  ap = (uint*)(void*)&fmt + 1;
 9ef:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 9f2:	eb 2f                	jmp    a23 <printf+0x53>
 9f4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
 9f8:	83 f8 25             	cmp    $0x25,%eax
 9fb:	0f 84 a7 00 00 00    	je     aa8 <printf+0xd8>
  write(fd, &c, 1);
 a01:	8d 45 e2             	lea    -0x1e(%ebp),%eax
 a04:	83 ec 04             	sub    $0x4,%esp
 a07:	88 5d e2             	mov    %bl,-0x1e(%ebp)
 a0a:	6a 01                	push   $0x1
 a0c:	50                   	push   %eax
 a0d:	ff 75 08             	pushl  0x8(%ebp)
 a10:	e8 8d fe ff ff       	call   8a2 <write>
 a15:	83 c4 10             	add    $0x10,%esp
 a18:	83 c6 01             	add    $0x1,%esi
  for(i = 0; fmt[i]; i++){
 a1b:	0f b6 5e ff          	movzbl -0x1(%esi),%ebx
 a1f:	84 db                	test   %bl,%bl
 a21:	74 77                	je     a9a <printf+0xca>
    if(state == 0){
 a23:	85 ff                	test   %edi,%edi
    c = fmt[i] & 0xff;
 a25:	0f be cb             	movsbl %bl,%ecx
 a28:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
 a2b:	74 cb                	je     9f8 <printf+0x28>
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
 a2d:	83 ff 25             	cmp    $0x25,%edi
 a30:	75 e6                	jne    a18 <printf+0x48>
      if(c == 'd'){
 a32:	83 f8 64             	cmp    $0x64,%eax
 a35:	0f 84 05 01 00 00    	je     b40 <printf+0x170>
        printint(fd, *ap, 10, 1);
        ap++;
      } else if(c == 'x' || c == 'p'){
 a3b:	81 e1 f7 00 00 00    	and    $0xf7,%ecx
 a41:	83 f9 70             	cmp    $0x70,%ecx
 a44:	74 72                	je     ab8 <printf+0xe8>
        printint(fd, *ap, 16, 0);
        ap++;
      } else if(c == 's'){
 a46:	83 f8 73             	cmp    $0x73,%eax
 a49:	0f 84 99 00 00 00    	je     ae8 <printf+0x118>
          s = "(null)";
        while(*s != 0){
          putc(fd, *s);
          s++;
        }
      } else if(c == 'c'){
 a4f:	83 f8 63             	cmp    $0x63,%eax
 a52:	0f 84 08 01 00 00    	je     b60 <printf+0x190>
        putc(fd, *ap);
        ap++;
      } else if(c == '%'){
 a58:	83 f8 25             	cmp    $0x25,%eax
 a5b:	0f 84 ef 00 00 00    	je     b50 <printf+0x180>
  write(fd, &c, 1);
 a61:	8d 45 e7             	lea    -0x19(%ebp),%eax
 a64:	83 ec 04             	sub    $0x4,%esp
 a67:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 a6b:	6a 01                	push   $0x1
 a6d:	50                   	push   %eax
 a6e:	ff 75 08             	pushl  0x8(%ebp)
 a71:	e8 2c fe ff ff       	call   8a2 <write>
 a76:	83 c4 0c             	add    $0xc,%esp
 a79:	8d 45 e6             	lea    -0x1a(%ebp),%eax
 a7c:	88 5d e6             	mov    %bl,-0x1a(%ebp)
 a7f:	6a 01                	push   $0x1
 a81:	50                   	push   %eax
 a82:	ff 75 08             	pushl  0x8(%ebp)
 a85:	83 c6 01             	add    $0x1,%esi
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 a88:	31 ff                	xor    %edi,%edi
  write(fd, &c, 1);
 a8a:	e8 13 fe ff ff       	call   8a2 <write>
  for(i = 0; fmt[i]; i++){
 a8f:	0f b6 5e ff          	movzbl -0x1(%esi),%ebx
  write(fd, &c, 1);
 a93:	83 c4 10             	add    $0x10,%esp
  for(i = 0; fmt[i]; i++){
 a96:	84 db                	test   %bl,%bl
 a98:	75 89                	jne    a23 <printf+0x53>
    }
  }
}
 a9a:	8d 65 f4             	lea    -0xc(%ebp),%esp
 a9d:	5b                   	pop    %ebx
 a9e:	5e                   	pop    %esi
 a9f:	5f                   	pop    %edi
 aa0:	5d                   	pop    %ebp
 aa1:	c3                   	ret    
 aa2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
        state = '%';
 aa8:	bf 25 00 00 00       	mov    $0x25,%edi
 aad:	e9 66 ff ff ff       	jmp    a18 <printf+0x48>
 ab2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
        printint(fd, *ap, 16, 0);
 ab8:	83 ec 0c             	sub    $0xc,%esp
 abb:	b9 10 00 00 00       	mov    $0x10,%ecx
 ac0:	6a 00                	push   $0x0
 ac2:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 ac5:	8b 45 08             	mov    0x8(%ebp),%eax
 ac8:	8b 17                	mov    (%edi),%edx
 aca:	e8 61 fe ff ff       	call   930 <printint>
        ap++;
 acf:	89 f8                	mov    %edi,%eax
 ad1:	83 c4 10             	add    $0x10,%esp
      state = 0;
 ad4:	31 ff                	xor    %edi,%edi
        ap++;
 ad6:	83 c0 04             	add    $0x4,%eax
 ad9:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 adc:	e9 37 ff ff ff       	jmp    a18 <printf+0x48>
 ae1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        s = (char*)*ap;
 ae8:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 aeb:	8b 08                	mov    (%eax),%ecx
        ap++;
 aed:	83 c0 04             	add    $0x4,%eax
 af0:	89 45 d4             	mov    %eax,-0x2c(%ebp)
        if(s == 0)
 af3:	85 c9                	test   %ecx,%ecx
 af5:	0f 84 8e 00 00 00    	je     b89 <printf+0x1b9>
        while(*s != 0){
 afb:	0f b6 01             	movzbl (%ecx),%eax
      state = 0;
 afe:	31 ff                	xor    %edi,%edi
        s = (char*)*ap;
 b00:	89 cb                	mov    %ecx,%ebx
        while(*s != 0){
 b02:	84 c0                	test   %al,%al
 b04:	0f 84 0e ff ff ff    	je     a18 <printf+0x48>
 b0a:	89 75 d0             	mov    %esi,-0x30(%ebp)
 b0d:	89 de                	mov    %ebx,%esi
 b0f:	8b 5d 08             	mov    0x8(%ebp),%ebx
 b12:	8d 7d e3             	lea    -0x1d(%ebp),%edi
 b15:	8d 76 00             	lea    0x0(%esi),%esi
  write(fd, &c, 1);
 b18:	83 ec 04             	sub    $0x4,%esp
          s++;
 b1b:	83 c6 01             	add    $0x1,%esi
 b1e:	88 45 e3             	mov    %al,-0x1d(%ebp)
  write(fd, &c, 1);
 b21:	6a 01                	push   $0x1
 b23:	57                   	push   %edi
 b24:	53                   	push   %ebx
 b25:	e8 78 fd ff ff       	call   8a2 <write>
        while(*s != 0){
 b2a:	0f b6 06             	movzbl (%esi),%eax
 b2d:	83 c4 10             	add    $0x10,%esp
 b30:	84 c0                	test   %al,%al
 b32:	75 e4                	jne    b18 <printf+0x148>
 b34:	8b 75 d0             	mov    -0x30(%ebp),%esi
      state = 0;
 b37:	31 ff                	xor    %edi,%edi
 b39:	e9 da fe ff ff       	jmp    a18 <printf+0x48>
 b3e:	66 90                	xchg   %ax,%ax
        printint(fd, *ap, 10, 1);
 b40:	83 ec 0c             	sub    $0xc,%esp
 b43:	b9 0a 00 00 00       	mov    $0xa,%ecx
 b48:	6a 01                	push   $0x1
 b4a:	e9 73 ff ff ff       	jmp    ac2 <printf+0xf2>
 b4f:	90                   	nop
  write(fd, &c, 1);
 b50:	83 ec 04             	sub    $0x4,%esp
 b53:	88 5d e5             	mov    %bl,-0x1b(%ebp)
 b56:	8d 45 e5             	lea    -0x1b(%ebp),%eax
 b59:	6a 01                	push   $0x1
 b5b:	e9 21 ff ff ff       	jmp    a81 <printf+0xb1>
        putc(fd, *ap);
 b60:	8b 7d d4             	mov    -0x2c(%ebp),%edi
  write(fd, &c, 1);
 b63:	83 ec 04             	sub    $0x4,%esp
        putc(fd, *ap);
 b66:	8b 07                	mov    (%edi),%eax
  write(fd, &c, 1);
 b68:	6a 01                	push   $0x1
        ap++;
 b6a:	83 c7 04             	add    $0x4,%edi
        putc(fd, *ap);
 b6d:	88 45 e4             	mov    %al,-0x1c(%ebp)
  write(fd, &c, 1);
 b70:	8d 45 e4             	lea    -0x1c(%ebp),%eax
 b73:	50                   	push   %eax
 b74:	ff 75 08             	pushl  0x8(%ebp)
 b77:	e8 26 fd ff ff       	call   8a2 <write>
        ap++;
 b7c:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 b7f:	83 c4 10             	add    $0x10,%esp
      state = 0;
 b82:	31 ff                	xor    %edi,%edi
 b84:	e9 8f fe ff ff       	jmp    a18 <printf+0x48>
          s = "(null)";
 b89:	bb a8 0e 00 00       	mov    $0xea8,%ebx
        while(*s != 0){
 b8e:	b8 28 00 00 00       	mov    $0x28,%eax
 b93:	e9 72 ff ff ff       	jmp    b0a <printf+0x13a>
 b98:	66 90                	xchg   %ax,%ax
 b9a:	66 90                	xchg   %ax,%ax
 b9c:	66 90                	xchg   %ax,%ax
 b9e:	66 90                	xchg   %ax,%ax

00000ba0 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 ba0:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 ba1:	a1 20 12 00 00       	mov    0x1220,%eax
{
 ba6:	89 e5                	mov    %esp,%ebp
 ba8:	57                   	push   %edi
 ba9:	56                   	push   %esi
 baa:	53                   	push   %ebx
 bab:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
 bae:	8d 4b f8             	lea    -0x8(%ebx),%ecx
 bb1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 bb8:	39 c8                	cmp    %ecx,%eax
 bba:	8b 10                	mov    (%eax),%edx
 bbc:	73 32                	jae    bf0 <free+0x50>
 bbe:	39 d1                	cmp    %edx,%ecx
 bc0:	72 04                	jb     bc6 <free+0x26>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 bc2:	39 d0                	cmp    %edx,%eax
 bc4:	72 32                	jb     bf8 <free+0x58>
      break;
  if(bp + bp->s.size == p->s.ptr){
 bc6:	8b 73 fc             	mov    -0x4(%ebx),%esi
 bc9:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 bcc:	39 fa                	cmp    %edi,%edx
 bce:	74 30                	je     c00 <free+0x60>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
  } else
    bp->s.ptr = p->s.ptr;
 bd0:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 bd3:	8b 50 04             	mov    0x4(%eax),%edx
 bd6:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 bd9:	39 f1                	cmp    %esi,%ecx
 bdb:	74 3a                	je     c17 <free+0x77>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
  } else
    p->s.ptr = bp;
 bdd:	89 08                	mov    %ecx,(%eax)
  freep = p;
 bdf:	a3 20 12 00 00       	mov    %eax,0x1220
}
 be4:	5b                   	pop    %ebx
 be5:	5e                   	pop    %esi
 be6:	5f                   	pop    %edi
 be7:	5d                   	pop    %ebp
 be8:	c3                   	ret    
 be9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 bf0:	39 d0                	cmp    %edx,%eax
 bf2:	72 04                	jb     bf8 <free+0x58>
 bf4:	39 d1                	cmp    %edx,%ecx
 bf6:	72 ce                	jb     bc6 <free+0x26>
{
 bf8:	89 d0                	mov    %edx,%eax
 bfa:	eb bc                	jmp    bb8 <free+0x18>
 bfc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    bp->s.size += p->s.ptr->s.size;
 c00:	03 72 04             	add    0x4(%edx),%esi
 c03:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 c06:	8b 10                	mov    (%eax),%edx
 c08:	8b 12                	mov    (%edx),%edx
 c0a:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 c0d:	8b 50 04             	mov    0x4(%eax),%edx
 c10:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 c13:	39 f1                	cmp    %esi,%ecx
 c15:	75 c6                	jne    bdd <free+0x3d>
    p->s.size += bp->s.size;
 c17:	03 53 fc             	add    -0x4(%ebx),%edx
  freep = p;
 c1a:	a3 20 12 00 00       	mov    %eax,0x1220
    p->s.size += bp->s.size;
 c1f:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 c22:	8b 53 f8             	mov    -0x8(%ebx),%edx
 c25:	89 10                	mov    %edx,(%eax)
}
 c27:	5b                   	pop    %ebx
 c28:	5e                   	pop    %esi
 c29:	5f                   	pop    %edi
 c2a:	5d                   	pop    %ebp
 c2b:	c3                   	ret    
 c2c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000c30 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 c30:	55                   	push   %ebp
 c31:	89 e5                	mov    %esp,%ebp
 c33:	57                   	push   %edi
 c34:	56                   	push   %esi
 c35:	53                   	push   %ebx
 c36:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 c39:	8b 45 08             	mov    0x8(%ebp),%eax
  if((prevp = freep) == 0){
 c3c:	8b 15 20 12 00 00    	mov    0x1220,%edx
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 c42:	8d 78 07             	lea    0x7(%eax),%edi
 c45:	c1 ef 03             	shr    $0x3,%edi
 c48:	83 c7 01             	add    $0x1,%edi
  if((prevp = freep) == 0){
 c4b:	85 d2                	test   %edx,%edx
 c4d:	0f 84 9d 00 00 00    	je     cf0 <malloc+0xc0>
 c53:	8b 02                	mov    (%edx),%eax
 c55:	8b 48 04             	mov    0x4(%eax),%ecx
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    if(p->s.size >= nunits){
 c58:	39 cf                	cmp    %ecx,%edi
 c5a:	76 6c                	jbe    cc8 <malloc+0x98>
 c5c:	81 ff 00 10 00 00    	cmp    $0x1000,%edi
 c62:	bb 00 10 00 00       	mov    $0x1000,%ebx
 c67:	0f 43 df             	cmovae %edi,%ebx
  p = sbrk(nu * sizeof(Header));
 c6a:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 c71:	eb 0e                	jmp    c81 <malloc+0x51>
 c73:	90                   	nop
 c74:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 c78:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 c7a:	8b 48 04             	mov    0x4(%eax),%ecx
 c7d:	39 f9                	cmp    %edi,%ecx
 c7f:	73 47                	jae    cc8 <malloc+0x98>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 c81:	39 05 20 12 00 00    	cmp    %eax,0x1220
 c87:	89 c2                	mov    %eax,%edx
 c89:	75 ed                	jne    c78 <malloc+0x48>
  p = sbrk(nu * sizeof(Header));
 c8b:	83 ec 0c             	sub    $0xc,%esp
 c8e:	56                   	push   %esi
 c8f:	e8 76 fc ff ff       	call   90a <sbrk>
  if(p == (char*)-1)
 c94:	83 c4 10             	add    $0x10,%esp
 c97:	83 f8 ff             	cmp    $0xffffffff,%eax
 c9a:	74 1c                	je     cb8 <malloc+0x88>
  hp->s.size = nu;
 c9c:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
 c9f:	83 ec 0c             	sub    $0xc,%esp
 ca2:	83 c0 08             	add    $0x8,%eax
 ca5:	50                   	push   %eax
 ca6:	e8 f5 fe ff ff       	call   ba0 <free>
  return freep;
 cab:	8b 15 20 12 00 00    	mov    0x1220,%edx
      if((p = morecore(nunits)) == 0)
 cb1:	83 c4 10             	add    $0x10,%esp
 cb4:	85 d2                	test   %edx,%edx
 cb6:	75 c0                	jne    c78 <malloc+0x48>
        return 0;
  }
}
 cb8:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return 0;
 cbb:	31 c0                	xor    %eax,%eax
}
 cbd:	5b                   	pop    %ebx
 cbe:	5e                   	pop    %esi
 cbf:	5f                   	pop    %edi
 cc0:	5d                   	pop    %ebp
 cc1:	c3                   	ret    
 cc2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(p->s.size == nunits)
 cc8:	39 cf                	cmp    %ecx,%edi
 cca:	74 54                	je     d20 <malloc+0xf0>
        p->s.size -= nunits;
 ccc:	29 f9                	sub    %edi,%ecx
 cce:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 cd1:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 cd4:	89 78 04             	mov    %edi,0x4(%eax)
      freep = prevp;
 cd7:	89 15 20 12 00 00    	mov    %edx,0x1220
}
 cdd:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return (void*)(p + 1);
 ce0:	83 c0 08             	add    $0x8,%eax
}
 ce3:	5b                   	pop    %ebx
 ce4:	5e                   	pop    %esi
 ce5:	5f                   	pop    %edi
 ce6:	5d                   	pop    %ebp
 ce7:	c3                   	ret    
 ce8:	90                   	nop
 ce9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    base.s.ptr = freep = prevp = &base;
 cf0:	c7 05 20 12 00 00 24 	movl   $0x1224,0x1220
 cf7:	12 00 00 
 cfa:	c7 05 24 12 00 00 24 	movl   $0x1224,0x1224
 d01:	12 00 00 
    base.s.size = 0;
 d04:	b8 24 12 00 00       	mov    $0x1224,%eax
 d09:	c7 05 28 12 00 00 00 	movl   $0x0,0x1228
 d10:	00 00 00 
 d13:	e9 44 ff ff ff       	jmp    c5c <malloc+0x2c>
 d18:	90                   	nop
 d19:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        prevp->s.ptr = p->s.ptr;
 d20:	8b 08                	mov    (%eax),%ecx
 d22:	89 0a                	mov    %ecx,(%edx)
 d24:	eb b1                	jmp    cd7 <malloc+0xa7>
